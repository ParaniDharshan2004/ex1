import dayjs from 'dayjs';
import { getDb } from './db';

function toSubscriptionRow(sub) {
  const db = getDb();
  const customer = db.customers.find((c) => c.id === sub.customerId);
  const address = db.addresses.find((a) => a.id === sub.addressId);
  const periods = db.periods
    .filter((p) => p.subscriptionId === sub.id)
    .sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
  const currentPeriod = periods[0] || null;
  const visits = currentPeriod ? db.visits.filter((v) => v.periodId === currentPeriod.id) : [];
  const nextVisit = visits
    .filter((v) => v.status === 'Scheduled')
    .sort((a, b) => new Date(a.date) - new Date(b.date))[0];

  const renewalStatus = currentPeriod
    ? dayjs(currentPeriod.endDate).diff(dayjs(), 'day') <= 7
      ? 'Renewal Due Soon'
      : dayjs(currentPeriod.endDate).isBefore(dayjs())
      ? 'Renewal Overdue'
      : 'On Track'
    : 'No Period';

  return { ...sub, customer, address, periods, currentPeriod, nextVisit, renewalStatus };
}

export async function listSubscriptions({ search = '', status = 'All' } = {}) {
  const response = await fetch('/api/subscriptions');
  if (!response.ok) throw new Error('Could not fetch subscriptions from the database');
  const [subscriptions, customers, bookings, visits] = await Promise.all([
    response.json(),
    fetch('/api/customers').then((res) => res.json()),
    fetch('/api/bookings').then((res) => res.json()),
    fetch('/api/visits').then((res) => res.json()),
  ]);
  const idOf = (value) => String(value && typeof value === 'object' ? value._id : value || '');
  let rows = subscriptions.map((subscription) => {
    const customer = customers.find((item) => idOf(item._id) === idOf(subscription.customerId));
    const booking = bookings.find((item) => idOf(item._id) === idOf(subscription.bookingId));
    const subscriptionVisits = visits.filter((item) => idOf(item.subscriptionId) === idOf(subscription._id));
    const nextVisit = subscriptionVisits
      .filter((item) => !item.isCompleted && !item.isCancelled)
      .sort((a, b) => new Date(a.scheduledDate) - new Date(b.scheduledDate))[0];
    const totalVisits = subscription.totalVisits || 0;
    const completedVisits = subscription.completedVisits || 0;
    return {
      ...subscription,
      id: subscription._id,
      subscriptionNumber: subscription.subscriptionId,
      customer: customer ? { ...customer, id: customer._id, customerNumber: customer.customerId || customer._id, mobile: customer.phoneNumber } : null,
      address: customer ? { addressLine: customer.address, area: customer.area, label: 'Service address' } : null,
      offeringId: booking?.offeringId,
      status: subscription.subscriptionStatus,
      currentPeriod: { totalServices: totalVisits, completedServices: completedVisits, endDate: null, planId: booking?.planId },
      nextVisit: nextVisit ? { ...nextVisit, date: nextVisit.scheduledDate } : null,
      renewalStatus: 'On Track',
      createdOn: subscription.createdAt,
    };
  });

  if (status !== 'All') rows = rows.filter((s) => s.status === status);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (s) =>
        s.subscriptionNumber.toLowerCase().includes(q) ||
        s.customer?.name.toLowerCase().includes(q) ||
        s.customer?.customerNumber.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getSubscription(subscriptionNumber) {
  const response = await fetch(`/api/subscriptions/${encodeURIComponent(subscriptionNumber)}`);
  let subscription;

  if (response.status === 404) {
    // Detail routes may only query MongoDB `_id`, while UI links use the
    // public subscriptionId (for example: SUB-BKG-07273886).
    const listResponse = await fetch('/api/subscriptions');
    if (!listResponse.ok) throw new Error('Could not fetch subscription details from the database');

    const subscriptions = await listResponse.json();
    subscription = subscriptions.find(
      (item) => item.subscriptionId === subscriptionNumber || item._id === subscriptionNumber
    );
    if (!subscription) return null;
  }
  if (response.status !== 404 && !response.ok) {
    throw new Error('Could not fetch subscription details from the database');
  }
  if (!subscription) subscription = await response.json();

  const [customersResponse, bookingsResponse, visitsResponse] = await Promise.all([
    fetch('/api/customers'),
    fetch('/api/bookings'),
    fetch('/api/visits'),
  ]);
  const [customers, bookings, visits] = await Promise.all([
    customersResponse.ok ? customersResponse.json() : [],
    bookingsResponse.ok ? bookingsResponse.json() : [],
    visitsResponse.ok ? visitsResponse.json() : [],
  ]);

  const idOf = (value) => String(value && typeof value === 'object' ? value._id : value || '');
  const customer = subscription.customerId && typeof subscription.customerId === 'object'
    ? subscription.customerId
    : customers.find((item) => idOf(item._id) === idOf(subscription.customerId));
  const booking = subscription.bookingId && typeof subscription.bookingId === 'object'
    ? subscription.bookingId
    : bookings.find(
        (item) => idOf(item._id) === idOf(subscription.bookingId) || item.bookingId === subscription.bookingId
      );
  const subscriptionVisits = visits.filter(
    (item) =>
      idOf(item.subscriptionId) === idOf(subscription._id) ||
      item.subscriptionId === subscription.subscriptionId
  );
  const periodVisits = subscriptionVisits.map((visit) => ({
    ...visit,
    id: visit._id,
    date: visit.scheduledDate || visit.date,
    status: visit.isCompleted ? 'Completed' : visit.isCancelled ? 'Cancelled' : 'Scheduled',
  }));
  const existingPeriods = Array.isArray(subscription.periods) ? subscription.periods : [];
  const period = existingPeriods[0] || {
    id: `${subscription._id || subscription.subscriptionId}-period`,
    periodNumber: subscription.periodNumber || `PER-${subscription.subscriptionId || subscription._id}`,
    kind: 'Current',
    status: subscription.subscriptionStatus || 'Active',
    startDate: booking?.scheduledDate || subscription.createdAt,
    endDate: subscription.periodEndDate || subscription.periodEnd || subscription.endDate || null,
    planId: booking?.planId,
    frequencyId: booking?.frequencyId || booking?.frequencyCode,
    planName: booking?.planName,
    frequencyName: booking?.frequencyName,
    totalServices: subscription.totalVisits || periodVisits.length,
    completedServices: subscription.completedVisits || periodVisits.filter((visit) => visit.status === 'Completed').length,
    booking: booking ? { ...booking, bookingNumber: booking.bookingId || booking._id } : null,
    visits: periodVisits,
  };

  return {
    ...subscription,
    id: subscription._id || subscription.subscriptionId,
    subscriptionNumber: subscription.subscriptionId || subscription._id,
    status: subscription.subscriptionStatus || subscription.status,
    customer: customer
      ? {
          ...customer,
          id: customer._id,
          customerNumber: customer.customerId || customer.customerNumber || customer._id,
          mobile: customer.phoneNumber,
        }
      : null,
    address: customer
      ? { addressLine: customer.address, area: customer.area, label: 'Service address', city: customer.city, pincode: customer.pincode }
      : null,
    currentPeriod: period,
    periods: existingPeriods.length ? existingPeriods : [period],
    nextVisit: periodVisits
      .filter((visit) => visit.status === 'Scheduled')
      .sort((a, b) => new Date(a.date) - new Date(b.date))[0] || null,
    renewalStatus: subscription.renewalStatus || 'On Track',
  };
}

// Renewal: purchases a new period on the *same* subscription account.
// Prior periods, their visits, and every historical booking/payment/invoice
// are left completely untouched.
