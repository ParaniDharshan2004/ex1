import dayjs from 'dayjs';

export async function getDashboardSummary({ date = dayjs().format('YYYY-MM-DD') } = {}) {
  const response = await fetch(`/api/dashboard?date=${date}`);
  const serverSummary = response.ok ? await response.json() : {};

  const [subscriptionsResponse, customersResponse, visitsResponse, bookingsResponse] = await Promise.all([
    fetch('/api/subscriptions'),
    fetch('/api/customers'),
    fetch('/api/visits'),
    fetch('/api/bookings'),
  ]);

  if (!subscriptionsResponse.ok || !customersResponse.ok || !visitsResponse.ok || !bookingsResponse.ok) {
    if (!response.ok) throw new Error('Could not fetch dashboard values from the database');
    return serverSummary;
  }

  const [subscriptions, customers, visits, bookings] = await Promise.all([
    subscriptionsResponse.json(),
    customersResponse.json(),
    visitsResponse.json(),
    bookingsResponse.json(),
  ]);
  const idOf = (value) => String(value && typeof value === 'object' ? value._id : value || '');
  const customerFor = (value) => customers.find((customer) => idOf(customer._id) === idOf(value));
  const bookingFor = (value) => {
    if (!value) return null;
    if (typeof value === 'object') {
      return bookings.find((booking) => idOf(booking._id) === idOf(value._id));
    }
    return bookings.find((booking) => idOf(booking._id) === idOf(value) || idOf(booking.bookingId) === idOf(value));
  };
  const toMinutes = (timeValue) => {
    if (!timeValue) return null;
    const match = String(timeValue).match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return null;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return null;
    return hours * 60 + minutes;
  };
  const timeFromMinutes = (totalMinutes) => {
    if (totalMinutes === null || Number.isNaN(totalMinutes)) return '';
    const safeMinutes = ((totalMinutes % 1440) + 1440) % 1440;
    const hours = Math.floor(safeMinutes / 60);
    const minutes = safeMinutes % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
  };
  const formatTime12 = (timeValue) => {
    if (!timeValue) return '';
    const match = String(timeValue).match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return timeValue;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    const suffix = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours % 12 || 12;
    return `${displayHours}:${String(minutes).padStart(2, '0')} ${suffix}`;
  };
  const timeFromSlotId = (slotId) => {
    const match = String(slotId || '').match(/-(\d+)$/);
    if (!match) return '';
    const minutes = Number(match[1]);
    if (Number.isNaN(minutes) || minutes < 0 || minutes > 1439) return '';
    return timeFromMinutes(minutes);
  };
  const visitDateOf = (visit) =>
    visit.scheduledDate || visit.visitDate || visit.startDateTime || visit.startDate || visit.date;
  const normalizeDateValue = (value) => {
    if (!value) return null;
    if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString();
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (typeof value === 'object' && value.$date) return String(value.$date);
    return null;
  };
  const resolveRenewalDate = (subscription) => {
    const candidates = [
      subscription.renewalDate,
      subscription.renewalDueDate,
      subscription.nextBillingDate,
      subscription.periodEnd,
      subscription.periodEndDate,
      subscription.endDate,
      subscription.expiresAt,
      subscription.expiryDate,
      subscription.currentPeriod?.endDate,
      subscription.currentPeriod?.date,
      subscription.currentPeriod?.periodEndDate,
      subscription.currentPeriod?.renewalDate,
      Array.isArray(subscription.periods) ? subscription.periods[0]?.endDate : null,
      Array.isArray(subscription.periods) ? subscription.periods[0]?.date : null,
      Array.isArray(subscription.periods) ? subscription.periods[0]?.renewalDate : null,
      subscription.currentPeriod && subscription.currentPeriod.endDate,
    ];

    for (const candidate of candidates) {
      const normalized = normalizeDateValue(candidate);
      if (normalized) return normalized;
    }

    return null;
  };
  const isActive = (subscription) => {
    const status = String(subscription.subscriptionStatus || subscription.status || '').toLowerCase();
    return subscription.isActive === true || ['active', 'confirmed'].includes(status);
  };
  const isCompleted = (visit) =>
    visit.isCompleted === true || String(visit.status || '').toLowerCase() === 'completed';
  const isCancelled = (visit) =>
    visit.isCancelled === true || String(visit.status || '').toLowerCase() === 'cancelled';
  const statusOf = (visit) => (isCompleted(visit) ? 'Completed' : isCancelled(visit) ? 'Cancelled' : 'Scheduled');

  const activeSubscriptionsList = subscriptions
    .filter(isActive)
    .map((subscription) => {
      const customer = customerFor(subscription.customerId);
      return {
        id: subscription._id || subscription.subscriptionId,
        subscriptionNumber: subscription.subscriptionId || subscription._id,
        customerName: customer?.name || 'Unknown customer',
        phoneNumber: customer?.phoneNumber || '—',
        subscriptionType: customer?.subscriptionTypeName || subscription.subscriptionType || 'Cleaning subscription',
        status: subscription.subscriptionStatus || subscription.status || 'Active',
      };
    });

  const todayVisitsList = visits
    .filter((visit) => {
      const visitDate = visitDateOf(visit);
      return visitDate && dayjs(visitDate).format('YYYY-MM-DD') === date;
    })
    .map((visit) => {
      const customer = customerFor(visit.customerId);
      return {
        id: visit._id || visit.visitNumber,
        customerName: customer?.name || 'Unknown customer',
        mobileNumber: customer?.phoneNumber || '—',
        visitDate: visitDateOf(visit),
        noOfService: 1,
        status: statusOf(visit),
      };
    });

  const renewalsList = subscriptions
    .filter(isActive)
    .map((subscription) => {
      const renewalDate = resolveRenewalDate(subscription);
      const customer = customerFor(subscription.customerId);
      return renewalDate
        ? {
            id: subscription._id || subscription.subscriptionId,
            customerName: customer?.name || 'Unknown customer',
            mobileNumber: customer?.phoneNumber || '—',
            renewalDate,
            subscriptionType: customer?.subscriptionTypeName || subscription.subscriptionType || 'Cleaning subscription',
          }
        : null;
    })
    .filter(Boolean);

  const upcomingVisits = visits
    .filter((visit) => !isCancelled(visit))
    .map((visit) => {
      const customer = customerFor(visit.customerId);
      const booking = bookingFor(visit.bookingId) || bookingFor(visit.customerId) || null;
      const slotTime = timeFromSlotId(booking?.slotId || visit.slotId);
      const bookingStartTime = typeof booking?.startDateTime === 'string'
        ? booking.startDateTime.includes('T') && !booking.startDateTime.includes('T00:00')
          ? dayjs(booking.startDateTime).format('HH:mm')
          : ''
        : '';
      const visitStartTime = typeof visit.startDateTime === 'string'
        ? visit.startDateTime.includes('T') && !visit.startDateTime.includes('T00:00')
          ? dayjs(visit.startDateTime).format('HH:mm')
          : ''
        : '';
      const startTime = slotTime || bookingStartTime || visitStartTime;
      const durationMinutes = Number(booking?.durationMinutes || booking?.duration || visit.durationMinutes || visit.duration || 60);
      const startMinutes = toMinutes(startTime);
      const endTime = startMinutes !== null ? timeFromMinutes(startMinutes + durationMinutes) : '';

      return {
        ...visit,
        id: visit._id || visit.visitNumber,
        date: visitDateOf(visit),
        status: statusOf(visit),
        customer: customer ? { ...customer, mobile: customer.phoneNumber } : null,
        serviceStartTime: formatTime12(startTime),
        serviceEndTime: formatTime12(endTime),
      };
    });

  return {
    ...serverSummary,
    kpis: {
      ...(serverSummary.kpis || {}),
      todayVisits: todayVisitsList.length,
      activeSubscriptions: activeSubscriptionsList.length,
      renewalsDueSoon: renewalsList.length,
      completedToday: todayVisitsList.filter((visit) => visit.status === 'Completed').length,
      pendingToday: todayVisitsList.filter((visit) => visit.status === 'Scheduled').length,
    },
    todayVisitsList,
    activeSubscriptionsList,
    renewalsList,
    upcomingVisits,
  };
}
