import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit } from './db';
import { generateId } from '../utils/idGenerator';
import { delay } from './masters';

function toCustomerRow(customer) {
  const db = getDb();
  const addresses = db.addresses.filter((a) => a.customerId === customer.id);
  const activeAddresses = addresses.filter((a) => a.status === 'Active');
  const bookings = db.bookings.filter((b) => b.customerId === customer.id);
  const subscriptions = db.subscriptions.filter((s) => s.customerId === customer.id);
  const activeSubscriptions = subscriptions.filter((s) => s.status === 'Active');
  const payments = db.payments.filter((p) => p.customerId === customer.id && p.status !== 'Reversed');
  const lifetimeCollected = payments.reduce((sum, p) => sum + p.amount, 0);

  const upcomingVisits = db.visits
    .filter((v) => subscriptions.some((s) => s.id === v.subscriptionId) && v.status === 'Scheduled')
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  return {
    ...customer,
    defaultAddress: addresses.find((a) => a.isDefault) || addresses[0] || null,
    addressCount: activeAddresses.length,
    activeSubscriptionCount: activeSubscriptions.length,
    nextVisit: upcomingVisits[0] || null,
    lifetimeCollected,
  };
}

export async function listCustomers({ search = '', status = 'All' } = {}) {
  const response = await fetch('/api/customers');
  if (!response.ok) {
    throw new Error('Could not fetch customers from the database');
  }

  const [customers, subscriptions, bookings, frequencies, subscriptionTypes] = await Promise.all([
    response.json(),
    fetch('/api/subscriptions').then((res) => (res.ok ? res.json() : [])),
    fetch('/api/bookings').then((res) => (res.ok ? res.json() : [])),
    fetch('/api/service-frequencies').then((res) => (res.ok ? res.json() : [])),
    fetch('/api/subscription-types').then((res) => (res.ok ? res.json() : [])),
  ]);

  const idOf = (value) => String(value && typeof value === 'object' ? value._id || value.id || value._id || '' : value || '');
  const frequencyNameById = Object.fromEntries(
    frequencies.flatMap((item) => {
      const entries = [
        [idOf(item._id), item.frequencyName || item.name || ''],
        [idOf(item.id), item.frequencyName || item.name || ''],
      ];
      return entries.filter(([key]) => key && key !== '');
    })
  );
  const planNameById = Object.fromEntries(
    subscriptionTypes.flatMap((item) => {
      const entries = [
        [idOf(item._id), item.subscriptionName || item.name || ''],
        [idOf(item.id), item.subscriptionName || item.name || ''],
      ];
      return entries.filter(([key]) => key && key !== '');
    })
  );
  const resolveFrequencyName = (value) => {
    if (!value) return '';
    if (typeof value === 'object' && (value.frequencyName || value.name)) return value.frequencyName || value.name;
    return frequencyNameById[idOf(value)] || value;
  };
  const resolvePlanName = (value) => {
    if (!value) return '';
    if (typeof value === 'object' && (value.subscriptionName || value.name)) return value.subscriptionName || value.name;
    return planNameById[idOf(value)] || value;
  };

  let rows = customers.map((customer) => {
    const byCustomer = (record) => idOf(record.customerId) === idOf(customer._id) || idOf(record.customerId) === idOf(customer.customerId);
    const customerSubscriptions = subscriptions.filter(byCustomer);
    const latestSubscription = [...customerSubscriptions].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))[0];
    const latestBooking = latestSubscription
      ? bookings.find((booking) => idOf(booking._id) === idOf(latestSubscription.bookingId) || idOf(booking.bookingId) === idOf(latestSubscription.bookingId))
      : bookings.filter(byCustomer).sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))[0];

    const serviceFrequencyName =
      customer.serviceFrequencyName ||
      customer.frequencyName ||
      resolveFrequencyName(customer.serviceFrequencyId || customer.frequencyId || customer.frequency) ||
      resolveFrequencyName(latestBooking?.frequencyId || latestBooking?.serviceFrequencyId || latestBooking?.frequency || latestBooking?.frequencyCode) ||
      resolveFrequencyName(latestSubscription?.frequencyId || latestSubscription?.serviceFrequencyId || latestSubscription?.frequency || latestSubscription?.frequencyCode) ||
      latestBooking?.frequencyName ||
      latestSubscription?.frequencyName ||
      '';

    const subscriptionTypeName =
      customer.subscriptionTypeName ||
      customer.planName ||
      resolvePlanName(customer.subscriptionTypeId || customer.planId || customer.plan) ||
      resolvePlanName(latestBooking?.planId || latestBooking?.subscriptionTypeId || latestBooking?.plan || latestBooking?.subscriptionType) ||
      resolvePlanName(latestSubscription?.planId || latestSubscription?.subscriptionTypeId || latestSubscription?.plan || latestSubscription?.subscriptionType) ||
      latestBooking?.planName ||
      latestSubscription?.planName ||
      latestSubscription?.subscriptionTypeName ||
      '';

    return {
      id: customer._id,
      customerNumber: customer.customerId || customer.customerNumber || customer._id,
      name: customer.name,
      mobile: customer.phoneNumber,
      email: customer.email || '',
      status: customer.isActive ? 'Active' : 'Inactive',
      defaultAddress: customer.address
        ? { addressLine: customer.address, area: customer.area || null }
        : null,
      defaultArea: customer.defaultArea || customer.area || '',
      serviceFrequencyName,
      subscriptionTypeName,
      addressCount: customer.addressCount ?? (customer.address ? 1 : 0),
      activeSubscriptionCount: customer.activeSubscriptionCount ?? 0,
      nextVisit: customer.nextVisit
        ? { ...customer.nextVisit, date: customer.nextVisit.scheduledDate }
        : null,
      lifetimeCollected: 0,
      createdOn: customer.createdAt,
    };
  });

  if (status !== 'All') {
    rows = rows.filter((c) => c.status === status);
  }
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (c) =>
        c.customerNumber.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.mobile.includes(q) ||
        (c.email || '').toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getCustomerByNumber(customerNumber) {
  await delay(150);
  const db = getDb();
  const customer = db.customers.find((c) => c.customerNumber === customerNumber);
  return customer ? toCustomerRow(customer) : null;
}

export async function listAddressesForCustomer(customerId) {
  const response = await fetch(`/api/customers/${customerId}`);
  if (!response.ok) throw new Error('Could not fetch customer addresses');
  const customer = await response.json();
  if (!customer.address) return [];
  return [{
    id: customer._id,
    addressNumber: customer._id,
    customerId: customer._id,
    label: 'Primary address',
    addressLine: customer.address,
    doorNo: customer.doorNo || '',
    block: customer.block || '',
    community: customer.apartmentName || '',
    area: customer.area || '',
    city: customer.city || '',
    pincode: customer.pincode || '',
    landmark: customer.landmark || '',
    isDefault: true,
    status: customer.isActive ? 'Active' : 'Inactive',
  }];
}

export async function findByMobile(mobile) {
  const response = await fetch(`/api/customers?phoneNumber=${encodeURIComponent(mobile)}`);
  if (!response.ok) throw new Error('Could not check existing customers');
  const customers = await response.json();
  return customers.map((customer) => ({
    id: customer._id,
    customerNumber: customer.customerId || customer.customerNumber || customer._id,
    name: customer.name,
    mobile: customer.phoneNumber,
  }));
}

export async function createCustomerWithAddress(payload) {
  const response = await fetch('/api/customers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: payload.name,
      phoneNumber: payload.mobile,
      address: payload.addressLine,
      doorNo: payload.doorNo || '',
      block: payload.block || '',
      apartmentName: payload.community || '',
      landmark: payload.landmark || '',
      city: payload.city || '',
      pincode: payload.pincode || '',
      area: payload.area || '',
      whatsapp: payload.sameAsMobile ? payload.mobile : payload.whatsapp || '',
      email: payload.email || '',
    }),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || 'Could not create customer in the database');
  }

  const customer = await response.json();
  return {
    customer: {
      ...customer,
      id: customer._id,
      customerNumber: customer.customerId || customer.customerNumber || customer._id,
      mobile: customer.phoneNumber,
    },
    address: {
      addressNumber: customer._id,
      addressLine: customer.address,
    },
  };
}

export async function addAddress(customerNumber, payload) {
  await delay(350);
  const db = getDb();
  const customer = db.customers.find((c) => c.customerNumber === customerNumber);
  if (!customer) throw new Error('Customer not found');

  if (payload.isDefault) {
    db.addresses
      .filter((a) => a.customerId === customer.id)
      .forEach((a) => {
        a.isDefault = false;
      });
  }

  const address = {
    id: `int-addr-${db.addresses.length + 1}-${Date.now()}`,
    addressNumber: generateId.address(),
    customerId: customer.id,
    label: payload.addressLabel || 'Address',
    doorNo: payload.doorNo || '',
    block: payload.block || '',
    community: payload.community || '',
    addressLine: payload.addressLine || '',
    area: payload.area,
    city: payload.city || '',
    pincode: payload.pincode || '',
    landmark: payload.landmark || '',
    isDefault: !!payload.isDefault || db.addresses.filter((a) => a.customerId === customer.id).length === 0,
    status: 'Active',
    createdOn: new Date().toISOString(),
  };
  db.addresses.push(address);

  recordAudit({
    module: 'Customers',
    action: 'ADD_ADDRESS',
    entityType: 'Customer',
    entityNumber: customer.customerNumber,
    details: `Added address ${address.addressNumber}`,
  });

  saveDb();
  return address;
}

export async function getCustomer360(customerNumber) {
  const response = await fetch(`/api/customers/${customerNumber}`);
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('Could not fetch customer details from the database');

  const record = await response.json();
  const customer = {
    ...record,
    id: record._id,
    customerNumber: record.customerId || record.customerNumber || record._id,
    mobile: record.phoneNumber,
    status: record.isActive ? 'Active' : 'Inactive',
  };
  const idOf = (value) => String(value && typeof value === 'object' ? value._id : value || '');
  const [subscriptionsResponse, bookingsResponse, visitsResponse] = await Promise.all([
    fetch('/api/subscriptions'),
    fetch('/api/bookings'),
    fetch('/api/visits'),
  ]);
  const [allSubscriptions, allBookings, allVisits] = await Promise.all([
    subscriptionsResponse.ok ? subscriptionsResponse.json() : [],
    bookingsResponse.ok ? bookingsResponse.json() : [],
    visitsResponse.ok ? visitsResponse.json() : [],
  ]);

  const addresses = record.addresses?.length
    ? record.addresses
    : record.address
      ? [{
          id: record._id,
          addressNumber: record._id,
          customerId: record._id,
          label: 'Primary address',
          addressLine: record.address,
          doorNo: record.doorNo || '',
          block: record.block || '',
          area: record.area || '',
          city: record.city || '',
          pincode: record.pincode || '',
          isDefault: true,
          status: record.isActive ? 'Active' : 'Inactive',
        }]
      : [];
  const bookings = (record.bookings?.length
    ? record.bookings
    : allBookings.filter((booking) => idOf(booking.customerId) === idOf(record._id))).map((booking) => ({
    ...booking,
    id: booking.id || booking._id,
  }));
  const subscriptions = (record.subscriptions?.length
    ? record.subscriptions
    : allSubscriptions.filter((subscription) => idOf(subscription.customerId) === idOf(record._id))).map((subscription) => ({
    ...subscription,
    id: subscription.id || subscription._id,
    subscriptionNumber: subscription.subscriptionNumber || subscription.subscriptionId || subscription._id,
    status: subscription.status || subscription.subscriptionStatus,
  }));
  const payments = record.payments || [];
  const invoices = record.invoices || [];
  const visits = record.visits?.length
    ? record.visits
    : allVisits
        .filter((visit) => idOf(visit.customerId) === idOf(record._id))
        .map((visit) => ({
          ...visit,
          id: visit._id,
          date: visit.scheduledDate || visit.date,
          status: visit.isCompleted ? 'Completed' : visit.isCancelled ? 'Cancelled' : 'Scheduled',
        }));
  const auditEvents = [];

  return {
    customer,
    addresses,
    bookings,
    subscriptions,
    payments,
    invoices,
    visits,
    auditEvents,
    summary: record.summary || {
      addressCount: addresses.filter((a) => a.status === 'Active').length,
      totalBookings: bookings.length,
      activeSubscriptions: subscriptions.filter((s) => s.status === 'Active').length,
      visitsCompleted: visits.filter((v) => v.status === 'Completed').length,
      lifetimeCollected: 0,
      nextVisits: [],
    },
  };
}

export async function deactivateCustomer(customerNumber) {
  await delay(300);
  const db = getDb();
  const customer = db.customers.find((c) => c.customerNumber === customerNumber);
  if (!customer) throw new Error('Customer not found');
  const hasActiveSub = db.subscriptions.some((s) => s.customerId === customer.id && s.status === 'Active');
  if (hasActiveSub) {
    throw new Error('Cannot deactivate: customer has active subscriptions.');
  }
  customer.status = 'Inactive';
  recordAudit({
    module: 'Customers',
    action: 'DEACTIVATE',
    entityType: 'Customer',
    entityNumber: customer.customerNumber,
  });
  saveDb();
  return customer;
}
