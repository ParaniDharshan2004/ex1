function normalizeInvoice(invoice, masters = {}) {
  const idOf = (value) => String(value && typeof value === 'object' ? value._id : value || '');
  const linkedBooking = invoice.bookingId && typeof invoice.bookingId === 'object'
    ? invoice.bookingId
    : masters.bookings?.find(
        (item) => idOf(item._id) === idOf(invoice.bookingId) || item.bookingId === invoice.bookingId
      );
  const customer = invoice.customerId && typeof invoice.customerId === 'object'
    ? invoice.customerId
    : masters.customers?.find(
        (item) =>
          idOf(item._id) === idOf(invoice.customerId) ||
          item.customerId === invoice.customerId ||
          item.customerNumber === invoice.customerId
      ) ||
      masters.customers?.find(
        (item) =>
          idOf(item._id) === idOf(linkedBooking?.customerId) ||
          item.customerId === linkedBooking?.customerId ||
          item.customerNumber === linkedBooking?.customerId
      ) || {};
  const booking = linkedBooking || {};
  const frequency = masters.frequencies?.find(
    (item) => String(item._id) === String(booking.frequencyCode || booking.frequencyId)
  );
  const subscriptionType = masters.subscriptionTypes?.find(
    (item) => String(item._id) === String(booking.planId || booking.subscriptionTypeId)
  );

  return {
    ...invoice,
    id: invoice.invoiceNumber || invoice._id,
    amount: invoice.totalAmount ?? invoice.amount ?? 0,
    createdDate: invoice.invoiceDate || invoice.createdAt,
    customer: {
      ...customer,
      phone: customer.phoneNumber,
    },
    booking: {
      ...booking,
      bathroomCount: booking.bathroomCountId?.bathroomCount,
      frequency: frequency?.frequencyName || '',
      subscriptionType: subscriptionType?.subscriptionName || '',
      weeks: booking.totalVisits,
      date: booking.scheduledDate,
    },
  };
}

export async function listInvoices({ search = '' } = {}) {
  const response = await fetch('/api/invoices');
  if (!response.ok) throw new Error('Could not fetch invoices from the database');
  const [frequencies, subscriptionTypes, customers, bookings] = await Promise.all([
    fetch('/api/service-frequencies').then((result) => result.json()),
    fetch('/api/subscription-types').then((result) => result.json()),
    fetch('/api/customers').then((result) => result.json()),
    fetch('/api/bookings').then((result) => result.json()),
  ]);
  let rows = (await response.json()).map((invoice) =>
    normalizeInvoice(invoice, { frequencies, subscriptionTypes, customers, bookings })
  );

  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (i) =>
        i.invoiceNumber.toLowerCase().includes(q) ||
        i.customer?.name?.toLowerCase().includes(q) ||
        i.booking?.bookingId?.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate));
}

export async function getInvoice(invoiceNumber) {
  const response = await fetch(`/api/invoices/${encodeURIComponent(invoiceNumber)}`);
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('Could not fetch invoice from the database');
  const [frequencies, subscriptionTypes, customers, bookings] = await Promise.all([
    fetch('/api/service-frequencies').then((result) => result.json()),
    fetch('/api/subscription-types').then((result) => result.json()),
    fetch('/api/customers').then((result) => result.json()),
    fetch('/api/bookings').then((result) => result.json()),
  ]);
  return normalizeInvoice(await response.json(), { frequencies, subscriptionTypes, customers, bookings });
}

export async function recordInvoiceDownload(invoiceNumber) {
  await delay(150);
  recordAudit({ module: 'Invoices', action: 'DOWNLOAD', entityType: 'Invoice', entityNumber: invoiceNumber });
  saveDb();
}
