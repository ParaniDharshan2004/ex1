import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit, recordStatusChange } from './db';
import { delay, serviceAreas } from './masters';

function toVisitRow(visit) {
  const db = getDb();
  const period = db.periods.find((p) => p.id === visit.periodId);
  const subscription = db.subscriptions.find((s) => s.id === visit.subscriptionId);
  const booking = period ? db.bookings.find((b) => b.id === period.bookingId) : null;
  const customer = subscription ? db.customers.find((c) => c.id === subscription.customerId) : null;
  const addressId = subscription?.addressId || booking?.addressId;
  const address = db.addresses.find((a) => a.id === addressId);

  return { ...visit, period, subscription, booking, customer, address };
}

export function areaWorkloadToday(visits) {
  return serviceAreas
    .map((area) => ({
      area,
      total: visits.filter((visit) => visit.areaId === area.id).length,
      completed: visits.filter((visit) => visit.areaId === area.id && visit.status === 'Completed').length,
    }))
    .filter((row) => row.total > 0);
}

export async function listVisits({ search = '', status = 'All', area = 'All', date, dateFrom, dateTo } = {}) {
  const response = await fetch('/api/visits');
  if (!response.ok) throw new Error('Could not fetch visits from the database');

  const [visits, customers, bookings, subscriptions, bathroomCounts, frequencies] = await Promise.all([
    response.json(),
    fetch('/api/customers').then((res) => res.json()),
    fetch('/api/bookings').then((res) => res.json()),
    fetch('/api/subscriptions').then((res) => res.json()),
    fetch('/api/bathroom-counts').then((res) => res.json()),
    fetch('/api/service-frequencies').then((res) => res.json()),
  ]);
  const idOf = (value) => (value && typeof value === 'object' ? value._id : value);
  const valueOf = (value) => (value && typeof value === 'object' ? value._id : value);
  const sequenceByVisitId = new Map();
  const visitsByBooking = new Map();
  visits.forEach((visit) => {
    const key = valueOf(visit.bookingId) || valueOf(visit.subscriptionId) || 'unlinked';
    const group = visitsByBooking.get(key) || [];
    group.push(visit);
    visitsByBooking.set(key, group);
  });
  visitsByBooking.forEach((group) => {
    group
      .slice()
      .sort((left, right) => new Date(left.scheduledDate) - new Date(right.scheduledDate))
      .forEach((visit, index) => {
        const parsedSequence = Number(String(visit.visitNumber || '').split('-').pop());
        sequenceByVisitId.set(visit._id, Number(visit.sequence || visit.visitSequence || parsedSequence || index + 1));
      });
  });

  let rows = visits.map((visit) => {
    const customer = typeof visit.customerId === 'object' ? visit.customerId : customers.find((item) => idOf(item._id) === idOf(visit.customerId));
    const booking = typeof visit.bookingId === 'object' ? visit.bookingId : bookings.find((item) => idOf(item._id) === idOf(visit.bookingId));
    const subscription = typeof visit.subscriptionId === 'object' ? visit.subscriptionId : subscriptions.find((item) => idOf(item._id) === idOf(visit.subscriptionId));
    const bathroomReference = booking?.bathroomCountId;
    const bathroomCount = Number(
      booking?.bathroomCount
      || booking?.bathrooms
      || (bathroomReference && typeof bathroomReference === 'object' ? bathroomReference.bathroomCount : 0)
      || bathroomCounts.find((item) => idOf(item._id) === valueOf(bathroomReference))?.bathroomCount
      || visit.bathroomCount
      || 1,
    );
    const frequencyReference = booking?.serviceFrequencyId
      || booking?.frequencyId
      || booking?.frequencyCode
      || subscription?.serviceFrequencyId
      || subscription?.frequencyId
      || subscription?.frequencyCode;
    const frequency = frequencyReference && typeof frequencyReference === 'object'
      ? frequencyReference
      : frequencies.find((item) => idOf(item._id) === valueOf(frequencyReference));
    const intervalDays = Number(frequency?.intervalDays || 0);
    const sequence = sequenceByVisitId.get(visit._id) || 1;
    const bookingStartDate = booking?.scheduledDate
      || booking?.startDate
      || subscription?.startDate
      || subscription?.subscriptionStartDate;
    const hasManualReschedule = Boolean(visit.rescheduleReason || visit.rescheduledOn || visit.isRescheduled);
    const expectedDate = intervalDays > 0 && bookingStartDate && !hasManualReschedule
      ? dayjs(bookingStartDate).add(Math.max(0, sequence - 1) * intervalDays, 'day').toISOString()
      : visit.scheduledDate;

    return {
    ...visit,
    id: visit._id,
    date: expectedDate,
    scheduledDate: expectedDate,
    status: visit.isCompleted ? 'Completed' : visit.isCancelled ? 'Cancelled' : 'Scheduled',
    customer: customer
      ? {
          ...customer,
          id: customer._id,
          customerNumber: customer.customerId || customer.customerNumber || customer._id,
          mobile: customer.phoneNumber,
        }
      : null,
    booking: booking
      ? {
          ...booking,
          id: booking._id,
          bookingNumber: booking.bookingId,
          bathroomCount,
          bathrooms: bathroomCount,
          frequencyId: valueOf(frequencyReference),
          frequencyName: frequency?.frequencyName || frequency?.name || valueOf(frequencyReference),
          intervalDays,
        }
      : null,
    subscription: subscription
      ? {
          ...subscription,
          id: subscription._id,
          subscriptionNumber: subscription.subscriptionId || subscription._id,
        }
      : null,
    slotId: booking?.slotId || visit.slotId || '',
    bathroomCount,
    bathrooms: bathroomCount,
    frequencyId: valueOf(frequencyReference),
    frequencyName: frequency?.frequencyName || frequency?.name || valueOf(frequencyReference),
    intervalDays,
    areaId: customer?.area || visit.areaId || '',
    sequence,
    address: customer ? { addressLine: customer.address, doorNo: customer.doorNo, block: customer.block, area: customer.area } : null,
    };
  });

  if (status !== 'All') rows = rows.filter((visit) => visit.status === status);
  if (area !== 'All') rows = rows.filter((visit) => visit.areaId === area);
  if (date) rows = rows.filter((visit) => dayjs(visit.date).format('YYYY-MM-DD') === date);
  if (dateFrom) rows = rows.filter((visit) => dayjs(visit.date).isSameOrAfter?.(dayjs(dateFrom)) ?? visit.date >= dateFrom);
  if (dateTo) rows = rows.filter((visit) => dayjs(visit.date).isSameOrBefore?.(dayjs(dateTo).endOf('day')) ?? visit.date <= dateTo);

  if (search.trim()) {
    const query = search.trim().toLowerCase();
    rows = rows.filter(
      (visit) =>
        visit.visitNumber.toLowerCase().includes(query) ||
        visit.customer?.name.toLowerCase().includes(query) ||
        visit.customer?.customerNumber.toLowerCase().includes(query)
    );
  }

  return rows.sort((a, b) => new Date(a.date) - new Date(b.date));
}

export async function getVisit(visitNumber) {
  // Visit links use the public visitNumber (for example VIS_13). The API's
  // detail route accepts MongoDB `_id`, so resolve the public number through
  // the collection endpoint and reuse the already-normalized list row.
  const rows = await listVisits({});
  return rows.find((row) => row.visitNumber === visitNumber || row._id === visitNumber) || null;
}

export async function completeVisit(visitNumber, { completedOn, completedBy = 'Demo Admin', remarks = '' } = {}) {
  const response = await fetch('/api/visits');
  if (!response.ok) throw new Error('Could not fetch visits from the database');

  const visits = await response.json();
  const visit = visits.find((item) => item.visitNumber === visitNumber || item._id === visitNumber);
  if (!visit) throw new Error('Visit not found.');
  if (visit.isCompleted || visit.status === 'Completed') throw new Error('This visit has already been completed.');
  if (visit.isCancelled || visit.status === 'Cancelled') throw new Error('Cancelled visits cannot be completed.');

  const updateResponse = await fetch(`/api/visits/${encodeURIComponent(visit._id)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      isCompleted: true,
      isPending: false,
      actualEndDateTime: completedOn || new Date().toISOString(),
      completedOn: completedOn || new Date().toISOString(),
      completedBy,
      completionRemarks: remarks || '',
    }),
  });
  if (!updateResponse.ok) {
    const error = await updateResponse.json().catch(() => ({}));
    throw new Error(error.message || 'Could not update the visit');
  }
  return updateResponse.json();
}

export async function batchCompleteVisits(visitNumbers, options = {}) {
  for (const visitNumber of visitNumbers) {
    await completeVisit(visitNumber, options);
  }
  return listVisits();
}

export async function rescheduleVisit(visitNumber, { newDate, newSlotId, reason, remarks = '' } = {}) {
  if (!newDate || !newSlotId || !reason) throw new Error('Date, slot, and reason are required.');

  const response = await fetch('/api/visits');
  if (!response.ok) throw new Error('Could not fetch visits from the database');

  const visits = await response.json();
  const visit = visits.find((item) => item.visitNumber === visitNumber || item._id === visitNumber);
  if (!visit) throw new Error('Visit not found.');
  if (visit.isCompleted || visit.status === 'Completed') throw new Error('Completed visits cannot be rescheduled.');

  const oldDate = visit.scheduledDate || visit.date;
  const updatedDate = dayjs(newDate).toISOString();
  const updateResponse = await fetch(`/api/visits/${encodeURIComponent(visit._id)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      scheduledDate: updatedDate,
      slotId: newSlotId,
      isCompleted: false,
      isCancelled: false,
      rescheduleReason: reason,
      rescheduleRemarks: remarks || '',
    }),
  });
  if (!updateResponse.ok) {
    const error = await updateResponse.json().catch(() => ({}));
    throw new Error(error.message || 'Could not update the visit');
  }

  const updatedVisit = await updateResponse.json();
  return { ...updatedVisit, oldDate, newDate: updatedVisit.scheduledDate || updatedDate };
}
