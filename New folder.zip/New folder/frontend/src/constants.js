export const BRAND = {
  black: '#111111',
  greenDark: '#0F5C57',
};

export const DAY_START_MIN = 8 * 60;
export const DAY_END_MIN = 19 * 60 + 30;

// Default service duration used when the database does not provide pricing
// duration metadata for the selected bathroom count.
export const DURATION_BY_BATHROOMS = {
  1: 30,
  2: 45,
  3: 60,
  4: 75,
};
