# Bathroom-Based Start Time Logic

## Summary

Yes — this project has logic that changes the available start times based on the selected bathroom count.

The app uses the selected bathroom count to determine the service duration, and then it only allows start times that fit within the defined time slots and do not overlap with other bookings.

---

## 1) Bathroom count → duration mapping

This is defined in:

- `frontend/src/constants.js`

Code:

```js
export const DURATION_BY_BATHROOMS = { 1: 30, 2: 45, 3: 60, 4: 75};
```

Meaning:

- 1 bathroom = 30 minutes
- 2 bathrooms = 45 minutes
- 3 bathrooms = 60 minutes
- 4 bathrooms = 75 minutes

This is the base rule that drives the start time availability.

---

## 2) Booking form calculates available start times from bathroom count

This is implemented in:

- `frontend/src/components/booking-components/NewBookingForm.jsx`

The relevant logic is:

```js
const serviceDuration = Number(durationByBathrooms[bathroomCount]) || 0;
const totalSlotDuration = serviceDuration + bufferMinutes;
```

Then it loops through each configured slot and adds possible start times:

```js
for (
  let currentMinutes = startMinutes;
  currentMinutes + totalSlotDuration <= endMinutes;
  currentMinutes += totalSlotDuration
) {
  generatedTimes.add(toTime(currentMinutes));
}
```

This means:

- the selected bathroom count determines how long the visit takes
- the system only creates valid start times that fit the slot duration
- if a selected bathroom count implies a longer service, fewer start times will remain available

---

## 3) Conflict check also depends on bathroom count

This is implemented in:

- `frontend/src/utils/scheduling.js`

Important code:

```js
const dur = durationByBathrooms[bathroomCount];
const s = timeToMin(startTime);
const e = s + dur + bufferMinutes;
```

And later:

```js
const [os, oe] = occupiedWindow(b, durationByBathrooms, bufferMinutes);
return s < oe && os < e;
```

This means the app checks each booking by its exact service duration based on bathroom count.

If a job for 4 bathrooms lasts 75 minutes, it is treated as a 75-minute booking in the overlap check.

---

## 4) The actual start-time dropdown is filtered by this logic

The form computes `availableStarts` and then shows them in the dropdown:

```js
const availableStarts = useMemo(() => {
  if (!startDate || !bathroomCount) return [];

  if (databaseStartTimes.length) {
    return databaseStartTimes.filter((start) => {
      const selectedSlot = timeSlots.find((slot) => {
        const slotStart = toMinutes(slot.startTime);
        const slotEnd = toMinutes(slot.endTime);
        const selectedStart = toMinutes(start);
        return (
          selectedStart !== null &&
          slotStart !== null &&
          slotEnd !== null &&
          selectedStart >= slotStart &&
          selectedStart <= slotEnd
        );
      });

      const bufferMinutes = Number(selectedSlot?.bufferTime) || 0;

      return !hasConflict(
        startDate,
        start,
        bathroomCount,
        bookings,
        null,
        durationByBathrooms,
        false,
        bufferMinutes,
      );
    });
  }

  const conflictFreeStarts = findAvailableStarts(
    startDate,
    bathroomCount,
    bookings,
    null,
    durationByBathrooms,
    false,
  );
  return timeSlots.length
    ? conflictFreeStarts.filter((start) => databaseStartTimes.includes(start))
    : conflictFreeStarts;
}, [
  startDate,
  bathroomCount,
  bookings,
  durationByBathrooms,
  databaseStartTimes,
]);
```

Then the dropdown is rendered like this:

```jsx
<TextField
  id="booking-start-time"
  select
  fullWidth
  size="small"
  label="Start time"
  value={startTime}
  onChange={(e) => setStartTime(e.target.value)}
  disabled={!startDate || !bathroomCount}
>
  <MenuItem value="">Select start time</MenuItem>
  {availableStarts.map((time) => (
    <MenuItem key={time} value={time}>
      {fmtTime12(time)}
    </MenuItem>
  ))}
</TextField>
```

---

## 5) Final business rule

The project logic is:

```txt
bathroomCount -> durationByBathrooms[bathroomCount] -> service duration
service duration + buffer -> valid slot generation
valid slots -> conflict check with existing bookings
available start times shown to user
```

So yes, the project absolutely has logic that lists start times based on the number of bathrooms selected.

---

## Key files to review

- `frontend/src/constants.js`
- `frontend/src/components/booking-components/NewBookingForm.jsx`
- `frontend/src/utils/scheduling.js`

---

## Example

If the user chooses:

- 1 bathroom → 30 min visit
- 2 bathrooms → 45 min visit
- 3 bathrooms → 60 min visit
- 4 bathrooms → 75 min visit

Then the system will only offer start times that can fit these durations without overlapping other bookings or going outside the scheduling rules.
