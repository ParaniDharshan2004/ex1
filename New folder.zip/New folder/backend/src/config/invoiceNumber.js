import Counter from '../models/counter.js';

export async function nextInvoiceNumber(date = new Date()) {
  const dateKey = date.toISOString().slice(0, 10).replace(/-/g, '');
  const counter = await Counter.findOneAndUpdate(
    { _id: `invoice:${dateKey}` },
    { $inc: { seq: 1 } },
    { new: true, upsert: true, setDefaultsOnInsert: true },
  );

  return `JHN${dateKey}-${String(counter.seq).padStart(4, '0')}`;
}
