export async function resolveDocument(Model, value, publicField) {
  if (!value) return null;

  if (/^[0-9a-fA-F]{24}$/.test(value)) {
    return Model.findById(value);
  }

  return Model.findOne({ [publicField]: value });
}
