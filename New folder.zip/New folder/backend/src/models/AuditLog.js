import mongoose from 'mongoose';
import sequentialIdPlugin from '../config/sequentialId.js';

const auditLogSchema = new mongoose.Schema(
  {
    auditLogId: {
      type: String,
      required: true,
      unique: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    operation: {
      type: String,
      enum: ['create', 'update', 'delete', 'CREATE', 'UPDATE', 'DELETE'],
      required: true,
    },
    collectionName: {
      type: String,
      required: true,
      trim: true,
    },
    recordId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
    },
    details: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },
    previousValue: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },
    newValue: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
  }
);

sequentialIdPlugin(auditLogSchema, { field: 'auditLogId', prefix: 'AUD' });

export default mongoose.models.AuditLog || mongoose.model('AuditLog', auditLogSchema);
