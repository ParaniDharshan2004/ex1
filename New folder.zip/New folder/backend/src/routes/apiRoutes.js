import express from 'express';
import { login, getCurrentUser } from '../controllers/authController.js';
import {
  getMasterList,
  getMasterById,
  createMasterItem,
  updateMasterItem,
  deleteMasterItem
} from '../controllers/masterController.js';
import {
  getCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  getBookings,
  getBookingById,
  createBooking,
  confirmBooking,
  updateBooking,
  deleteBooking,
  getSubscriptions,
  updateSubscription,
  getVisits,
  updateVisit,
  getServicePayments,
  createServicePayment,
  getInvoices,
  getInvoiceById
} from '../controllers/operationsController.js';
import { getAuditLogs } from '../controllers/auditController.js';
import { checkAvailability } from '../middleware/availability.js';
import { getAvailability } from '../controllers/availabilityController.js';
import { getDashboardSummary } from '../controllers/dashboardController.js';

const router = express.Router();

// ==================== AUTH ROUTES ====================
router.post('/login', login);
router.get('/me', getCurrentUser);
router.get('/users/me', getCurrentUser);
router.get('/audit-logs', getAuditLogs);
router.get('/dashboard', getDashboardSummary);
router.get('/availability', checkAvailability, getAvailability);
router.post('/availability', checkAvailability, getAvailability);
router.get('/time-slots/availability', checkAvailability, getAvailability);
router.post('/time-slots/availability', checkAvailability, getAvailability);

// ==================== CUSTOMERS ====================
router.get('/customers', getCustomers);
router.get('/customers/:id', getCustomerById);
router.post('/customers', createCustomer);
router.put('/customers/:id', updateCustomer);
router.delete('/customers/:id', deleteCustomer);

// ==================== BOOKINGS ====================
router.get('/bookings', getBookings);
router.get('/bookings/:id', getBookingById);
router.post('/bookings', createBooking);
router.post('/bookings/:id/confirm', confirmBooking);
router.put('/bookings/:id', updateBooking);
router.delete('/bookings/:id', deleteBooking);

// ==================== SUBSCRIPTIONS ====================
router.get('/subscriptions', getSubscriptions);
router.put('/subscriptions/:id', updateSubscription);

// ==================== VISITS ====================
router.get('/visits', getVisits);
router.put('/visits/:id', updateVisit);

// ==================== SERVICE PAYMENTS ====================
router.get('/service-payments', getServicePayments);
router.post('/service-payments', createServicePayment);

// ==================== INVOICES ====================
router.get('/invoices', getInvoices);
router.get('/invoices/:id', getInvoiceById);

// ==================== GENERIC MASTER DATA ROUTES ====================
// Matches /api/roles, /api/users, /api/bathroom-counts, /api/service-durations,
// /api/service-frequencies, /api/subscription-types, /api/time-slots,
// /api/payment-methods, /api/payment-accounts, /api/payment-masters, /api/pricing
router.get('/:resource', getMasterList);
router.get('/:resource/:id', getMasterById);
router.post('/:resource', createMasterItem);
router.put('/:resource/:id', updateMasterItem);
router.delete('/:resource/:id', deleteMasterItem);

export default router;
