import { Booking, BathroomCount, Pricing, ServiceDuration, TimeSlot } from '../models/index.js';

export function parseTimeToMinutes(value) {
  if (!value || typeof value !== 'string') return 0;
  const normalized = value.trim().toUpperCase();
  const is12Hour = normalized.includes('AM') || normalized.includes('PM');
  const timePart = normalized.replace(/(AM|PM)/g, '').trim();
  const [hoursText, minutesText = '0'] = timePart.split(':');
  let hours = Number.parseInt(hoursText, 10);
  const minutes = Number.parseInt(minutesText, 10);
  if (is12Hour) {
    if (normalized.includes('PM') && hours !== 12) hours += 12;
    if (normalized.includes('AM') && hours === 12) hours = 0;
  }
  return hours * 60 + minutes;
}

function formatMinutes(totalMinutes) {
  return `${String(Math.floor(totalMinutes / 60)).padStart(2, '0')}:${String(totalMinutes % 60).padStart(2, '0')}`;
}

export async function checkAvailability(req, res, next) {
  try {
    const params = req.method === 'POST' ? req.body : req.query;
    const rawDate = params.scheduledDate || params.date;
    if (!rawDate) return res.status(400).json({ message: 'scheduledDate is required (format: YYYY-MM-DD)' });
    const requestedDate = new Date(rawDate);
    if (Number.isNaN(requestedDate.getTime())) return res.status(400).json({ message: 'Invalid scheduledDate format' });

    const dateKey = requestedDate.toISOString().slice(0, 10);
    let bathroomCount = Number(params.bathroomCount || params.bathrooms || 1);
    if (params.bathroomCountId) {
      const bathroom = await BathroomCount.findById(params.bathroomCountId);
      if (bathroom) bathroomCount = bathroom.bathroomCount;
    }

    let duration = Number(params.serviceDuration || params.duration || 0);
    if (!duration && params.serviceDurationId) {
      const serviceDuration = await ServiceDuration.findById(params.serviceDurationId);
      duration = serviceDuration?.durationMinutes || 0;
    }
    if (!duration && params.bathroomCountId) {
      const pricing = await Pricing.findOne({ bathroomCountReference: params.bathroomCountId, isActive: true }).populate('serviceDurationReference');
      duration = pricing?.serviceDurationReference?.durationMinutes || 0;
    }
    duration ||= bathroomCount * 60;

    let bufferTime = Number(params.bufferTime || params.bufferDuration || 0);
    if (!bufferTime) {
      const configuredSlot = await TimeSlot.findOne({ isActive: true, bufferTime: { $gt: 0 } });
      bufferTime = configuredSlot?.bufferTime || 30;
    }

    const configuredSlots = await TimeSlot.find({ isActive: true }).sort({ startTime: 1 });
    const startMinutes = configuredSlots.length ? Math.min(...configuredSlots.map((slot) => parseTimeToMinutes(slot.startTime))) : 9 * 60;
    const endMinutes = configuredSlots.length ? Math.max(...configuredSlots.map((slot) => parseTimeToMinutes(slot.endTime))) : 18 * 60 + 30;
    const slotDuration = duration + bufferTime;
    const generatedSlots = [];
    for (let start = startMinutes; start + slotDuration <= endMinutes; start += slotDuration) {
      generatedSlots.push({
        startMinutes: start,
        startTime: formatMinutes(start),
        endTime: formatMinutes(start + duration),
        occupiedEndTime: formatMinutes(start + slotDuration),
      });
    }

    const dayStart = new Date(`${dateKey}T00:00:00.000Z`);
    const dayEnd = new Date(`${dateKey}T23:59:59.999Z`);
    const bookings = await Booking.find({ startDateTime: { $gte: dayStart, $lte: dayEnd }, isCancelled: { $ne: true } });
    const slots = generatedSlots.map((slot) => {
      const slotStart = new Date(`${dateKey}T${slot.startTime}:00.000Z`);
      const slotEnd = new Date(`${dateKey}T${slot.occupiedEndTime}:00.000Z`);
      const available = !bookings.some((booking) => {
        const bookingStart = new Date(booking.startDateTime);
        const bookingEnd = booking.endDateTime ? new Date(booking.endDateTime) : new Date(bookingStart.getTime() + slotDuration * 60000);
        return slotStart < bookingEnd && slotEnd > bookingStart;
      });
      return available
        ? {
            id: `${configuredSlots[0]?._id}-${slot.startMinutes}`,
            startTime: slot.startTime,
            endTime: slot.endTime,
            label: `${slot.startTime} - ${slot.endTime}`,
            status: 'active',
          }
        : null;
    }).filter(Boolean);

    req.availabilityData = { scheduledDate: dateKey, slots };
    return next();
  } catch (error) {
    return res.status(500).json({ message: 'Error calculating availability', error: error.message });
  }
}
