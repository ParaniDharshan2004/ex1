import {
  Role,
  User,
  BathroomCount,
  ServiceDuration,
  ServiceFrequency,
  SubscriptionType,
  TimeSlot,
  PaymentMethod,
  PaymentAccount,
  PaymentMaster,
  Pricing
} from '../models/index.js';
import { writeAudit } from '../utils/audit.js';
import { resolveDocument } from '../utils/resolveDocument.js';

// Map model names to actual Mongoose model instances
const models = {
  roles: Role,
  users: User,
  'bathroom-counts': BathroomCount,
  'service-durations': ServiceDuration,
  'service-frequencies': ServiceFrequency,
  'subscription-types': SubscriptionType,
  'time-slots': TimeSlot,
  'payment-methods': PaymentMethod,
  'payment-accounts': PaymentAccount,
  'payment-masters': PaymentMaster,
  pricing: Pricing
};

/**
 * Get model instance by resource name
 */
const getModel = (resourceName) => models[resourceName];

const publicIdFields = {
  roles: 'roleId',
  users: 'userId',
  'bathroom-counts': 'bathroomCountId',
  'service-durations': 'serviceDurationId',
  'service-frequencies': 'serviceFrequencyId',
  'subscription-types': 'subscriptionTypeId',
  'time-slots': 'timeSlotId',
  'payment-methods': 'paymentMethodId',
  'payment-accounts': 'paymentAccountId',
  'payment-masters': 'paymentMasterId',
  pricing: 'pricingId',
};

/**
 * Generic GET Handler for master tables
 */
export const getMasterList = async (req, res) => {
  try {
    const { resource } = req.params;
    const Model = getModel(resource);

    if (!Model) {
      return res.status(404).json({ message: `Resource '${resource}' not found.` });
    }

    let query = Model.find();

    // Populate references if fetching pricing or users
    if (resource === 'pricing') {
      query = query.populate('serviceDurationReference').populate('bathroomCountReference');
    } else if (resource === 'users') {
      query = query.populate('roleId');
    }

    const items = await query.exec();
    return res.json(items);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching list', error: error.message });
  }
};

/**
 * Generic GET Single Handler for master item
 */
export const getMasterById = async (req, res) => {
  try {
    const { resource, id } = req.params;
    const Model = getModel(resource);

    if (!Model) {
      return res.status(404).json({ message: `Resource '${resource}' not found.` });
    }

    const item = await resolveDocument(Model, id, publicIdFields[resource]);
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    let query = Model.findById(item._id);

    if (resource === 'pricing') {
      query = query.populate('serviceDurationReference').populate('bathroomCountReference');
    } else if (resource === 'users') {
      query = query.populate('roleId');
    }

    return res.json(await query.exec());
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching item', error: error.message });
  }
};

/**
 * Generic POST Handler to create master item
 */
export const createMasterItem = async (req, res) => {
  try {
    const { resource } = req.params;
    const Model = getModel(resource);

    if (!Model) {
      return res.status(404).json({ message: `Resource '${resource}' not found.` });
    }

    const newItem = new Model(req.body);
    await newItem.save();
    await writeAudit(req, {
      operation: 'create',
      collectionName: resource,
      record: newItem,
      newValue: newItem.toObject(),
    });
    return res.status(201).json(newItem);
  } catch (error) {
    return res.status(400).json({ message: 'Error creating item', error: error.message });
  }
};

/**
 * Generic PUT/PATCH Handler to update master item
 */
export const updateMasterItem = async (req, res) => {
  try {
    const { resource, id } = req.params;
    const Model = getModel(resource);

    if (!Model) {
      return res.status(404).json({ message: `Resource '${resource}' not found.` });
    }

    const previousItem = await resolveDocument(Model, id, publicIdFields[resource]);
    const updatedItem = previousItem
      ? await Model.findByIdAndUpdate(previousItem._id, req.body, { new: true, runValidators: true })
      : null;
    if (!updatedItem) {
      return res.status(404).json({ message: 'Item not found' });
    }

    await writeAudit(req, {
      operation: 'update',
      collectionName: resource,
      record: updatedItem,
      previousValue: previousItem?.toObject() || null,
      newValue: updatedItem.toObject(),
    });
    return res.json(updatedItem);
  } catch (error) {
    return res.status(400).json({ message: 'Error updating item', error: error.message });
  }
};

/**
 * Generic DELETE Handler to delete master item
 */
export const deleteMasterItem = async (req, res) => {
  try {
    const { resource, id } = req.params;
    const Model = getModel(resource);

    if (!Model) {
      return res.status(404).json({ message: `Resource '${resource}' not found.` });
    }

    const existingItem = await resolveDocument(Model, id, publicIdFields[resource]);
    const deletedItem = existingItem ? await Model.findByIdAndDelete(existingItem._id) : null;
    if (!deletedItem) {
      return res.status(404).json({ message: 'Item not found' });
    }

    await writeAudit(req, {
      operation: 'delete',
      collectionName: resource,
      record: deletedItem,
      previousValue: deletedItem.toObject(),
    });
    return res.json({ message: 'Item deleted successfully', deletedItem });
  } catch (error) {
    return res.status(500).json({ message: 'Error deleting item', error: error.message });
  }
};
