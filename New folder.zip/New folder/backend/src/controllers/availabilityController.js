export const getAvailability = (req, res) => {
  if (!req.availabilityData) return res.status(500).json({ message: 'Availability data not found' });
  return res.json(req.availabilityData);
};
