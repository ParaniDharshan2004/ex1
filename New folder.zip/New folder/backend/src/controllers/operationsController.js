import {
  Customer,
  Booking,
  Subscription,
  Visit,
  ServicePayment,
  Invoice,
  BathroomCount,
  Pricing,
} from '../models/index.js';
import { writeAudit } from '../utils/audit.js';
import { nextInvoiceNumber } from '../config/invoiceNumber.js';
import { resolveDocument } from '../utils/resolveDocument.js';

export const getCustomers = async (req, res) => {
  try {
    const filter = {};
    if (req.query.phoneNumber) filter.phoneNumber = req.query.phoneNumber;
    return res.json(await Customer.find(filter).sort({ createdAt: -1 }));
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching customers', error: error.message });
  }
};

export const createCustomer = async (req, res) => {
  try {
    const customer = new Customer({
      name: req.body.name,
      phoneNumber: req.body.phoneNumber || req.body.mobile,
      address: req.body.address || req.body.addressLine,
      doorNo: req.body.doorNo,
      block: req.body.block,
      apartmentName: req.body.apartmentName || req.body.community,
      landmark: req.body.landmark,
      city: req.body.city,
      pincode: req.body.pincode,
      area: req.body.area,
      email: req.body.email,
      whatsapp: req.body.whatsapp,
    });
    await customer.save();
    await writeAudit(req, { operation: 'create', collectionName: 'customers', record: customer, newValue: customer.toObject() });
    return res.status(201).json(customer);
  } catch (error) {
    return res.status(400).json({ message: 'Error creating customer', error: error.message });
  }
};

export const getCustomerById = async (req, res) => {
  try {
    const customer = await resolveDocument(Customer, req.params.id, 'customerId');
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    return res.json(customer);
  } catch (error) {
    return res.status(400).json({ message: 'Error fetching customer', error: error.message });
  }
};

export const updateCustomer = async (req, res) => {
  try {
    const previousCustomer = await resolveDocument(Customer, req.params.id, 'customerId');
    const customer = previousCustomer
      ? await Customer.findByIdAndUpdate(previousCustomer._id, req.body, { new: true, runValidators: true })
      : null;
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    await writeAudit(req, { operation: 'update', collectionName: 'customers', record: customer, previousValue: previousCustomer?.toObject() || null, newValue: customer.toObject() });
    return res.json(customer);
  } catch (error) {
    return res.status(400).json({ message: 'Error updating customer', error: error.message });
  }
};

export const deleteCustomer = async (req, res) => {
  try {
    const existingCustomer = await resolveDocument(Customer, req.params.id, 'customerId');
    const customer = existingCustomer ? await Customer.findByIdAndDelete(existingCustomer._id) : null;
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    await writeAudit(req, { operation: 'delete', collectionName: 'customers', record: customer, previousValue: customer.toObject() });
    return res.json({ message: 'Customer deleted successfully' });
  } catch (error) {
    return res.status(500).json({ message: 'Error deleting customer', error: error.message });
  }
};

export const getBookings = async (req, res) => {
  try { return res.json(await Booking.find().sort({ createdAt: -1 })); }
  catch (error) { return res.status(500).json({ message: 'Error fetching bookings', error: error.message }); }
};

export const getBookingById = async (req, res) => {
  try {
    const booking = await resolveDocument(Booking, req.params.id, 'bookingId');
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    return res.json(booking);
  } catch (error) { return res.status(500).json({ message: 'Error fetching booking', error: error.message }); }
};

export const createBooking = async (req, res) => {
  try {
    const body = req.body;
    const customer = await Customer.findById(body.customerId);
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    const bathroomCount = await BathroomCount.findOne({ bathroomCount: body.bathroomCount });
    if (!bathroomCount) return res.status(400).json({ message: 'Bathroom count is not configured' });
    const pricing = await Pricing.findOne({ bathroomCountReference: bathroomCount._id, isActive: true }).populate('serviceDurationReference');
    const serviceDurationMinutes = pricing?.serviceDurationReference?.durationMinutes || bathroomCount.bathroomCount * 60;
    const startMinutes = Number(String(body.slotId || '').split('-').pop());
    const startDateTime = body.startDate && Number.isFinite(startMinutes)
      ? new Date(`${body.startDate}T${String(Math.floor(startMinutes / 60)).padStart(2, '0')}:${String(startMinutes % 60).padStart(2, '0')}:00.000Z`)
      : body.startDate ? new Date(body.startDate) : undefined;
    const endDateTime = startDateTime ? new Date(startDateTime.getTime() + serviceDurationMinutes * 60000) : undefined;
    const booking = new Booking({
      customerId: customer._id,
      bathroomCountId: bathroomCount._id,
      scheduledDate: body.startDate,
      startDateTime,
      endDateTime,
      addressId: body.addressId,
      offeringId: body.offeringId,
      frequencyCode: body.frequencyId,
      planId: body.planId,
      slotId: body.slotId,
      discountAmount: body.discount || 0,
      serviceCharges: body.serviceCharges || 0,
      taxableAmount: body.taxableAmount || 0,
      totalAmount: body.totalAmount || 0,
      totalVisits: body.totalVisits || 0,
      isPending: true,
      isActive: true,
    });
    await booking.save();
    await writeAudit(req, { operation: 'create', collectionName: 'bookings', record: booking, newValue: booking.toObject() });
    return res.status(201).json({ booking });
  } catch (error) { return res.status(400).json({ message: 'Error creating booking', error: error.message }); }
};

export const confirmBooking = async (req, res) => {
  try {
    const booking = await Booking.findOne({ bookingId: req.params.id });
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    if (!booking.isPending || booking.isCompleted) return res.status(400).json({ message: 'Only pending bookings can be confirmed' });
    const now = new Date();
    const totalVisits = booking.totalVisits || 0;
    const subscription = await Subscription.create({ bookingId: booking._id, customerId: booking.customerId, totalVisits, remainingVisits: totalVisits, subscriptionStatus: 'Active', isActive: true });
    const visits = [];
    const startDate = booking.startDateTime || now;
    for (let index = 0; index < totalVisits; index += 1) {
      const visitDate = new Date(startDate);
      visitDate.setDate(visitDate.getDate() + index * 7);
      visits.push(await Visit.create({ subscriptionId: subscription._id, bookingId: booking._id, customerId: booking.customerId, scheduledDate: visitDate, isPending: true, isActive: true }));
    }
    const payment = await ServicePayment.create({ bookingId: booking._id, customerId: booking.customerId, amount: booking.totalAmount || 0, transactionId: req.body.paymentReference || '', status: 'Completed', isActive: true });
    const invoice = await Invoice.create({ invoiceNumber: await nextInvoiceNumber(now), bookingId: booking._id, subscriptionId: subscription._id, customerId: booking.customerId, amount: booking.totalAmount || 0, totalAmount: booking.totalAmount || 0, invoiceDate: now, status: 'Paid', isActive: true });
    booking.isPending = false;
    booking.isCompleted = true;
    await booking.save();
    await writeAudit(req, { operation: 'update', collectionName: 'bookings', record: booking, newValue: booking.toObject(), details: { action: 'confirm' } });
    await writeAudit(req, { operation: 'create', collectionName: 'subscriptions', record: subscription, newValue: subscription.toObject() });
    await writeAudit(req, { operation: 'create', collectionName: 'service-payments', record: payment, newValue: payment.toObject() });
    await writeAudit(req, { operation: 'create', collectionName: 'invoices', record: invoice, newValue: invoice.toObject() });
    return res.json({ booking, payment, invoice, subscription, visits });
  } catch (error) { return res.status(400).json({ message: 'Error confirming booking', error: error.message }); }
};

export const updateBooking = async (req, res) => {
  try {
    const previousBooking = await resolveDocument(Booking, req.params.id, 'bookingId');
    const booking = previousBooking
      ? await Booking.findByIdAndUpdate(previousBooking._id, req.body, { new: true, runValidators: true })
      : null;
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    await writeAudit(req, { operation: 'update', collectionName: 'bookings', record: booking, previousValue: previousBooking?.toObject() || null, newValue: booking.toObject() });
    return res.json(booking);
  } catch (error) { return res.status(400).json({ message: 'Error updating booking', error: error.message }); }
};

export const deleteBooking = async (req, res) => {
  try {
    const existingBooking = await resolveDocument(Booking, req.params.id, 'bookingId');
    const booking = existingBooking ? await Booking.findByIdAndDelete(existingBooking._id) : null;
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    await writeAudit(req, { operation: 'delete', collectionName: 'bookings', record: booking, previousValue: booking.toObject() });
    return res.json({ message: 'Booking deleted successfully' });
  } catch (error) { return res.status(500).json({ message: 'Error deleting booking', error: error.message }); }
};

export const getSubscriptions = async (req, res) => {
  try { return res.json(await Subscription.find().sort({ createdAt: -1 })); }
  catch (error) { return res.status(500).json({ message: 'Error fetching subscriptions', error: error.message }); }
};

export const updateSubscription = async (req, res) => {
  try {
    const previousSubscription = await resolveDocument(Subscription, req.params.id, 'subscriptionId');
    const subscription = previousSubscription
      ? await Subscription.findByIdAndUpdate(previousSubscription._id, req.body, { new: true, runValidators: true })
      : null;
    if (!subscription) return res.status(404).json({ message: 'Subscription not found' });
    await writeAudit(req, { operation: 'update', collectionName: 'subscriptions', record: subscription, previousValue: previousSubscription?.toObject() || null, newValue: subscription.toObject() });
    return res.json(subscription);
  } catch (error) { return res.status(400).json({ message: 'Error updating subscription', error: error.message }); }
};

export const getVisits = async (req, res) => {
  try { return res.json(await Visit.find().sort({ scheduledDate: 1 })); }
  catch (error) { return res.status(500).json({ message: 'Error fetching visits', error: error.message }); }
};

export const updateVisit = async (req, res) => {
  try {
    const previousVisit = await resolveDocument(Visit, req.params.id, 'visitNumber');
    if (!previousVisit) return res.status(404).json({ message: 'Visit not found' });
    const updatedVisit = await Visit.findByIdAndUpdate(previousVisit._id, req.body, { new: true, runValidators: true });
    if (!previousVisit.isCompleted && req.body.isCompleted === true) {
      const subscription = await Subscription.findById(previousVisit.subscriptionId);
      if (subscription) {
        const completedVisits = subscription.completedVisits + 1;
        await Subscription.findByIdAndUpdate(subscription._id, { completedVisits, remainingVisits: Math.max(0, subscription.totalVisits - completedVisits), subscriptionStatus: completedVisits >= subscription.totalVisits ? 'Completed' : 'Active' });
      }
    }
    await writeAudit(req, { operation: 'update', collectionName: 'visits', record: updatedVisit, previousValue: previousVisit.toObject(), newValue: updatedVisit.toObject() });
    return res.json(updatedVisit);
  } catch (error) { return res.status(400).json({ message: 'Error updating visit', error: error.message }); }
};

export const getServicePayments = async (req, res) => {
  try { return res.json(await ServicePayment.find().sort({ createdAt: -1 })); }
  catch (error) { return res.status(500).json({ message: 'Error fetching service payments', error: error.message }); }
};

export const createServicePayment = async (req, res) => {
  try {
    const payment = new ServicePayment(req.body);
    await payment.save();
    await writeAudit(req, { operation: 'create', collectionName: 'service-payments', record: payment, newValue: payment.toObject() });
    return res.status(201).json(payment);
  } catch (error) { return res.status(400).json({ message: 'Error creating payment', error: error.message }); }
};

export const getInvoices = async (req, res) => {
  try { return res.json(await Invoice.find().sort({ createdAt: -1 })); }
  catch (error) { return res.status(500).json({ message: 'Error fetching invoices', error: error.message }); }
};

export const getInvoiceById = async (req, res) => {
  try {
    const invoice = await resolveDocument(Invoice, req.params.id, 'invoiceNumber');
    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
    return res.json(invoice);
  } catch (error) { return res.status(500).json({ message: 'Error fetching invoice', error: error.message }); }
};
