import {
  Booking,
  Customer,
  ServicePayment,
  Subscription,
  Visit,
} from '../models/index.js';

export const getDashboardSummary = async (req, res) => {
  try {
    const requestedDate = new Date(`${req.query.date || new Date().toISOString().slice(0, 10)}T00:00:00.000Z`);
    if (Number.isNaN(requestedDate.getTime())) return res.status(400).json({ message: 'Invalid date' });

    const nextDate = new Date(requestedDate);
    nextDate.setUTCDate(nextDate.getUTCDate() + 1);
    const monthStart = new Date(Date.UTC(requestedDate.getUTCFullYear(), requestedDate.getUTCMonth(), 1));
    const now = new Date();

    const [todayVisits, activeSubscriptions, recentBookings, upcomingVisits, staleDrafts, todayPayments, monthPayments] = await Promise.all([
      Visit.find({ scheduledDate: { $gte: requestedDate, $lt: nextDate }, isCancelled: { $ne: true } }).populate('customerId', 'name area').sort({ scheduledDate: 1 }),
      Subscription.countDocuments({ subscriptionStatus: 'Active', isActive: true }),
      Booking.find({ isCompleted: true }).populate('customerId', 'name').sort({ updatedAt: -1 }).limit(8),
      Visit.find({ scheduledDate: { $gte: now }, isCancelled: { $ne: true } }).populate('customerId', 'name area').sort({ scheduledDate: 1 }).limit(8),
      Booking.find({ isPending: true, createdAt: { $lt: new Date(now.getTime() - 24 * 60 * 60 * 1000) } }).sort({ createdAt: 1 }).limit(8),
      ServicePayment.find({ paymentDate: { $gte: requestedDate, $lt: nextDate }, status: { $ne: 'Reversed' } }),
      ServicePayment.find({ paymentDate: { $gte: monthStart, $lt: nextDate }, status: { $ne: 'Reversed' } }),
    ]);

    const completedToday = todayVisits.filter((visit) => visit.isCompleted).length;
    const pendingToday = todayVisits.filter((visit) => visit.isPending && !visit.isCompleted).length;
    const areaMap = new Map();
    todayVisits.forEach((visit) => {
      const areaName = visit.customerId?.area || 'Unassigned';
      const current = areaMap.get(areaName) || { areaName, completed: 0, scheduled: 0 };
      if (visit.isCompleted) current.completed += 1;
      else current.scheduled += 1;
      areaMap.set(areaName, current);
    });

    const toVisitRow = (visit) => ({
      id: visit._id,
      visitNumber: visit.visitNumber,
      customer: visit.customerId,
      date: visit.scheduledDate,
      slotId: visit.bookingId?.slotId || visit.slotId,
      status: visit.isCompleted ? 'Completed' : visit.isCancelled ? 'Cancelled' : 'Scheduled',
    });

    return res.json({
      kpis: {
        todayVisits: todayVisits.length,
        completedToday,
        pendingToday,
        rescheduledToday: 0,
        activeSubscriptions,
        renewalsDueSoon: 0,
        renewalsDue: 0,
        todaysCollection: todayPayments.reduce((total, payment) => total + (payment.amount || 0), 0),
        mtdCollection: monthPayments.reduce((total, payment) => total + (payment.amount || 0), 0),
      },
      areaWorkload: [...areaMap.values()],
      recentBookings: recentBookings.map((booking) => ({
        id: booking._id,
        bookingNumber: booking.bookingId,
        customer: booking.customerId,
        confirmedOn: booking.updatedAt,
        total: booking.totalAmount || 0,
      })),
      upcomingVisits: upcomingVisits.map(toVisitRow),
      exceptions: {
        staleDrafts: staleDrafts.map((booking) => ({ id: booking._id, bookingNumber: booking.bookingId })),
      },
    });
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching dashboard summary', error: error.message });
  }
};
