import { describe, expect, it } from "@jest/globals";
import { buildFullyLoadedCostTotals } from "../src/modules/fully-loaded-cost/utils/fully-loaded-cost-report-totals.js";

describe("fully loaded cost report totals", () => {
  it("calculates and preserves the uploaded section and grand totals", () => {
    const rows = [
      { data: { "Direct Cost": "Salary", "Cost Per Annum (RS)": "3,00,000", "Cost Per Month (RS)": "25,000" } },
      { data: { "Direct Cost": "Life insurance", "Cost Per Annum (RS)": "6,453", "Cost Per Month (RS)": "538" } },
      { data: { "Direct Cost": "Health Insurance", "Cost Per Annum (RS)": "12,000", "Cost Per Month (RS)": "1,000" } },
      { data: { "Direct Cost": "Holiday Bonus", "Cost Per Annum (RS)": "6,000", "Cost Per Month (RS)": "500" } },
      { data: { "Direct Cost": "Special Professional certification reimbursement", "Cost Per Annum (RS)": "4,500", "Cost Per Month (RS)": "375" } },
      { data: { "Direct Cost": "Total Direct Labour", "Cost Per Annum (RS)": "3,28,953", "Cost Per Month (RS)": "27,413" } },
      { data: { "Direct Cost": "Dedicated Employee resource (Depreciation)", "Cost Per Annum (RS)": "18,294", "Cost Per Month (RS)": "1,525" } },
      { data: { "Direct Cost": "Dedicated Employee software access cost", "Cost Per Annum (RS)": "72,306", "Cost Per Month (RS)": "6,026" } },
      { data: { "Direct Cost": "Total Direct Material", "Cost Per Annum (RS)": "90,600", "Cost Per Month (RS)": "7,550" } },
      { data: { "Direct Cost": "Total Direct Cost", "Cost Per Annum (RS)": "4,19,553", "Cost Per Month (RS)": "34,963" } },
      { data: { "Variable Cost": "Office Rent", "Total Cost": "6,54,720", Ratio: "0.11", "Cost Per Annum (RS)": "72,747", "Cost Per Month (RS)": "6,062" } },
      { data: { "Variable Cost": "Total Variable cost", "Total Cost": "12,75,586", "Cost Per Annum (RS)": "1,41,732", "Cost Per Month (RS)": "11,811" } },
      { data: { "Fixed Cost": "Air conditioner", "Total Cost": "13,942", Ratio: "0.11", "Cost Per Annum (RS)": "1,549", "Cost Per Month (RS)": "129" } },
      { data: { "Fixed Cost": "Total Fixed cost depreciation", "Cost Per Annum (RS)": "6,006", "Cost Per Month (RS)": "500" } },
      { data: { "Fixed Cost": "Total Direct Cost + Total Variable cost", "Cost Per Annum (RS)": "5,61,285", "Cost Per Month (RS)": "46,774" } },
      { data: { "Fixed Cost": "Total Direct Cost + Total Variable cost + Total Fixed Cost depreciation", "Cost Per Annum (RS)": "5,67,291", "Cost Per Month (RS)": "47,274" } },
    ];

    expect(buildFullyLoadedCostTotals(rows)).toMatchObject({
      directLabour: { annual: 328953, monthly: 27413 },
      directMaterial: { annual: 90600, monthly: 7550 },
      directCost: { annual: 419553, monthly: 34963 },
      variableCost: { totalCost: 1275586, annual: 141732, monthly: 11811 },
      directCostAndVariableCost: { annual: 561285, monthly: 46774 },
      fixedCostDepreciation: { annual: 6006, monthly: 500 },
      totalFullyLoadedCost: { annual: 567291, monthly: 47274 },
    });
  });

  it("derives totals from detail rows when explicit subtotal rows are absent", () => {
    const rows = [
      { data: { "Direct Cost": "Salary", "Cost Per Annum (RS)": "120,000" } },
      { data: { "Direct Cost": "Dedicated Employee resource (Depreciation)", "Cost Per Annum (RS)": "12,000" } },
      { data: { "Fixed Cost": "Air conditioner", "Total Cost": "10,000", "Cost Per Annum (RS)": "1,000" } },
    ];

    expect(buildFullyLoadedCostTotals(rows)).toMatchObject({
      directCost: { annual: 132000, monthly: 11000 },
      fixedCostDepreciation: { totalCost: 10000, annual: 1000, monthly: 83 },
      totalFullyLoadedCost: { annual: 133000, monthly: 11083 },
    });
  });
});
