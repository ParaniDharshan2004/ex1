import express from 'express';
import { authenticateUser } from '../../../shared/middleware/auth-middleware.js';
import {
  createHandler,
  getAllHandler,
  getByIdHandler,
  updateHandler,
  deleteHandler,
} from '../controllers/fully-loaded-cost-controller.js';
import {
  approveFullyLoadedCostReport,
  createFullyLoadedCostReport,
  deleteFullyLoadedCostReport,
  getFullyLoadedCostReportById,
  getFullyLoadedCostReports,
} from '../controllers/fully-loaded-cost-report-controller.js';

const router = express.Router();

router.post('/reports', authenticateUser, createFullyLoadedCostReport);
router.get('/reports', authenticateUser, getFullyLoadedCostReports);
router.get('/reports/:id', authenticateUser, getFullyLoadedCostReportById);
router.patch('/reports/:id/approve', authenticateUser, approveFullyLoadedCostReport);
router.delete('/reports/:id', authenticateUser, deleteFullyLoadedCostReport);

const resources = [
  'departments',
  'teams',
  'employees',
  'employee-salaries',
  'certification-reimbursements',
  'holiday-bonuses',
  'resource-categories',
  'resource-items',
  'resource-assignments',
  'software-categories',
  'software-items',
  'insurance-categories',
  'insurance-items',
  'insurance-premiums',
  'fixed-asset-register',
  'fixed-asset-values',
  'depreciation-configurations',
  'fixed-asset-depreciations',
  'fixed-asset-assignments',
];

for (const resource of resources) {
  router.post(`/${resource}`, authenticateUser, createHandler(resource));
  router.get(`/${resource}`, authenticateUser, getAllHandler(resource));
  router.get(`/${resource}/:id`, authenticateUser, getByIdHandler(resource));
  router.patch(`/${resource}/:id`, authenticateUser, updateHandler(resource));
  router.delete(`/${resource}/:id`, authenticateUser, deleteHandler(resource));
}

export default router;
