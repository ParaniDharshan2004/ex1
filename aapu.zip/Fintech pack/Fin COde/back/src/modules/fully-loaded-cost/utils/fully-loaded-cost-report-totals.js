const normalizeText = (value) =>
  String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

const normalizeAmount = (value) => {
  const numeric = Number(String(value ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(numeric) ? Math.max(0, numeric) : 0;
};

const findValue = (data, keys) => {
  const normalizedKeys = keys.map(normalizeText);
  const entry = Object.entries(data || {}).find(([key]) =>
    normalizedKeys.includes(normalizeText(key)),
  );
  return entry?.[1];
};

const getRowName = (data) =>
  findValue(data, [
    "category",
    "subcategory",
    "item",
    "name",
    "description",
    "particular",
    "particulars",
    "ledger",
    "asset",
    "resource",
    "direct cost",
    "fixed cost",
    "variable cost",
    "indirect overhead cost",
  ])?.toString().trim() || "";

const getRowValues = (data) => {
  const annualAmount = normalizeAmount(
    findValue(data, [
      "cost per annum",
      "cost per annum rs",
      "cost per year",
      "annual cost",
      "annual amount",
      "annual salary",
      "annual",
    ]),
  );
  const monthlyAmount = normalizeAmount(
    findValue(data, [
      "cost per month",
      "cost per month rs",
      "monthly cost",
      "monthly amount",
      "monthly salary",
      "monthly",
    ]),
  );
  const amount = normalizeAmount(
    findValue(data, ["amount", "cost", "total", "purchase cost", "premium amount"]),
  );

  return {
    annualAmount: annualAmount || amount || monthlyAmount * 12,
    monthlyAmount: monthlyAmount || amount / 12 || annualAmount / 12,
    totalCost: normalizeAmount(findValue(data, ["total cost", "purchase cost"])),
    ratio: normalizeAmount(findValue(data, ["ratio"])),
  };
};

const isMatch = (name, aliases) => {
  const normalizedName = normalizeText(name);
  return aliases.some((alias) => normalizedName.includes(normalizeText(alias)));
};

const classifyRow = (name) => {
  if (
    isMatch(name, [
      "salary",
      "life insurance",
      "health insurance",
      "holiday bonus",
      "special professional certification reimbursement",
    ])
  ) {
    return "directLabour";
  }
  if (
    isMatch(name, [
      "dedicated employee resource",
      "dedicated employee software",
      "software access cost",
    ])
  ) {
    return "directMaterial";
  }
  if (
    isMatch(name, [
      "air conditioner",
      "furniture",
      "printer",
      "inverter",
      "ups",
      "mobile phone",
      "security camera",
      "water dispenser",
    ])
  ) {
    return "fixedCostDepreciation";
  }
  if (
    isMatch(name, [
      "office rent",
      "electricity",
      "travel",
      "internet",
      "phone",
      "food",
      "water",
      "small tools",
      "equipment",
      "software",
      "bank charges",
      "professional fees",
      "registration",
      "legal expenses",
      "marketing",
      "advertisement",
      "liability insurance",
      "employee recognition",
      "rewards",
      "employee related events",
      "trips",
      "misc office",
    ])
  ) {
    return "variableCost";
  }
  return null;
};

const getSummaryKey = (name) => {
  if (!normalizeText(name).startsWith("total")) return null;
  if (isMatch(name, ["totaldirectlabour"])) return "directLabour";
  if (isMatch(name, ["totaldirectmaterial"])) return "directMaterial";
  if (
    isMatch(name, [
      "totaldirectcosttotalvariablecosttotalfixedcostdepreciation",
    ])
  ) {
    return "totalFullyLoadedCost";
  }
  if (isMatch(name, ["totaldirectcosttotalvariablecost"])) {
    return "directCostAndVariableCost";
  }
  if (isMatch(name, ["totaldirectcost"])) return "directCost";
  if (isMatch(name, ["totalvariablecost"])) return "variableCost";
  if (isMatch(name, ["totalfixedcostdepreciation"])) {
    return "fixedCostDepreciation";
  }
  return null;
};

const emptySummary = () => ({
  totalCost: 0,
  annual: 0,
  monthly: 0,
  ratio: 0,
});

export const buildFullyLoadedCostTotals = (rows = []) => {
  const categories = {
    directLabour: emptySummary(),
    directMaterial: emptySummary(),
    variableCost: emptySummary(),
    fixedCostDepreciation: emptySummary(),
  };
  const explicitTotals = {};

  rows.forEach((row) => {
    const data = row?.data || row || {};
    const name = getRowName(data);
    if (!name) return;

    const values = getRowValues(data);
    const summaryKey = getSummaryKey(name);
    if (summaryKey) {
      explicitTotals[summaryKey] = values;
      return;
    }

    const category = classifyRow(name);
    if (!category) return;

    categories[category].totalCost += values.totalCost;
    categories[category].annual += values.annualAmount;
    categories[category].monthly += values.monthlyAmount;
    categories[category].ratio = Math.max(
      categories[category].ratio,
      values.ratio,
    );
  });

  const roundedMonthly = (annual) => Math.round(annual / 12);
  Object.entries(categories).forEach(([key, summary]) => {
    summary.monthly = Math.round(summary.monthly);
    if (explicitTotals[key]?.annualAmount) {
      summary.annual = explicitTotals[key].annualAmount;
      summary.monthly =
        explicitTotals[key].monthlyAmount || roundedMonthly(summary.annual);
    }
    if (explicitTotals[key]?.totalCost) {
      summary.totalCost = explicitTotals[key].totalCost;
    }
  });

  const directCost = {
    totalCost: categories.directLabour.totalCost + categories.directMaterial.totalCost,
    annual: categories.directLabour.annual + categories.directMaterial.annual,
    monthly:
      categories.directLabour.monthly + categories.directMaterial.monthly,
    ratio: 0,
  };
  if (explicitTotals.directCost?.annualAmount) {
    directCost.annual = explicitTotals.directCost.annualAmount;
    directCost.monthly =
      explicitTotals.directCost.monthlyAmount || roundedMonthly(directCost.annual);
    directCost.totalCost = explicitTotals.directCost.totalCost || directCost.totalCost;
  }

  const directCostAndVariableCost = {
    totalCost: directCost.totalCost + categories.variableCost.totalCost,
    annual: directCost.annual + categories.variableCost.annual,
    monthly: directCost.monthly + categories.variableCost.monthly,
    ratio: 0,
  };
  if (explicitTotals.directCostAndVariableCost?.annualAmount) {
    directCostAndVariableCost.annual =
      explicitTotals.directCostAndVariableCost.annualAmount;
    directCostAndVariableCost.monthly =
      explicitTotals.directCostAndVariableCost.monthlyAmount ||
      roundedMonthly(directCostAndVariableCost.annual);
  }

  const totalFullyLoadedCost = {
    totalCost:
      directCostAndVariableCost.totalCost +
      categories.fixedCostDepreciation.totalCost,
    annual:
      directCostAndVariableCost.annual +
      categories.fixedCostDepreciation.annual,
    monthly:
      directCostAndVariableCost.monthly +
      categories.fixedCostDepreciation.monthly,
    ratio: 0,
  };
  if (explicitTotals.totalFullyLoadedCost?.annualAmount) {
    totalFullyLoadedCost.annual =
      explicitTotals.totalFullyLoadedCost.annualAmount;
    totalFullyLoadedCost.monthly =
      explicitTotals.totalFullyLoadedCost.monthlyAmount ||
      roundedMonthly(totalFullyLoadedCost.annual);
  }

  return {
    ...categories,
    directCost,
    directCostAndVariableCost,
    totalFullyLoadedCost,
  };
};

export const getFullyLoadedCostRowName = getRowName;
export const getFullyLoadedCostRowValues = getRowValues;
export const getFullyLoadedCostRowCategory = classifyRow;
export const getFullyLoadedCostRowSummaryKey = getSummaryKey;
