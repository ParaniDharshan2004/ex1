import mongoose from 'mongoose';

const insuranceCategorySchema = new mongoose.Schema(
  {
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CompanyMaster',
      required: true,
    },
    categoryName: { type: String, required: true, trim: true },
    description: { type: String, default: '', trim: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'insurance_categories' },
);

export default mongoose.model('InsuranceCategory', insuranceCategorySchema);
