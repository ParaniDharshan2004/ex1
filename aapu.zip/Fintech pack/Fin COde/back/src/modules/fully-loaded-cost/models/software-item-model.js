import mongoose from 'mongoose';

const softwareItemSchema = new mongoose.Schema(
  {
    softwareCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'SoftwareCategory',
      required: true,
    },
    empId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'DirectCostEmployee',
      default: null,
    },
    softwareName: { type: String, required: true, trim: true },
    vendor: { type: String, default: '', trim: true },
    contactDetails: { type: String, default: '', trim: true },
    frequency: { type: String, default: '', trim: true },
    amount: { type: Number, default: 0, min: 0 },
    purchasedDate: { type: Date, default: null },
    renewalDate: { type: Date, default: null },
    remainingDays: { type: Number, default: 0 },
    status: {
      type: String,
      enum: ['active', 'inactive', 'expired'],
      default: 'active',
    },
    remarks: { type: String, default: '', trim: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'software_items' },
);

export default mongoose.model('SoftwareItem', softwareItemSchema);
