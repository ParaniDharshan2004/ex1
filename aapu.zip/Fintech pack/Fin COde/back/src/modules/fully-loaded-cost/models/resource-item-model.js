import mongoose from 'mongoose';

const resourceItemSchema = new mongoose.Schema(
  {
    resourceCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ResourceCategory',
      required: true,
    },
    assetCode: { type: String, trim: true, uppercase: true },
    serialNumber: { type: String, trim: true },
    asset: { type: String, trim: true },
    assetName: { type: String, required: true, trim: true },
    brand: { type: String, default: '', trim: true },
    purchaseFrom: { type: String, default: '', trim: true },
    purchaseCost: { type: Number, default: 0, min: 0 },
    invoiceDate: { type: Date, default: null },
    warrantyDate: { type: Date, default: null },
    status: {
      type: String,
      enum: ['active', 'inactive', 'maintenance', 'disposed'],
      default: 'active',
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'resource_items' },
);

export default mongoose.model('ResourceItem', resourceItemSchema);
