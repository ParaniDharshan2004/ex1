import mongoose from 'mongoose';

const insuranceItemSchema = new mongoose.Schema(
  {
    insuranceCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'InsuranceCategory',
      required: true,
    },
    empId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'DirectCostEmployee',
      default: null,
    },
    policyNo: { type: String, required: true, trim: true },
    policyName: { type: String, required: true, trim: true },
    riderOpted: { type: String, default: '', trim: true },
    riderAvailable: { type: Number, default: 0 },
    provider: { type: String, default: '', trim: true },
    frequency: { type: String, default: '', trim: true },
    effectiveFrom: { type: Date, required: true },
    renewalDate: { type: Date, default: null },
    remainingPolicyTerm: { type: Number, default: 0 },
    remarks: { type: String, default: '', trim: true },
    status: {
      type: String,
      enum: ['active', 'inactive', 'expired'],
      default: 'active',
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'insurance_items' },
);

export default mongoose.model('InsuranceItem', insuranceItemSchema);
