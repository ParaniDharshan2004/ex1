import mongoose from 'mongoose';

const rowSchema = new mongoose.Schema(
  {
    rowNumber: { type: Number, default: null },
    data: { type: mongoose.Schema.Types.Mixed, default: {} },
  },
  { _id: false },
);

const structuredCostRowSchema = new mongoose.Schema(
  {
    name: { type: String, default: '', trim: true },
    amount: { type: Number, default: 0, min: 0 },
    totalCost: { type: Number, default: 0, min: 0 },
    annualAmount: { type: Number, default: 0, min: 0 },
    monthlyAmount: { type: Number, default: 0, min: 0 },
    ratio: { type: Number, default: 0, min: 0 },
    estimated: { type: Boolean, default: false },
  },
  { _id: false },
);

const costTotalSchema = new mongoose.Schema(
  {
    totalCost: { type: Number, default: 0, min: 0 },
    annual: { type: Number, default: 0, min: 0 },
    monthly: { type: Number, default: 0, min: 0 },
    ratio: { type: Number, default: 0, min: 0 },
  },
  { _id: false },
);

const structuredSectionSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    rows: { type: [structuredCostRowSchema], default: [] },
  },
  { _id: false },
);

const reportSchema = new mongoose.Schema(
  {
    reportCode: { type: String, required: true, trim: true, uppercase: true },
    reportName: { type: String, required: true, trim: true },
    reportMonth: {
      type: String,
      required: true,
      trim: true,
      match: [
        /^\d{4}-(0[1-9]|1[0-2])$/,
        'Report month must use YYYY-MM format',
      ],
    },
    sourceFileName: { type: String, default: '', trim: true },
    worksheetName: { type: String, default: '', trim: true },
    headers: { type: [String], default: [] },
    rows: { type: [rowSchema], default: [] },
    sections: { type: [structuredSectionSchema], default: [] },
    totals: {
      directLabour: { type: costTotalSchema, default: () => ({}) },
      directMaterial: { type: costTotalSchema, default: () => ({}) },
      directCost: { type: costTotalSchema, default: () => ({}) },
      variableCost: { type: costTotalSchema, default: () => ({}) },
      directCostAndVariableCost: {
        type: costTotalSchema,
        default: () => ({}),
      },
      fixedCostDepreciation: { type: costTotalSchema, default: () => ({}) },
      totalFullyLoadedCost: { type: costTotalSchema, default: () => ({}) },
    },
    totalAmount: { type: Number, default: 0, min: 0 },
    status: {
      type: String,
      enum: ['DRAFT', 'APPROVED'],
      default: 'DRAFT',
    },
    approvedAt: { type: Date, default: null },
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  { timestamps: true, collection: 'fully_loaded_cost_reports' },
);

reportSchema.index({ reportCode: 1 }, { unique: true });
reportSchema.index({ reportMonth: 1 }, { unique: true });

export default mongoose.model('FullyLoadedCostReport', reportSchema);
