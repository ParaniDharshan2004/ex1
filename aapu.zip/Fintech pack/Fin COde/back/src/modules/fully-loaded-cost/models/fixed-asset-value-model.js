import mongoose from "mongoose";

const fixedAssetValueSchema = new mongoose.Schema(
  {
    assetRegisterId: { type: mongoose.Schema.Types.ObjectId, ref: "FixedAssetRegister", required: true },
    assetValue: { type: Number, required: true, min: 0 },
    valuationType: { type: String, default: "", trim: true },
    currency: { type: String, default: "INR", trim: true, uppercase: true },
    effectiveFrom: { type: Date, required: true },
    effectiveTo: { type: Date, default: null },
    isActive: { type: Boolean, default: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  },
  { timestamps: true, collection: "fixed_asset_values" }
);

export default mongoose.model("FixedAssetValue", fixedAssetValueSchema);
