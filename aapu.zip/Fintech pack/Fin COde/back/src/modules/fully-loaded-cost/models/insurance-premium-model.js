import mongoose from 'mongoose';

const insurancePremiumSchema = new mongoose.Schema(
  {
    insuranceItemId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'InsuranceItem',
      required: true,
    },
    effectiveYear: { type: Number, required: true },
    premiumAmount: { type: Number, required: true, min: 0 },
    isActive: { type: Boolean, default: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'insurance_premium_history' },
);

export default mongoose.model('InsurancePremium', insurancePremiumSchema);
