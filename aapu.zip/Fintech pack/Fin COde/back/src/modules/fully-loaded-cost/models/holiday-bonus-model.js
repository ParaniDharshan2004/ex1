import mongoose from 'mongoose';

const holidayBonusSchema = new mongoose.Schema(
  {
    empId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'DirectCostEmployee',
      required: true,
    },
    amount: { type: Number, required: true, min: 0 },
    effectiveYear: { type: Number, required: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'holiday_bonuses' },
);

export default mongoose.model('HolidayBonus', holidayBonusSchema);
