import mongoose from "mongoose";

const fixedAssetAssignmentSchema = new mongoose.Schema(
  {
    assetRegisterId: { type: mongoose.Schema.Types.ObjectId, ref: "FixedAssetRegister", required: true },
    empId: { type: mongoose.Schema.Types.ObjectId, ref: "DirectCostEmployee", default: null },
    deptId: { type: mongoose.Schema.Types.ObjectId, ref: "DirectCostDepartment", default: null },
    assignedToType: { type: String, enum: ["employee", "department"], required: true },
    assignedDate: { type: Date, required: true },
    returnedDate: { type: Date, default: null },
    assignmentStatus: { type: String, enum: ["assigned", "returned"], default: "assigned" },
    remarks: { type: String, default: "", trim: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  },
  { timestamps: true, collection: "fixed_asset_assignment_history" }
);

export default mongoose.model("FixedAssetAssignment", fixedAssetAssignmentSchema);
