import mongoose from 'mongoose';

const teamSchema = new mongoose.Schema(
  {
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CompanyMaster',
      required: true,
    },
    teamCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
    },
    teamName: { type: String, required: true, trim: true },
    description: { type: String, default: '', trim: true },
    isActive: { type: Boolean, default: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'teams' },
);

export default mongoose.model('DirectCostTeam', teamSchema);
