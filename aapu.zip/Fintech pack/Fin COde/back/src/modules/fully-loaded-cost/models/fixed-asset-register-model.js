import mongoose from "mongoose";

const fixedAssetRegisterSchema = new mongoose.Schema(
  {
    compId: { type: mongoose.Schema.Types.ObjectId, ref: "CompanyMaster", required: true },
    assetId: { type: mongoose.Schema.Types.ObjectId, ref: "FixedAssetMaster", required: true },
    assetCode: { type: String, required: true, trim: true, uppercase: true },
    serialNumber: { type: String, default: "", trim: true },
    assetName: { type: String, required: true, trim: true },
    brand: { type: String, default: "", trim: true },
    model: { type: String, default: "", trim: true },
    vendor: { type: String, default: "", trim: true },
    purchaseDate: { type: Date, required: true },
    purchaseCost: { type: Number, required: true, min: 0 },
    location: { type: String, default: "", trim: true },
    status: { type: String, enum: ["active", "inactive", "disposed"], default: "active" },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  },
  { timestamps: true, collection: "fixed_asset_register" }
);

fixedAssetRegisterSchema.index({ assetCode: 1 }, { unique: true });

export default mongoose.model("FixedAssetRegister", fixedAssetRegisterSchema);
