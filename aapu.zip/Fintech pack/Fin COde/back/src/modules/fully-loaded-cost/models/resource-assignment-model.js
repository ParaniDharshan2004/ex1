import mongoose from 'mongoose';

const resourceAssignmentSchema = new mongoose.Schema(
  {
    resourceItemId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ResourceItem',
      required: true,
    },
    empId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'DirectCostEmployee',
      required: true,
    },
    assignedDate: { type: Date, required: true },
    returnedDate: { type: Date, default: null },
    assignmentStatus: {
      type: String,
      enum: ['assigned', 'returned'],
      default: 'assigned',
    },
    remarks: { type: String, default: '', trim: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'resource_assignment_history' },
);

export default mongoose.model('ResourceAssignment', resourceAssignmentSchema);
