import mongoose from 'mongoose';

const directCostEmployeeSchema = new mongoose.Schema(
  {
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CompanyMaster',
      required: true,
    },
    deptId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'DirectCostDepartment',
      required: true,
    },
    teamId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'DirectCostTeam',
      default: null,
    },
    empCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
    },
    empName: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true, lowercase: true },
    designation: { type: String, default: '', trim: true },
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'direct_cost_employees' },
);

export default mongoose.model('DirectCostEmployee', directCostEmployeeSchema);
