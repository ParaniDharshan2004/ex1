import mongoose from "mongoose";

const depreciationConfigurationSchema = new mongoose.Schema(
  {
    compId: { type: mongoose.Schema.Types.ObjectId, ref: "CompanyMaster", required: true },
    depreciationMethod: { type: String, required: true, trim: true },
    depreciationPercentage: { type: Number, default: 0, min: 0 },
    scrapValuePercentage: { type: Number, default: 0, min: 0 },
    residualValue: { type: Number, default: 0, min: 0 },
    usefulLifeYears: { type: Number, required: true, min: 0 },
    depreciationFrequency: { type: String, default: "YEARLY", trim: true },
    isActive: { type: Boolean, default: true },
    effectiveFrom: { type: Date, required: true },
    effectiveTo: { type: Date, default: null },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  },
  { timestamps: true, collection: "depreciation_configurations" }
);

export default mongoose.model("DepreciationConfiguration", depreciationConfigurationSchema);
