import mongoose from 'mongoose';

const softwareCategorySchema = new mongoose.Schema(
  {
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CompanyMaster',
      required: true,
    },
    softwareType: { type: String, required: true, trim: true },
    description: { type: String, default: '', trim: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'software_categories' },
);

export default mongoose.model('SoftwareCategory', softwareCategorySchema);
