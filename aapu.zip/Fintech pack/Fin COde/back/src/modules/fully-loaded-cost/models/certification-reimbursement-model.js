import mongoose from 'mongoose';

const certificationReimbursementSchema = new mongoose.Schema(
  {
    empId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'DirectCostEmployee',
      required: true,
    },
    certificationName: { type: String, required: true, trim: true },
    provider: { type: String, default: '', trim: true },
    amount: { type: Number, required: true, min: 0 },
    reimbursementDate: { type: Date, required: true },
    effectiveYear: { type: Number, required: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'professional_certification_reimbursements' },
);

export default mongoose.model(
  'CertificationReimbursement',
  certificationReimbursementSchema,
);
