import mongoose from "mongoose";

const fixedAssetDepreciationSchema = new mongoose.Schema(
  {
    assetValueId: { type: mongoose.Schema.Types.ObjectId, ref: "FixedAssetValue", required: true },
    depreciationConfigId: { type: mongoose.Schema.Types.ObjectId, ref: "DepreciationConfiguration", required: true },
    financialYear: { type: String, required: true, trim: true },
    periodStart: { type: Date, required: true },
    periodEnd: { type: Date, required: true },
    openingWDV: { type: Number, default: 0, min: 0 },
    depreciationAmount: { type: Number, default: 0, min: 0 },
    accumulatedDepreciation: { type: Number, default: 0, min: 0 },
    closingWDV: { type: Number, default: 0, min: 0 },
    calculatedAt: { type: Date, default: Date.now },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  },
  { timestamps: true, collection: "fixed_asset_depreciations" }
);

export default mongoose.model("FixedAssetDepreciation", fixedAssetDepreciationSchema);
