import mongoose from 'mongoose';

const directCostDepartmentSchema = new mongoose.Schema(
  {
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CompanyMaster',
      required: true,
    },
    deptCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
    },
    deptName: { type: String, required: true, trim: true },
    isActive: { type: Boolean, default: true },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true, collection: 'fl_departments' },
);

export default mongoose.model(
  'DirectCostDepartment',
  directCostDepartmentSchema,
);
