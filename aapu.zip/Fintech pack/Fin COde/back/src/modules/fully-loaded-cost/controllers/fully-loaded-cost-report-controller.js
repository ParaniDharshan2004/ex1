import mongoose from "mongoose";
import FullyLoadedCostReport from "../models/fully-loaded-cost-report-model.js";
import {
  buildFullyLoadedCostTotals,
  getFullyLoadedCostRowCategory,
  getFullyLoadedCostRowName,
  getFullyLoadedCostRowSummaryKey,
  getFullyLoadedCostRowValues,
} from "../utils/fully-loaded-cost-report-totals.js";

const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

const actor = (req) => req.user?.userId || req.user?.id || null;

const normalizeAmount = (value) => {
  const numeric = Number(String(value ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(numeric) ? Math.max(0, numeric) : 0;
};

const normalizeText = (value) =>
  String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

const buildStructuredSections = (normalizedRows) => {
  const sections = [
    { title: "Direct Labour", rows: [] },
    { title: "Direct Material", rows: [] },
    { title: "Variable Cost", rows: [] },
    { title: "Fixed Cost", rows: [] },
  ];
  const unclassified = [];

  normalizedRows.forEach((row) => {
    const name = getFullyLoadedCostRowName(row.data);
    if (!name) return;
    if (getFullyLoadedCostRowSummaryKey(name)) return;
    if (
      [
        "directcost",
        "directlabour",
        "directmaterial",
        "variablecost",
        "fixedcost",
        "fixedcostdepreciation",
        "indirectoverheadcost",
      ].includes(normalizeText(name))
    ) {
      return;
    }

    const values = getFullyLoadedCostRowValues(row.data);
    const outputRow = {
      name,
      amount: values.annualAmount,
      totalCost: values.totalCost,
      annualAmount: values.annualAmount,
      monthlyAmount: values.monthlyAmount,
      ratio: values.ratio,
      estimated: [
        "bank charges",
        "professional fees",
        "registration",
        "small tools",
        "software",
        "employee recognition",
        "employee related events",
        "trips",
        "misc office",
      ].some((alias) => normalizeText(name).includes(normalizeText(alias))),
    };

    const category = getFullyLoadedCostRowCategory(name);
    if (category === "directLabour") sections[0].rows.push(outputRow);
    else if (category === "directMaterial") sections[1].rows.push(outputRow);
    else if (category === "fixedCostDepreciation") sections[3].rows.push(outputRow);
    else if (category === "variableCost") sections[2].rows.push(outputRow);
    else unclassified.push(outputRow);
  });

  if (unclassified.length > 0) {
    sections.splice(3, 0, {
      title: "Unclassified",
      rows: unclassified,
    });
  }

  return sections.filter((section) => section.rows.length > 0);
};

export const createFullyLoadedCostReport = async (req, res) => {
  try {
    const { reportMonth, reportName, sourceFileName, worksheetName, headers, rows } = req.body;

    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(reportMonth || ""))) {
      return fail(res, 400, "Report month must use YYYY-MM format");
    }
    if (!reportName?.trim()) return fail(res, 400, "Report name is required");
    if (!Array.isArray(rows)) return fail(res, 400, "Rows must be an array");
    if (await FullyLoadedCostReport.exists({ reportMonth })) {
      return fail(res, 409, `A Fully Loaded Cost report already exists for ${reportMonth}`);
    }

    const normalizedRows = rows
      .filter((row) => row && typeof row === "object")
      .map((row, index) => ({
        rowNumber: Number(row.rowNumber) || index + 2,
        data: row.data || row,
      }));

    const sections = buildStructuredSections(normalizedRows);
    const totals = buildFullyLoadedCostTotals(normalizedRows);

    const amountKeys = ["amount", "cost", "total", "annualsalary", "monthlysalary", "premiumamount", "purchasecost"];
    const rawAmountTotal = normalizedRows.reduce((sum, row) => {
      const amountEntry = Object.entries(row.data).find(([key]) =>
        amountKeys.includes(key.toLowerCase().replace(/[^a-z]/g, ""))
      );
      return sum + normalizeAmount(amountEntry?.[1]);
    }, 0);
    const totalAmount =
      totals.totalFullyLoadedCost.annual || rawAmountTotal;

    const report = await FullyLoadedCostReport.create({
      reportCode: `FLC-${reportMonth}`,
      reportName: reportName.trim(),
      reportMonth,
      sourceFileName: sourceFileName || "",
      worksheetName: worksheetName || "",
      headers: Array.isArray(headers) ? headers : [],
      rows: normalizedRows,
      sections,
      totals,
      totalAmount,
      status: "DRAFT",
      createdBy: actor(req),
      updatedBy: actor(req),
    });

    return res.status(201).json({ success: true, data: report });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};

export const getFullyLoadedCostReports = async (req, res) => {
  try {
    const reports = await FullyLoadedCostReport.find()
      .select("reportCode reportName reportMonth sourceFileName worksheetName totalAmount status approvedAt createdAt")
      .sort({ reportMonth: -1, createdAt: -1 });
    return res.json({ success: true, data: reports });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};

export const getFullyLoadedCostReportById = async (req, res) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    return fail(res, 400, "Invalid report ID");
  }

  try {
    const report = await FullyLoadedCostReport.findById(req.params.id);
    if (!report) return fail(res, 404, "Report not found");
    return res.json({ success: true, data: report });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};

export const approveFullyLoadedCostReport = async (req, res) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    return fail(res, 400, "Invalid report ID");
  }

  try {
    const report = await FullyLoadedCostReport.findById(req.params.id);
    if (!report) return fail(res, 404, "Report not found");

    report.status = "APPROVED";
    report.approvedAt = new Date();
    report.approvedBy = actor(req);
    report.updatedBy = actor(req);
    await report.save();

    return res.json({ success: true, data: report });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};

export const deleteFullyLoadedCostReport = async (req, res) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    return fail(res, 400, "Invalid report ID");
  }

  try {
    const report = await FullyLoadedCostReport.findByIdAndDelete(req.params.id);
    if (!report) return fail(res, 404, "Report not found");
    return res.json({ success: true, data: report });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};
