import mongoose from 'mongoose';
import DirectCostDepartment from '../models/department-model.js';
import DirectCostTeam from '../models/team-model.js';
import DirectCostEmployee from '../models/direct-cost-employee-model.js';
import EmployeeSalary from '../models/employee-salary-model.js';
import CertificationReimbursement from '../models/certification-reimbursement-model.js';
import HolidayBonus from '../models/holiday-bonus-model.js';
import ResourceCategory from '../models/resource-category-model.js';
import ResourceItem from '../models/resource-item-model.js';
import ResourceAssignment from '../models/resource-assignment-model.js';
import SoftwareCategory from '../models/software-category-model.js';
import SoftwareItem from '../models/software-item-model.js';
import InsuranceCategory from '../models/insurance-category-model.js';
import InsuranceItem from '../models/insurance-item-model.js';
import InsurancePremium from '../models/insurance-premium-model.js';
import FixedAssetRegister from '../models/fixed-asset-register-model.js';
import FixedAssetValue from '../models/fixed-asset-value-model.js';
import DepreciationConfiguration from '../models/depreciation-configuration-model.js';
import FixedAssetDepreciation from '../models/fixed-asset-depreciation-model.js';
import FixedAssetAssignment from '../models/fixed-asset-assignment-model.js';

const MODELS = {
  departments: [DirectCostDepartment, 'companyId', null],
  teams: [DirectCostTeam, 'companyId', null],
  employees: [DirectCostEmployee, 'companyId deptId teamId', null],
  'employee-salaries': [EmployeeSalary, 'empId', null],
  'certification-reimbursements': [CertificationReimbursement, 'empId', null],
  'holiday-bonuses': [HolidayBonus, 'empId', null],
  'resource-categories': [ResourceCategory, 'companyId', null],
  'resource-items': [ResourceItem, 'resourceCategoryId', null],
  'resource-assignments': [ResourceAssignment, 'resourceItemId empId', null],
  'software-categories': [SoftwareCategory, 'companyId', null],
  'software-items': [SoftwareItem, 'softwareCategoryId empId', null],
  'insurance-categories': [InsuranceCategory, 'companyId', null],
  'insurance-items': [InsuranceItem, 'insuranceCategoryId empId', null],
  'insurance-premiums': [InsurancePremium, 'insuranceItemId', null],
  'fixed-asset-register': [FixedAssetRegister, 'compId assetId', null],
  'fixed-asset-values': [FixedAssetValue, 'assetRegisterId', null],
  'depreciation-configurations': [DepreciationConfiguration, 'compId', null],
  'fixed-asset-depreciations': [
    FixedAssetDepreciation,
    'assetValueId depreciationConfigId',
    null,
  ],
  'fixed-asset-assignments': [
    FixedAssetAssignment,
    'assetRegisterId empId deptId',
    null,
  ],
};

const actor = (req) => req.user?.userId || req.user?.id || null;
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

export const createHandler = (resource) => async (req, res) => {
  const entry = MODELS[resource];
  if (!entry) return fail(res, 404, 'Resource not found');

  try {
    const [Model] = entry;
    const data = await Model.create({
      ...req.body,
      createdBy: actor(req),
      updatedBy: actor(req),
    });
    return res.status(201).json({ success: true, data });
  } catch (error) {
    return fail(res, 400, error.message);
  }
};

export const getAllHandler = (resource) => async (req, res) => {
  const entry = MODELS[resource];
  if (!entry) return fail(res, 404, 'Resource not found');

  try {
    const [Model, populate] = entry;
    let query = Model.find();
    if (populate) query = query.populate(populate);
    const data = await query.sort({ createdAt: -1 });
    return res.json({ success: true, data });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};

export const getByIdHandler = (resource) => async (req, res) => {
  const entry = MODELS[resource];
  if (!entry) return fail(res, 404, 'Resource not found');
  if (!mongoose.Types.ObjectId.isValid(req.params.id))
    return fail(res, 400, 'Invalid ID');

  try {
    const [Model, populate] = entry;
    let query = Model.findById(req.params.id);
    if (populate) query = query.populate(populate);
    const data = await query;
    if (!data) return fail(res, 404, 'Record not found');
    return res.json({ success: true, data });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};

export const updateHandler = (resource) => async (req, res) => {
  const entry = MODELS[resource];
  if (!entry) return fail(res, 404, 'Resource not found');
  if (!mongoose.Types.ObjectId.isValid(req.params.id))
    return fail(res, 400, 'Invalid ID');

  try {
    const [Model] = entry;
    const data = await Model.findByIdAndUpdate(
      req.params.id,
      { ...req.body, updatedBy: actor(req) },
      { new: true, runValidators: true },
    );
    if (!data) return fail(res, 404, 'Record not found');
    return res.json({ success: true, data });
  } catch (error) {
    return fail(res, 400, error.message);
  }
};

export const deleteHandler = (resource) => async (req, res) => {
  const entry = MODELS[resource];
  if (!entry) return fail(res, 404, 'Resource not found');
  if (!mongoose.Types.ObjectId.isValid(req.params.id))
    return fail(res, 400, 'Invalid ID');

  try {
    const [Model] = entry;
    let data;

    if (Model.schema.path('isActive')) {
      data = await Model.findByIdAndUpdate(
        req.params.id,
        { isActive: false, updatedBy: actor(req) },
        { new: true },
      );
    } else {
      data = await Model.findByIdAndDelete(req.params.id);
    }
    if (!data) return fail(res, 404, 'Record not found');

    if (Model === DirectCostEmployee) {
      await Promise.all([
        FixedAssetAssignment.deleteMany({ empId: req.params.id }),
        ResourceAssignment.deleteMany({ empId: req.params.id }),
        SoftwareItem.updateMany(
          { empId: req.params.id },
          { $unset: { empId: 1 } },
        ),
        InsuranceItem.updateMany(
          { empId: req.params.id },
          { $unset: { empId: 1 } },
        ),
        EmployeeSalary.deleteMany({ empId: req.params.id }),
        CertificationReimbursement.deleteMany({ empId: req.params.id }),
        HolidayBonus.deleteMany({ empId: req.params.id }),
      ]);
    }

    return res.json({ success: true, data });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};
