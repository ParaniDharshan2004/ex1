import { useMemo, useRef, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  useTheme,
} from '@mui/material';
import CloudUploadRoundedIcon from '@mui/icons-material/CloudUploadRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';
import {
  approveFullyLoadedCostReport,
  createFullyLoadedCostReport,
} from '../api/fullyLoadedCostApi';

const displayValue = (value) => {
  if (value === null || value === undefined) return '';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
};

const normalizeText = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');

const findRowName = (row) => {
  const nameKeys = ['category', 'subcategory', 'item', 'name', 'description', 'particular', 'particulars', 'ledger', 'asset', 'resource', 'directcost', 'fixedcost', 'variablecost', 'indirectoverheadcost'];
  const entry = Object.entries(row).find(([key]) =>
    nameKeys.includes(normalizeText(key)),
  );
  return entry ? String(entry[1] || '').trim() : '';
};

const findRowAmount = (row) => {
  const amountKeys = ['costperannum', 'costperannumrs', 'annualcost', 'annualamount', 'amount', 'cost', 'total', 'annualsalary', 'monthlysalary', 'premiumamount', 'purchasecost'];
  const entry = Object.entries(row).find(([key]) =>
    amountKeys.includes(normalizeText(key)),
  );
  const amount = Number(String(entry?.[1] ?? '').replace(/[^\d.-]/g, ''));
  return Number.isFinite(amount) ? Math.max(0, amount) : 0;
};

const getUploadTotal = (rows) => {
  const grandTotalRow = rows.find((row) =>
    normalizeText(findRowName(row)).includes(
      'totaldirectcosttotalvariablecosttotalfixedcostdepreciation',
    ),
  );
  if (grandTotalRow) return findRowAmount(grandTotalRow);

  return rows.reduce((sum, row) => {
    if (normalizeText(findRowName(row)).startsWith('total')) return sum;
    return sum + findRowAmount(row);
  }, 0);
};

const matchesCategory = (name, aliases) => {
  const normalizedName = normalizeText(name);
  return aliases.some((alias) => {
    const normalizedAlias = normalizeText(alias);
    return normalizedName === normalizedAlias ||
      normalizedName.includes(normalizedAlias) ||
      normalizedAlias.includes(normalizedName);
  });
};

const buildUploadSections = (rows) => {
  const sections = [
    { title: 'Direct Labour', rows: [] },
    { title: 'Direct Material', rows: [] },
    { title: 'Variable Cost', rows: [] },
    { title: 'Fixed Cost', rows: [] },
  ];

  rows.forEach((row) => {
    const name = findRowName(row);
    if (!name) return;
    if (normalizeText(name).startsWith('total')) return;
    const item = { name, amount: findRowAmount(row) };

    if (matchesCategory(name, ['salary', 'life insurance', 'health insurance', 'holiday bonus', 'certification reimbursement'])) {
      sections[0].rows.push(item);
    } else if (matchesCategory(name, ['dedicated employee resource', 'depreciation', 'dedicated employee software', 'software access'])) {
      sections[1].rows.push(item);
    } else if (matchesCategory(name, ['air conditioner', 'furniture', 'printer', 'inverter', 'ups', 'mobile phone', 'security camera', 'water dispenser'])) {
      sections[3].rows.push(item);
    } else if (matchesCategory(name, ['office rent', 'electricity', 'travel', 'internet', 'phone', 'food', 'water', 'small tools', 'equipment', 'software', 'bank charges', 'professional fees', 'registration', 'marketing', 'insurance', 'employee recognition', 'events', 'trips', 'misc office'])) {
      sections[2].rows.push(item);
    }
  });

  return sections.filter((section) => section.rows.length > 0);
};

export default function FullyLoadedCostUploadPage() {
  const navigate = useNavigate();
  const theme = useTheme();
  const fileInputRef = useRef(null);
  const [reportMonth, setReportMonth] = useState('');
  const [reportName, setReportName] = useState('');
  const [sourceFileName, setSourceFileName] = useState('');
  const [worksheetName, setWorksheetName] = useState('');
  const [headers, setHeaders] = useState([]);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const totalAmount = useMemo(() => getUploadTotal(rows), [rows]);

  const structuredSections = useMemo(
    () => buildUploadSections(rows),
    [rows],
  );

  const handleFile = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      setLoading(true);
      setErrorMessage('');
      setSourceFileName(file.name);

      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonRows = XLSX.utils.sheet_to_json(sheet, {
        defval: '',
        raw: false,
      });

      if (jsonRows.length === 0) {
        throw new Error('The selected worksheet does not contain any data.');
      }

      const sheetHeaders = Object.keys(jsonRows[0]);
      setWorksheetName(sheetName);
      setHeaders(sheetHeaders);
      setRows(jsonRows.map((row, index) => ({ rowNumber: index + 2, data: row })).map((item) => item.data));

      if (!reportName) {
        setReportName(`Fully Loaded Cost - ${sheetName}`);
      }
    } catch (error) {
      setErrorMessage(error.message || 'Unable to read the Excel file.');
    } finally {
      setLoading(false);
      event.target.value = '';
    }
  };

  const approveReport = async () => {
    if (!reportMonth) {
      setErrorMessage('Select the report month.');
      return;
    }
    if (!reportName.trim()) {
      setErrorMessage('Enter a report name.');
      return;
    }
    if (rows.length === 0) {
      setErrorMessage('Upload an Excel file first.');
      return;
    }

    try {
      setLoading(true);
      setErrorMessage('');
      const response = await createFullyLoadedCostReport({
        reportMonth,
        reportName,
        sourceFileName,
        worksheetName,
        headers,
        rows: rows.map((row, index) => ({
          rowNumber: index + 2,
          data: row,
        })),
      });
      const reportId = response.data?.data?._id;
      if (!reportId) throw new Error('The report could not be saved.');

      await approveFullyLoadedCostReport(reportId);
      navigate('/fully-loaded-cost-reports', {
        state: { notification: 'Uploaded data approved and saved.' },
      });
    } catch (error) {
      setErrorMessage(error.response?.data?.message || error.message || 'Unable to save the report.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        p: { xs: 2, md: 3 },
        bgcolor: 'background.default',
        minHeight: '100%',
      }}
    >
      <Typography variant="h5" sx={{ mb: 2 }}>
        Fully Loaded Cost - Upload & Review
      </Typography>

      <Paper sx={{ p: 3, mb: 3, bgcolor: 'background.paper' }}>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 2fr' }, gap: 2 }}>
          <TextField
            label="Report Month"
            type="month"
            value={reportMonth}
            onChange={(event) => setReportMonth(event.target.value)}
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="Report Name"
            value={reportName}
            onChange={(event) => setReportName(event.target.value)}
          />
        </Box>

        <Box
          sx={{
            mt: 3,
            p: 3,
            border: '2px dashed',
            borderColor: 'divider',
            borderRadius: `${theme.shape.borderRadius}px`,
            bgcolor: 'background.paper',
            textAlign: 'center',
          }}
        >
          <CloudUploadRoundedIcon color="primary" sx={{ fontSize: 40 }} />
          <Typography fontWeight={700} sx={{ mt: 1 }}>Upload Excel worksheet</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            .xlsx or .xls
          </Typography>
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            hidden
            onChange={handleFile}
          />
          <Button variant="contained" onClick={() => fileInputRef.current?.click()} disabled={loading}>
            Choose Excel
          </Button>
          {sourceFileName && (
            <Box sx={{ mt: 2, color: 'success.main', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 1 }}>
              <CheckCircleRoundedIcon fontSize="small" />
              <Typography variant="body2" fontWeight={700}>{sourceFileName}</Typography>
            </Box>
          )}
        </Box>
      </Paper>

      {errorMessage && <Alert severity="error" sx={{ mb: 2 }}>{errorMessage}</Alert>}

      {rows.length > 0 && (
        <Paper sx={{ p: 3, bgcolor: 'background.paper' }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Box>
              <Typography fontWeight={700}>Uploaded Data Review</Typography>
              <Typography variant="body2" color="text.secondary">
                {rows.length} rows | Estimated amount total: ₹{totalAmount.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
              </Typography>
            </Box>
            <Button variant="contained" color="success" onClick={approveReport} disabled={loading}>
              {loading ? <CircularProgress size={20} /> : 'Approve & Save Report'}
            </Button>
          </Box>

          {structuredSections.length > 0 && (
            <Box sx={{ mb: 2 }}>
              {structuredSections.map((section) => (
                <Box key={section.title} sx={{ mb: 2 }}>
                  <Typography fontWeight={700} sx={{ mb: 0.75 }}>
                    {section.title}
                  </Typography>
                  <TableContainer sx={{ border: `1px solid ${theme.palette.divider}` }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow sx={{ bgcolor: 'action.hover' }}>
                          <TableCell sx={{ fontWeight: 700 }}>Category</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Amount</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {section.rows.map((row, index) => (
                          <TableRow key={`${section.title}-${row.name}-${index}`}>
                            <TableCell>{row.name}</TableCell>
                            <TableCell>
                              ₹{row.amount.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              ))}
            </Box>
          )}

          <TableContainer sx={{ maxHeight: 520, border: `1px solid ${theme.palette.divider}` }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: 'action.hover' }}>
                  {headers.map((header) => (
                    <TableCell key={header} sx={{ fontWeight: 700 }}>{header}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row, index) => (
                  <TableRow key={index} hover>
                    {headers.map((header) => (
                      <TableCell key={`${index}-${header}`}>
                        {displayValue(row[header])}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}
    </Box>
  );
}
