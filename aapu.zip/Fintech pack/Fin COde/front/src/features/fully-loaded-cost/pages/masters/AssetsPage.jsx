import { useEffect, useState } from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Chip,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useTheme,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import EntityFormDialog from '../../../../shared/components/dialogs/EntityFormDialog';
import ConfirmDialog from '../../../../shared/components/dialogs/ConfirmDialog';
import {
  createFullyLoadedCostResource,
  deleteFullyLoadedCostResource,
  getFullyLoadedCostResource,
  updateFullyLoadedCostResource,
} from '../../api/fullyLoadedCostApi';

const getId = (value) =>
  typeof value === 'object' ? value?._id || value?.id : value;

export default function AssetsPage() {
  const theme = useTheme();
  const [rows, setRows] = useState([]);
  const [categories, setCategories] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [form, setForm] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const loadData = async () => {
    const [items, categoryData, employeeData, assignmentData] =
      await Promise.all([
        getFullyLoadedCostResource('resource-items'),
        getFullyLoadedCostResource('resource-categories'),
        getFullyLoadedCostResource('employees'),
        getFullyLoadedCostResource('resource-assignments'),
      ]);
    setRows(items.data?.data || []);
    setCategories(categoryData.data?.data || []);
    setEmployees(employeeData.data?.data || []);
    setAssignments(assignmentData.data?.data || []);
  };

  useEffect(() => {
    loadData().catch(() => {});
  }, []);

  const fields = [
    {
      name: 'resourceCategoryId',
      label: 'Resource Category',
      type: 'select',
      required: true,
      options: categories.map((item) => ({
        label: item.resourceName,
        value: getId(item),
      })),
    },
    { name: 'assetCode', label: 'Asset Code', type: 'text', required: true },
    { name: 'assetName', label: 'Resource / Asset Name', type: 'text', required: true },
    { name: 'serialNumber', label: 'Serial Number', type: 'text' },
    { name: 'brand', label: 'Brand', type: 'text' },
    { name: 'purchaseFrom', label: 'Purchase From', type: 'text' },
    { name: 'purchaseCost', label: 'Purchase Cost', type: 'number', min: 0 },
    { name: 'invoiceDate', label: 'Purchased Date', type: 'date' },
    { name: 'warrantyDate', label: 'Warranty Expiry Date', type: 'date' },
  ];

  const saveRow = async (values) => {
    const payload = {
      resourceCategoryId: values.resourceCategoryId,
      assetCode: values.assetCode,
      serialNumber: values.serialNumber || '',
      asset: values.assetName,
      assetName: values.assetName,
      brand: values.brand || '',
      purchaseFrom: values.purchaseFrom || '',
      purchaseCost: Number(values.purchaseCost || 0),
      invoiceDate: values.invoiceDate || null,
      warrantyDate: values.warrantyDate || null,
      status: 'active',
    };

    if (form.mode === 'edit') {
      await updateFullyLoadedCostResource(
        'resource-items',
        form.initialValues._id,
        payload,
      );
    } else {
      await createFullyLoadedCostResource('resource-items', payload);
    }
    setForm(null);
    await loadData();
  };

  const deleteRow = async () => {
    await deleteFullyLoadedCostResource('resource-items', deleteTarget._id);
    setDeleteTarget(null);
    await loadData();
  };

  const categoryRows = categories.map((category) => ({
    category,
    rows: rows.filter(
      (row) => getId(row.resourceCategoryId) === getId(category),
    ),
  }));

  return (
    <Box sx={{ p: { xs: 2, md: 3 }, bgcolor: 'background.default', minHeight: '100%' }}>
      <Typography variant="h5" sx={{ mb: 2 }}>Resource Items</Typography>
      <Paper sx={{ p: { xs: 2, md: 3 }, bgcolor: 'background.paper' }}>
        <Stack direction="row" justifyContent="flex-end" sx={{ mb: 3 }}>
          <Button
            variant="contained"
            startIcon={<AddRoundedIcon />}
            onClick={() =>
              setForm({ open: true, mode: 'create', initialValues: {} })
            }
            sx={{ height: 48, px: 2.5 }}
          >
            Add Resource Item
          </Button>
        </Stack>

        {categoryRows.length === 0 ? (
          <Typography align="center" sx={{ py: 5, color: 'text.secondary' }}>
            No categories found
          </Typography>
        ) : categoryRows.map(({ category, rows: categoryItems }) => (
          <Accordion
            key={getId(category)}
            disableGutters
            sx={{
              mb: 1.25,
              border: `1px solid ${theme.palette.divider}`,
              borderRadius: 2,
              boxShadow: 'none',
              '&:before': { display: 'none' },
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreRoundedIcon />}
              sx={{
                minHeight: 64,
                px: 2.5,
                '&.Mui-expanded': {
                  minHeight: 64,
                  borderBottom: `1px solid ${theme.palette.divider}`,
                },
              }}
            >
              <Typography fontWeight={700}>
                {category.resourceName}
                <Typography component="span" color="text.secondary">
                  {' '}({categoryItems.length})
                </Typography>
              </Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0 }}>
              {categoryItems.length === 0 ? (
                <Typography align="center" sx={{ py: 3, color: 'text.secondary' }}>
                  No resource items in this category
                </Typography>
              ) : (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow sx={{ bgcolor: 'action.hover' }}>
                        <TableCell sx={{ fontWeight: 700 }}>Asset Code</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Resource / Asset</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Employee Code</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Serial Number</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Purchase From</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                        <TableCell align="right" sx={{ fontWeight: 700 }}>Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {categoryItems.map((row) => {
                        const assignment = assignments.find(
                          (item) => getId(item.resourceItemId) === getId(row),
                        );
                        const employee = employees.find(
                          (item) => getId(item) === getId(assignment?.empId),
                        );
                        return (
                          <TableRow key={getId(row)} hover>
                            <TableCell>{row.assetCode || '-'}</TableCell>
                            <TableCell>{row.assetName || row.asset || '-'}</TableCell>
                            <TableCell>{employee?.empCode || '-'}</TableCell>
                            <TableCell>{row.serialNumber || '-'}</TableCell>
                            <TableCell>{row.purchaseFrom || '-'}</TableCell>
                            <TableCell>
                              <Chip
                                size="small"
                                label={row.status === 'inactive' ? 'Inactive' : 'Active'}
                                color={row.status === 'inactive' ? 'default' : 'success'}
                              />
                            </TableCell>
                            <TableCell align="right">
                              <IconButton
                                size="small"
                                onClick={() =>
                                  setForm({
                                    open: true,
                                    mode: 'edit',
                                    initialValues: {
                                      ...row,
                                      resourceCategoryId: getId(row.resourceCategoryId),
                                    },
                                  })
                                }
                              >
                                <EditOutlinedIcon fontSize="small" />
                              </IconButton>
                              <IconButton
                                size="small"
                                color="error"
                                onClick={() => setDeleteTarget(row)}
                              >
                                <DeleteOutlineRoundedIcon fontSize="small" />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </AccordionDetails>
          </Accordion>
        ))}
      </Paper>

      {form && (
        <EntityFormDialog
          open={form.open}
          mode={form.mode}
          title={`${form.mode === 'edit' ? 'Edit' : 'Add'} Resource Item`}
          fields={fields}
          initialValues={form.initialValues}
          onClose={() => setForm(null)}
          onSave={saveRow}
        />
      )}
      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete resource item"
        message="Delete this resource item?"
        confirmLabel="Delete"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={deleteRow}
      />
    </Box>
  );
}
