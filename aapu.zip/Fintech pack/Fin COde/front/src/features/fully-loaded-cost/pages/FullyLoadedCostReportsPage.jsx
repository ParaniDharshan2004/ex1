import { useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Dialog,
  DialogContent,
  DialogTitle,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useTheme,
} from '@mui/material';
import { useLocation, useParams } from 'react-router-dom';
import {
  getFullyLoadedCostReport,
  getFullyLoadedCostReports,
} from '../api/fullyLoadedCostApi';

const formatAmount = (value) =>
  `₹${Number(value || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;

const renderStructuredSections = (sections = []) =>
  sections.map((section) => (
    <Box key={section.title} sx={{ mb: 2 }}>
      <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 0.75 }}>
        {section.title}
      </Typography>
      {section.rows?.length ? (
        <Table size="small" sx={{ border: `1px solid`, borderColor: 'divider' }}>
          <TableHead>
            <TableRow sx={{ bgcolor: 'action.hover' }}>
              <TableCell sx={{ fontWeight: 700 }}>Name</TableCell>
              <TableCell sx={{ fontWeight: 700 }}>Amount</TableCell>
              <TableCell sx={{ fontWeight: 700 }}>Estimated</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {section.rows.map((row, index) => (
              <TableRow key={`${section.title}-${row.name}-${index}`}>
                <TableCell>{row.name}</TableCell>
                <TableCell>
                  ₹{Number(row.amount || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                </TableCell>
                <TableCell>{row.estimated ? 'Yes' : '-'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <Typography color="text.secondary">No records</Typography>
      )}
    </Box>
  ));

const renderCostTotals = (totals) => {
  const rows = [
    ['Total Direct Labour', totals.directLabour],
    ['Total Direct Material', totals.directMaterial],
    ['Total Direct Cost', totals.directCost],
    ['Total Variable Cost', totals.variableCost],
    ['Total Direct Cost + Total Variable Cost', totals.directCostAndVariableCost],
    ['Total Fixed Cost Depreciation', totals.fixedCostDepreciation],
    ['Total Fully Loaded Cost', totals.totalFullyLoadedCost],
  ];

  return (
    <Box sx={{ mb: 3 }}>
      <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 0.75 }}>
        Cost Totals
      </Typography>
      <Table size="small" sx={{ border: `1px solid`, borderColor: 'divider' }}>
        <TableHead>
          <TableRow sx={{ bgcolor: 'action.hover' }}>
            <TableCell sx={{ fontWeight: 700 }}>Category</TableCell>
            <TableCell align="right" sx={{ fontWeight: 700 }}>Total Cost</TableCell>
            <TableCell align="right" sx={{ fontWeight: 700 }}>Cost Per Annum</TableCell>
            <TableCell align="right" sx={{ fontWeight: 700 }}>Cost Per Month</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map(([label, total]) => (
            <TableRow key={label}>
              <TableCell>{label}</TableCell>
              <TableCell align="right">{formatAmount(total?.totalCost)}</TableCell>
              <TableCell align="right">{formatAmount(total?.annual)}</TableCell>
              <TableCell align="right">{formatAmount(total?.monthly)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Box>
  );
};

const formatMonth = (month) => {
  if (!/^\d{4}-\d{2}$/.test(month || '')) return month || '-';
  const [year, monthNumber] = month.split('-');
  return new Date(Number(year), Number(monthNumber) - 1, 1).toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric',
  });
};

const displayValue = (value) => {
  if (value === null || value === undefined) return '';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
};

export default function FullyLoadedCostReportsPage() {
  const { reportId } = useParams();
  const location = useLocation();
  const theme = useTheme();
  const [reports, setReports] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState(location.state?.notification || '');

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        setLoading(true);
        const response = await getFullyLoadedCostReports();
        if (!active) return;
        setReports(response.data?.data || []);

        if (reportId) {
          const detail = await getFullyLoadedCostReport(reportId);
          if (active) setSelectedReport(detail.data?.data || null);
        }
      } catch (error) {
        if (active) {
          setErrorMessage(error.response?.data?.message || 'Unable to load reports.');
        }
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => {
      active = false;
    };
  }, [reportId]);

  const openReport = async (report) => {
    try {
      setErrorMessage(location.state?.notification || '');
      const response = await getFullyLoadedCostReport(report._id);
      setSelectedReport(response.data?.data || report);
    } catch (error) {
      setErrorMessage(error.response?.data?.message || 'Unable to load report details.');
    }
  };

  return (
    <Box
      sx={{
        p: { xs: 2, md: 3 },
        bgcolor: 'background.default',
        minHeight: '100%',
      }}
    >
      <Typography variant="h5" sx={{ mb: 2 }}>
        Fully Loaded Cost Reports
      </Typography>

      {errorMessage && <Alert severity="success" sx={{ mb: 2 }}>{errorMessage}</Alert>}

      {loading ? (
        <Box sx={{ py: 5, textAlign: 'center' }}><CircularProgress /></Box>
      ) : (
        <Card sx={{ bgcolor: 'background.paper', border: `1px solid ${theme.palette.divider}` }}>
          <CardContent>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700 }}>Expense Month</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Report Name</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Source File</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Total Amount</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {reports.length === 0 ? (
                    <TableRow><TableCell colSpan={5} align="center">No approved reports found</TableCell></TableRow>
                  ) : reports.map((report) => (
                    <TableRow
                      key={report._id}
                      hover
                      sx={{ cursor: 'pointer' }}
                      onClick={() => openReport(report)}
                    >
                      <TableCell>{formatMonth(report.reportMonth)}</TableCell>
                      <TableCell>{report.reportName}</TableCell>
                      <TableCell>{report.sourceFileName || '-'}</TableCell>
                      <TableCell>
                        <Chip
                          size="small"
                          label={report.status}
                          color={report.status === 'APPROVED' ? 'success' : 'default'}
                        />
                      </TableCell>
                      <TableCell>
                        ₹{Number(report.totalAmount || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}

      <Dialog
        open={Boolean(selectedReport)}
        onClose={() => setSelectedReport(null)}
        fullWidth
        maxWidth="lg"
      >
        <DialogTitle>{selectedReport?.reportName || 'Report Details'}</DialogTitle>
        <DialogContent>
          {selectedReport?.totals && renderCostTotals(selectedReport.totals)}

          {selectedReport?.sections?.length > 0 && (
            <Box sx={{ mb: 3 }}>
              {renderStructuredSections(selectedReport.sections)}
            </Box>
          )}

          {selectedReport?.headers?.length ? (
            <TableContainer sx={{ maxHeight: 520 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    {selectedReport.headers.map((header) => (
                      <TableCell key={header} sx={{ fontWeight: 700 }}>{header}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {(selectedReport.rows || []).map((row, index) => (
                    <TableRow key={index}>
                      {selectedReport.headers.map((header) => (
                        <TableCell key={`${index}-${header}`}>
                          {displayValue(row.data?.[header])}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Typography>No row data available</Typography>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
}
