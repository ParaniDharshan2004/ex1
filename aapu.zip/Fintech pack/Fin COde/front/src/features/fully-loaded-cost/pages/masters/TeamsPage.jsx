import { useEffect, useState } from 'react';
import MasterTableShell from '../../components/masters/MasterTableShell';
import {
  getFullyLoadedCostCompanies,
} from '../../api/fullyLoadedCostApi';

export default function TeamsPage() {
  const [companies, setCompanies] = useState([]);

  useEffect(() => {
    getFullyLoadedCostCompanies()
      .then((response) => setCompanies(response.data?.data || []))
      .catch(() => setCompanies([]));
  }, []);

  return (
    <MasterTableShell
      title="Teams"
      resource="teams"
      fields={[
        {
          name: 'companyId',
          label: 'Company',
          type: 'select',
          required: true,
          options: companies.map((item) => ({ label: item.companyName, value: item._id })),
        },
        { name: 'teamCode', label: 'Team Code', type: 'text', required: true },
        { name: 'teamName', label: 'Team Name', type: 'text', required: true },
        { name: 'description', label: 'Description', type: 'text', multiline: true, rows: 2 },
        {
          name: 'isActive',
          label: 'Status',
          type: 'select',
          required: true,
          options: [
            { label: 'Active', value: true },
            { label: 'Inactive', value: false },
          ],
        },
      ]}
      columns={[
        ['Team Code', (row) => row.teamCode],
        ['Team', (row) => row.teamName],
        ['Company', (row) => row.companyId?.companyName || '-'],
      ]}
      getStatus={(row) =>
        row.isActive
          ? { label: 'Active', color: 'success' }
          : { label: 'Inactive', color: 'default' }
      }
    />
  );
}
