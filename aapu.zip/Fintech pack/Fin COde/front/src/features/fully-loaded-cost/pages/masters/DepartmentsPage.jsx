import { useEffect, useState } from 'react';
import MasterTableShell from '../../components/masters/MasterTableShell';
import { getFullyLoadedCostCompanies } from '../../api/fullyLoadedCostApi';

export default function DepartmentsPage() {
  const [companies, setCompanies] = useState([]);

  useEffect(() => {
    getFullyLoadedCostCompanies()
      .then((response) => setCompanies(response.data?.data || []))
      .catch(() => setCompanies([]));
  }, []);

  const companyOptions = companies.map((item) => ({
    label: item.companyName,
    value: item._id,
  }));

  return (
    <MasterTableShell
      title="Departments"
      resource="departments"
      fields={[
        { name: 'companyId', label: 'Company', type: 'select', required: true, options: companyOptions },
        { name: 'deptCode', label: 'Department Code', type: 'text', required: true },
        { name: 'deptName', label: 'Department Name', type: 'text', required: true },
        {
          name: 'isActive',
          label: 'Status',
          type: 'select',
          required: true,
          options: [
            { label: 'Active', value: true },
            { label: 'Inactive', value: false },
          ],
        },
      ]}
      columns={[
        ['Dept Code', (row) => row.deptCode],
        ['Department', (row) => row.deptName],
        ['Company', (row) => row.companyId?.companyName || '-'],
      ]}
      getStatus={(row) =>
        row.isActive
          ? { label: 'Active', color: 'success' }
          : { label: 'Inactive', color: 'default' }
      }
    />
  );
}
