import { useEffect, useMemo, useState } from 'react';
import {
  Box,
  CircularProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useTheme,
} from '@mui/material';
import { getFullyLoadedCostResource } from '../api/fullyLoadedCostApi';
import { getEmployeeDepartmentGroup } from '../utils/employeeDepartmentGrouping';

const getId = (value) =>
  typeof value === 'object' ? value?._id || value?.id : value;

const formatAmount = (value = 0) =>
  `₹${Number(value || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;

const VARIABLE_ROWS = [
  ['Office Rent', 0],
  ['Electricity', 0],
  ['Travel', 0],
  ['Internet & Phone', 0],
  ['Food & Water', 0],
  ['Small Tools & Equipment', 0],
  ['Software', 0],
  ['Bank Charges (Estimated)', 0],
  ['Professional Fees (Estimated)', 0],
  ['Registration & Legal Expenses (Estimated)', 0],
  ['Marketing & Advertisement', 0],
  ['Liability Insurance', 0],
  ['Employee Recognition & Rewards (Estimated)', 0],
  ['Employee Related Events & Trips (Estimated)', 0],
  ['Misc Office Expenses (Estimated)', 0],
];

const FIXED_ROWS = [
  'Air Conditioner',
  'Furniture',
  'Printer',
  'Inverter (UPS)',
  'Mobile Phone',
  'Security Camera',
  'Water Dispenser',
];

export default function FullyLoadedCostAnalysisPage() {
  const theme = useTheme();
  const [loading, setLoading] = useState(true);
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [salaries, setSalaries] = useState([]);
  const [insuranceItems, setInsuranceItems] = useState([]);
  const [holidayBonuses, setHolidayBonuses] = useState([]);
  const [certifications, setCertifications] = useState([]);
  const [softwareItems, setSoftwareItems] = useState([]);
  const [resourceAssignments, setResourceAssignments] = useState([]);
  const [resourceItems, setResourceItems] = useState([]);
  const [fixedDepreciation, setFixedDepreciation] = useState([]);
  const [fixedAssetRegisters, setFixedAssetRegisters] = useState([]);

  useEffect(() => {
    let active = true;

    Promise.all([
      getFullyLoadedCostResource('employees'),
      getFullyLoadedCostResource('departments'),
      getFullyLoadedCostResource('employee-salaries'),
      getFullyLoadedCostResource('insurance-items'),
      getFullyLoadedCostResource('holiday-bonuses'),
      getFullyLoadedCostResource('certification-reimbursements'),
      getFullyLoadedCostResource('software-items'),
      getFullyLoadedCostResource('resource-assignments'),
      getFullyLoadedCostResource('resource-items'),
      getFullyLoadedCostResource('fixed-asset-depreciations'),
      getFullyLoadedCostResource('fixed-asset-register'),
    ])
      .then((responses) => {
        if (!active) return;
        setEmployees(responses[0].data?.data || []);
        setDepartments(responses[1].data?.data || []);
        setSalaries(responses[2].data?.data || []);
        setInsuranceItems(responses[3].data?.data || []);
        setHolidayBonuses(responses[4].data?.data || []);
        setCertifications(responses[5].data?.data || []);
        setSoftwareItems(responses[6].data?.data || []);
        setResourceAssignments(responses[7].data?.data || []);
        setResourceItems(responses[8].data?.data || []);
        setFixedDepreciation(responses[9].data?.data || []);
        setFixedAssetRegisters(responses[10].data?.data || []);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const departmentGroups = useMemo(() => {
    const groups = {
      revenue: [],
      reserve: [],
      administrative: [],
    };

    employees
      .filter((employee) => employee.status !== 'inactive')
      .forEach((employee) => {
        groups[getEmployeeDepartmentGroup(employee, departments)].push(employee);
      });

    return groups;
  }, [employees, departments]);

  const getSalary = (employee) => {
    const record = salaries.find(
      (item) =>
        getId(item.empId) === getId(employee) && item.isActive !== false,
    );
    const annual =
      Number(record?.annualSalary) ||
      Number(record?.monthlySalary || 0) * 12;
    const monthly =
      Number(record?.monthlySalary) ||
      Number(record?.annualSalary || 0) / 12;
    return { annual, monthly };
  };

  const getInsurance = (employee) => {
    const categoryItems = insuranceItems.filter(
      (item) => getId(item.empId) === getId(employee),
    );
    return {
      life: 0,
      health: 0,
      categoryItems,
    };
  };

  const getBonus = (employee) =>
    holidayBonuses
      .filter((item) => getId(item.empId) === getId(employee))
      .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const getCertification = (employee) =>
    certifications
      .filter((item) => getId(item.empId) === getId(employee))
      .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const getDirectResourceDepreciation = (employee) =>
    resourceAssignments
      .filter((item) => getId(item.empId) === getId(employee))
      .reduce((sum, item) => {
        const resource = resourceItems.find(
          (resourceItem) =>
            getId(resourceItem) === getId(item.resourceItemId),
        );
        return sum + Number(resource?.purchaseCost || 0);
      }, 0);

  const getSoftwareCost = (employee) =>
    softwareItems
      .filter((item) => getId(item.empId) === getId(employee))
      .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const groupTotals = (group) =>
    group.reduce(
      (totals, employee) => {
        const salary = getSalary(employee);
        totals.salaryAnnual += salary.annual;
        totals.salaryMonthly += salary.monthly;
        totals.bonusAnnual += getBonus(employee);
        totals.certificationAnnual += getCertification(employee);
        totals.resourceAnnual += getDirectResourceDepreciation(employee);
        totals.softwareAnnual += getSoftwareCost(employee);
        return totals;
      },
      {
        salaryAnnual: 0,
        salaryMonthly: 0,
        bonusAnnual: 0,
        certificationAnnual: 0,
        resourceAnnual: 0,
        softwareAnnual: 0,
      },
    );

  const employeeColumns = useMemo(() => {
    const revenue = departmentGroups.revenue;
    const reserve = departmentGroups.reserve;
    const administrative = departmentGroups.administrative;
    return [
      { title: 'Revenue Generating Department', employees: revenue },
      { title: 'Reserve Department', employees: reserve },
      { title: 'Administrative Department', employees: administrative },
    ].filter((group) => group.employees.length > 0);
  }, [departmentGroups]);

  const employeeCount = employeeColumns.reduce(
    (count, group) => count + group.employees.length,
    0,
  );
  const tableColumnCount = employeeCount * 2 + 4;

  const getFixedDepreciationTotal = (assetName) =>
    fixedDepreciation.reduce((sum, item) => {
      const assetRegisterId = getId(item.assetValueId?.assetRegisterId);
      const assetNameForRecord =
        item.assetValueId?.assetRegisterId?.assetName ||
        fixedAssetRegisters.find(
          (asset) => getId(asset) === assetRegisterId,
        )?.assetName ||
        '';
      const normalizeName = (value) =>
        String(value).toLowerCase().replace(/[^a-z0-9]/g, '');

      if (normalizeName(assetNameForRecord) !== normalizeName(assetName)) {
        return sum;
      }

      return sum + Number(item.depreciationAmount || 0);
    }, 0);

  if (loading) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <CircularProgress />
      </Box>
    );
  }

  const renderSectionRow = (label, backgroundColor) => (
    <TableRow sx={{ bgcolor: backgroundColor }}>
      <TableCell colSpan={tableColumnCount} sx={{ fontWeight: 700 }}>
        {label}
      </TableCell>
    </TableRow>
  );

  const renderEmployeeCostRow = (label, getAnnual, getMonthly) => {
    const costs = employeeColumns.flatMap((group) =>
      group.employees.map((employee) => {
        const annual = getAnnual(employee);
        return {
          employeeId: getId(employee),
          annual,
          monthly: getMonthly ? getMonthly(employee, annual) : annual / 12,
        };
      }),
    );
    const totalAnnual = costs.reduce((sum, cost) => sum + cost.annual, 0);
    const totalMonthly = costs.reduce((sum, cost) => sum + cost.monthly, 0);

    return (
      <TableRow>
        <TableCell sx={{ fontWeight: 500, fontStyle: 'italic', minWidth: 260 }}>
          {label}
        </TableCell>
        <TableCell align="right">{formatAmount(totalAnnual)}</TableCell>
        <TableCell align="right">-</TableCell>
        {costs.flatMap(({ employeeId, annual, monthly }) => [
          <TableCell key={`${employeeId}-annual`} align="right" sx={{ minWidth: 110 }}>
            {formatAmount(annual)}
          </TableCell>,
          <TableCell key={`${employeeId}-monthly`} align="right" sx={{ minWidth: 110 }}>
            {formatAmount(monthly)}
          </TableCell>,
        ])}
        <TableCell align="right" sx={{ fontWeight: 700, minWidth: 110 }}>
          {formatAmount(totalMonthly)}
        </TableCell>
      </TableRow>
    );
  };

  return (
    <Box sx={{ p: { xs: 1, md: 3 }, bgcolor: 'background.default', minHeight: '100%' }}>
      <Typography variant="h5" sx={{ mb: 2 }}>
        Fully Loaded Cost Per Employee
      </Typography>

      <Paper sx={{ p: 1, bgcolor: 'background.paper', overflow: 'hidden' }}>
        <TableContainer
          sx={{
            maxHeight: 'calc(100vh - 180px)',
            overflow: 'auto',
            border: `1px solid ${theme.palette.divider}`,
          }}
        >
          <Table
            size="small"
            stickyHeader
            sx={{
              minWidth: 1400,
              '& td, & th': {
                borderRight: `1px solid ${theme.palette.divider}`,
                borderBottom: `1px solid ${theme.palette.divider}`,
                whiteSpace: 'nowrap',
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell
                  rowSpan={2}
                  sx={{ fontWeight: 700, minWidth: 260, bgcolor: 'background.paper' }}
                >
                  Cost Component
                </TableCell>
                <TableCell
                  rowSpan={2}
                  align="right"
                  sx={{ fontWeight: 700, bgcolor: 'background.paper', minWidth: 110 }}
                >
                  Total
                </TableCell>
                <TableCell
                  rowSpan={2}
                  align="right"
                  sx={{ fontWeight: 700, bgcolor: 'background.paper', minWidth: 80 }}
                >
                  Ratio
                </TableCell>
                {employeeColumns.map((group) => (
                  <TableCell
                    key={group.title}
                    colSpan={group.employees.length * 2}
                    align="center"
                    sx={{ fontWeight: 700, bgcolor: 'background.paper' }}
                  >
                    {group.title}
                  </TableCell>
                ))}
                <TableCell
                  rowSpan={2}
                  align="center"
                  sx={{ fontWeight: 700, bgcolor: 'background.paper', minWidth: 110 }}
                >
                  Per Month
                </TableCell>
              </TableRow>
              <TableRow>
                {employeeColumns.map((group) =>
                  group.employees.map((employee) => (
                    <TableCell
                      key={`${getId(employee)}-name`}
                      colSpan={2}
                      align="center"
                      sx={{
                        fontWeight: 700,
                        bgcolor: 'background.paper',
                        minWidth: 220,
                        borderRight: `1px solid ${theme.palette.divider}`,
                      }}
                    >
                      {employee.empName}
                    </TableCell>
                  )),
                )}
              </TableRow>
              <TableRow>
                <TableCell sx={{ fontWeight: 700, bgcolor: 'background.paper' }}>
                  Direct Cost
                </TableCell>
                <TableCell sx={{ bgcolor: 'background.paper' }} />
                <TableCell sx={{ bgcolor: 'background.paper' }} />
                {employeeColumns.map((group) =>
                  group.employees.flatMap((employee) => [
                    <TableCell
                      key={`${getId(employee)}-header-annual`}
                      align="right"
                      sx={{ bgcolor: 'background.paper' }}
                    >
                      Cost Per Annum
                    </TableCell>,
                    <TableCell
                      key={`${getId(employee)}-header-monthly`}
                      align="right"
                      sx={{ bgcolor: 'background.paper' }}
                    >
                      Cost Per Month
                    </TableCell>,
                  ]),
                )}
                <TableCell sx={{ bgcolor: 'background.paper' }} />
              </TableRow>
            </TableHead>
            <TableBody>
              {renderSectionRow('Direct Labour', 'primary.light')}
              {renderEmployeeCostRow(
                'Salary',
                (employee) => getSalary(employee).annual,
                (employee) => getSalary(employee).monthly,
              )}
              {renderEmployeeCostRow(
                'Life Insurance',
                (employee) =>
                  getInsurance(employee).categoryItems
                    .filter((item) =>
                      String(
                        item.insuranceCategoryId?.categoryName ||
                          '',
                      ).toLowerCase().includes('life'),
                    ).length * 0,
              )}
              {renderEmployeeCostRow(
                'Health Insurance',
                (employee) =>
                  getInsurance(employee).categoryItems
                    .filter((item) =>
                      String(
                        item.insuranceCategoryId?.categoryName ||
                          '',
                      ).toLowerCase().includes('health'),
                    ).length * 0,
              )}
              {renderEmployeeCostRow(
                'Holiday Bonus',
                (employee) => getBonus(employee),
              )}
              {renderEmployeeCostRow(
                'Special Professional Certification Reimbursement',
                (employee) => getCertification(employee),
              )}
              {renderSectionRow('Total Direct Labour', 'action.hover')}

              {renderSectionRow('Direct Material', 'primary.light')}
              {renderEmployeeCostRow(
                'Dedicated Employee Resource - Depreciation',
                (employee) => getDirectResourceDepreciation(employee),
              )}
              {renderEmployeeCostRow(
                'Dedicated Employee Software Access Cost',
                (employee) => getSoftwareCost(employee),
              )}
              {renderSectionRow('Total Direct Material', 'action.hover')}
              {renderSectionRow('Total Direct Cost', 'success.light')}

              {renderSectionRow('Indirect Overhead Cost', 'primary.light')}
              {renderSectionRow('Variable Cost', 'action.hover')}
              {VARIABLE_ROWS.map(([name, amount]) => {
                const ratio = employeeCount ? 1 / employeeCount : 0;
                const allocatedAnnual = amount * ratio;

                return (
                <TableRow key={name}>
                  <TableCell sx={{ fontStyle: 'italic' }}>{name}</TableCell>
                  <TableCell align="right">{formatAmount(amount)}</TableCell>
                  <TableCell align="right">{ratio.toFixed(2)}</TableCell>
                  {employeeColumns.map((group) =>
                    group.employees.flatMap((employee) => [
                      <TableCell key={`${getId(employee)}-${name}-annual`} align="right">
                        {formatAmount(allocatedAnnual)}
                      </TableCell>,
                      <TableCell key={`${getId(employee)}-${name}-monthly`} align="right">
                        {formatAmount(allocatedAnnual / 12)}
                      </TableCell>,
                    ]),
                  )}
                  <TableCell align="right" sx={{ fontWeight: 700 }}>
                    {formatAmount(amount / 12)}
                  </TableCell>
                </TableRow>
                );
              })}
              {renderSectionRow('Total Variable Cost', 'action.hover')}
              {renderSectionRow(
                'Total Direct Cost + Total Variable Cost',
                'success.light',
              )}

              {renderSectionRow('Fixed Cost (Depreciation)', 'primary.light')}
              {FIXED_ROWS.map((name) => {
                const amount = getFixedDepreciationTotal(name);
                const ratio = employeeCount ? 1 / employeeCount : 0;
                const allocatedAnnual = amount * ratio;

                return (
                <TableRow key={name}>
                  <TableCell sx={{ fontStyle: 'italic' }}>{name}</TableCell>
                  <TableCell align="right">{formatAmount(amount)}</TableCell>
                  <TableCell align="right">{ratio.toFixed(2)}</TableCell>
                  {employeeColumns.map((group) =>
                    group.employees.flatMap((employee) => [
                      <TableCell key={`${getId(employee)}-${name}-annual`} align="right">
                        {formatAmount(allocatedAnnual)}
                      </TableCell>,
                      <TableCell key={`${getId(employee)}-${name}-monthly`} align="right">
                        {formatAmount(allocatedAnnual / 12)}
                      </TableCell>,
                    ]),
                  )}
                  <TableCell align="right" sx={{ fontWeight: 700 }}>
                    {formatAmount(amount / 12)}
                  </TableCell>
                </TableRow>
                );
              })}
              {renderSectionRow('Total Fixed Cost Depreciation', 'action.hover')}
              {renderSectionRow(
                'Total Direct Cost + Total Variable Cost + Total Fixed Cost Depreciation',
                'success.light',
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  );
}
