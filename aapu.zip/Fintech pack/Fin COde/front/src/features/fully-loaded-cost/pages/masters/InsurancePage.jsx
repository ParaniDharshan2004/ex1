import { useEffect, useState } from 'react';
import MasterTableShell from '../../components/masters/MasterTableShell';
import { getFullyLoadedCostResource } from '../../api/fullyLoadedCostApi';

export default function InsurancePage() {
  const [categories, setCategories] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    Promise.all([
      getFullyLoadedCostResource('insurance-categories'),
      getFullyLoadedCostResource('employees'),
      getFullyLoadedCostResource('departments'),
    ])
      .then(([categoryResponse, employeeResponse, departmentResponse]) => {
        setCategories(categoryResponse.data?.data || []);
        setEmployees(employeeResponse.data?.data || []);
        setDepartments(departmentResponse.data?.data || []);
      })
      .catch(() => {});
  }, []);

  const eligibleEmployees = employees.filter((employee) => {
    const department =
      employee.deptId?.deptName ||
      departments.find((item) => item._id === employee.deptId)?.deptName ||
      '';
    const name = department.toLowerCase();
    return name.includes('revenue') || name.includes('administrative') || name.includes('admin');
  });

  return (
    <MasterTableShell
      title="Insurance"
      resource="insurance-items"
      fields={[
        {
          name: 'insuranceCategoryId',
          label: 'Insurance Category',
          type: 'select',
          required: true,
          options: categories.map((item) => ({ label: item.categoryName, value: item._id })),
        },
        {
          name: 'empId',
          label: 'Employee',
          type: 'select',
          required: true,
          options: eligibleEmployees.map((item) => ({
            label: `${item.empCode} - ${item.empName}`,
            value: item._id,
          })),
        },
        { name: 'policyNo', label: 'Policy Number', type: 'text', required: true },
        { name: 'policyName', label: 'Policy Name', type: 'text', required: true },
        { name: 'provider', label: 'Provider', type: 'text' },
        { name: 'effectiveFrom', label: 'Effective From', type: 'date', required: true },
        { name: 'renewalDate', label: 'Renewal Date', type: 'date' },
        {
          name: 'status',
          label: 'Status',
          type: 'select',
          required: true,
          options: [
            { label: 'Active', value: 'active' },
            { label: 'Inactive', value: 'inactive' },
            { label: 'Expired', value: 'expired' },
          ],
        },
      ]}
      columns={[
        ['Policy Number', (row) => row.policyNo],
        ['Policy Name', (row) => row.policyName],
        ['Category', (row) =>
          row.insuranceCategoryId?.categoryName ||
          categories.find((item) => item._id === row.insuranceCategoryId)?.categoryName ||
          '-',
        ],
        ['Employee', (row) => {
          const employee = employees.find((item) => item._id === row.empId?._id || item._id === row.empId);
          return employee ? `${employee.empCode} - ${employee.empName}` : '-';
        }],
        ['Renewal Date', (row) => row.renewalDate ? new Date(row.renewalDate).toLocaleDateString('en-IN') : '-'],
      ]}
    />
  );
}
