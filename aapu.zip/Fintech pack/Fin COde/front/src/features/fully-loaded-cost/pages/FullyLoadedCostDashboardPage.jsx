import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useTheme,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import { useNavigate } from 'react-router-dom';
import { getFullyLoadedCostReports } from '../api/fullyLoadedCostApi';

const formatMonth = (month) => {
  if (!/^\d{4}-\d{2}$/.test(month || '')) return month || '-';
  const [year, monthNumber] = month.split('-');
  return new Date(Number(year), Number(monthNumber) - 1, 1).toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric',
  });
};

export default function FullyLoadedCostDashboardPage() {
  const navigate = useNavigate();
  const theme = useTheme();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    let active = true;
    getFullyLoadedCostReports()
      .then((response) => {
        if (active) setReports(response.data?.data || []);
      })
      .catch((error) => {
        if (active) {
          setErrorMessage(error.response?.data?.message || 'Unable to load Fully Loaded Cost reports.');
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const kpis = useMemo(() => ({
    totalReports: reports.length,
    approved: reports.filter((report) => report.status === 'APPROVED').length,
    draft: reports.filter((report) => report.status === 'DRAFT').length,
  }), [reports]);

  return (
    <Box
      sx={{
        p: { xs: 2, md: 3 },
        bgcolor: 'background.default',
        minHeight: '100%',
      }}
    >
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5">Fully Loaded Cost</Typography>
          <Typography color="text.secondary">Direct cost reports and uploaded cost data</Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<AddRoundedIcon />}
          onClick={() => navigate('/fully-loaded-cost-upload')}
        >
          Upload Report
        </Button>
      </Box>

      {errorMessage && <Alert severity="error" sx={{ mb: 2 }}>{errorMessage}</Alert>}

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, 1fr)' }, gap: 2, mb: 3 }}>
        {[
          ['Total Reports', kpis.totalReports],
          ['Approved', kpis.approved],
          ['Draft', kpis.draft],
        ].map(([label, value]) => (
          <Card
            key={label}
            sx={{
              bgcolor: 'background.paper',
              border: `1px solid ${theme.palette.divider}`,
            }}
          >
            <CardContent>
              <Typography color="text.secondary" variant="body2">{label}</Typography>
              <Typography variant="h5" fontWeight={700}>{value}</Typography>
            </CardContent>
          </Card>
        ))}
      </Box>

      <Card sx={{ bgcolor: 'background.paper', border: `1px solid ${theme.palette.divider}` }}>
        <CardContent>
          <Typography fontWeight={700} sx={{ mb: 2 }}>Recent Reports</Typography>
          {loading ? (
            <Box sx={{ py: 4, textAlign: 'center' }}><CircularProgress /></Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700 }}>Month</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Report</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Source</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {reports.length === 0 ? (
                    <TableRow><TableCell colSpan={4} align="center">No reports found</TableCell></TableRow>
                  ) : reports.slice(0, 8).map((report) => (
                    <TableRow
                      key={report._id}
                      hover
                      sx={{ cursor: 'pointer' }}
                      onClick={() => navigate(`/fully-loaded-cost-reports/${report._id}`)}
                    >
                      <TableCell>{formatMonth(report.reportMonth)}</TableCell>
                      <TableCell>{report.reportName}</TableCell>
                      <TableCell>{report.status}</TableCell>
                      <TableCell>{report.sourceFileName || '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
