import { useEffect, useState } from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Chip,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useTheme,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import EntityFormDialog from '../../../../shared/components/dialogs/EntityFormDialog';
import ConfirmDialog from '../../../../shared/components/dialogs/ConfirmDialog';
import {
  createFullyLoadedCostResource,
  deleteFullyLoadedCostResource,
  getFullyLoadedCostResource,
  updateFullyLoadedCostResource,
} from '../../api/fullyLoadedCostApi';

const getId = (value) =>
  typeof value === 'object' ? value?._id || value?.id : value;

export default function SoftwarePage() {
  const theme = useTheme();
  const [rows, setRows] = useState([]);
  const [categories, setCategories] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const loadData = async () => {
    const [items, categoryData, employeeData] = await Promise.all([
      getFullyLoadedCostResource('software-items'),
      getFullyLoadedCostResource('software-categories'),
      getFullyLoadedCostResource('employees'),
    ]);
    setRows(items.data?.data || []);
    setCategories(categoryData.data?.data || []);
    setEmployees(employeeData.data?.data || []);
  };

  useEffect(() => {
    loadData().catch(() => {});
  }, []);

  const fields = [
    {
      name: 'softwareCategoryId',
      label: 'Software Category',
      type: 'select',
      required: true,
      options: categories.map((item) => ({
        label: item.softwareType,
        value: getId(item),
      })),
    },
    { name: 'softwareName', label: 'Software Name', type: 'text', required: true },
    { name: 'vendor', label: 'Vendor', type: 'text' },
    { name: 'contactDetails', label: 'Contact Details', type: 'text' },
    { name: 'frequency', label: 'Renewal Frequency', type: 'text' },
    { name: 'amount', label: 'Amount', type: 'number', min: 0 },
    { name: 'purchasedDate', label: 'Purchased Date', type: 'date' },
    { name: 'renewalDate', label: 'Renewal Date', type: 'date' },
  ];

  const saveRow = async (values) => {
    const payload = {
      softwareCategoryId: values.softwareCategoryId,
      softwareName: values.softwareName,
      vendor: values.vendor || '',
      contactDetails: values.contactDetails || '',
      frequency: values.frequency || '',
      amount: Number(values.amount || 0),
      purchasedDate: values.purchasedDate || null,
      renewalDate: values.renewalDate || null,
      status: 'active',
    };
    if (form.mode === 'edit') {
      await updateFullyLoadedCostResource(
        'software-items',
        form.initialValues._id,
        payload,
      );
    } else {
      await createFullyLoadedCostResource('software-items', payload);
    }
    setForm(null);
    await loadData();
  };

  const deleteRow = async () => {
    await deleteFullyLoadedCostResource('software-items', deleteTarget._id);
    setDeleteTarget(null);
    await loadData();
  };

  const categoryRows = categories.map((category) => ({
    category,
    rows: rows.filter(
      (row) => getId(row.softwareCategoryId) === getId(category),
    ),
  }));

  return (
    <Box sx={{ p: { xs: 2, md: 3 }, bgcolor: 'background.default', minHeight: '100%' }}>
      <Typography variant="h5" sx={{ mb: 2 }}>Software</Typography>
      <Paper sx={{ p: { xs: 2, md: 3 }, bgcolor: 'background.paper' }}>
        <Stack direction="row" justifyContent="flex-end" sx={{ mb: 3 }}>
          <Button
            variant="contained"
            startIcon={<AddRoundedIcon />}
            onClick={() =>
              setForm({ open: true, mode: 'create', initialValues: {} })
            }
            sx={{ height: 48, px: 2.5 }}
          >
            Add Software
          </Button>
        </Stack>

        {categoryRows.length === 0 ? (
          <Typography align="center" sx={{ py: 5, color: 'text.secondary' }}>
            No categories found
          </Typography>
        ) : categoryRows.map(({ category, rows: categoryItems }) => (
          <Accordion
            key={getId(category)}
            disableGutters
            sx={{
              mb: 1.25,
              border: `1px solid ${theme.palette.divider}`,
              borderRadius: 2,
              boxShadow: 'none',
              '&:before': { display: 'none' },
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreRoundedIcon />}
              sx={{
                minHeight: 64,
                px: 2.5,
                '&.Mui-expanded': {
                  minHeight: 64,
                  borderBottom: `1px solid ${theme.palette.divider}`,
                },
              }}
            >
              <Typography fontWeight={700}>
                {category.softwareType}
                <Typography component="span" color="text.secondary">
                  {' '}({categoryItems.length})
                </Typography>
              </Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0 }}>
              {categoryItems.length === 0 ? (
                <Typography align="center" sx={{ py: 3, color: 'text.secondary' }}>
                  No software in this category
                </Typography>
              ) : (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow sx={{ bgcolor: 'action.hover' }}>
                        <TableCell sx={{ fontWeight: 700 }}>Software Name</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Vendor</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Employee Code</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Renewal Date</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                        <TableCell align="right" sx={{ fontWeight: 700 }}>Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {categoryItems.map((row) => {
                        const employee = employees.find(
                          (item) => getId(item) === getId(row.empId),
                        );
                        return (
                          <TableRow key={getId(row)} hover>
                            <TableCell>{row.softwareName}</TableCell>
                            <TableCell>{row.vendor || '-'}</TableCell>
                            <TableCell>{employee?.empCode || '-'}</TableCell>
                            <TableCell>
                              {row.renewalDate
                                ? new Date(row.renewalDate).toLocaleDateString('en-IN')
                                : '-'}
                            </TableCell>
                            <TableCell>
                              <Chip
                                size="small"
                                label={row.status === 'inactive' ? 'Inactive' : 'Active'}
                                color={row.status === 'inactive' ? 'default' : 'success'}
                              />
                            </TableCell>
                            <TableCell align="right">
                              <IconButton
                                size="small"
                                onClick={() =>
                                  setForm({
                                    open: true,
                                    mode: 'edit',
                                    initialValues: {
                                      ...row,
                                      softwareCategoryId: getId(row.softwareCategoryId),
                                    },
                                  })
                                }
                              >
                                <EditOutlinedIcon fontSize="small" />
                              </IconButton>
                              <IconButton
                                size="small"
                                color="error"
                                onClick={() => setDeleteTarget(row)}
                              >
                                <DeleteOutlineRoundedIcon fontSize="small" />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </AccordionDetails>
          </Accordion>
        ))}
      </Paper>

      {form && (
        <EntityFormDialog
          open={form.open}
          mode={form.mode}
          title={`${form.mode === 'edit' ? 'Edit' : 'Add'} Software`}
          fields={fields}
          initialValues={form.initialValues}
          onClose={() => setForm(null)}
          onSave={saveRow}
        />
      )}
      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete software"
        message="Delete this software?"
        confirmLabel="Delete"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={deleteRow}
      />
    </Box>
  );
}
