import { useEffect, useState } from 'react';
import MasterTableShell from '../../components/masters/MasterTableShell';
import {
  createFullyLoadedCostResource,
  deleteFullyLoadedCostResource,
  getFullyLoadedCostCompanies,
  getFullyLoadedCostResource,
  updateFullyLoadedCostResource,
} from '../../api/fullyLoadedCostApi';

export default function EmployeesPage() {
  const [companies, setCompanies] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [teams, setTeams] = useState([]);
  const [resourceItems, setResourceItems] = useState([]);
  const [resourceAssignments, setResourceAssignments] = useState([]);
  const [resourceCategories, setResourceCategories] = useState([]);
  const [softwareItems, setSoftwareItems] = useState([]);
  const [softwareCategories, setSoftwareCategories] = useState([]);
  const [insuranceCategories, setInsuranceCategories] = useState([]);
  const [insuranceItems, setInsuranceItems] = useState([]);

  useEffect(() => {
    Promise.all([
      getFullyLoadedCostCompanies(),
      getFullyLoadedCostResource('departments'),
      getFullyLoadedCostResource('teams'),
      getFullyLoadedCostResource('resource-items'),
      getFullyLoadedCostResource('resource-assignments'),
      getFullyLoadedCostResource('resource-categories'),
      getFullyLoadedCostResource('software-items'),
      getFullyLoadedCostResource('software-categories'),
      getFullyLoadedCostResource('insurance-categories'),
      getFullyLoadedCostResource('insurance-items'),
    ])
      .then(([
        companyResponse,
        departmentResponse,
        teamResponse,
        resourceResponse,
        assignmentResponse,
        resourceCategoryResponse,
        softwareResponse,
        softwareCategoryResponse,
        insuranceCategoryResponse,
        insuranceResponse,
      ]) => {
        setCompanies(companyResponse.data?.data || []);
        setDepartments(departmentResponse.data?.data || []);
        setTeams(teamResponse.data?.data || []);
        setResourceItems(resourceResponse.data?.data || []);
        setResourceAssignments(assignmentResponse.data?.data || []);
        setResourceCategories(resourceCategoryResponse.data?.data || []);
        setSoftwareItems(softwareResponse.data?.data || []);
        setSoftwareCategories(softwareCategoryResponse.data?.data || []);
        setInsuranceCategories(insuranceCategoryResponse.data?.data || []);
        setInsuranceItems(insuranceResponse.data?.data || []);
      })
      .catch(() => {});
  }, []);

  const getDepartmentName = (row) =>
    row.deptId?.deptName || departments.find((item) => item._id === row.deptId)?.deptName || '-';

  const getTeamName = (row) =>
    row.teamId?.teamName || teams.find((item) => item._id === row.teamId)?.teamName || '-';

  const getId = (value) =>
    typeof value === 'object' ? value?._id || value?.id : value;

  const getInsuranceFieldName = (field, categoryId) =>
    `insurance${field}:${categoryId}`;

  const normalizeInitialValues = (row) => {
    const currentEmployeeId = getId(row);
    const normalized = {
      ...row,
      companyId: getId(row.companyId),
      deptId: getId(row.deptId),
      teamId: getId(row.teamId),
      resourceIds: resourceAssignments
        .filter((item) => getId(item.empId) === currentEmployeeId)
        .map((item) => getId(item.resourceItemId)),
      softwareIds: softwareItems
        .filter((item) => getId(item.empId) === currentEmployeeId)
        .map((item) => getId(item)),
    };

    normalized.resourceCategoryIds = [
      ...new Set(
        resourceItems
          .filter((item) =>
            resourceAssignments
              .filter((assignment) => getId(assignment.empId) === currentEmployeeId)
              .some((assignment) =>
                getId(assignment.resourceItemId) === getId(item),
              ),
          )
          .map((item) => getId(item.resourceCategoryId)),
      ),
    ];
    normalized.softwareCategoryIds = [
      ...new Set(
        softwareItems
          .filter((item) => getId(item.empId) === currentEmployeeId)
          .map((item) => getId(item.softwareCategoryId)),
      ),
    ];

    resourceAssignments
      .filter((item) => getId(item.empId) === getId(row))
      .forEach((item) => {
        const resourceId = getId(item.resourceItemId);
        normalized[`resourceAssignedDate:${resourceId}`] =
          item.assignedDate ? String(item.assignedDate).slice(0, 10) : '';
        normalized[`resourceRemarks:${resourceId}`] = item.remarks || '';
      });

    const employeeInsuranceItems = insuranceItems.filter(
      (item) => getId(item.empId) === currentEmployeeId,
    );
    normalized.insuranceCategoryIds = [
      ...new Set(
        employeeInsuranceItems.map((item) => getId(item.insuranceCategoryId)),
      ),
    ];
    employeeInsuranceItems.forEach((item) => {
      const categoryId = getId(item.insuranceCategoryId);
      normalized[getInsuranceFieldName('PolicyNo', categoryId)] = item.policyNo || '';
      normalized[getInsuranceFieldName('PolicyName', categoryId)] = item.policyName || '';
      normalized[getInsuranceFieldName('Provider', categoryId)] = item.provider || '';
      normalized[getInsuranceFieldName('EffectiveFrom', categoryId)] =
        item.effectiveFrom ? String(item.effectiveFrom).slice(0, 10) : '';
      normalized[getInsuranceFieldName('RenewalDate', categoryId)] =
        item.renewalDate ? String(item.renewalDate).slice(0, 10) : '';
    });

    return normalized;
  };

  const handleEmployeeSave = async (values, context) => {
    const employeePayload = {
      companyId: values.companyId,
      deptId: values.deptId,
      teamId: values.teamId || null,
      empCode: values.empCode,
      empName: values.empName,
      email: values.email,
      designation: values.designation || '',
      status: values.status,
    };

    let employeeId = getId(context.initialValues);

    if (context.mode === 'edit') {
      await updateFullyLoadedCostResource('employees', employeeId, employeePayload);
    } else {
      const response = await createFullyLoadedCostResource('employees', employeePayload);
      employeeId = getId(response.data?.data);
    }

    if (!employeeId) throw new Error('Employee could not be saved.');

    if (context.mode === 'edit') {
      await Promise.all(
        resourceAssignments
          .filter((item) => getId(item.empId) === employeeId)
          .map((item) => deleteFullyLoadedCostResource('resource-assignments', getId(item))),
      );
      await Promise.all(
        softwareItems
          .filter((item) => getId(item.empId) === employeeId)
          .map((item) => updateFullyLoadedCostResource('software-items', getId(item), { empId: null })),
      );
      await Promise.all(
        insuranceItems
          .filter((item) => getId(item.empId) === employeeId)
          .map((item) => updateFullyLoadedCostResource('insurance-items', getId(item), { empId: null })),
      );
    }

    await Promise.all(
      Object.entries(values)
        .filter(([name, selected]) =>
          name.startsWith('resourceItem:') && selected,
        )
        .map(([name]) => name.split(':')[1])
        .map((resourceId) =>
        createFullyLoadedCostResource('resource-assignments', {
          resourceItemId: resourceId,
          empId: employeeId,
          assignedDate:
            values[`resourceAssignedDate:${resourceId}`] ||
            new Date().toISOString().slice(0, 10),
          remarks: values[`resourceRemarks:${resourceId}`] || '',
          assignmentStatus: 'assigned',
        }),
      ),
    );

    await Promise.all(
      Object.entries(values)
        .filter(([name, selected]) =>
          name.startsWith('softwareItem:') && selected,
        )
        .map(([name]) => name.split(':')[1])
        .map((softwareId) =>
        updateFullyLoadedCostResource('software-items', softwareId, {
          empId: employeeId,
        }),
      ),
    );

    await Promise.all(
      (values.insuranceCategoryIds || []).map((insuranceCategoryId) =>
        createFullyLoadedCostResource('insurance-items', {
          insuranceCategoryId,
          empId: employeeId,
          policyNo: values[getInsuranceFieldName('PolicyNo', insuranceCategoryId)],
          policyName: values[getInsuranceFieldName('PolicyName', insuranceCategoryId)],
          provider:
            values[getInsuranceFieldName('Provider', insuranceCategoryId)] || '',
          effectiveFrom:
            values[getInsuranceFieldName('EffectiveFrom', insuranceCategoryId)],
          renewalDate:
            values[getInsuranceFieldName('RenewalDate', insuranceCategoryId)] || null,
          status: 'active',
        }),
      ),
    );
  };

  return (
    <MasterTableShell
      title="Employees"
      resource="employees"
      normalizeInitialValues={normalizeInitialValues}
      onSave={handleEmployeeSave}
      fields={[
        {
          name: 'companyId',
          label: 'Company',
          type: 'select',
          required: true,
          options: companies.map((item) => ({ label: item.companyName, value: item._id })),
        },
        {
          name: 'deptId',
          label: 'Department',
          type: 'select',
          required: true,
          options: departments.map((item) => ({ label: item.deptName, value: item._id })),
        },
        {
          name: 'teamId',
          label: 'Team',
          type: 'select',
          options: teams.map((item) => ({ label: item.teamName, value: item._id })),
        },
        { name: 'empCode', label: 'Employee Code', type: 'text', required: true },
        { name: 'empName', label: 'Employee Name', type: 'text', required: true },
        { name: 'email', label: 'Email', type: 'text', required: true },
        { name: 'designation', label: 'Designation', type: 'text' },
        {
          name: 'resourceCategoryHeading',
          label: 'Hardware Resources',
          type: 'sectionHeading',
        },
        {
          name: 'resourceCategoryIds',
          label: '',
          type: 'checkboxGroup',
          options: resourceCategories.map((item) => ({
            label: item.resourceName,
            value: getId(item),
          })),
        },
        ...resourceCategories.flatMap((category) => {
          const categoryItems = resourceItems.filter(
            (item) =>
              getId(item.resourceCategoryId) === getId(category) &&
              !resourceAssignments.some(
                (assignment) =>
                  getId(assignment.resourceItemId) === getId(item),
              ),
          );

          return categoryItems.map((item) => ({
            name: `resourceItem:${getId(item)}`,
            label: `${item.assetName || item.asset} (${item.assetCode || '-'})`,
            type: 'checkbox',
            showWhen: (values) =>
              (values.resourceCategoryIds || []).includes(getId(category)),
          }));
        }),
        {
          name: 'softwareCategoryHeading',
          label: 'Software',
          type: 'sectionHeading',
        },
        {
          name: 'softwareCategoryIds',
          label: '',
          type: 'checkboxGroup',
          options: softwareCategories.map((item) => ({
            label: item.softwareType,
            value: getId(item),
          })),
        },
        ...softwareCategories.flatMap((category) =>
          softwareItems
            .filter(
              (item) =>
                getId(item.softwareCategoryId) === getId(category) &&
                !getId(item.empId),
            )
            .map((item) => ({
              name: `softwareItem:${getId(item)}`,
              label: `${item.softwareName} (${item.vendor || '-'})`,
              type: 'checkbox',
              showWhen: (values) =>
                (values.softwareCategoryIds || []).includes(getId(category)),
            })),
        ),
        {
          name: 'allocateInsuranceHeading',
          label: 'Allocate Insurance',
          type: 'sectionHeading',
          showWhen: (values) => {
            const department = departments.find(
              (item) => getId(item) === getId(values.deptId),
            );
            const name = String(department?.deptName || '').toLowerCase();
            return name.includes('revenue') ||
              name.includes('administrative') ||
              name.includes('admin');
          },
        },
        {
          name: 'insuranceCategoryIds',
          label: '',
          type: 'checkboxGroup',
          options: insuranceCategories.map((item) => ({
            label: item.categoryName,
            value: getId(item),
          })),
          showWhen: (values) => {
            const department = departments.find(
              (item) => getId(item) === getId(values.deptId),
            );
            const name = String(department?.deptName || '').toLowerCase();
            return name.includes('revenue') ||
              name.includes('administrative') ||
              name.includes('admin');
          },
        },
        ...insuranceCategories.flatMap((category) => {
          const categoryId = getId(category);
          const showWhen = (values) =>
            (values.insuranceCategoryIds || []).includes(categoryId);
          const categoryName = category.categoryName;

          return [
            {
              name: getInsuranceFieldName('PolicyNo', categoryId),
              label: `${categoryName} Policy Number`,
              type: 'text',
              required: true,
              showWhen,
            },
            {
              name: getInsuranceFieldName('PolicyName', categoryId),
              label: `${categoryName} Policy Name`,
              type: 'text',
              required: true,
              showWhen,
            },
            {
              name: getInsuranceFieldName('Provider', categoryId),
              label: `${categoryName} Insurance Provider`,
              type: 'text',
              showWhen,
            },
            {
              name: getInsuranceFieldName('EffectiveFrom', categoryId),
              label: `${categoryName} Effective From`,
              type: 'date',
              required: true,
              showWhen,
            },
            {
              name: getInsuranceFieldName('RenewalDate', categoryId),
              label: `${categoryName} Renewal Date`,
              type: 'date',
              showWhen,
            },
          ];
        }),
        {
          name: 'status',
          label: 'Status',
          type: 'select',
          required: true,
          options: [
            { label: 'Active', value: 'active' },
            { label: 'Inactive', value: 'inactive' },
          ],
        },
      ]}
      columns={[
        ['Employee Code', (row) => row.empCode],
        ['Employee', (row) => row.empName],
        ['Department', getDepartmentName],
        ['Team', getTeamName],
        ['Email', (row) => row.email],
      ]}
      getStatus={(row) =>
        row.status === 'inactive'
          ? { label: 'Inactive', color: 'default' }
          : { label: 'Active', color: 'success' }
      }
    />
  );
}
