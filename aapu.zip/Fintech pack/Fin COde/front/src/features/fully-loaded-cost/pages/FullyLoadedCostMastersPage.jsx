import { Navigate, useParams } from 'react-router-dom';
import DepartmentsPage from './masters/DepartmentsPage';
import TeamsPage from './masters/TeamsPage';
import EmployeesPage from './masters/EmployeesPage';
import AssetsPage from './masters/AssetsPage';
import SoftwarePage from './masters/SoftwarePage';
import InsurancePage from './masters/InsurancePage';

export default function FullyLoadedCostMastersPage() {
  const { masterKey } = useParams();

  if (masterKey === 'departments') return <DepartmentsPage />;
  if (masterKey === 'teams') return <TeamsPage />;
  if (masterKey === 'employees') return <EmployeesPage />;
  if (masterKey === 'resource-items') return <AssetsPage />;
  if (masterKey === 'software-items') return <SoftwarePage />;
  if (masterKey === 'insurance-items') return <InsurancePage />;

  return <Navigate to="/fully-loaded-cost-masters/departments" replace />;
}
