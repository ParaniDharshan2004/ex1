import api from '../../../services/api/client';

const BASE_PATH = '/api/fullyLoadedCost';

export const getFullyLoadedCostReports = () =>
  api.get(`${BASE_PATH}/reports`);

export const getFullyLoadedCostReport = (reportId) =>
  api.get(`${BASE_PATH}/reports/${reportId}`);

export const createFullyLoadedCostReport = (payload) =>
  api.post(`${BASE_PATH}/reports`, payload);

export const approveFullyLoadedCostReport = (reportId) =>
  api.patch(`${BASE_PATH}/reports/${reportId}/approve`);

export const deleteFullyLoadedCostReport = (reportId) =>
  api.delete(`${BASE_PATH}/reports/${reportId}`);

export const getFullyLoadedCostResource = (resource) =>
  api.get(`${BASE_PATH}/${resource}`);

export const createFullyLoadedCostResource = (resource, payload) =>
  api.post(`${BASE_PATH}/${resource}`, payload);

export const updateFullyLoadedCostResource = (resource, id, payload) =>
  api.patch(`${BASE_PATH}/${resource}/${id}`, payload);

export const deleteFullyLoadedCostResource = (resource, id) =>
  api.delete(`${BASE_PATH}/${resource}/${id}`);

export const getFullyLoadedCostCompanies = () =>
  api.get('/api/companyMasterRouter/getAllCompanies');

export const getFullyLoadedCostFixedAssetMasters = () =>
  api.get('/api/fixedAssetRouter/getAllFixedAssets');
