const getId = (value) =>
  typeof value === 'object' ? value?._id || value?.id : value;

export const getEmployeeDepartmentGroup = (employee, departments) => {
  const departmentId = getId(employee.deptId);
  const department = employee.deptId?.deptName
    ? employee.deptId
    : departments.find(
        (item) =>
          departmentId != null &&
          String(getId(item)) === String(departmentId),
      );
  const name = String(department?.deptName || '').toLowerCase();

  if (name.includes('revenue')) return 'revenue';
  if (name.includes('administrative') || name.includes('admin')) {
    return 'administrative';
  }
  return 'reserve';
};
