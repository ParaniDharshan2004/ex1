import { useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useTheme,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import EntityFormDialog from '../../../../shared/components/dialogs/EntityFormDialog';
import ConfirmDialog from '../../../../shared/components/dialogs/ConfirmDialog';
import {
  createFullyLoadedCostResource,
  deleteFullyLoadedCostResource,
  getFullyLoadedCostResource,
  updateFullyLoadedCostResource,
} from '../../api/fullyLoadedCostApi';

export default function MasterTableShell({
  title,
  resource,
  fields,
  columns,
  getStatus,
  normalizeInitialValues,
  onSave,
}) {
  const theme = useTheme();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [form, setForm] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const normalizeEditValues = (row) => {
    const getReferenceId = (value) =>
      typeof value === 'object' ? value?._id || value?.id : value;

    return {
      ...row,
      companyId: getReferenceId(row.companyId),
      deptId: getReferenceId(row.deptId),
      teamId: getReferenceId(row.teamId),
      empId: getReferenceId(row.empId),
      resourceCategoryId: getReferenceId(row.resourceCategoryId),
      softwareCategoryId: getReferenceId(row.softwareCategoryId),
      insuranceCategoryId: getReferenceId(row.insuranceCategoryId),
      resourceItemId: getReferenceId(row.resourceItemId),
      assetRegisterId: getReferenceId(row.assetRegisterId),
    };
  };

  const loadRows = async () => {
    try {
      setLoading(true);
      setErrorMessage('');
      const response = await getFullyLoadedCostResource(resource);
      setRows(response.data?.data || []);
    } catch (error) {
      setErrorMessage(error.response?.data?.message || `Unable to load ${title}.`);
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRows();
  }, [resource]);

  const saveRow = async (values) => {
    try {
      setSaving(true);
      if (onSave) {
        await onSave(values, {
          mode: form.mode,
          initialValues: form.initialValues,
          reload: loadRows,
        });
        setForm(null);
        await loadRows();
        return;
      }

      if (form.mode === 'edit') {
        await updateFullyLoadedCostResource(resource, form.initialValues._id, values);
      } else {
        await createFullyLoadedCostResource(resource, values);
      }
      setForm(null);
      await loadRows();
    } catch (error) {
      throw new Error(error.response?.data?.message || `Unable to save ${title}.`);
    } finally {
      setSaving(false);
    }
  };

  const deleteRow = async () => {
    try {
      setSaving(true);
      await deleteFullyLoadedCostResource(resource, deleteTarget._id);
      setDeleteTarget(null);
      await loadRows();
    } catch (error) {
      setErrorMessage(error.response?.data?.message || `Unable to delete ${title}.`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box sx={{ p: { xs: 2, md: 3 }, bgcolor: 'background.default', minHeight: '100%' }}>
      <Typography variant="h5" sx={{ mb: 2 }}>{title}</Typography>
      {errorMessage && <Alert severity="error" sx={{ mb: 2 }}>{errorMessage}</Alert>}

      <Paper sx={{ p: { xs: 2, md: 3 }, bgcolor: 'background.paper' }}>
        <Stack direction="row" justifyContent="flex-end" sx={{ mb: 2 }}>
          <Button
            variant="contained"
            startIcon={<AddRoundedIcon />}
            onClick={() => setForm({ open: true, mode: 'create', initialValues: {} })}
          >
            Add {title.replace(/s$/, '')}
          </Button>
        </Stack>

        {loading ? (
          <Box sx={{ py: 5, textAlign: 'center' }}><CircularProgress /></Box>
        ) : (
          <TableContainer sx={{ border: `1px solid ${theme.palette.divider}` }}>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: 'action.hover' }}>
                  {columns.map(([label]) => (
                    <TableCell key={label} sx={{ fontWeight: 700 }}>{label}</TableCell>
                  ))}
                  <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700 }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={columns.length + 2} align="center">No records found</TableCell>
                  </TableRow>
                ) : rows.map((row) => (
                  <TableRow key={row._id} hover>
                    {columns.map(([label, getValue]) => (
                      <TableCell key={label}>{getValue(row)}</TableCell>
                    ))}
                    <TableCell>
                      <Chip
                        size="small"
                        label={getStatus?.(row)?.label || 'Active'}
                        color={getStatus?.(row)?.color || 'success'}
                      />
                    </TableCell>
                    <TableCell align="right">
                      <IconButton
                        size="small"
                        onClick={() => setForm({
                          open: true,
                          mode: 'edit',
                          initialValues:
                            normalizeInitialValues?.(row) ||
                            normalizeEditValues(row),
                        })}
                      >
                        <EditOutlinedIcon fontSize="small" />
                      </IconButton>
                      <IconButton
                        size="small"
                        color="error"
                        onClick={() => setDeleteTarget(row)}
                      >
                        <DeleteOutlineRoundedIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Paper>

      {form && (
        <EntityFormDialog
          open={form.open}
          mode={form.mode}
          title={`${form.mode === 'edit' ? 'Edit' : 'Add'} ${title.replace(/s$/, '')}`}
          fields={typeof fields === 'function' ? fields() : fields}
          initialValues={form.initialValues}
          loading={saving}
          onClose={() => setForm(null)}
          onSave={saveRow}
        />
      )}

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Delete record"
        message={`Delete this ${title.replace(/s$/, '').toLowerCase()}?`}
        confirmLabel="Delete"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={deleteRow}
      />
    </Box>
  );
}
