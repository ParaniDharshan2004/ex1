import { render, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import EmployeesPage from '../features/fully-loaded-cost/pages/masters/EmployeesPage';

const { masterTableShell, createResource, updateResource, getResource, getCompanies } =
  vi.hoisted(() => ({
    masterTableShell: vi.fn(() => null),
    createResource: vi.fn(),
    updateResource: vi.fn(),
    getResource: vi.fn(),
    getCompanies: vi.fn(),
  }));

vi.mock('../features/fully-loaded-cost/components/masters/MasterTableShell', () => ({
  default: masterTableShell,
}));

vi.mock('../features/fully-loaded-cost/api/fullyLoadedCostApi', () => ({
  createFullyLoadedCostResource: createResource,
  deleteFullyLoadedCostResource: vi.fn(),
  getFullyLoadedCostCompanies: getCompanies,
  getFullyLoadedCostResource: getResource,
  updateFullyLoadedCostResource: updateResource,
}));

const employeeId = 'employee-1';
const healthCategoryId = 'health-category';
const lifeCategoryId = 'life-category';

describe('employee insurance allocation', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    getCompanies.mockResolvedValue({ data: { data: [] } });
    getResource.mockImplementation((resource) => {
      const data = {
        departments: [{ _id: 'department-1', deptName: 'Administrative' }],
        'insurance-categories': [
          { _id: healthCategoryId, categoryName: 'Health Insurance' },
          { _id: lifeCategoryId, categoryName: 'Life Insurance' },
        ],
        'insurance-items': [
          {
            _id: 'insurance-1',
            empId: employeeId,
            insuranceCategoryId: healthCategoryId,
            policyNo: 'HEALTH-001',
            policyName: 'Health plan',
            effectiveFrom: '2025-01-01T00:00:00.000Z',
          },
          {
            _id: 'insurance-2',
            empId: employeeId,
            insuranceCategoryId: lifeCategoryId,
            policyNo: 'LIFE-001',
            policyName: 'Life plan',
            effectiveFrom: '2025-02-01T00:00:00.000Z',
          },
        ],
      };

      return Promise.resolve({ data: { data: data[resource] || [] } });
    });
    createResource.mockResolvedValue({ data: { data: { _id: 'new-record' } } });
    updateResource.mockResolvedValue({ data: { data: {} } });
  });

  it('keeps policy details separate for each selected category', async () => {
    render(<EmployeesPage />);

    await waitFor(() => {
      expect(masterTableShell).toHaveBeenCalled();
      expect(
        masterTableShell.mock.calls.at(-1)[0].fields.some(
          (field) => field.name === `insurancePolicyNo:${lifeCategoryId}`,
        ),
      ).toBe(true);
    });

    const props = masterTableShell.mock.calls.at(-1)[0];
    expect(props.columns.map(([label]) => label)).not.toContain('Life Insurance');
    expect(props.columns.map(([label]) => label)).not.toContain('Health Insurance');

    const initialValues = props.normalizeInitialValues({
      _id: employeeId,
      deptId: 'department-1',
    });

    expect(initialValues.insuranceCategoryIds).toEqual([
      healthCategoryId,
      lifeCategoryId,
    ]);
    expect(initialValues[`insurancePolicyNo:${healthCategoryId}`]).toBe('HEALTH-001');
    expect(initialValues[`insurancePolicyNo:${lifeCategoryId}`]).toBe('LIFE-001');

    await props.onSave(
      {
        insuranceCategoryIds: [healthCategoryId, lifeCategoryId],
        [`insurancePolicyNo:${healthCategoryId}`]: 'HEALTH-002',
        [`insurancePolicyName:${healthCategoryId}`]: 'New health plan',
        [`insuranceEffectiveFrom:${healthCategoryId}`]: '2026-01-01',
        [`insurancePolicyNo:${lifeCategoryId}`]: 'LIFE-002',
        [`insurancePolicyName:${lifeCategoryId}`]: 'New life plan',
        [`insuranceEffectiveFrom:${lifeCategoryId}`]: '2026-02-01',
      },
      { mode: 'edit', initialValues: { _id: employeeId } },
    );

    expect(createResource).toHaveBeenCalledWith('insurance-items', {
      insuranceCategoryId: healthCategoryId,
      empId: employeeId,
      policyNo: 'HEALTH-002',
      policyName: 'New health plan',
      provider: '',
      effectiveFrom: '2026-01-01',
      renewalDate: null,
      status: 'active',
    });
    expect(createResource).toHaveBeenCalledWith('insurance-items', {
      insuranceCategoryId: lifeCategoryId,
      empId: employeeId,
      policyNo: 'LIFE-002',
      policyName: 'New life plan',
      provider: '',
      effectiveFrom: '2026-02-01',
      renewalDate: null,
      status: 'active',
    });
  });
});
