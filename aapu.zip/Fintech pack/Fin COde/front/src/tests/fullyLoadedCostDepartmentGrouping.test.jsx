import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import FullyLoadedCostAnalysisPage from '../features/fully-loaded-cost/pages/FullyLoadedCostAnalysisPage';
import { getEmployeeDepartmentGroup } from '../features/fully-loaded-cost/utils/employeeDepartmentGrouping';

const { getResource } = vi.hoisted(() => ({
  getResource: vi.fn(),
}));

vi.mock('../features/fully-loaded-cost/api/fullyLoadedCostApi', () => ({
  getFullyLoadedCostResource: getResource,
}));

describe('fully loaded cost employee department grouping', () => {
  it('keeps an administrative employee under the administrative heading when other groups are empty', async () => {
    getResource.mockImplementation((resource) => {
      const data = {
        employees: [
          {
            _id: 'employee-1',
            empName: 'Keiani',
            deptId: { _id: { toString: () => 'admin-department' } },
            status: 'active',
          },
        ],
        departments: [
          { _id: 'admin-department', deptName: 'Administrative Department' },
        ],
        'fixed-asset-depreciations': [
          {
            _id: 'depreciation-1',
            assetValueId: {
              _id: 'asset-value-1',
              assetRegisterId: 'asset-1',
            },
            depreciationAmount: 1200,
          },
        ],
        'fixed-asset-register': [
          { _id: 'asset-1', assetName: 'Air Conditioner' },
        ],
      };

      return Promise.resolve({ data: { data: data[resource] || [] } });
    });

    render(<FullyLoadedCostAnalysisPage />);

    const administrativeHeading = await screen.findByRole('columnheader', {
      name: 'Administrative Department',
    });

    expect(administrativeHeading.colSpan).toBe(2);
    expect(screen.queryByRole('columnheader', { name: 'Reserve Department' })).toBeNull();
    expect(screen.getByRole('columnheader', { name: 'Keiani' })).toBeTruthy();
    expect(
      screen.getAllByRole('columnheader', { name: 'Per Month', exact: true }),
    ).toHaveLength(1);
    expect(screen.getByRole('columnheader', { name: 'Total', exact: true })).toBeTruthy();
    expect(screen.getByRole('columnheader', { name: 'Ratio', exact: true })).toBeTruthy();
    expect(screen.getByText('Direct Labour').closest('td').colSpan).toBe(6);
    expect(screen.getByText('Salary').closest('tr').cells).toHaveLength(6);
    expect(screen.getByText('Office Rent').closest('tr').cells).toHaveLength(6);
    const fixedCostCells = Array.from(
      screen.getByText('Air Conditioner').closest('tr').cells,
      (cell) => cell.textContent,
    );
    expect(fixedCostCells).toEqual([
      'Air Conditioner',
      '₹1,200',
      '1.00',
      '₹1,200',
      '₹100',
      '₹100',
    ]);
  });

  it('resolves an administrative department when its employee reference is an ObjectId-like value', () => {
    const employee = {
      deptId: { _id: { toString: () => 'admin-department' } },
    };
    const departments = [
      { _id: 'admin-department', deptName: 'Administrative Department' },
    ];

    expect(getEmployeeDepartmentGroup(employee, departments)).toBe(
      'administrative',
    );
  });
});
