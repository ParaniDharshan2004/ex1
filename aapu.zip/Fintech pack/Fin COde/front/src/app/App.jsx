import { Routes, Route, Navigate } from "react-router-dom";

import { ThemeProvider, CssBaseline } from "@mui/material";

import { useState } from "react";

import buildTheme from "../theme";

import Dashboard from "../features/dashboard/pages/Dashboard";
import PettyCashPage from "../features/petty-cash/pages/PettyCashPage";
import CashInflowPage from "../features/cash-inflow/pages/CashInflowPage";
import AddComponentsPage from "../features/master-data/pages/AddComponents";
import LoginPage from "../features/auth/pages/LoginPage";

import ProtectedRoute from "./router/ProtectedRoute";
import AppLayout from "./layouts/AppLayout";
import ReportsPage from "../features/reports/pages/ReportsPage";
import CashFlowForecastPage from "../features/cash-flow/pages/CashFlowForcastPage";
import CashFlowEntriesPage from "../features/cash-flow/pages/CashFlowEntriesPage";
import CashFlowReportPage from "../features/cash-flow/pages/CashFlowReportPage";
import ClientsPage from "../features/clients/pages/ClientsPage";

// Operational Expense Command Center pages
import OperationalExpenseDashboardPage from "../features/operational-expense/pages/OperationalExpenseDashboardPage";
import OperationalExpenseUploadReviewPage from "../features/operational-expense/pages/OperationalExpenseUploadReviewPage";
import OperationalExpenseAllocationPage from "../features/operational-expense/pages/OperationalExpenseAllocationPage";
import OperationalExpenseInvoicesPage from "../features/operational-expense/pages/OperationalExpenseInvoicesPage";
import OperationalExpenseReportsPage from "../features/operational-expense/pages/OperationalExpenseReportsPage";
import OperationalExpenseFinalizeReportPage from "../features/operational-expense/pages/OperationalExpenseFinalizeReportPage";
import FullyLoadedCostDashboardPage from "../features/fully-loaded-cost/pages/FullyLoadedCostDashboardPage";
import FullyLoadedCostUploadPage from "../features/fully-loaded-cost/pages/FullyLoadedCostUploadPage";
import FullyLoadedCostReportsPage from "../features/fully-loaded-cost/pages/FullyLoadedCostReportsPage";
import FullyLoadedCostMastersPage from "../features/fully-loaded-cost/pages/FullyLoadedCostMastersPage";
import FullyLoadedCostAnalysisPage from "../features/fully-loaded-cost/pages/FullyLoadedCostAnalysisPage";

import { DataProvider } from "./providers/DataContext.jsx";

export const backendUrl = import.meta.env.VITE_BACKEND_URL;

function App() {
  const [mode] = useState("light");

  const theme = buildTheme(mode);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      <Routes>
        {/* Public Route */}
        <Route path="/login" element={<LoginPage />} />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route path="/" element={<Dashboard />} />

            <Route path="/transactions" element={<PettyCashPage />} />

            <Route path="/cash-inflow" element={<CashInflowPage />} />

            <Route path="/add-components" element={<AddComponentsPage />} />
            <Route path="/clients" element={<ClientsPage />} />

            <Route path="/pettycash-report" element={<ReportsPage />} />
            <Route path="/cash-flow-entry" element={<CashFlowEntriesPage />} />
            <Route path="/cash-flow-analysis" element={<CashFlowForecastPage />} />
            <Route path="/cash-flow-report" element={<CashFlowReportPage />} />

            {/* Operational Expense Command Center Routes */}
            <Route
              path="/operational-expense-finalize/:reportId"
              element={<DataProvider><OperationalExpenseFinalizeReportPage /></DataProvider>}
            />
            <Route
              path="/operational-expense-dashboard"
              element={
                <DataProvider>
                  <OperationalExpenseDashboardPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expenses"
              element={
                <DataProvider>
                  <OperationalExpenseUploadReviewPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expenses/:reportId"
              element={
                <DataProvider>
                  <OperationalExpenseUploadReviewPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expense-allocation"
              element={
                <DataProvider>
                  <OperationalExpenseAllocationPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expense-allocation/:reportId"
              element={
                <DataProvider>
                  <OperationalExpenseAllocationPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expense-invoices"
              element={
                <DataProvider>
                  <OperationalExpenseInvoicesPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expense-invoices/:reportId"
              element={
                <DataProvider>
                  <OperationalExpenseInvoicesPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expense-reports"
              element={
                <DataProvider>
                  <OperationalExpenseReportsPage />
                </DataProvider>
              }
            />
            <Route
              path="/operational-expense-report"
              element={<Navigate to="/operational-expense-reports" replace />}
            />
            <Route
              path="/operational-expense-audit"
              element={
                <DataProvider>
                  <OperationalExpenseDashboardPage />
                </DataProvider>
              }
            />

            <Route
              path="/fully-loaded-cost"
              element={<FullyLoadedCostDashboardPage />}
            />
            <Route
              path="/fully-loaded-cost-upload"
              element={<FullyLoadedCostUploadPage />}
            />
            <Route
              path="/fully-loaded-cost-reports"
              element={<FullyLoadedCostReportsPage />}
            />
            <Route
              path="/fully-loaded-cost-reports/:reportId"
              element={<FullyLoadedCostReportsPage />}
            />
            <Route
              path="/fully-loaded-cost-analysis"
              element={<FullyLoadedCostAnalysisPage />}
            />
            <Route
              path="/fully-loaded-cost-masters"
              element={<Navigate to="/fully-loaded-cost-masters/departments" replace />}
            />
            <Route
              path="/fully-loaded-cost-masters/:masterKey"
              element={<FullyLoadedCostMastersPage />}
            />
          </Route>
        </Route>

        {/* Default Redirect */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;
