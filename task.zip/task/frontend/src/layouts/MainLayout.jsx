/**
 * MainLayout Component
 *
 * Provides the overarching layout frame for the entire application:
 * - Persistent Navbar at the top
 * - Responsive Sidebar / Drawer on the left
 * - Content area hosting routed pages via React Router's <Outlet />
 */

import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import { Box, Toolbar, CssBaseline } from "@mui/material";
import Navbar from "../components/Navbar";
import Sidebar, { DRAWER_WIDTH } from "../components/Sidebar";

const MainLayout = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleMobileNavToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleMobileClose = () => {
    setMobileOpen(false);
  };

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", backgroundColor: "#f4f6f8" }}>
      <CssBaseline />

      {/* Top Navigation Bar */}
      <Navbar onMobileNavToggle={handleMobileNavToggle} />

      {/* Left Navigation Sidebar */}
      <Sidebar mobileOpen={mobileOpen} onMobileClose={handleMobileClose} />

      {/* Main Content Area */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: { xs: 2, sm: 3, md: 4 },
          width: { sm: `calc(100% - ${DRAWER_WIDTH}px)` },
        }}
      >
        {/* Empty toolbar spacer pushes content below the fixed AppBar */}
        <Toolbar />

        {/* Child route page will render here */}
        <Outlet />
      </Box>
    </Box>
  );
};

export default MainLayout;

