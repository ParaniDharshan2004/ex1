/**
 * API Service Layer
 *
 * This module configures Axios and exposes clean, reusable functions
 * for communicating between the React frontend and the Express backend.
 */

import axios from "axios";

// Step 1: Create an Axios instance with base URL from environment variables
// Fallback to http://localhost:5000/api if environment variable is not defined
const API_BASE_URL =
  import.meta.env.VITE_API_URL || "http://localhost:5000/api";

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

/* ==========================================================================
   BOOKS API FUNCTIONS
   ========================================================================== */

/**
 * Fetch all books from the library
 */
export const getBooks = async () => {
  const response = await apiClient.get("/books");
  return response.data;
};

/**
 * Search books by title (case-insensitive partial match)
 * @param {string} title - The title substring to search for
 */
export const searchBooks = async (title) => {
  const response = await apiClient.get("/books/search", {
    params: { title },
  });
  return response.data;
};

/**
 * Fetch details of a single book by its MongoDB ID
 * @param {string} id - Book ID
 */
export const getBookById = async (id) => {
  const response = await apiClient.get(`/books/${id}`);
  return response.data;
};

/**
 * Add a new book to the library
 * @param {Object} bookData - { title, totalCopies }
 */
export const addBook = async (bookData) => {
  const response = await apiClient.post("/books", bookData);
  return response.data;
};

/**
 * Update an existing book's details
 * @param {string} id - Book ID
 * @param {Object} updateData - { title, totalCopies }
 */
export const updateBook = async (id, updateData) => {
  const response = await apiClient.put(`/books/${id}`, updateData);
  return response.data;
};

/**
 * Delete a book from the library
 * @param {string} id - Book ID
 */
export const deleteBook = async (id) => {
  const response = await apiClient.delete(`/books/${id}`);
  return response.data;
};

/* ==========================================================================
   ISSUES & QUEUE API FUNCTIONS
   ========================================================================== */

/**
 * Issue a book copy to a borrower
 * @param {string} bookId - ID of the book being borrowed
 */
export const issueBook = async (bookId) => {
  const response = await apiClient.post("/issues", { bookId });
  return response.data;
};

/**
 * Fetch all issue records (optionally filter by status: ISSUED or RETURNED)
 * @param {string} [status] - Optional status filter
 */
export const getIssues = async (status) => {
  const params = status ? { status } : {};
  const response = await apiClient.get("/issues", { params });
  return response.data;
};

/**
 * Return an issued book copy
 * @param {string} issueId - ID of the issue record being returned
 */
export const returnBook = async (issueId) => {
  const response = await apiClient.post(`/issues/${issueId}/return`);
  return response.data;
};

/**
 * Fetch current state of the backend active in-memory Queue
 */
export const getActiveQueue = async () => {
  const response = await apiClient.get("/issues/queue/status");
  return response.data;
};

/* ==========================================================================
   DASHBOARD & BONUS ANALYTICS API FUNCTIONS
   ========================================================================== */

/**
 * Fetch summary metrics for dashboard (total, available, issued counts)
 */
export const getDashboardStats = async () => {
  const response = await apiClient.get("/dashboard/stats");
  return response.data;
};

/**
 * Bonus API 1: Fetch the book issued the highest number of times
 */
export const getMostIssuedBook = async () => {
  const response = await apiClient.get("/analytics/most-issued");
  return response.data;
};

/**
 * Bonus API 2: Fetch the book with the lowest available copies
 */
export const getLeastAvailableBook = async () => {
  const response = await apiClient.get("/analytics/least-available");
  return response.data;
};

export default apiClient;

