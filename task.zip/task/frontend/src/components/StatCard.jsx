/**
 * StatCard Component
 *
 * A reusable Material UI Card component to display key dashboard metrics
 * with an icon, numerical value, and descriptive label.
 */

import React from "react";
import { Card, CardContent, Typography, Box, Avatar } from "@mui/material";

const StatCard = ({ title, value, icon, color = "#1976d2", subtitle }) => {
  return (
    <Card
      elevation={2}
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        borderRadius: 2,
        transition: "transform 0.2s, box-shadow 0.2s",
        "&:hover": {
          transform: "translateY(-4px)",
          boxShadow: 4,
        },
      }}
    >
      <CardContent>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            mb: 2,
          }}
        >
          <Typography variant="body2" color="text.secondary" fontWeight={500}>
            {title}
          </Typography>
          <Avatar
            sx={{
              backgroundColor: `${color}1A`, // 10% opacity tint
              color: color,
              width: 44,
              height: 44,
            }}
          >
            {icon}
          </Avatar>
        </Box>

        <Typography variant="h4" component="div" fontWeight={700} color="text.primary">
          {value !== undefined && value !== null ? value : "—"}
        </Typography>

        {subtitle && (
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: "block" }}>
            {subtitle}
          </Typography>
        )}
      </CardContent>
    </Card>
  );
};

export default StatCard;

