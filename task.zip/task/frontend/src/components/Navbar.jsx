/**
 * Navbar Component
 *
 * Displays the top navigation bar with application branding
 * and a mobile menu hamburger button.
 */

import React from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Box,
  Chip,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import LocalLibraryIcon from "@mui/icons-material/LocalLibrary";

const Navbar = ({ onMobileNavToggle }) => {
  return (
    <AppBar
      position="fixed"
      sx={{
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backgroundColor: "#1976d2",
        boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
      }}
    >
      <Toolbar>
        {/* Mobile menu button (visible only on small screens) */}
        <IconButton
          color="inherit"
          aria-label="open drawer"
          edge="start"
          onClick={onMobileNavToggle}
          sx={{ mr: 2, display: { sm: "none" } }}
        >
          <MenuIcon />
        </IconButton>

        {/* Library Brand Icon */}
        <LocalLibraryIcon sx={{ mr: 1.5, fontSize: 30 }} />

        {/* System Title */}
        <Typography
          variant="h6"
          noWrap
          component="div"
          sx={{ fontWeight: 600, letterSpacing: 0.5, flexGrow: 1 }}
        >
          Library Book Management System
        </Typography>

        {/* Tech Stack Chip */}
        <Box sx={{ display: { xs: "none", md: "block" } }}>
          <Chip
            label="MERN Stack"
            size="small"
            sx={{
              backgroundColor: "rgba(255, 255, 255, 0.2)",
              color: "#fff",
              fontWeight: 500,
            }}
          />
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;

