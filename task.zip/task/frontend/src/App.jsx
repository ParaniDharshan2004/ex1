/**
 * Main Application Component
 *
 * Configures Material UI Theme and React Router DOM routes.
 */

import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

import MainLayout from "./layouts/MainLayout";
import Dashboard from "./pages/Dashboard";
import Books from "./pages/Books";
import IssueBooks from "./pages/IssueBooks";
import ReturnBooks from "./pages/ReturnBooks";

// Customize Material UI theme
const theme = createTheme({
  palette: {
    primary: {
      main: "#1976d2",
      light: "#42a5f5",
      dark: "#1565c0",
    },
    secondary: {
      main: "#9c27b0",
    },
    background: {
      default: "#f4f6f8",
      paper: "#ffffff",
    },
  },
  typography: {
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    h4: {
      fontWeight: 700,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: "none",
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 12,
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <Routes>
          {/* Main Layout wrapper containing Navbar and Sidebar */}
          <Route path="/" element={<MainLayout />}>
            {/* Dashboard: default home route */}
            <Route index element={<Dashboard />} />

            {/* Feature 1 & 4: Book Management (Add, Edit, Search, Delete) */}
            <Route path="books" element={<Books />} />

            {/* Feature 2: Issue Books */}
            <Route path="issue" element={<IssueBooks />} />

            {/* Feature 3: Return Books */}
            <Route path="return" element={<ReturnBooks />} />

            {/* Catch-all route redirects back to Dashboard */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;

