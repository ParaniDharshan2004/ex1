/**
 * Issue Books Page
 *
 * Implements Feature 2: Issue Books
 * - Displays books with available copies
 * - Allows user to select and issue a book copy
 * - Connects to backend FIFO Queue data structure
 * - Updates available and issued book quantities
 * - Enforces zero-availability validation
 */

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Alert,
  Snackbar,
  Paper,
  Chip,
  Divider,
} from "@mui/material";
import AddShoppingCartIcon from "@mui/icons-material/AddShoppingCart";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import QueueIcon from "@mui/icons-material/Queue";

import { getBooks, issueBook, getActiveQueue } from "../api/api";

const IssueBooks = () => {
  const [books, setBooks] = useState([]);
  const [selectedBookId, setSelectedBookId] = useState("");
  const [loading, setLoading] = useState(true);
  const [issuing, setIssuing] = useState(false);

  // Queue state for teaching visibility
  const [queueInfo, setQueueInfo] = useState({
    size: 0,
    oldestActiveIssue: null,
  });

  // Snackbar notifications
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const showNotification = (message, severity = "success") => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  /**
   * loadData
   * Loads books and current active queue info
   */
  const loadData = async () => {
    try {
      setLoading(true);
      const [booksRes, queueRes] = await Promise.all([
        getBooks(),
        getActiveQueue(),
      ]);

      if (booksRes.success) {
        setBooks(booksRes.data);
      }
      if (queueRes.success) {
        setQueueInfo({
          size: queueRes.size,
          oldestActiveIssue: queueRes.oldestActiveIssue,
        });
      }
    } catch (err) {
      console.error("Failed to load books for issuing:", err);
      showNotification("Failed to fetch available books", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filter books that have available copies > 0
  const availableBooks = books.filter((book) => book.availableCopies > 0);

  // Find currently selected book object
  const selectedBook = books.find((b) => b._id === selectedBookId);

  /**
   * handleIssueBook
   * Executes the issue transaction via POST /api/issues
   */
  const handleIssueBook = async (bookIdToIssue) => {
    const idToUse = bookIdToIssue || selectedBookId;
    if (!idToUse) {
      showNotification("Please select a book to issue", "warning");
      return;
    }

    try {
      setIssuing(true);
      // Step 1: Call POST /api/issues on backend
      const res = await issueBook(idToUse);

      // Step 2: Show success notification
      showNotification(
        res.message || "Book issued successfully and enqueued!",
        "success"
      );

      // Reset dropdown selection
      setSelectedBookId("");

      // Step 3: Refresh books and queue status
      await loadData();
    } catch (err) {
      console.error("Issue book error:", err);
      showNotification(
        err.response?.data?.message || "Failed to issue book",
        "error"
      );
    } finally {
      setIssuing(false);
    }
  };

  return (
    <Box>
      {/* Page Header */}
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700} color="text.primary">
          Issue Books
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Borrow an available book copy. This updates inventory counts and enqueues the record into the FIFO loan queue.
        </Typography>
      </Box>

      {/* Queue Info Banner */}
      <Paper
        elevation={1}
        sx={{
          p: 2,
          mb: 4,
          borderRadius: 2,
          backgroundColor: "#f5f9ff",
          border: "1px solid #bbdefb",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: 2,
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <QueueIcon color="primary" sx={{ fontSize: 32 }} />
          <Box>
            <Typography variant="subtitle1" fontWeight={600} color="primary.main">
              Active Loans FIFO Queue Status
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Issuing enqueues a new record to the back (Tail). Returning removes it from the active queue.
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Chip
            label={`${queueInfo.size} Active Loan(s)`}
            color="primary"
            variant="filled"
          />
          {queueInfo.oldestActiveIssue && (
            <Chip
              label={`Oldest Active: "${queueInfo.oldestActiveIssue.bookTitle}"`}
              color="info"
              variant="outlined"
            />
          )}
        </Box>
      </Paper>

      {/* Quick Issue Selector Card */}
      <Paper elevation={2} sx={{ p: 3, mb: 4, borderRadius: 2 }}>
        <Typography variant="h6" fontWeight={600} gutterBottom>
          Quick Issue by Selection
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Choose any available title from the dropdown below and click "Issue Selected Book".
        </Typography>

        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={8} md={6}>
            <FormControl fullWidth size="small">
              <InputLabel id="select-book-label">Select Available Book</InputLabel>
              <Select
                labelId="select-book-label"
                value={selectedBookId}
                label="Select Available Book"
                onChange={(e) => setSelectedBookId(e.target.value)}
                disabled={availableBooks.length === 0}
              >
                {availableBooks.length === 0 ? (
                  <MenuItem value="" disabled>
                    No books currently have copies available
                  </MenuItem>
                ) : (
                  availableBooks.map((b) => (
                    <MenuItem key={b._id} value={b._id}>
                      {b.title} ({b.availableCopies} copy/copies available)
                    </MenuItem>
                  ))
                )}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={4} md={3}>
            <Button
              variant="contained"
              fullWidth
              startIcon={<AddShoppingCartIcon />}
              onClick={() => handleIssueBook()}
              disabled={!selectedBookId || issuing}
              sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600, py: 1 }}
            >
              {issuing ? <CircularProgress size={24} color="inherit" /> : "Issue Selected Book"}
            </Button>
          </Grid>
        </Grid>

        {selectedBook && (
          <Box sx={{ mt: 2, p: 2, backgroundColor: "#f0fdf4", borderRadius: 1.5, border: "1px solid #bbf7d0" }}>
            <Typography variant="body2" color="success.dark">
              <strong>Selected:</strong> {selectedBook.title} — {selectedBook.availableCopies} available out of {selectedBook.totalCopies} total.
            </Typography>
          </Box>
        )}
      </Paper>

      {/* Available Books Grid Cards */}
      <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>
        Available Books Catalog ({availableBooks.length})
      </Typography>

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", p: 6 }}>
          <CircularProgress />
        </Box>
      ) : availableBooks.length === 0 ? (
        <Alert severity="info" sx={{ borderRadius: 2 }}>
          There are currently no books with available copies. Please check the Book Management tab or wait for borrowed books to be returned.
        </Alert>
      ) : (
        <Grid container spacing={3}>
          {availableBooks.map((book) => (
            <Grid item xs={12} sm={6} md={4} key={book._id}>
              <Card
                elevation={2}
                sx={{
                  height: "100%",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  borderRadius: 2,
                  border: "1px solid #e0e0e0",
                }}
              >
                <CardContent>
                  <Typography variant="h6" fontWeight={700} gutterBottom>
                    {book.title}
                  </Typography>

                  <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", mb: 2 }}>
                    <Chip
                      size="small"
                      icon={<CheckCircleOutlineIcon />}
                      label={`${book.availableCopies} Available`}
                      color="success"
                      variant="filled"
                    />
                    <Chip
                      size="small"
                      label={`Total: ${book.totalCopies}`}
                      variant="outlined"
                    />
                    <Chip
                      size="small"
                      label={`Issued: ${book.issuedCopies}`}
                      variant="outlined"
                    />
                  </Box>

                  <Typography variant="caption" color="text.secondary">
                    MongoDB Book ID: {book._id}
                  </Typography>
                </CardContent>

                <Divider />

                <CardActions sx={{ p: 2 }}>
                  <Button
                    variant="contained"
                    fullWidth
                    size="small"
                    startIcon={<AddShoppingCartIcon />}
                    onClick={() => handleIssueBook(book._id)}
                    disabled={issuing}
                    sx={{ borderRadius: 1.5, textTransform: "none", fontWeight: 600 }}
                  >
                    Issue This Copy
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: "100%", borderRadius: 2 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default IssueBooks;

