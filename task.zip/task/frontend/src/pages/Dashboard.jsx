/**
 * Dashboard Page
 *
 * Displays high-level library metrics:
 * - Total Copies, Available Copies, Issued Copies
 * - Bonus 1: Most Issued Book
 * - Bonus 2: Least Available Book
 * - Active Issue Queue monitor (FIFO order inspection)
 */

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardHeader,
  Button,
  CircularProgress,
  Alert,
  Divider,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import MenuBookIcon from "@mui/icons-material/MenuBook";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AssignmentTurnedInIcon from "@mui/icons-material/AssignmentTurnedIn";
import StarIcon from "@mui/icons-material/Star";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import QueueIcon from "@mui/icons-material/Queue";
import FormatListNumberedIcon from "@mui/icons-material/FormatListNumbered";

import StatCard from "../components/StatCard";
import {
  getDashboardStats,
  getMostIssuedBook,
  getLeastAvailableBook,
  getActiveQueue,
} from "../api/api";

const Dashboard = () => {
  // State for metrics data
  const [stats, setStats] = useState({
    totalTitles: 0,
    totalCopies: 0,
    availableCopies: 0,
    issuedCopies: 0,
    activeIssuesCount: 0,
  });

  // State for bonus analytics
  const [mostIssued, setMostIssued] = useState(null);
  const [leastAvailable, setLeastAvailable] = useState(null);

  // State for Queue status
  const [queueState, setQueueState] = useState({
    size: 0,
    isEmpty: true,
    oldestActiveIssue: null,
    queueItems: [],
  });

  // Loading and error states
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  /**
   * fetchAllDashboardData
   * Loads statistics, bonus analytics, and current active queue in parallel.
   */
  const fetchAllDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Execute all 4 API calls concurrently using Promise.all
      const [statsRes, mostIssuedRes, leastAvailRes, queueRes] =
        await Promise.all([
          getDashboardStats(),
          getMostIssuedBook(),
          getLeastAvailableBook(),
          getActiveQueue(),
        ]);

      if (statsRes.success) {
        setStats(statsRes.data);
      }
      if (mostIssuedRes.success) {
        setMostIssued(mostIssuedRes.data);
      }
      if (leastAvailRes.success) {
        setLeastAvailable(leastAvailRes.data);
      }
      if (queueRes.success) {
        setQueueState(queueRes);
      }
    } catch (err) {
      console.error("Error fetching dashboard data:", err);
      setError(
        err.response?.data?.message ||
          "Failed to load dashboard data. Ensure backend is running."
      );
    } finally {
      setLoading(false);
    }
  };

  // Fetch metrics when page mounts
  useEffect(() => {
    fetchAllDashboardData();
  }, []);

  return (
    <Box>
      {/* Page Header */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
          flexWrap: "wrap",
          gap: 2,
        }}
      >
        <Box>
          <Typography variant="h4" fontWeight={700} color="text.primary">
            Library Dashboard
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Real-time book inventory counts, bonus analytics, and active issue queue
          </Typography>
        </Box>

        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={fetchAllDashboardData}
          disabled={loading}
          sx={{ borderRadius: 2, textTransform: "none" }}
        >
          Refresh Data
        </Button>
      </Box>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Loading Indicator */}
      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", p: 8 }}>
          <CircularProgress size={48} />
        </Box>
      ) : (
        <>
          {/* Main Inventory Stat Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            {/* Total Copies */}
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Book Copies"
                value={stats.totalCopies}
                icon={<MenuBookIcon />}
                color="#1976d2"
                subtitle={`Across ${stats.totalTitles} unique title(s)`}
              />
            </Grid>

            {/* Available Copies */}
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Available Copies"
                value={stats.availableCopies}
                icon={<CheckCircleIcon />}
                color="#2e7d32"
                subtitle="Ready on shelf for borrowing"
              />
            </Grid>

            {/* Issued Copies */}
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Issued Copies"
                value={stats.issuedCopies}
                icon={<AssignmentTurnedInIcon />}
                color="#ed6c02"
                subtitle="Currently in borrowers' hands"
              />
            </Grid>

            {/* Active Queue Size */}
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Active Loans in Queue"
                value={queueState.size}
                icon={<QueueIcon />}
                color="#9c27b0"
                subtitle="Tracked in memory FIFO order"
              />
            </Grid>
          </Grid>

          {/* Bonus Analytics Section */}
          <Typography variant="h5" fontWeight={600} sx={{ mb: 2 }}>
            Bonus Analytics Insights
          </Typography>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            {/* Bonus 1: Most Issued Book */}
            <Grid item xs={12} md={6}>
              <Card elevation={2} sx={{ borderRadius: 2, height: "100%" }}>
                <CardHeader
                  avatar={<StarIcon sx={{ color: "#fbc02d" }} />}
                  title={
                    <Typography variant="h6" fontWeight={600}>
                      Bonus API 1: Most Issued Book
                    </Typography>
                  }
                  subheader="Computed from historical issue records in MongoDB"
                />
                <Divider />
                <CardContent>
                  {mostIssued ? (
                    <Box>
                      <Typography variant="h5" fontWeight={700} color="primary.main" gutterBottom>
                        {mostIssued.title}
                      </Typography>
                      <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap", mt: 2 }}>
                        <Chip
                          label={`Total Times Issued: ${mostIssued.issueCount}`}
                          color="primary"
                          variant="filled"
                        />
                        <Chip
                          label={`Currently Available: ${mostIssued.availableCopies ?? "N/A"}`}
                          color="success"
                          variant="outlined"
                        />
                      </Box>
                    </Box>
                  ) : (
                    <Typography color="text.secondary">
                      No issue history recorded yet. Issue books to see rankings!
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>

            {/* Bonus 2: Least Available Book */}
            <Grid item xs={12} md={6}>
              <Card elevation={2} sx={{ borderRadius: 2, height: "100%" }}>
                <CardHeader
                  avatar={<WarningAmberIcon sx={{ color: "#d32f2f" }} />}
                  title={
                    <Typography variant="h6" fontWeight={600}>
                      Bonus API 2: Least Available Book
                    </Typography>
                  }
                  subheader="Identifies lowest in-stock title for restocking"
                />
                <Divider />
                <CardContent>
                  {leastAvailable ? (
                    <Box>
                      <Typography variant="h5" fontWeight={700} color="error.main" gutterBottom>
                        {leastAvailable.title}
                      </Typography>
                      <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap", mt: 2 }}>
                        <Chip
                          label={`Available Copies: ${leastAvailable.availableCopies}`}
                          color={leastAvailable.availableCopies === 0 ? "error" : "warning"}
                          variant="filled"
                        />
                        <Chip
                          label={`Total Owned Copies: ${leastAvailable.totalCopies}`}
                          variant="outlined"
                        />
                        <Chip
                          label={`Issued Out: ${leastAvailable.issuedCopies}`}
                          variant="outlined"
                        />
                      </Box>
                    </Box>
                  ) : (
                    <Typography color="text.secondary">
                      No books found in the library catalog yet.
                    </Typography>
                  )}
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Active Queue Visualizer */}
          <Card elevation={2} sx={{ borderRadius: 2 }}>
            <CardHeader
              avatar={<FormatListNumberedIcon color="primary" />}
              title={
                <Typography variant="h6" fontWeight={600}>
                  Active Loans FIFO Queue (In-Memory Data Structure)
                </Typography>
              }
              subheader={`Current Queue Size: ${queueState.size} active loan(s). Oldest issue at the front (Head), newest at the back (Tail).`}
              action={
                <Chip
                  label={queueState.isEmpty ? "Queue Empty" : `${queueState.size} Active in Queue`}
                  color={queueState.isEmpty ? "default" : "info"}
                />
              }
            />
            <Divider />
            <CardContent>
              {queueState.isEmpty ? (
                <Typography color="text.secondary" sx={{ py: 2 }}>
                  No books are currently issued. The FIFO queue is empty.
                </Typography>
              ) : (
                <List dense>
                  {queueState.queueItems.map((item, index) => (
                    <ListItem
                      key={item._id || index}
                      sx={{
                        border: "1px solid #e0e0e0",
                        borderRadius: 1,
                        mb: 1,
                        backgroundColor: index === 0 ? "rgba(25, 118, 210, 0.05)" : "transparent",
                      }}
                    >
                      <ListItemIcon>
                        <Chip
                          size="small"
                          label={index === 0 ? "HEAD (Oldest)" : `#${index + 1}`}
                          color={index === 0 ? "primary" : "default"}
                        />
                      </ListItemIcon>
                      <ListItemText
                        primary={item.bookTitle}
                        secondary={`Issue ID: ${item._id} | Issued: ${new Date(
                          item.issuedAt
                        ).toLocaleString()}`}
                      />
                    </ListItem>
                  ))}
                </List>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </Box>
  );
};

export default Dashboard;

