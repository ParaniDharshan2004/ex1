/**
 * Return Books Page
 *
 * Implements Feature 3: Return Books
 * - Displays active book loans (status: 'ISSUED')
 * - Allows returning an issued copy
 * - Decrements issued copy count, increments available copy count
 * - Updates issue record status to 'RETURNED' with return timestamp
 * - Removes loan from active Queue
 * - Prevents double return operations
 */

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Chip,
  CircularProgress,
  Snackbar,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Divider,
} from "@mui/material";
import AssignmentReturnedIcon from "@mui/icons-material/AssignmentReturned";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AccessTimeIcon from "@mui/icons-material/AccessTime";

import { getIssues, returnBook } from "../api/api";

const ReturnBooks = () => {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);

  // Return Confirmation Dialog state
  const [returnDialogOpen, setReturnDialogOpen] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [returning, setReturning] = useState(false);

  // Snackbar notifications
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const showNotification = (message, severity = "success") => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  /**
   * loadActiveIssues
   * Fetches only active loans (status: ISSUED) from backend
   */
  const loadActiveIssues = async () => {
    try {
      setLoading(true);
      const res = await getIssues("ISSUED");
      if (res.success) {
        setIssues(res.data);
      }
    } catch (err) {
      console.error("Failed to load active issues:", err);
      showNotification("Failed to load issued records", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActiveIssues();
  }, []);

  /**
   * Open return confirmation modal
   */
  const handleOpenReturnModal = (issue) => {
    setSelectedIssue(issue);
    setReturnDialogOpen(true);
  };

  const handleCloseReturnModal = () => {
    if (!returning) {
      setReturnDialogOpen(false);
      setSelectedIssue(null);
    }
  };

  /**
   * handleConfirmReturn
   * Calls POST /api/issues/:id/return
   */
  const handleConfirmReturn = async () => {
    if (!selectedIssue) return;

    try {
      setReturning(true);
      // Step 1: Execute return API call
      const res = await returnBook(selectedIssue._id);

      // Step 2: Show confirmation
      showNotification(
        res.message || `"${selectedIssue.bookTitle}" returned successfully!`,
        "success"
      );

      // Step 3: Close modal and refresh active issued list
      setReturnDialogOpen(false);
      setSelectedIssue(null);
      await loadActiveIssues();
    } catch (err) {
      console.error("Error returning book:", err);
      showNotification(
        err.response?.data?.message || "Failed to process book return",
        "error"
      );
    } finally {
      setReturning(false);
    }
  };

  return (
    <Box>
      {/* Page Header */}
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700} color="text.primary">
          Return Books
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Manage and return currently borrowed book copies. Restores available shelf inventory and updates the active queue.
        </Typography>
      </Box>

      {/* Active Loans Table */}
      <TableContainer component={Paper} elevation={2} sx={{ borderRadius: 2 }}>
        <Box sx={{ p: 2, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <Typography variant="h6" fontWeight={600}>
            Active Issued Book Records ({issues.length})
          </Typography>
          <Button
            size="small"
            variant="outlined"
            onClick={loadActiveIssues}
            disabled={loading}
            sx={{ textTransform: "none", borderRadius: 1.5 }}
          >
            Refresh List
          </Button>
        </Box>
        <Divider />

        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", p: 6 }}>
            <CircularProgress />
          </Box>
        ) : issues.length === 0 ? (
          <Box sx={{ p: 6, textAlign: "center" }}>
            <CheckCircleIcon sx={{ fontSize: 48, color: "success.main", mb: 1 }} />
            <Typography variant="h6" fontWeight={600} color="text.primary">
              All books are returned!
            </Typography>
            <Typography variant="body2" color="text.secondary">
              There are currently no outstanding loans. All book copies are safely on the library shelves.
            </Typography>
          </Box>
        ) : (
          <Table>
            <TableHead sx={{ backgroundColor: "#f0f4f8" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: 600 }}>Book Title</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Issue ID</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Date & Time Issued</TableCell>
                <TableCell align="center" sx={{ fontWeight: 600 }}>
                  Loan Status
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  Action
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {issues.map((issue) => (
                <TableRow key={issue._id} hover>
                  <TableCell>
                    <Typography variant="body1" fontWeight={600}>
                      {issue.bookTitle}
                    </Typography>
                    {issue.bookId && (
                      <Typography variant="caption" color="text.secondary">
                        Catalog Copies: {issue.bookId.availableCopies} available / {issue.bookId.totalCopies} total
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" sx={{ fontFamily: "monospace", color: "text.secondary" }}>
                      {issue._id}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                      <AccessTimeIcon fontSize="small" color="action" />
                      <Typography variant="body2">
                        {new Date(issue.issuedAt).toLocaleString()}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell align="center">
                    <Chip
                      size="small"
                      label="ISSUED"
                      color="warning"
                      variant="filled"
                      sx={{ fontWeight: 600 }}
                    />
                  </TableCell>
                  <TableCell align="right">
                    <Button
                      variant="contained"
                      color="primary"
                      size="small"
                      startIcon={<AssignmentReturnedIcon />}
                      onClick={() => handleOpenReturnModal(issue)}
                      sx={{ borderRadius: 1.5, textTransform: "none", fontWeight: 600 }}
                    >
                      Return Book
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </TableContainer>

      {/* Return Confirmation Dialog */}
      <Dialog
        open={returnDialogOpen}
        onClose={handleCloseReturnModal}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <DialogTitle sx={{ fontWeight: 700 }}>
          Confirm Book Return
        </DialogTitle>
        <DialogContent dividers>
          <Typography variant="body1" gutterBottom>
            Process return for <strong>"{selectedIssue?.bookTitle}"</strong>?
          </Typography>
          <Box sx={{ mt: 2, p: 2, backgroundColor: "#f8fafc", borderRadius: 1, border: "1px solid #e2e8f0" }}>
            <Typography variant="body2" color="text.secondary">
              • Available shelf copies will increase by 1.
            </Typography>
            <Typography variant="body2" color="text.secondary">
              • Issued copies count will decrease by 1.
            </Typography>
            <Typography variant="body2" color="text.secondary">
              • Issue record status will be updated to "RETURNED".
            </Typography>
            <Typography variant="body2" color="text.secondary">
              • Record will be removed from the active in-memory Queue.
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            onClick={handleCloseReturnModal}
            disabled={returning}
            sx={{ textTransform: "none" }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleConfirmReturn}
            disabled={returning}
            sx={{ textTransform: "none", fontWeight: 600, minWidth: 100 }}
          >
            {returning ? <CircularProgress size={24} color="inherit" /> : "Confirm Return"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar Alert */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: "100%", borderRadius: 2 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ReturnBooks;

