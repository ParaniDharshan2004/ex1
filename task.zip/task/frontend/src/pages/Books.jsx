/**
 * Books Management Page
 *
 * Implements:
 * - Feature 1: Add Books (with validation, CRUD, success/error alerts, refresh)
 * - Feature 4: Search Books by Title (partial title matching, empty search handling, no results state)
 * - Edit book information
 * - Delete book (safely blocked if active issues exist)
 */

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Button,
  TextField,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  Snackbar,
  Alert,
  CircularProgress,
  Tooltip,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import SearchIcon from "@mui/icons-material/Search";
import ClearIcon from "@mui/icons-material/Clear";
import EditIcon from "@mui/icons-material/Edit";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";

import {
  getBooks,
  searchBooks,
  addBook,
  updateBook,
  deleteBook,
} from "../api/api";

const Books = () => {
  // Books list state
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  // Search state
  const [searchQuery, setSearchQuery] = useState("");

  // Add/Edit Dialog modal state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedBookId, setSelectedBookId] = useState(null);
  const [formData, setFormData] = useState({
    title: "",
    totalCopies: 1,
  });
  const [formErrors, setFormErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  // Delete Confirmation Dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [bookToDelete, setBookToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // Snackbar notification state
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  /**
   * showNotification
   * Helper to trigger toast snackbar notifications
   */
  const showNotification = (message, severity = "success") => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  /**
   * loadBooks
   * Loads all books from the backend
   */
  const loadBooks = async () => {
    try {
      setLoading(true);
      const res = await getBooks();
      if (res.success) {
        setBooks(res.data);
      }
    } catch (err) {
      console.error("Failed to load books:", err);
      showNotification(
        err.response?.data?.message || "Failed to load books",
        "error"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBooks();
  }, []);

  /**
   * handleSearch
   * Executes partial-title search via GET /api/books/search?title=...
   */
  const handleSearch = async (e) => {
    if (e) e.preventDefault();
    try {
      setLoading(true);
      const res = await searchBooks(searchQuery);
      if (res.success) {
        setBooks(res.data);
      }
    } catch (err) {
      console.error("Search error:", err);
      showNotification("Error executing search query", "error");
    } finally {
      setLoading(false);
    }
  };

  /**
   * handleClearSearch
   * Resets the search input and reloads all books
   */
  const handleClearSearch = () => {
    setSearchQuery("");
    loadBooks();
  };

  /**
   * Open modal to Add Book
   */
  const handleOpenAddDialog = () => {
    setIsEditing(false);
    setSelectedBookId(null);
    setFormData({ title: "", totalCopies: 1 });
    setFormErrors({});
    setDialogOpen(true);
  };

  /**
   * Open modal to Edit Book
   */
  const handleOpenEditDialog = (book) => {
    setIsEditing(true);
    setSelectedBookId(book._id);
    setFormData({
      title: book.title,
      totalCopies: book.totalCopies,
    });
    setFormErrors({});
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    if (!submitting) {
      setDialogOpen(false);
    }
  };

  /**
   * validateForm
   * Validates title and totalCopies fields
   */
  const validateForm = () => {
    const errors = {};
    if (!formData.title || !formData.title.trim()) {
      errors.title = "Book title is required";
    }
    const copies = parseInt(formData.totalCopies, 10);
    if (isNaN(copies) || copies <= 0) {
      errors.totalCopies = "Total copies must be a positive number greater than 0";
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  /**
   * handleSubmitBook
   * Submits new or edited book to the backend
   */
  const handleSubmitBook = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setSubmitting(true);
      if (isEditing) {
        // Step 1: Update book details via PUT /api/books/:id
        const res = await updateBook(selectedBookId, {
          title: formData.title.trim(),
          totalCopies: parseInt(formData.totalCopies, 10),
        });
        showNotification(res.message || "Book updated successfully", "success");
      } else {
        // Step 2: Add new book via POST /api/books
        const res = await addBook({
          title: formData.title.trim(),
          totalCopies: parseInt(formData.totalCopies, 10),
        });
        showNotification(res.message || "Book added successfully", "success");
      }

      setDialogOpen(false);
      // Step 3: Refresh book list
      loadBooks();
    } catch (err) {
      console.error("Save book error:", err);
      showNotification(
        err.response?.data?.message || "Failed to save book",
        "error"
      );
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * Open Delete confirmation dialog
   */
  const handleOpenDeleteDialog = (book) => {
    setBookToDelete(book);
    setDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    if (!deleting) {
      setDeleteDialogOpen(false);
      setBookToDelete(null);
    }
  };

  /**
   * handleConfirmDelete
   * Calls DELETE /api/books/:id
   */
  const handleConfirmDelete = async () => {
    if (!bookToDelete) return;
    try {
      setDeleting(true);
      const res = await deleteBook(bookToDelete._id);
      showNotification(res.message || "Book deleted successfully", "success");
      setDeleteDialogOpen(false);
      setBookToDelete(null);
      loadBooks();
    } catch (err) {
      console.error("Delete book error:", err);
      showNotification(
        err.response?.data?.message || "Failed to delete book",
        "error"
      );
    } finally {
      setDeleting(false);
    }
  };

  return (
    <Box>
      {/* Page Header */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
          flexWrap: "wrap",
          gap: 2,
        }}
      >
        <Box>
          <Typography variant="h4" fontWeight={700} color="text.primary">
            Book Management
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage your book inventory, track copy availability, and search titles
          </Typography>
        </Box>

        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleOpenAddDialog}
          sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}
        >
          Add New Book
        </Button>
      </Box>

      {/* Feature 4: Search Bar */}
      <Paper
        component="form"
        onSubmit={handleSearch}
        elevation={1}
        sx={{
          p: 2,
          mb: 3,
          display: "flex",
          alignItems: "center",
          gap: 2,
          borderRadius: 2,
        }}
      >
        <TextField
          fullWidth
          size="small"
          placeholder="Search books by title (partial or full match)..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon color="action" />
              </InputAdornment>
            ),
            endAdornment: searchQuery && (
              <InputAdornment position="end">
                <IconButton size="small" onClick={handleClearSearch}>
                  <ClearIcon fontSize="small" />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        <Button
          variant="contained"
          type="submit"
          sx={{ borderRadius: 2, textTransform: "none", minWidth: 100 }}
        >
          Search
        </Button>
      </Paper>

      {/* Books Table */}
      <TableContainer component={Paper} elevation={2} sx={{ borderRadius: 2 }}>
        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", p: 6 }}>
            <CircularProgress />
          </Box>
        ) : books.length === 0 ? (
          <Box sx={{ p: 6, textAlign: "center" }}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No matching books found.
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              {searchQuery
                ? `No books match the title "${searchQuery}". Try a different keyword.`
                : "Your library is currently empty. Click 'Add New Book' above to get started!"}
            </Typography>
            {searchQuery && (
              <Button
                variant="outlined"
                onClick={handleClearSearch}
                sx={{ borderRadius: 2, textTransform: "none" }}
              >
                Clear Search Filter
              </Button>
            )}
          </Box>
        ) : (
          <Table>
            <TableHead sx={{ backgroundColor: "#f0f4f8" }}>
              <TableRow>
                <TableCell sx={{ fontWeight: 600 }}>Book Title</TableCell>
                <TableCell align="center" sx={{ fontWeight: 600 }}>
                  Total Copies
                </TableCell>
                <TableCell align="center" sx={{ fontWeight: 600 }}>
                  Available
                </TableCell>
                <TableCell align="center" sx={{ fontWeight: 600 }}>
                  Issued
                </TableCell>
                <TableCell align="center" sx={{ fontWeight: 600 }}>
                  Status
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: 600 }}>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {books.map((book) => {
                const isOutOfStock = book.availableCopies <= 0;
                return (
                  <TableRow key={book._id} hover>
                    <TableCell>
                      <Typography variant="body1" fontWeight={600}>
                        {book.title}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        ID: {book._id}
                      </Typography>
                    </TableCell>
                    <TableCell align="center">{book.totalCopies}</TableCell>
                    <TableCell align="center">
                      <Typography
                        variant="body2"
                        fontWeight={600}
                        color={isOutOfStock ? "error.main" : "success.main"}
                      >
                        {book.availableCopies}
                      </Typography>
                    </TableCell>
                    <TableCell align="center">{book.issuedCopies}</TableCell>
                    <TableCell align="center">
                      <Chip
                        size="small"
                        label={isOutOfStock ? "Out of Stock" : "Available"}
                        color={isOutOfStock ? "error" : "success"}
                        variant={isOutOfStock ? "filled" : "outlined"}
                      />
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="Edit Book">
                        <IconButton
                          color="primary"
                          size="small"
                          onClick={() => handleOpenEditDialog(book)}
                          sx={{ mr: 1 }}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Delete Book">
                        <IconButton
                          color="error"
                          size="small"
                          onClick={() => handleOpenDeleteDialog(book)}
                        >
                          <DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </TableContainer>

      {/* Feature 1: Add / Edit Book Modal Dialog */}
      <Dialog
        open={dialogOpen}
        onClose={handleCloseDialog}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <DialogTitle sx={{ fontWeight: 700 }}>
          {isEditing ? "Edit Book Information" : "Add New Book to Library"}
        </DialogTitle>
        <form onSubmit={handleSubmitBook}>
          <DialogContent dividers>
            <TextField
              autoFocus
              margin="dense"
              label="Book Title"
              fullWidth
              variant="outlined"
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              error={Boolean(formErrors.title)}
              helperText={formErrors.title}
              sx={{ mb: 3 }}
            />

            <TextField
              margin="dense"
              label="Total Copies"
              type="number"
              fullWidth
              variant="outlined"
              inputProps={{ min: 1 }}
              value={formData.totalCopies}
              onChange={(e) =>
                setFormData({ ...formData, totalCopies: e.target.value })
              }
              error={Boolean(formErrors.totalCopies)}
              helperText={
                formErrors.totalCopies ||
                (isEditing
                  ? "Note: Cannot be set lower than currently issued copies"
                  : "All copies will be initially available on the shelf")
              }
            />
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button
              onClick={handleCloseDialog}
              disabled={submitting}
              sx={{ textTransform: "none" }}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              disabled={submitting}
              sx={{ textTransform: "none", fontWeight: 600, minWidth: 100 }}
            >
              {submitting ? (
                <CircularProgress size={24} color="inherit" />
              ) : isEditing ? (
                "Update Book"
              ) : (
                "Save Book"
              )}
            </Button>
          </DialogActions>
        </form>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={handleCloseDeleteDialog}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: 2 } }}
      >
        <DialogTitle sx={{ fontWeight: 700, color: "error.main" }}>
          Confirm Delete
        </DialogTitle>
        <DialogContent dividers>
          <Typography variant="body1">
            Are you sure you want to delete{" "}
            <strong>"{bookToDelete?.title}"</strong> from the catalog?
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: "block" }}>
            Note: Books with copies currently borrowed cannot be deleted.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={handleCloseDeleteDialog} disabled={deleting} sx={{ textTransform: "none" }}>
            Cancel
          </Button>
          <Button
            onClick={handleConfirmDelete}
            color="error"
            variant="contained"
            disabled={deleting}
            sx={{ textTransform: "none", fontWeight: 600 }}
          >
            {deleting ? <CircularProgress size={24} color="inherit" /> : "Delete"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar Alert */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: "100%", borderRadius: 2 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Books;

