/**
 * End-to-End API and Workflow Test Suite
 *
 * Verifies all 7 required test workflows:
 * Test 1: Add Book (Mongoose persistence, copy initialization)
 * Test 2: Issue Book (Quantity decrements, issue created, FIFO queue receives)
 * Test 3: Return Book (Quantity increments, status RETURNED, queue updated, double-return prevention)
 * Test 4: Search Books by Title (complete, partial, nonexistent)
 * Test 5: Dashboard Stats (counts, dynamic calculation)
 * Test 6: Bonus APIs (Most Issued Book, Least Available Book)
 * Test 7: CRUD & Constraints (Create, Read, Update, Delete with active loan protection)
 */

const http = require("http");
const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");
const { app } = require("./server");
const Book = require("./models/Book");
const Issue = require("./models/Issue");
const { activeIssueQueue } = require("./utils/Queue");

// Helper for making HTTP JSON requests against our Express app
function makeRequest(server, options, requestData = null) {
  return new Promise((resolve, reject) => {
    const address = server.address();
    const port = address.port;

    const reqOptions = {
      hostname: "127.0.0.1",
      port: port,
      path: options.path,
      method: options.method || "GET",
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {}),
      },
    };

    const req = http.request(reqOptions, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode, body: parsed });
        } catch {
          resolve({ status: res.statusCode, raw: data });
        }
      });
    });

    req.on("error", (err) => {
      reject(err);
    });

    if (requestData) {
      req.write(JSON.stringify(requestData));
    }
    req.end();
  });
}

async function runTests() {
  console.log("=================================================");
  console.log("   LIBRARY MANAGEMENT SYSTEM - INTEGRATION TESTS ");
  console.log("=================================================\n");

  let mongod = null;
  let server = null;

  try {
    // Step 0: Start MongoMemoryServer and connect Mongoose
    console.log("Starting In-Memory MongoDB Server...");
    mongod = await MongoMemoryServer.create();
    const uri = mongod.getUri();
    await mongoose.connect(uri);
    console.log("Connected to In-Memory MongoDB successfully.\n");

    // Start Express server on random ephemeral port
    server = app.listen(0);
    const port = server.address().port;
    console.log(`Test Express server listening on port ${port}.\n`);

    /* ==========================================================================
       TEST 1: ADD BOOK
       ========================================================================== */
    console.log("--- TEST 1: Add Book ---");
    const bookPayload = {
      title: "Clean Architecture",
      totalCopies: 5,
    };
    const addRes = await makeRequest(
      server,
      { method: "POST", path: "/api/books" },
      bookPayload
    );
    console.log("POST /api/books status:", addRes.status);
    if (addRes.status !== 201 || !addRes.body.success) {
      throw new Error(`Failed to add book: ${JSON.stringify(addRes.body)}`);
    }
    const book1 = addRes.body.data;
    if (book1.availableCopies !== 5 || book1.issuedCopies !== 0) {
      throw new Error("Copy counts not initialized properly");
    }
    // Verify in MongoDB
    const bookInDb = await Book.findById(book1._id);
    if (!bookInDb) {
      throw new Error("Book was not persisted in MongoDB");
    }
    console.log("✔ Test 1 Passed: Book created and verified in MongoDB\n");

    /* ==========================================================================
       TEST 2: ISSUE BOOK & QUEUE
       ========================================================================== */
    console.log("--- TEST 2: Issue Book & Queue Verification ---");
    const issueRes1 = await makeRequest(
      server,
      { method: "POST", path: "/api/issues" },
      { bookId: book1._id }
    );
    console.log("POST /api/issues status:", issueRes1.status);
    if (issueRes1.status !== 201 || !issueRes1.body.success) {
      throw new Error(`Failed to issue book: ${JSON.stringify(issueRes1.body)}`);
    }
    const issue1 = issueRes1.body.data.issue;
    // Verify book inventory updated
    const bookAfterIssue1 = await Book.findById(book1._id);
    if (bookAfterIssue1.availableCopies !== 4 || bookAfterIssue1.issuedCopies !== 1) {
      throw new Error(`Inventory copy count mismatch: available=${bookAfterIssue1.availableCopies}, issued=${bookAfterIssue1.issuedCopies}`);
    }
    // Verify Queue received the record
    if (activeIssueQueue.size() !== 1) {
      throw new Error(`Queue size expected 1, got ${activeIssueQueue.size()}`);
    }
    if (activeIssueQueue.peek()._id.toString() !== issue1._id.toString()) {
      throw new Error("Queue head does not match issued record ID");
    }
    console.log("✔ Test 2 Passed: Book issued, inventory updated, Queue received loan in FIFO order\n");

    /* ==========================================================================
       TEST 3: RETURN BOOK & DOUBLE RETURN PREVENTION
       ========================================================================== */
    console.log("--- TEST 3: Return Book & Double-Return Prevention ---");
    // Return the book copy
    const returnRes1 = await makeRequest(
      server,
      { method: "POST", path: `/api/issues/${issue1._id}/return` }
    );
    console.log(`POST /api/issues/${issue1._id}/return status:`, returnRes1.status);
    if (returnRes1.status !== 200 || !returnRes1.body.success) {
      throw new Error(`Failed to return book: ${JSON.stringify(returnRes1.body)}`);
    }
    // Verify inventory restored
    const bookAfterReturn1 = await Book.findById(book1._id);
    if (bookAfterReturn1.availableCopies !== 5 || bookAfterReturn1.issuedCopies !== 0) {
      throw new Error("Inventory copy count not restored on return");
    }
    // Verify Queue updated
    if (activeIssueQueue.size() !== 0) {
      throw new Error(`Queue size expected 0 after return, got ${activeIssueQueue.size()}`);
    }
    // Verify Double-Return Prevention
    const doubleReturnRes = await makeRequest(
      server,
      { method: "POST", path: `/api/issues/${issue1._id}/return` }
    );
    console.log("Double return status:", doubleReturnRes.status);
    if (doubleReturnRes.status !== 400 || doubleReturnRes.body.success) {
      throw new Error("Double-return was not prevented!");
    }
    console.log("✔ Test 3 Passed: Return restored inventory, dequeued active record, and blocked duplicate return\n");

    /* ==========================================================================
       TEST 4: SEARCH BOOKS BY TITLE
       ========================================================================== */
    console.log("--- TEST 4: Search Books by Title ---");
    // Add two more books
    await makeRequest(
      server,
      { method: "POST", path: "/api/books" },
      { title: "Design Patterns in JavaScript", totalCopies: 3 }
    );
    await makeRequest(
      server,
      { method: "POST", path: "/api/books" },
      { title: "Learning Node.js", totalCopies: 2 }
    );

    // 4a. Complete title search
    const exactSearch = await makeRequest(
      server,
      { method: "GET", path: "/api/books/search?title=Learning%20Node.js" }
    );
    if (exactSearch.body.count !== 1 || exactSearch.body.data[0].title !== "Learning Node.js") {
      throw new Error("Complete title search failed");
    }

    // 4b. Partial title search (case-insensitive)
    const partialSearch = await makeRequest(
      server,
      { method: "GET", path: "/api/books/search?title=pattern" }
    );
    if (partialSearch.body.count !== 1 || !partialSearch.body.data[0].title.includes("Patterns")) {
      throw new Error("Partial title search failed");
    }

    // 4c. Nonexistent title search
    const emptySearch = await makeRequest(
      server,
      { method: "GET", path: "/api/books/search?title=QuantumTeleportation" }
    );
    if (emptySearch.body.count !== 0 || emptySearch.body.data.length !== 0) {
      throw new Error("Nonexistent title should return 0 results");
    }
    console.log("✔ Test 4 Passed: Complete, partial, and nonexistent searches work accurately\n");

    /* ==========================================================================
       TEST 5: DASHBOARD STATISTICS
       ========================================================================== */
    console.log("--- TEST 5: Dashboard Statistics ---");
    // Currently 3 books:
    // 1. Clean Architecture: 5 copies (5 available, 0 issued)
    // 2. Design Patterns in JavaScript: 3 copies (3 available, 0 issued)
    // 3. Learning Node.js: 2 copies (2 available, 0 issued)
    // Total = 10 copies, Available = 10, Issued = 0
    let statsRes = await makeRequest(
      server,
      { method: "GET", path: "/api/dashboard/stats" }
    );
    let s = statsRes.body.data;
    if (s.totalCopies !== 10 || s.availableCopies !== 10 || s.issuedCopies !== 0 || s.totalTitles !== 3) {
      throw new Error(`Unexpected initial stats: ${JSON.stringify(s)}`);
    }

    // Issue 1 copy of Learning Node.js
    const nodeBook = (await Book.findOne({ title: "Learning Node.js" }));
    await makeRequest(
      server,
      { method: "POST", path: "/api/issues" },
      { bookId: nodeBook._id }
    );

    // Recheck dashboard stats
    statsRes = await makeRequest(
      server,
      { method: "GET", path: "/api/dashboard/stats" }
    );
    s = statsRes.body.data;
    if (s.totalCopies !== 10 || s.availableCopies !== 9 || s.issuedCopies !== 1 || s.activeIssuesCount !== 1) {
      throw new Error(`Stats after issue incorrect: ${JSON.stringify(s)}`);
    }
    console.log("✔ Test 5 Passed: Dashboard counts accurately update on issue and return\n");

    /* ==========================================================================
       TEST 6: BONUS APIS (MOST ISSUED & LEAST AVAILABLE)
       ========================================================================== */
    console.log("--- TEST 6: Bonus Analytics APIs ---");
    // Issue Clean Architecture twice more (then return one)
    // History count for Clean Architecture = 1 (from Test 2) + 2 = 3
    // History count for Learning Node.js = 1
    const cleanBook = (await Book.findOne({ title: "Clean Architecture" }));
    const issueA = await makeRequest(
      server,
      { method: "POST", path: "/api/issues" },
      { bookId: cleanBook._id }
    );
    const issueB = await makeRequest(
      server,
      { method: "POST", path: "/api/issues" },
      { bookId: cleanBook._id }
    );

    // 6a. Most Issued Book
    const mostIssuedRes = await makeRequest(
      server,
      { method: "GET", path: "/api/analytics/most-issued" }
    );
    console.log("Most Issued Book:", mostIssuedRes.body.data);
    if (
      mostIssuedRes.body.data.title !== "Clean Architecture" ||
      mostIssuedRes.body.data.issueCount !== 3
    ) {
      throw new Error(`Most issued book mismatch: ${JSON.stringify(mostIssuedRes.body)}`);
    }

    // 6b. Least Available Book
    // Available counts:
    // - Clean Architecture: 5 - 2 = 3
    // - Design Patterns: 3 - 0 = 3
    // - Learning Node.js: 2 - 1 = 1 (Lowest!)
    const leastAvailRes = await makeRequest(
      server,
      { method: "GET", path: "/api/analytics/least-available" }
    );
    console.log("Least Available Book:", leastAvailRes.body.data);
    if (
      leastAvailRes.body.data.title !== "Learning Node.js" ||
      leastAvailRes.body.data.availableCopies !== 1
    ) {
      throw new Error(`Least available book mismatch: ${JSON.stringify(leastAvailRes.body)}`);
    }
    console.log("✔ Test 6 Passed: Bonus APIs (Most Issued & Least Available) accurately computed\n");

    /* ==========================================================================
       TEST 7: CRUD & DELETION CONSTRAINT
       ========================================================================== */
    console.log("--- TEST 7: CRUD & Deletion Constraint Verification ---");
    // 7a. Update book
    const updateRes = await makeRequest(
      server,
      { method: "PUT", path: `/api/books/${cleanBook._id}` },
      { title: "Clean Architecture: Second Edition", totalCopies: 6 }
    );
    if (updateRes.status !== 200 || updateRes.body.data.title !== "Clean Architecture: Second Edition") {
      throw new Error("Update book failed");
    }

    // 7b. Attempt to delete book that has active issued copies (nodeBook has 1 active loan)
    const deleteBlockedRes = await makeRequest(
      server,
      { method: "DELETE", path: `/api/books/${nodeBook._id}` }
    );
    console.log("Delete book with active loan status:", deleteBlockedRes.status);
    if (deleteBlockedRes.status !== 400 || deleteBlockedRes.body.success) {
      throw new Error("Deleting a book with active loans should be blocked with 400!");
    }

    // 7c. Delete a book with 0 active loans (Design Patterns)
    const patternBook = await Book.findOne({ title: "Design Patterns in JavaScript" });
    const deleteAllowedRes = await makeRequest(
      server,
      { method: "DELETE", path: `/api/books/${patternBook._id}` }
    );
    if (deleteAllowedRes.status !== 200 || !deleteAllowedRes.body.success) {
      throw new Error("Failed to delete book with 0 active loans");
    }
    const checkDeleted = await Book.findById(patternBook._id);
    if (checkDeleted !== null) {
      throw new Error("Book still found in database after delete");
    }
    console.log("✔ Test 7 Passed: Book CRUD and active-loan deletion protection verified\n");

    console.log("=================================================");
    console.log("   🎉 ALL 7 TEST WORKFLOWS PASSED COMPLETELY!    ");
    console.log("=================================================\n");
  } catch (error) {
    console.error("❌ TEST RUN FAILED:", error);
    process.exitCode = 1;
  } finally {
    if (server) {
      server.close();
    }
    if (mongoose.connection.readyState !== 0) {
      await mongoose.disconnect();
    }
    if (mongod) {
      await mongod.stop();
    }
  }
}

runTests();

