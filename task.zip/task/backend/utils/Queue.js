/**
 * Queue Data Structure Implementation
 *
 * What is a Queue?
 * A Queue is a linear data structure that follows the FIFO (First-In, First-Out) principle.
 * Just like a queue of people at a ticket counter, the first element added to the queue
 * is the first one to be removed.
 *
 * Why is a Queue used in this Library System?
 * We use this Queue to track active book issue records in the exact order they were issued.
 * This allows the library to easily see:
 * 1. Which book issue was created first (oldest active loan).
 * 2. Active issues in chronological FIFO order.
 * 3. Fast peek and queue management in memory, synchronized with MongoDB persistence.
 */

class Queue {
  constructor() {
    // We use an internal array to store queue items in memory.
    this.items = [];
  }

  /**
   * enqueue(element)
   * Adds an element to the back (tail) of the queue.
   *
   * @param {Object} element - The book issue record to add
   */
  enqueue(element) {
    // Step 1: Add the new item to the end of the array.
    this.items.push(element);
    return element;
  }

  /**
   * dequeue()
   * Removes and returns the front (head) element of the queue.
   *
   * @returns {Object|null} The removed front item, or null if the queue is empty.
   */
  dequeue() {
    // Step 1: Check if the queue is empty before trying to remove.
    if (this.isEmpty()) {
      return null;
    }
    // Step 2: Remove and return the first element in FIFO order.
    return this.items.shift();
  }

  /**
   * peek()
   * Returns the front element without removing it.
   *
   * @returns {Object|null} The first item in the queue, or null if empty.
   */
  peek() {
    // Step 1: Check if the queue has items.
    if (this.isEmpty()) {
      return null;
    }
    // Step 2: Return the first item without modifying the array.
    return this.items[0];
  }

  /**
   * isEmpty()
   * Checks whether the queue contains any items.
   *
   * @returns {boolean} True if the queue has no elements, false otherwise.
   */
  isEmpty() {
    return this.items.length === 0;
  }

  /**
   * size()
   * Returns the current number of items in the queue.
   *
   * @returns {number} The count of active items in the queue.
   */
  size() {
    return this.items.length;
  }

  /**
   * toArray()
   * Returns a copy of the items in the queue in their current order.
   *
   * @returns {Array} List of queue elements.
   */
  toArray() {
    return [...this.items];
  }

  /**
   * removeById(issueId)
   * Removes an issue from the active queue when a book is returned.
   * Since users may return books in any order (not strictly FIFO),
   * this helper removes the specific returned issue while preserving
   * the relative FIFO order of all remaining active issued books.
   *
   * @param {string} issueId - The ID of the issue to remove
   * @returns {Object|null} The removed issue record or null if not found
   */
  removeById(issueId) {
    const stringId = issueId.toString();
    const index = this.items.findIndex(
      (item) => item._id && item._id.toString() === stringId
    );

    if (index === -1) {
      return null;
    }

    // Remove the item at the found index and return it.
    const [removedItem] = this.items.splice(index, 1);
    return removedItem;
  }

  /**
   * reconstruct(issueRecords)
   * Clears the current queue and reloads active issue records in order.
   * Used when the server restarts to reconstruct active loans from MongoDB.
   *
   * @param {Array} issueRecords - Array of active issue documents from MongoDB
   */
  reconstruct(issueRecords = []) {
    this.clear();
    for (const record of issueRecords) {
      this.enqueue(record);
    }
  }

  /**
   * clear()
   * Empties the queue.
   */
  clear() {
    this.items = [];
  }
}

// Export a singleton instance of the Queue so the whole application shares one active queue.
const activeIssueQueue = new Queue();

module.exports = {
  Queue,
  activeIssueQueue,
};

