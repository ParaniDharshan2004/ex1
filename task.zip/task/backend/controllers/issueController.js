/**
 * Issue Controller
 *
 * Handles book borrowing (issuing) and returning operations.
 * Coordinates database updates with the in-memory active Queue data structure.
 */

const mongoose = require("mongoose");
const Book = require("../models/Book");
const Issue = require("../models/Issue");
const { activeIssueQueue } = require("../utils/Queue");

/**
 * @desc    Issue a book copy to a borrower
 * @route   POST /api/issues
 */
const issueBook = async (req, res) => {
  try {
    const { bookId } = req.body;

    // Step 1: Validate incoming book ID
    if (!bookId) {
      return res.status(400).json({
        success: false,
        message: "Book ID is required to issue a book",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(bookId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Book ID format",
      });
    }

    // Step 2: Find the requested book in MongoDB
    const book = await Book.findById(bookId);

    // Step 3: Verify the book exists
    if (!book) {
      return res.status(404).json({
        success: false,
        message: "Book not found",
      });
    }

    // Step 4: Verify that at least one copy is currently available
    if (book.availableCopies <= 0) {
      return res.status(400).json({
        success: false,
        message: "Cannot issue book: No copies are currently available",
      });
    }

    // Step 5: Update book quantities
    // Reduce the number of available shelf copies by 1
    book.availableCopies -= 1;
    // Increase the number of issued copies in circulation by 1
    book.issuedCopies += 1;

    // Save the updated book quantity to MongoDB
    await book.save();

    // Step 6: Create the new Issue record
    const newIssue = new Issue({
      bookId: book._id,
      bookTitle: book.title,
      status: "ISSUED",
      issuedAt: new Date(),
      returnedAt: null,
    });

    // Save the issue document in MongoDB
    const savedIssue = await newIssue.save();

    // Step 7: Enqueue the new issue into our in-memory Queue
    // This maintains active loans in strict FIFO issuance order
    activeIssueQueue.enqueue(savedIssue);

    // Step 8: Return a 201 response with the issue details and updated book copies
    return res.status(201).json({
      success: true,
      message: `"${book.title}" was issued successfully`,
      data: {
        issue: savedIssue,
        book: {
          _id: book._id,
          title: book.title,
          availableCopies: book.availableCopies,
          issuedCopies: book.issuedCopies,
        },
      },
    });
  } catch (error) {
    console.error("[issueBook Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to issue book due to a server error",
      error: error.message,
    });
  }
};

/**
 * @desc    Get all issue records (optionally filter by status: ISSUED / RETURNED)
 * @route   GET /api/issues?status=ISSUED
 */
const getIssues = async (req, res) => {
  try {
    const { status } = req.query;

    // Step 1: Build filter query
    const filter = {};
    if (status && ["ISSUED", "RETURNED"].includes(status.toUpperCase())) {
      filter.status = status.toUpperCase();
    }

    // Step 2: Query issue records, newest issues first
    const issues = await Issue.find(filter)
      .populate("bookId", "title totalCopies availableCopies issuedCopies")
      .sort({ issuedAt: -1 });

    return res.status(200).json({
      success: true,
      count: issues.length,
      data: issues,
    });
  } catch (error) {
    console.error("[getIssues Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch issue records",
      error: error.message,
    });
  }
};

/**
 * @desc    Return an issued book copy
 * @route   POST /api/issues/:id/return
 */
const returnBook = async (req, res) => {
  try {
    const { id } = req.params;

    // Step 1: Validate Issue ID format
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Issue ID format",
      });
    }

    // Step 2: Find the issue record in MongoDB
    const issue = await Issue.findById(id);

    // Step 3: Check if issue record exists
    if (!issue) {
      return res.status(404).json({
        success: false,
        message: "Issue record not found",
      });
    }

    // Step 4: Prevent returning the same issue twice
    if (issue.status === "RETURNED") {
      return res.status(400).json({
        success: false,
        message: "This book copy has already been returned",
      });
    }

    // Step 5: Update the corresponding Book inventory in MongoDB
    const book = await Book.findById(issue.bookId);
    if (book) {
      // Increase available shelf copies
      book.availableCopies += 1;
      // Decrease issued copies (never allow below 0)
      book.issuedCopies = Math.max(0, book.issuedCopies - 1);
      await book.save();
    }

    // Step 6: Update the Issue record status and record return timestamp
    issue.status = "RETURNED";
    issue.returnedAt = new Date();
    const updatedIssue = await issue.save();

    // Step 7: Remove the returned issue from our active in-memory Queue
    activeIssueQueue.removeById(issue._id);

    // Step 8: Return success response
    return res.status(200).json({
      success: true,
      message: `"${issue.bookTitle}" has been returned successfully`,
      data: {
        issue: updatedIssue,
        book: book
          ? {
              _id: book._id,
              title: book.title,
              availableCopies: book.availableCopies,
              issuedCopies: book.issuedCopies,
            }
          : null,
      },
    });
  } catch (error) {
    console.error("[returnBook Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to return book due to a server error",
      error: error.message,
    });
  }
};

/**
 * @desc    Get the current active issue Queue status
 * @route   GET /api/issues/queue/status
 */
const getActiveQueue = async (req, res) => {
  try {
    return res.status(200).json({
      success: true,
      size: activeIssueQueue.size(),
      isEmpty: activeIssueQueue.isEmpty(),
      oldestActiveIssue: activeIssueQueue.peek(),
      queueItems: activeIssueQueue.toArray(),
    });
  } catch (error) {
    console.error("[getActiveQueue Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch active queue",
      error: error.message,
    });
  }
};

module.exports = {
  issueBook,
  getIssues,
  returnBook,
  getActiveQueue,
};

