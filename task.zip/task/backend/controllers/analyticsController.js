/**
 * Analytics Controller (Bonus APIs)
 *
 * Implements two bonus analytics endpoints:
 * 1. Most Issued Book (derived from MongoDB issue transaction history)
 * 2. Least Available Book (derived from lowest availableCopies count)
 */

const Book = require("../models/Book");
const Issue = require("../models/Issue");

/**
 * @desc    Get the book that has been issued the highest number of times
 * @route   GET /api/analytics/most-issued
 */
const getMostIssuedBook = async (req, res) => {
  try {
    // Step 1: Use MongoDB Aggregation Pipeline on the Issue collection
    // Group all issues by bookId and count how many times each book was issued
    const mostIssuedAggregate = await Issue.aggregate([
      {
        $group: {
          _id: "$bookId",
          bookTitle: { $first: "$bookTitle" },
          issueCount: { $sum: 1 },
        },
      },
      // Sort in descending order to place the highest issue count first
      { $sort: { issueCount: -1 } },
      // Take only the top record
      { $limit: 1 },
    ]);

    // Step 2: Handle scenario where no books have been issued yet
    if (!mostIssuedAggregate || mostIssuedAggregate.length === 0) {
      return res.status(200).json({
        success: true,
        message: "No issue history found yet",
        data: null,
      });
    }

    const topRecord = mostIssuedAggregate[0];

    // Step 3: Fetch the complete Book document to include current copies info
    const book = await Book.findById(topRecord._id);

    return res.status(200).json({
      success: true,
      message: "Most issued book retrieved successfully",
      data: {
        bookId: topRecord._id,
        title: topRecord.bookTitle,
        issueCount: topRecord.issueCount,
        totalCopies: book ? book.totalCopies : null,
        availableCopies: book ? book.availableCopies : null,
        issuedCopies: book ? book.issuedCopies : null,
      },
    });
  } catch (error) {
    console.error("[getMostIssuedBook Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to calculate most issued book",
      error: error.message,
    });
  }
};

/**
 * @desc    Get the book with the lowest number of available copies
 * @route   GET /api/analytics/least-available
 */
const getLeastAvailableBook = async (req, res) => {
  try {
    // Step 1: Query MongoDB for the book with the smallest availableCopies number
    // Sort availableCopies in ascending order (0, 1, 2...)
    const leastAvailableBook = await Book.findOne().sort({
      availableCopies: 1,
      createdAt: 1,
    });

    // Step 2: Handle empty database situation
    if (!leastAvailableBook) {
      return res.status(200).json({
        success: true,
        message: "No books found in the library",
        data: null,
      });
    }

    // Step 3: Return book information with available quantity
    return res.status(200).json({
      success: true,
      message: "Least available book retrieved successfully",
      data: {
        _id: leastAvailableBook._id,
        title: leastAvailableBook.title,
        availableCopies: leastAvailableBook.availableCopies,
        totalCopies: leastAvailableBook.totalCopies,
        issuedCopies: leastAvailableBook.issuedCopies,
      },
    });
  } catch (error) {
    console.error("[getLeastAvailableBook Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch least available book",
      error: error.message,
    });
  }
};

module.exports = {
  getMostIssuedBook,
  getLeastAvailableBook,
};

