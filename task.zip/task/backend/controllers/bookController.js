/**
 * Book Controller
 *
 * Handles HTTP requests for creating, reading, updating, deleting,
 * and searching books in MongoDB.
 */

const mongoose = require("mongoose");
const Book = require("../models/Book");
const Issue = require("../models/Issue");

/**
 * @desc    Add a new book to the library
 * @route   POST /api/books
 */
const addBook = async (req, res) => {
  try {
    const { title, totalCopies } = req.body;

    // Step 1: Validate required fields
    if (!title || !title.trim()) {
      return res.status(400).json({
        success: false,
        message: "Book title is required",
      });
    }

    const parsedCopies = parseInt(totalCopies, 10);
    if (isNaN(parsedCopies) || parsedCopies <= 0) {
      return res.status(400).json({
        success: false,
        message: "Total copies must be a positive number greater than 0",
      });
    }

    // Step 2: Initialize copy counts
    // For a newly added book, all copies are initially available, and 0 are issued.
    const newBook = new Book({
      title: title.trim(),
      totalCopies: parsedCopies,
      availableCopies: parsedCopies,
      issuedCopies: 0,
    });

    // Step 3: Save the book document to MongoDB
    const savedBook = await newBook.save();

    // Step 4: Return a 201 Created response with the new book record
    return res.status(201).json({
      success: true,
      message: "Book added successfully",
      data: savedBook,
    });
  } catch (error) {
    console.error("[addBook Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to add book due to a server error",
      error: error.message,
    });
  }
};

/**
 * @desc    Get all books in the library
 * @route   GET /api/books
 */
const getAllBooks = async (req, res) => {
  try {
    // Step 1: Query all books from MongoDB, sorted newest first
    const books = await Book.find().sort({ createdAt: -1 });

    // Step 2: Send the list of books to the frontend
    return res.status(200).json({
      success: true,
      count: books.length,
      data: books,
    });
  } catch (error) {
    console.error("[getAllBooks Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch books",
      error: error.message,
    });
  }
};

/**
 * @desc    Search books by partial or complete title
 * @route   GET /api/books/search?title=...
 */
const searchBooksByTitle = async (req, res) => {
  try {
    const { title } = req.query;

    // Step 1: If search query is missing or empty, return all books
    if (!title || !title.trim()) {
      const allBooks = await Book.find().sort({ createdAt: -1 });
      return res.status(200).json({
        success: true,
        count: allBooks.length,
        data: allBooks,
      });
    }

    // Step 2: Use a case-insensitive regular expression for partial matching
    const searchRegex = new RegExp(title.trim(), "i");

    // Step 3: Search MongoDB for books where title matches the pattern
    const matchingBooks = await Book.find({ title: { $regex: searchRegex } }).sort({
      createdAt: -1,
    });

    // Step 4: Return results (even if empty, with count 0)
    return res.status(200).json({
      success: true,
      count: matchingBooks.length,
      data: matchingBooks,
    });
  } catch (error) {
    console.error("[searchBooksByTitle Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to search books",
      error: error.message,
    });
  }
};

/**
 * @desc    Get a single book by MongoDB ID
 * @route   GET /api/books/:id
 */
const getBookById = async (req, res) => {
  try {
    const { id } = req.params;

    // Step 1: Validate MongoDB ObjectId format
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Book ID format",
      });
    }

    // Step 2: Find the book in MongoDB
    const book = await Book.findById(id);

    // Step 3: Check if the book was found
    if (!book) {
      return res.status(404).json({
        success: false,
        message: "Book not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: book,
    });
  } catch (error) {
    console.error("[getBookById Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch book details",
      error: error.message,
    });
  }
};

/**
 * @desc    Update book details (title and/or total copies)
 * @route   PUT /api/books/:id
 */
const updateBook = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, totalCopies } = req.body;

    // Step 1: Validate ID
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Book ID format",
      });
    }

    // Step 2: Fetch current book from MongoDB
    const book = await Book.findById(id);
    if (!book) {
      return res.status(404).json({
        success: false,
        message: "Book not found",
      });
    }

    // Step 3: Update title if provided
    if (title && title.trim()) {
      book.title = title.trim();
    }

    // Step 4: Update totalCopies if provided
    if (totalCopies !== undefined) {
      const newTotal = parseInt(totalCopies, 10);
      if (isNaN(newTotal) || newTotal <= 0) {
        return res.status(400).json({
          success: false,
          message: "Total copies must be a positive number greater than 0",
        });
      }

      // Important validation: totalCopies cannot be less than currently issued copies!
      if (newTotal < book.issuedCopies) {
        return res.status(400).json({
          success: false,
          message: `Cannot reduce total copies below currently issued count (${book.issuedCopies})`,
        });
      }

      // Re-calculate available copies based on current issued copies
      book.totalCopies = newTotal;
      book.availableCopies = newTotal - book.issuedCopies;
    }

    // Step 5: Save changes in MongoDB
    const updatedBook = await book.save();

    return res.status(200).json({
      success: true,
      message: "Book updated successfully",
      data: updatedBook,
    });
  } catch (error) {
    console.error("[updateBook Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to update book",
      error: error.message,
    });
  }
};

/**
 * @desc    Delete a book from library
 * @route   DELETE /api/books/:id
 */
const deleteBook = async (req, res) => {
  try {
    const { id } = req.params;

    // Step 1: Validate ID
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Book ID format",
      });
    }

    // Step 2: Check if book exists
    const book = await Book.findById(id);
    if (!book) {
      return res.status(404).json({
        success: false,
        message: "Book not found",
      });
    }

    // Step 3: Prevent deleting a book that currently has active borrowed copies
    const activeIssue = await Issue.findOne({ bookId: id, status: "ISSUED" });
    if (activeIssue) {
      return res.status(400).json({
        success: false,
        message: "Cannot delete this book because copies are currently issued to borrowers",
      });
    }

    // Step 4: Remove book from MongoDB
    await Book.findByIdAndDelete(id);

    return res.status(200).json({
      success: true,
      message: "Book deleted successfully",
    });
  } catch (error) {
    console.error("[deleteBook Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to delete book",
      error: error.message,
    });
  }
};

module.exports = {
  addBook,
  getAllBooks,
  searchBooksByTitle,
  getBookById,
  updateBook,
  deleteBook,
};

