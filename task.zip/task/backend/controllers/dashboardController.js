/**
 * Dashboard Controller
 *
 * Computes high-level library statistics:
 * - Total book copies
 * - Available book copies
 * - Issued book copies
 * - Total book titles
 */

const Book = require("../models/Book");
const Issue = require("../models/Issue");

/**
 * @desc    Get dashboard summary metrics
 * @route   GET /api/dashboard/stats
 */
const getDashboardStats = async (req, res) => {
  try {
    // Step 1: Retrieve all books to compute aggregate copy totals
    const books = await Book.find();

    // Step 2: Calculate sum of totalCopies, availableCopies, and issuedCopies
    let totalCopies = 0;
    let availableCopies = 0;
    let issuedCopies = 0;

    for (const book of books) {
      totalCopies += book.totalCopies || 0;
      availableCopies += book.availableCopies || 0;
      issuedCopies += book.issuedCopies || 0;
    }

    // Step 3: Count active issues currently borrowed
    const activeIssuesCount = await Issue.countDocuments({ status: "ISSUED" });

    // Step 4: Return calculated statistics
    return res.status(200).json({
      success: true,
      data: {
        totalTitles: books.length,
        totalCopies,
        availableCopies,
        issuedCopies,
        activeIssuesCount,
      },
    });
  } catch (error) {
    console.error("[getDashboardStats Error]:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to calculate dashboard statistics",
      error: error.message,
    });
  }
};

module.exports = {
  getDashboardStats,
};

