/**
 * Issue Routes
 *
 * Defines API endpoints for borrowing and returning books:
 * - POST /api/issues            -> Issue a book copy
 * - GET  /api/issues            -> Get issue records
 * - POST /api/issues/:id/return -> Return an issued book
 * - GET  /api/issues/queue      -> Inspect in-memory queue status
 */

const express = require("express");
const router = express.Router();

const {
  issueBook,
  getIssues,
  returnBook,
  getActiveQueue,
} = require("../controllers/issueController");

router.post("/", issueBook);
router.get("/", getIssues);
router.post("/:id/return", returnBook);
router.get("/queue/status", getActiveQueue);

module.exports = router;

