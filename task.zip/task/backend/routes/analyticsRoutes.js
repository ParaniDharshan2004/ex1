/**
 * Analytics Routes (Bonus APIs)
 *
 * Defines bonus analytical endpoints:
 * - GET /api/analytics/most-issued     -> Most issued book from history
 * - GET /api/analytics/least-available  -> Least available book by copies count
 */

const express = require("express");
const router = express.Router();

const {
  getMostIssuedBook,
  getLeastAvailableBook,
} = require("../controllers/analyticsController");

router.get("/most-issued", getMostIssuedBook);
router.get("/least-available", getLeastAvailableBook);

module.exports = router;

