/**
 * Book Routes
 *
 * Defines API endpoints for book management:
 * - POST   /api/books        -> Add a new book
 * - GET    /api/books        -> Get all books
 * - GET    /api/books/search -> Search books by title
 * - GET    /api/books/:id    -> Get a single book
 * - PUT    /api/books/:id    -> Update book details
 * - DELETE /api/books/:id    -> Delete a book
 */

const express = require("express");
const router = express.Router();

const {
  addBook,
  getAllBooks,
  searchBooksByTitle,
  getBookById,
  updateBook,
  deleteBook,
} = require("../controllers/bookController");

// Search endpoint placed before /:id so Express doesn't mistake "search" for an ID
router.get("/search", searchBooksByTitle);

router.post("/", addBook);
router.get("/", getAllBooks);
router.get("/:id", getBookById);
router.put("/:id", updateBook);
router.delete("/:id", deleteBook);

module.exports = router;

