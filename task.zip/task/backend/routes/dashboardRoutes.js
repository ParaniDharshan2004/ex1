/**
 * Dashboard Routes
 *
 * Defines API endpoints for dashboard statistics:
 * - GET /api/dashboard/stats -> Available, issued and total book counts
 */

const express = require("express");
const router = express.Router();

const { getDashboardStats } = require("../controllers/dashboardController");

router.get("/stats", getDashboardStats);

module.exports = router;

