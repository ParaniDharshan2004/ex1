/**
 * Unit Tests for Queue Data Structure
 *
 * Verifies all Queue operations:
 * - enqueue()
 * - dequeue()
 * - peek()
 * - isEmpty()
 * - size()
 * - toArray()
 * - removeById()
 * - reconstruct()
 */

const assert = require("assert");
const { Queue } = require("./utils/Queue");

console.log("=== Running Queue Data Structure Unit Tests ===");

const queue = new Queue();

// 1. Initial State
assert.strictEqual(queue.isEmpty(), true, "New queue must be empty");
assert.strictEqual(queue.size(), 0, "New queue size must be 0");
assert.strictEqual(queue.peek(), null, "Peeking empty queue must return null");
assert.strictEqual(queue.dequeue(), null, "Dequeue on empty queue must return null");
console.log("✔ Initial empty queue state passed");

// 2. Enqueue operations
const item1 = { _id: "issue_1", bookTitle: "Clean Code", issuedAt: new Date(1000) };
const item2 = { _id: "issue_2", bookTitle: "The Pragmatic Programmer", issuedAt: new Date(2000) };
const item3 = { _id: "issue_3", bookTitle: "Design Patterns", issuedAt: new Date(3000) };

queue.enqueue(item1);
assert.strictEqual(queue.isEmpty(), false, "Queue should not be empty after enqueue");
assert.strictEqual(queue.size(), 1, "Queue size should be 1");
assert.deepStrictEqual(queue.peek(), item1, "Peek should return the head item (item1)");

queue.enqueue(item2);
queue.enqueue(item3);
assert.strictEqual(queue.size(), 3, "Queue size should be 3");
assert.deepStrictEqual(queue.peek(), item1, "Peek should still return item1 (FIFO)");
console.log("✔ Enqueue operations passed");

// 3. FIFO Dequeue operations
const dequeued1 = queue.dequeue();
assert.deepStrictEqual(dequeued1, item1, "First dequeued item must be item1 (FIFO)");
assert.strictEqual(queue.size(), 2, "Queue size should be 2 after 1 dequeue");
assert.deepStrictEqual(queue.peek(), item2, "Peek should now be item2");
console.log("✔ Dequeue FIFO order passed");

// 4. removeById operation (arbitrary book return)
// Currently in queue: [item2, item3]
const removed = queue.removeById("issue_3");
assert.deepStrictEqual(removed, item3, "removeById should return item3");
assert.strictEqual(queue.size(), 1, "Queue size should be 1 after removing item3");
assert.deepStrictEqual(queue.peek(), item2, "Head should remain item2");
console.log("✔ removeById operation passed");

// 5. Reconstruct Queue from database list (server restart simulation)
const dbRecords = [
  { _id: "db_1", bookTitle: "Refactoring" },
  { _id: "db_2", bookTitle: "JavaScript: The Good Parts" },
  { _id: "db_3", bookTitle: "You Don't Know JS" },
];
queue.reconstruct(dbRecords);
assert.strictEqual(queue.size(), 3, "Reconstructed queue size should be 3");
assert.strictEqual(queue.peek().bookTitle, "Refactoring", "Head must be the first restored element");
const list = queue.toArray();
assert.strictEqual(list.length, 3, "toArray should return 3 items");
assert.strictEqual(list[0]._id, "db_1");
assert.strictEqual(list[2]._id, "db_3");
console.log("✔ Reconstruct from persistence passed");

console.log("\n🎉 ALL QUEUE DATA STRUCTURE TESTS PASSED SUCCESSFULLY!\n");

