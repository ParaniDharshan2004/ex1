/**
 * Express Server Entry Point
 *
 * Library Book Management System - Backend
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const Issue = require("./models/Issue");
const { activeIssueQueue } = require("./utils/Queue");

// Import route modules
const bookRoutes = require("./routes/bookRoutes");
const issueRoutes = require("./routes/issueRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");

// Initialize Express app
const app = express();

// Middleware
// Enable Cross-Origin Resource Sharing so React frontend can call this API
app.use(cors());
// Parse incoming JSON request bodies
app.use(express.json());

// API Routes
app.use("/api/books", bookRoutes);
app.use("/api/issues", issueRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/analytics", analyticsRoutes);

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.status(200).json({
    status: "ok",
    message: "Library Management System API is running smoothly",
    timestamp: new Date().toISOString(),
  });
});

// 404 Handler for undefined routes
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `API route not found: ${req.method} ${req.originalUrl}`,
  });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error("[Global Error]:", err.stack || err.message);
  res.status(500).json({
    success: false,
    message: "An internal server error occurred",
    error: err.message,
  });
});

// Define Port
const PORT = process.env.PORT || 5000;

/**
 * startServer
 * Connects to MongoDB, reconstructs the active Queue from database, and starts listening.
 */
const startServer = async () => {
  try {
    // Step 1: Connect to MongoDB
    await connectDB();

    // Step 2: Reconstruct active Issue Queue from MongoDB persistence
    // Find all records that are currently 'ISSUED' in chronological order
    const activeIssues = await Issue.find({ status: "ISSUED" }).sort({
      issuedAt: 1,
    });
    activeIssueQueue.reconstruct(activeIssues);
    console.log(
      `[Queue Initialized]: Reconstructed ${activeIssueQueue.size()} active issued record(s) in FIFO order`
    );

    // Step 3: Start Express listening on port
    const server = app.listen(PORT, () => {
      console.log(`[Server Running]: http://localhost:${PORT}`);
    });

    return { app, server };
  } catch (error) {
    console.error("[Server Startup Failed]:", error.message);
    process.exit(1);
  }
};

// Start server if run directly
if (require.main === module) {
  startServer();
}

module.exports = { app, startServer };

