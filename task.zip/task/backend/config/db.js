/**
 * Database Configuration
 *
 * This file establishes a connection between our Express server and MongoDB
 * using the Mongoose Object Data Modeling (ODM) library.
 */

const dns = require("dns");
const mongoose = require("mongoose");

// On Windows, local ISP or router DNS often fails to resolve MongoDB Atlas SRV records
// resulting in "querySrv ECONNREFUSED". Configuring public DNS resolvers (Google & Cloudflare)
// guarantees seamless connectivity for MongoDB Atlas clusters.
try {
  dns.setServers(["8.8.8.8", "1.1.1.1", "8.8.4.4"]);
} catch (dnsError) {
  console.warn("[DNS Warning]: Could not set custom DNS servers, using system default.");
}

/**
 * connectDB
 * Connects to the MongoDB database specified in the environment variables.
 */
const connectDB = async () => {
  try {
    // Step 1: Read the connection URI from the .env file.
    // If not provided, fallback to standard local MongoDB port 27017.
    const mongoURI =
      process.env.MONGO_URI || "mongodb://127.0.0.1:27017/library_management_system";

    // Step 2: Connect using Mongoose with modern default options.
    const conn = await mongoose.connect(mongoURI);

    console.log(`[MongoDB Connected]: ${conn.connection.host}/${conn.connection.name}`);
    return conn;
  } catch (error) {
    // Step 3: Handle connection errors.
    console.error(`[MongoDB Connection Error]: ${error.message}`);
    throw error;
  }
};

module.exports = connectDB;
