/**
 * Issue Model
 *
 * Defines the MongoDB schema for issued book records.
 * Each document represents a single transaction where a book copy was borrowed.
 */

const mongoose = require("mongoose");

const issueSchema = new mongoose.Schema(
  {
    // Reference to the book being borrowed
    bookId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Book",
      required: [true, "Book ID is required"],
    },
    // Storing the book title directly avoids extra lookups when displaying issues
    bookTitle: {
      type: String,
      required: [true, "Book title is required"],
      trim: true,
    },
    // The current status of this loan transaction: 'ISSUED' or 'RETURNED'
    status: {
      type: String,
      enum: ["ISSUED", "RETURNED"],
      default: "ISSUED",
      index: true,
    },
    // Timestamp when the book was checked out / issued
    issuedAt: {
      type: Date,
      default: Date.now,
    },
    // Timestamp when the book was returned back to the library
    returnedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

const Issue = mongoose.model("Issue", issueSchema);

module.exports = Issue;

