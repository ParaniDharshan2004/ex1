/**
 * Book Model
 *
 * Defines the MongoDB schema for library books.
 * Tracks book title, total copies, available copies, and issued copies.
 */

const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema(
  {
    // The title or name of the book
    title: {
      type: String,
      required: [true, "Book title is required"],
      trim: true,
    },
    // Total number of copies owned by the library
    totalCopies: {
      type: Number,
      required: [true, "Total copies count is required"],
      min: [1, "Total copies must be at least 1"],
    },
    // Number of copies currently available on the shelf to be issued
    availableCopies: {
      type: Number,
      required: true,
      min: [0, "Available copies cannot be negative"],
    },
    // Number of copies currently in circulation (issued to members)
    issuedCopies: {
      type: Number,
      required: true,
      default: 0,
      min: [0, "Issued copies cannot be negative"],
    },
  },
  {
    // Automatically creates and manages createdAt and updatedAt fields
    timestamps: true,
  }
);

// Create and export the Book Mongoose Model
const Book = mongoose.model("Book", bookSchema);

module.exports = Book;

