# 📚 Library Book Management System – MERN Stack

A clean, robust, and beginner-friendly **Library Book Management System** built with the **MERN Stack** (MongoDB, Express.js, React.js, Node.js) and **Material UI (MUI)**.

This application fulfills all five mandatory functional requirements and both bonus analytical challenges assigned by **Kamala Outsourcing Private Limited**. It features an in-memory **Queue data structure** with MongoDB persistence to track active book loans in strict First-In-First-Out (FIFO) order.

---

## 📑 Table of Contents

1. [Project Overview](#1-project-overview)
2. [Technology Stack](#2-technology-stack)
3. [Project Folder Structure](#3-project-folder-structure)
4. [Prerequisites](#4-prerequisites)
5. [Installation & Setup](#5-installation--setup)
6. [Environment Configuration](#6-environment-configuration)
7. [MongoDB Setup Options](#7-mongodb-setup-options)
8. [Starting the Application](#8-starting-the-application)
9. [API Endpoint Documentation](#9-api-endpoint-documentation)
10. [Queue Implementation Explanation](#10-queue-implementation-explanation)
11. [Database Schema & Collections](#11-database-schema--collections)
12. [How Issue and Return Processes Work](#12-how-issue-and-return-processes-work)
13. [Testing & Verification](#13-testing--verification)
14. [Code Review Guide](#14-code-review-guide)

---

## 1. Project Overview

The **Library Book Management System** allows librarians and library patrons to:
- **Add Books**: Register new book titles along with total copy counts.
- **Manage Inventory**: Edit titles, adjust total copy counts, and safely delete books that have no active loans.
- **Issue Books**: Borrow available shelf copies, decrementing available counts, incrementing issued counts, and enqueuing active loans into an in-memory FIFO Queue.
- **Return Books**: Return borrowed copies, restoring available inventory, marking issue records as `RETURNED`, and dequeuing/removing them from the active queue.
- **Search Books by Title**: Real-time and on-demand search using case-insensitive partial title matching.
- **Real-Time Dashboard**: Immediate live stats for total copies, available copies, issued copies, and active queue size.
- **Bonus Analytics**:
  - **Most Issued Book**: Historical aggregation calculating the book title borrowed the most times.
  - **Least Available Book**: Identifies the title with the lowest shelf availability to trigger restocking.

---

## 2. Technology Stack

### **Frontend**
- **React.js** (v18.3) with ES6+ JavaScript
- **Material UI (MUI v5)**: Modern, accessible UI components (AppBar, Drawer, Cards, Tables, Dialogs, TextFields, Buttons, Chips, Snackbars, CircularProgress)
- **Axios**: HTTP client for communicating with Express REST APIs
- **React Router DOM (v6)**: Declarative client-side routing
- **Vite**: Ultra-fast build tool and dev server

### **Backend**
- **Node.js** (v20+ / v24+)
- **Express.js** (v4.21): RESTful API server
- **Mongoose** (v8.9): Elegant MongoDB Object Data Modeling (ODM)
- **CORS & Dotenv**: Cross-origin resource sharing and environment management
- **Queue Data Structure**: In-memory FIFO queue synchronized with MongoDB persistence

### **Database**
- **MongoDB** (Local instance or MongoDB Atlas Cloud Cluster)

---

## 3. Project Folder Structure

```
library-management-system/
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── api/
│   │   │   └── api.js              # Centralized Axios API service layer
│   │   ├── components/
│   │   │   ├── Navbar.jsx          # Top AppBar with branding and mobile drawer toggle
│   │   │   ├── Sidebar.jsx         # Navigation drawer (Desktop & Mobile)
│   │   │   └── StatCard.jsx        # Reusable metric card with icons
│   │   ├── layouts/
│   │   │   └── MainLayout.jsx      # Top frame layout with responsive drawer and <Outlet />
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx       # Real-time metrics, bonus cards, and queue visualizer
│   │   │   ├── Books.jsx           # Book catalog, search bar, add/edit/delete modals
│   │   │   ├── IssueBooks.jsx      # Available books grid and quick issue selector
│   │   │   └── ReturnBooks.jsx     # Active issued loans table and return processor
│   │   ├── App.jsx                 # Theme provider and route configuration
│   │   └── main.jsx                # React DOM root entrypoint
│   ├── index.html
│   ├── vite.config.js
│   ├── .env.example
│   ├── .env
│   └── package.json
│
├── backend/
│   ├── config/
│   │   └── db.js                   # Mongoose connection configuration
│   ├── models/
│   │   ├── Book.js                 # Book collection schema
│   │   └── Issue.js                # Issue transaction collection schema
│   ├── controllers/
│   │   ├── bookController.js       # Book CRUD and partial title search
│   │   ├── issueController.js      # Borrow, return, and queue management
│   │   ├── dashboardController.js  # Inventory aggregation metrics
│   │   └── analyticsController.js  # Most issued & least available bonus APIs
│   ├── routes/
│   │   ├── bookRoutes.js           # /api/books routes
│   │   ├── issueRoutes.js          # /api/issues routes
│   │   ├── dashboardRoutes.js      # /api/dashboard routes
│   │   └── analyticsRoutes.js      # /api/analytics routes
│   ├── utils/
│   │   └── Queue.js                # Genuine Queue implementation (FIFO)
│   ├── server.js                   # Express application and server startup
│   ├── test-queue.js               # Queue unit tests
│   ├── test-api.js                 # Complete end-to-end integration test suite
│   ├── .env.example
│   ├── .env
│   └── package.json
│
├── README.md                       # Comprehensive project documentation
└── CODE_REVIEW_GUIDE.md            # Technical interview & code explanation guide
```

---

## 4. Prerequisites

Before running the application, ensure you have the following installed on your machine:
- **Node.js**: `v18.0.0` or higher (tested with `v24.18.0`)
- **npm**: `v9.0.0` or higher (tested with `v11.16.0`)
- **MongoDB**: Either a local MongoDB Community Server running on `mongodb://127.0.0.1:27017` or a free MongoDB Atlas connection string.

---

## 5. Installation & Setup

Clone or download the project repository, then install dependencies for both the backend and frontend:

```bash
# 1. Navigate to the project root
cd task

# 2. Install backend dependencies
cd backend
npm install

# 3. Install frontend dependencies
cd ../frontend
npm install
```

---

## 6. Environment Configuration

### **Backend (`backend/.env`)**
Create a `.env` file inside the `backend/` directory by copying `.env.example`:

```bash
cd backend
cp .env.example .env
```

Content:
```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/library_management_system
```

### **Frontend (`frontend/.env`)**
Create a `.env` file inside the `frontend/` directory by copying `.env.example`:

```bash
cd frontend
cp .env.example .env
```

Content:
```env
VITE_API_URL=http://localhost:5000/api
```

---

## 7. MongoDB Setup Options

### Option A: Local MongoDB
If you have MongoDB installed locally as a Windows service or daemon:
```
MONGO_URI=mongodb://127.0.0.1:27017/library_management_system
```

### Option B: MongoDB Atlas (Cloud)
1. Create a free account at [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas).
2. Create a free M0 cluster.
3. Under **Database Access**, create a user with read/write privileges.
4. Under **Network Access**, add IP `0.0.0.0/0` (allow from anywhere).
5. Click **Connect** -> **Drivers** (Node.js) and copy the URI into `backend/.env`:
```
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/library_db?retryWrites=true&w=majority
```

---

## 8. Starting the Application

### 1. Start the Backend Server
```bash
cd backend
npm start
# Or for live auto-reload during development:
npm run dev
```
The server will start on `http://localhost:5000`. You will see:
```
[MongoDB Connected]: 127.0.0.1/library_management_system
[Queue Initialized]: Reconstructed 0 active issued record(s) in FIFO order
[Server Running]: http://localhost:5000
```

### 2. Start the Frontend Application
In a separate terminal window:
```bash
cd frontend
npm run dev
```
The Vite development server will start on `http://localhost:3000`. Open this URL in your web browser!

---

## 9. API Endpoint Documentation

### **Books Endpoints (`/api/books`)**

| Method | Endpoint | Description | Request Body / Query | Success Status |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/books` | Add a new book title | `{ "title": "Clean Code", "totalCopies": 5 }` | `201 Created` |
| `GET` | `/api/books` | Get all books | None | `200 OK` |
| `GET` | `/api/books/search` | Search books by title | Query: `?title=clean` | `200 OK` |
| `GET` | `/api/books/:id` | Get book details by ID | None | `200 OK` |
| `PUT` | `/api/books/:id` | Update title or total copies | `{ "title": "Clean Code 2nd Ed", "totalCopies": 6 }` | `200 OK` |
| `DELETE`| `/api/books/:id` | Delete book (blocked if active loans) | None | `200 OK` |

### **Issue & Return Endpoints (`/api/issues`)**

| Method | Endpoint | Description | Request Body / Query | Success Status |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/issues` | Issue an available book copy | `{ "bookId": "65fc123..." }` | `201 Created` |
| `GET` | `/api/issues` | Get all issues (or filter by status) | Query: `?status=ISSUED` | `200 OK` |
| `POST` | `/api/issues/:id/return`| Return an issued book copy | None | `200 OK` |
| `GET` | `/api/issues/queue/status`| Inspect in-memory active Queue | None | `200 OK` |

### **Dashboard & Bonus Analytics Endpoints**

| Method | Endpoint | Description | Response Structure | Success Status |
| :--- | :--- | :--- | :--- | :--- |
| `GET` | `/api/dashboard/stats` | Inventory metrics | `{ totalTitles, totalCopies, availableCopies, issuedCopies, activeIssuesCount }` | `200 OK` |
| `GET` | `/api/analytics/most-issued` | **Bonus API 1**: Most issued book | `{ title, issueCount, availableCopies, totalCopies }` | `200 OK` |
| `GET` | `/api/analytics/least-available`| **Bonus API 2**: Least available book | `{ title, availableCopies, totalCopies, issuedCopies }` | `200 OK` |

---

## 10. Queue Implementation Explanation

### What is a Queue?
A **Queue** is a fundamental linear data structure that operates according to the **FIFO (First-In, First-Out)** principle. The first item entered into the queue is the first item to be retrieved or served.

### Methods in `backend/utils/Queue.js`:
- `enqueue(element)`: Appends an element to the back (tail) of the queue.
- `dequeue()`: Removes and returns the element at the front (head) of the queue. Returns `null` if empty.
- `peek()`: Inspects the front element without removing it. Returns `null` if empty.
- `isEmpty()`: Returns `true` if size is 0, `false` otherwise.
- `size()`: Returns total number of active items in the queue.
- `toArray()`: Returns a snapshot copy of the queue elements in their FIFO sequence.
- `removeById(id)`: Removes a specific returned issue when books are returned in arbitrary order, maintaining the FIFO order of all remaining loans.
- `reconstruct(records)`: Repopulates the in-memory queue from MongoDB on server restart.

### Why is a Queue Used Here?
1. **Chronological Loan Tracking**: The library maintains an exact chronological sequence of outstanding borrowed books.
2. **Oldest Loan Priority**: The head (`peek()`) instantly identifies the oldest active loan in the system.
3. **In-Memory Speed + MongoDB Persistence**: Real-time queue queries run in $O(1)$ memory time, while MongoDB guarantees zero data loss across server restarts.

---

## 11. Database Schema & Collections

### **Collection 1: `books`**
Defined in `backend/models/Book.js`:
```javascript
{
  title: { type: String, required: true, trim: true },
  totalCopies: { type: Number, required: true, min: 1 },
  availableCopies: { type: Number, required: true, min: 0 },
  issuedCopies: { type: Number, required: true, default: 0, min: 0 },
  createdAt: { type: Date },
  updatedAt: { type: Date }
}
```

### **Collection 2: `issues`**
Defined in `backend/models/Issue.js`:
```javascript
{
  bookId: { type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true },
  bookTitle: { type: String, required: true, trim: true },
  status: { type: String, enum: ['ISSUED', 'RETURNED'], default: 'ISSUED', index: true },
  issuedAt: { type: Date, default: Date.now },
  returnedAt: { type: Date, default: null },
  createdAt: { type: Date },
  updatedAt: { type: Date }
}
```

---

## 12. How Issue and Return Processes Work

### **The Issue Process Flow:**
1. Patron selects an available book on the **Issue Books** page (`availableCopies > 0`).
2. Frontend sends `POST /api/issues` with `{ bookId }`.
3. Backend checks book existence and verifies `availableCopies > 0`.
4. Backend decrements `availableCopies` by 1 and increments `issuedCopies` by 1.
5. An `Issue` document is created in MongoDB with `status = "ISSUED"`.
6. The saved `Issue` document is enqueued into `activeIssueQueue`.
7. Updated book counts and issue confirmation are returned to the frontend.

### **The Return Process Flow:**
1. Librarian selects an active loan on the **Return Books** page and clicks **Return Book**.
2. Frontend sends `POST /api/issues/:id/return`.
3. Backend finds the issue record and verifies `status === "ISSUED"` (prevents double returns).
4. Backend marks the issue as `status = "RETURNED"` and sets `returnedAt = new Date()`.
5. Backend increments `availableCopies` by 1 and decrements `issuedCopies` by 1 on the `Book` document.
6. The issue record is removed from `activeIssueQueue`.
7. Success message is sent to frontend, and tables immediately refresh.

---

## 13. Testing & Verification

The project includes two automated test suites:

### 1. Run Queue Unit Tests
```bash
cd backend
node test-queue.js
```
Output:
```
=== Running Queue Data Structure Unit Tests ===
✔ Initial empty queue state passed
✔ Enqueue operations passed
✔ Dequeue FIFO order passed
✔ removeById operation passed
✔ Reconstruct from persistence passed

🎉 ALL QUEUE DATA STRUCTURE TESTS PASSED SUCCESSFULLY!
```

### 2. Run Complete End-to-End API Test Suite
```bash
cd backend
npm run test:api
```
This script uses an in-memory MongoDB server to test all 7 workflows required by Section 12:
- **Test 1**: Add Book & MongoDB persistence
- **Test 2**: Issue Book, copy decrements, and Queue enqueue
- **Test 3**: Return Book, copy restoration, queue update, and double-return prevention
- **Test 4**: Search Books by Title (complete, partial, nonexistent)
- **Test 5**: Dashboard Statistics calculation
- **Test 6**: Bonus APIs (Most Issued Book & Least Available Book)
- **Test 7**: CRUD operations & deletion block when active loans exist

---

## 14. Code Review Guide

For detailed technical interview questions, step-by-step logic explanations, architecture comparisons, and debugging tips, please refer to:
👉 **[CODE_REVIEW_GUIDE.md](./CODE_REVIEW_GUIDE.md)**

