# 🎓 Technical Code Review & Interview Preparation Guide
## Library Book Management System – MERN Stack

This document provides junior developers with the theoretical and practical knowledge needed to confidently explain, debug, and defend this codebase during a technical code review with senior engineers and hiring managers.

---

## 1. What is MERN?

**MERN** is an acronym for four key open-source technologies used to build full-stack web applications:
1. **M – MongoDB**: A NoSQL document database that stores data in flexible, JSON-like BSON format.
2. **E – Express.js**: A minimalist web application framework for Node.js used to build RESTful APIs and handle HTTP requests/responses.
3. **R – React.js**: A front-end JavaScript library developed by Meta for building dynamic, reactive user interfaces through reusable components and hooks.
4. **N – Node.js**: An open-source, cross-platform JavaScript runtime built on Chrome's V8 engine that allows developers to run JavaScript on the server.

Together, the MERN stack enables developers to use a single programming language—**JavaScript**—across the entire stack from database queries to server logic and user interface rendering.

---

## 2. How React Communicates with Express

Communication between the React front-end and the Express back-end happens over standard **HTTP (Hypertext Transfer Protocol)** using asynchronous AJAX requests powered by **Axios**.

### Flow:
1. **Trigger**: A user performs an action (e.g., clicks the "Issue This Copy" button).
2. **Client Request**: React invokes a function in `frontend/src/api/api.js`. Axios packages the HTTP method (`POST`), endpoint URL (`http://localhost:5000/api/issues`), headers (`Content-Type: application/json`), and request body (`{ "bookId": "..." }`).
3. **CORS Handling**: Express uses the `cors()` middleware in `server.js` to allow cross-origin requests originating from the front-end origin (`http://localhost:3000`).
4. **JSON Parsing**: The incoming JSON payload is parsed by `express.json()` middleware and made accessible on `req.body`.
5. **Route & Controller Execution**: Express matches the path `/api/issues` to `issueRoutes.js` and calls `issueBook` in `issueController.js`.
6. **Server Response**: Express sends an HTTP status code (e.g., `201 Created`) with a JSON payload via `res.status(201).json({ success: true, data: ... })`.
7. **UI Update**: Axios unwraps the response data, React updates its component state via `useState()`, and the DOM automatically re-renders the updated counts.

---

## 3. How Express Communicates with MongoDB

Express communicates with MongoDB using **Mongoose**, an Object Data Modeling (ODM) library.

### Flow:
1. **Connection**: At server startup, `backend/config/db.js` calls `mongoose.connect(process.env.MONGO_URI)`. Mongoose establishes a persistent TCP connection pool to the MongoDB instance.
2. **Schema & Model**: In `models/Book.js`, we define a `mongoose.Schema` specifying field types, required rules, and default values. Mongoose compiles this schema into a model class: `const Book = mongoose.model("Book", bookSchema)`.
3. **Query Execution**: When a controller calls `Book.findById(id)` or `book.save()`, Mongoose translates the JavaScript call into native BSON commands (like `findOne` or `updateOne`) and transmits them over the database connection.
4. **Async/Await**: MongoDB operations return Promises. We use `await` to pause execution until the database responds, with `try/catch` blocks capturing network errors or validation failures.

---

## 4. What is CRUD?

**CRUD** stands for the four basic operations of persistent storage:
- **C – Create**: Adding new records (HTTP `POST` -> `new Book().save()`).
- **R – Read**: Querying existing records (HTTP `GET` -> `Book.find()` or `Book.findById()`).
- **U – Update**: Modifying existing records (HTTP `PUT` -> `book.save()` or `findByIdAndUpdate()`).
- **D – Delete**: Removing records (HTTP `DELETE` -> `Book.findByIdAndDelete()`).

In this project:
- `POST /api/books` = Create book
- `GET /api/books` & `GET /api/books/:id` = Read books
- `PUT /api/books/:id` = Update book
- `DELETE /api/books/:id` = Delete book

---

## 5. What are MongoDB Collections and Documents?

- **Document**: The basic unit of data in MongoDB, equivalent to a row in a relational database or a JSON object in JavaScript. Each document contains key-value pairs and a unique `_id` field.
- **Collection**: A grouping of related MongoDB documents, equivalent to a table in relational databases. In this application, we have two collections:
  1. `books`: Stores book catalog items.
  2. `issues`: Stores individual borrowing transaction records.

---

## 6. Why Mongoose is Used

While native MongoDB is schemaless (any document in a collection can have arbitrary fields), production applications require structure and safety. Mongoose provides:
1. **Schema Definition**: Enforces required fields, types (String, Number, Date, ObjectId), and limits (min, max).
2. **Validation**: Automatically validates data before saving (e.g., preventing negative copies or empty titles).
3. **Type Casting**: Converts incoming strings to Numbers or Dates if needed.
4. **Population**: Enables relational-like joins (`.populate('bookId')`) across documents.
5. **Business Logic & Middleware**: Supports pre/post hooks, virtuals, and default values (`Date.now`).

---

## 7. Arrays vs. Queues

### Array (List)
- An indexed collection of elements.
- Allows random access by index: `arr[i]` in $O(1)$ time.
- Allows adding/removing from anywhere (beginning, middle, end).

### Queue (Abstract Data Type)
- A specialized linear data structure governed strictly by **FIFO (First-In, First-Out)**.
- Insertion only happens at the **back (Tail / Enqueue)**.
- Removal only happens from the **front (Head / Dequeue)**.
- Inspection without removal only happens at the front (**Peek**).
- Elements in the middle cannot be arbitrarily pushed or pulled in a strict queue.

---

## 8. How Enqueue and Dequeue Work

- **`enqueue(item)`**:
  - Pushes an item to the end of the line.
  - In our implementation (`backend/utils/Queue.js`):
    ```javascript
    enqueue(element) {
      this.items.push(element);
      return element;
    }
    ```
- **`dequeue()`**:
  - Removes the item that has been waiting the longest (the head).
  - In our implementation:
    ```javascript
    dequeue() {
      if (this.isEmpty()) return null;
      return this.items.shift();
    }
    ```

---

## 9. How the Queue is Used in this Project

1. **Chronological Tracking**: Every time a book is issued via `POST /api/issues`, the issue record is enqueued into `activeIssueQueue`.
2. **FIFO Active Loan Order**: The queue maintains all currently active loans in the exact sequence they occurred.
3. **Inspection (`peek`)**: Allows the library to instantly see the oldest outstanding loan without expensive database sorting.
4. **Arbitrary Returns (`removeById`)**: In real life, borrowers return books in random order. Our Queue provides a `removeById(issueId)` helper that safely extracts the returned record while preserving the relative FIFO sequence of all remaining loans.
5. **Server Restart Persistence**: In `server.js`, upon startup, the backend queries MongoDB for `{ status: "ISSUED" }` sorted by `issuedAt: 1` and calls `activeIssueQueue.reconstruct(activeIssues)`. This guarantees that if the server crashes or reboots, the active loan queue is perfectly restored.

---

## 10. How Book Quantities are Calculated

Consistency rule:
$$\text{totalCopies} = \text{availableCopies} + \text{issuedCopies}$$

1. **When a book is added**:
   - `availableCopies = totalCopies`
   - `issuedCopies = 0`
2. **When a book is issued**:
   - Check: `availableCopies > 0`
   - `availableCopies = availableCopies - 1`
   - `issuedCopies = issuedCopies + 1`
3. **When a book is returned**:
   - `availableCopies = availableCopies + 1`
   - `issuedCopies = Math.max(0, issuedCopies - 1)`
4. **When total copies are edited**:
   - Enforce: `newTotal >= issuedCopies`
   - `availableCopies = newTotal - issuedCopies`

---

## 11. How the Most Issued Book API Works (Bonus 1)

**Endpoint**: `GET /api/analytics/most-issued`

Uses MongoDB's **Aggregation Pipeline** on the `issues` collection:
```javascript
const mostIssued = await Issue.aggregate([
  // Group all historical issue records by bookId and count them
  {
    $group: {
      _id: "$bookId",
      bookTitle: { $first: "$bookTitle" },
      issueCount: { $sum: 1 },
    },
  },
  // Sort from highest issue count to lowest
  { $sort: { issueCount: -1 } },
  // Pick the top record
  { $limit: 1 },
]);
```
- Preserves complete loan history (even returned loans count toward popularity).
- If no books have been issued yet, returns `{ success: true, data: null, message: "No issue history found yet" }`.

---

## 12. How the Least Available Book API Works (Bonus 2)

**Endpoint**: `GET /api/analytics/least-available`

Queries MongoDB for the book with the smallest `availableCopies`:
```javascript
const leastAvailableBook = await Book.findOne().sort({
  availableCopies: 1,
  createdAt: 1,
});
```
- Sorts ascending (`1`): 0 copies available comes first.
- Identifies critical stock depletion for librarians.
- Gracefully handles empty databases.

---

## 13. Step-by-Step Flow: Issuing and Returning a Book

### **Issuing Flow (Step-by-Step):**
```mermaid
sequenceDiagram
    autonumber
    actor User as User / Librarian
    participant React as React Frontend (IssueBooks.jsx)
    participant Express as Express Backend (issueController.js)
    participant Mongo as MongoDB (Book & Issue Collections)
    participant Queue as In-Memory Queue (Queue.js)

    User->>React: Selects book and clicks "Issue This Copy"
    React->>Express: POST /api/issues with { bookId }
    Express->>Mongo: Book.findById(bookId)
    Mongo-->>Express: Returns book document
    Note over Express: Validate availableCopies > 0
    Express->>Express: availableCopies -= 1; issuedCopies += 1
    Express->>Mongo: book.save()
    Express->>Mongo: new Issue({ status: 'ISSUED' }).save()
    Mongo-->>Express: Returns saved issue document
    Express->>Queue: activeIssueQueue.enqueue(savedIssue)
    Express-->>React: HTTP 201 Created { issue, updatedBook }
    React->>User: Displays success Snackbar & refreshes UI
```

### **Returning Flow (Step-by-Step):**
```mermaid
sequenceDiagram
    autonumber
    actor User as User / Librarian
    participant React as React Frontend (ReturnBooks.jsx)
    participant Express as Express Backend (issueController.js)
    participant Mongo as MongoDB (Book & Issue Collections)
    participant Queue as In-Memory Queue (Queue.js)

    User->>React: Clicks "Return Book" on active loan row
    React->>Express: POST /api/issues/:id/return
    Express->>Mongo: Issue.findById(id)
    Mongo-->>Express: Returns issue document
    Note over Express: Check status !== 'RETURNED' (prevent double return)
    Express->>Mongo: Book.findById(issue.bookId)
    Express->>Express: availableCopies += 1; issuedCopies -= 1
    Express->>Mongo: book.save()
    Express->>Express: issue.status = 'RETURNED'; issue.returnedAt = new Date()
    Express->>Mongo: issue.save()
    Express->>Queue: activeIssueQueue.removeById(issue._id)
    Express-->>React: HTTP 200 OK { issue, updatedBook }
    React->>User: Displays return confirmation & removes loan from active table
```

---

## 14. How to Debug Key Issues

1. **MongoDB Connection Failures**:
   - Check `backend/.env` for correct `MONGO_URI`.
   - Ensure MongoDB is running locally (`net start MongoDB` on Windows) or check network access IP whitelist (`0.0.0.0/0`) on MongoDB Atlas.
2. **CORS Errors in Browser Console**:
   - Check that `app.use(cors())` is placed before routes in `backend/server.js`.
3. **Invalid ObjectId Cast Errors**:
   - Always validate with `mongoose.Types.ObjectId.isValid(id)` before querying by ID.
4. **Queue Inconsistency**:
   - Call `GET /api/issues/queue/status` to inspect current memory state vs. database records.
5. **Negative Book Quantities**:
   - Validate `availableCopies > 0` before decrementing during issue.
   - Use `Math.max(0, book.issuedCopies - 1)` during return.
   - Prevent deleting books with active issues: `Issue.findOne({ bookId: id, status: 'ISSUED' })`.

