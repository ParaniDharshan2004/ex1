import dotenv from 'dotenv';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mongoose from 'mongoose';

dotenv.config();

const scriptDirectory = path.dirname(fileURLToPath(import.meta.url));
const defaultSeedDataFile = path.join(scriptDirectory, 'seed-data.json');
const objectIdPattern = /^[a-f\d]{24}$/i;
const sourceIdMappings = new Map();

const identityFieldsByCollection = {
  fixedassetcategorymasters: ['categoryName'],
  fixedassetmasters: ['assetName', 'categoryId'],
};

const isObjectIdField = (key) =>
  key === '_id' || key.endsWith('Id') || key.endsWith('Ids');

const isDateField = (key) =>
  key.endsWith('At') || key.endsWith('Date') || key.endsWith('Until');

const restoreMongoTypes = (value, key = '') => {
  if (Array.isArray(value)) {
    return value.map((item) => restoreMongoTypes(item, key));
  }

  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([fieldName, fieldValue]) => [
        fieldName,
        restoreMongoTypes(fieldValue, fieldName),
      ]),
    );
  }

  if (
    typeof value === 'string' &&
    isObjectIdField(key) &&
    objectIdPattern.test(value)
  ) {
    return new mongoose.Types.ObjectId(value);
  }

  if (typeof value === 'string' && isDateField(key)) {
    const date = new Date(value);
    if (!Number.isNaN(date.getTime())) {
      return date;
    }
  }

  return value;
};

const remapSourceIds = (value) => {
  if (value instanceof mongoose.Types.ObjectId) {
    return sourceIdMappings.get(value.toHexString()) || value;
  }

  if (Array.isArray(value)) {
    return value.map(remapSourceIds);
  }

  if (value && typeof value === 'object' && !(value instanceof Date)) {
    return Object.fromEntries(
      Object.entries(value).map(([key, nestedValue]) => [
        key,
        remapSourceIds(nestedValue),
      ]),
    );
  }

  return value;
};

const getIdentityFilter = (collectionName, document) => {
  const identityFields = identityFieldsByCollection[collectionName];
  if (!identityFields) {
    return null;
  }

  return Object.fromEntries(
    identityFields.map((fieldName) => [fieldName, document[fieldName]]),
  );
};

const loadSeedData = async () => {
  const filePath = process.env.SEED_DATA_FILE || defaultSeedDataFile;
  let contents;

  try {
    contents = await fs.readFile(filePath, 'utf8');
  } catch (error) {
    throw new Error(`Could not read seed data file "${filePath}": ${error.message}`);
  }

  try {
    const data = JSON.parse(contents);
    if (!data || Array.isArray(data) || typeof data !== 'object') {
      throw new Error('The root value must be an object keyed by collection name');
    }
    return data;
  } catch (error) {
    throw new Error(`Could not parse seed data file "${filePath}": ${error.message}`);
  }
};

const importCollection = async (collectionName, documents) => {
  if (!Array.isArray(documents)) {
    throw new Error(`Collection "${collectionName}" must contain an array`);
  }

  const operations = [];
  let alreadyPresent = 0;

  for (const [index, document] of documents.entries()) {
    if (!document || typeof document !== 'object' || Array.isArray(document)) {
      throw new Error(
        `Collection "${collectionName}" contains an invalid document at index ${index}`,
      );
    }
    if (
      document._id === null ||
      document._id === undefined ||
      (typeof document._id !== 'string' &&
        typeof document._id !== 'number' &&
        typeof document._id !== 'object')
    ) {
      throw new Error(
        `Collection "${collectionName}" document ${index} has an invalid _id`,
      );
    }

    const sourceId = document._id;
    const restoredDocument = remapSourceIds(restoreMongoTypes(document));
    const collection = mongoose.connection.collection(collectionName);
    let existing = await collection.findOne({ _id: restoredDocument._id });

    if (!existing) {
      const identityFilter = getIdentityFilter(collectionName, restoredDocument);
      if (identityFilter) {
        existing = await collection.findOne(identityFilter);
      }
    }

    if (existing) {
      sourceIdMappings.set(String(sourceId), existing._id);
      alreadyPresent += 1;
      continue;
    }

    operations.push({
      updateOne: {
        filter: { _id: restoredDocument._id },
        update: { $setOnInsert: restoredDocument },
        upsert: true,
      },
    });
  }

  if (operations.length === 0) {
    return { inserted: 0, alreadyPresent };
  }

  const result = await mongoose.connection
    .collection(collectionName)
    .bulkWrite(operations, { ordered: true });

  return {
    inserted: result.upsertedCount,
    alreadyPresent: alreadyPresent + operations.length - result.upsertedCount,
  };
};

const seed = async () => {
  if (!process.env.MONGO_URI) {
    throw new Error('MONGO_URI is missing from the environment');
  }

  const seedData = await loadSeedData();
  await mongoose.connect(process.env.MONGO_URI);

  const totals = { inserted: 0, alreadyPresent: 0 };
  console.log(`Importing ${Object.keys(seedData).length} collections...`);

  for (const [collectionName, documents] of Object.entries(seedData)) {
    const counts = await importCollection(collectionName, documents);
    totals.inserted += counts.inserted;
    totals.alreadyPresent += counts.alreadyPresent;
    console.log(
      `${collectionName}: ${counts.inserted} inserted, ${counts.alreadyPresent} already present`,
    );
  }

  console.log(
    `Seed completed: ${totals.inserted} inserted, ${totals.alreadyPresent} already present`,
  );
};

seed()
  .catch((error) => {
    console.error('Seed failed:', error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect();
  });
