import mongoose from 'mongoose';
import dotenv from 'dotenv';

import FixedAssetCategoryMaster from '../models/master-models/fixed-assets-category-model.js';

dotenv.config();

const userId = new mongoose.Types.ObjectId('6aa0ddb3f070abe2bf992b11');

const categories = [
  {
    categoryName: 'Computer & Equipment',
    description: 'Laptops, monitors, printers and peripherals',
    displayOrder: 1,
  },
  {
    categoryName: 'Furniture',
    description: 'Office furniture and fixtures',
    displayOrder: 2,
  },
  {
    categoryName: 'Networking Equipment',
    description: 'Routers, switches and network devices',
    displayOrder: 3,
  },
  {
    categoryName: 'Office Infrastructure',
    description: 'Air conditioners, UPS, projectors and infrastructure assets',
    displayOrder: 4,
  },
  {
    categoryName: 'Mobile Devices',
    description: 'Mobile phones and tablets',
    displayOrder: 5,
  },
];

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    for (const category of categories) {
      await FixedAssetCategoryMaster.updateOne(
        {
          categoryName: category.categoryName,
        },
        {
          $set: {
            ...category,
            updatedBy: userId,
          },
          $setOnInsert: {
            createdBy: userId,
          },
        },
        {
          upsert: true,
        },
      );
    }

    console.log('Fixed Asset Categories Seeded Successfully');

    process.exit(0);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

seed();
