# Changelog — FLC Intelligence Next Level

## Redesigned prototype

- Replaced the static page collection with a unified responsive application shell.
- Added dashboard, annual FLC, three-file intake, employee register, fixed asset register, version history, version comparison, reports and calculation settings.
- Added direct-cost, indirect-cost and fixed-assets input templates in Excel format.
- Added CSV and Excel parsing, editable staging tables and import validation.
- Added dynamic ratio and FLC calculations based on the confirmed requirements.
- Added local version snapshots and CSV/JSON export.
- Added visible warnings for unresolved fixed asset depreciation policy and production readiness.

## Known limitations

- Browser `localStorage` only; no server or database.
- SheetJS is loaded from a CDN for Excel file parsing.
- Only the first worksheet of each uploaded workbook is parsed.
- Header names should follow the supplied templates or supported aliases.
- Fixed asset depreciation uses the uploaded asset value as the base; no WDV carry-forward is implemented until Finance confirms the policy.

## Workbook-focused enhancement (23 Nov 2026)
- Added a dedicated **Uploaded data & calculation workbook** page inspired by the original Uploaded Excel Data screen.
- Added six switchable workbook sheets: Direct Cost, Indirect Cost, Fixed Assets, Allocation Working, FLC per Hour, and FLC per Month.
- Added a searchable, scrollable spreadsheet-style table with sticky column headers, source/version context, row counts, currency formatting, and calculation bridge cards.
- Expanded the demo dataset to 60 employees (36 RG, 18 Administrative, 6 Reserve), 35 indirect-cost components, and 30 fixed assets.
- The first-time browser experience now seeds the expanded demo workbook and calculates a live preview. The demo is clearly labelled and is not saved as an immutable version until the user creates one.
- Added direct navigation to the workbook from the dashboard and annual FLC page.
