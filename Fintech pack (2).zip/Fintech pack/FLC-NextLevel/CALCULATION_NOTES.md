# FLC Calculation Notes and Open Decisions

## Confirmed from requirements discussion

- Financial year follows India: April to March.
- FLC is calculated once per annum.
- Admin can select any month from April to March as the reference month.
- Employee working hours for that selected month are imported in File 1 and can be edited before calculation.
- File 1 contains employee-specific direct costs and Employee ID.
- File 2 contains one company-wide value per indirect cost component.
- File 3 contains the complete fixed assets list and asset values.
- Three separate files are uploaded together for every version.
- Each new version is a complete re-upload of all three files and a full recalculation. Old versions are retained.
- Employee ID is the stable identity across versions. Missing employees are excluded from the new version; new employees are included.
- New employees use full annualized cost, even if hired partway through the year.
- Admin cost apportionment is equal per Revenue Generating employee.
- Administrative employee cost pool includes Direct + Variable + Fixed Depreciation.
- Administrative employees have individual cost detail but no separate final FLC.
- Reserve working hours are excluded from the allocation ratio, but Reserve employee count is included in its denominator.
- Reserve allocations are calculated but excluded from final FLC.
- Annual cost values are divided by 12. Monthly values are not divided again.
- Department ratio and final allocation ratio are rounded to two decimals before cost allocation.
- Intermediate monetary calculations are rounded to two decimals.

## Allocation ratio

Let:
- `RG_Hours` = sum of active Revenue Generating employee reference-month hours.
- `ADMIN_Hours` = sum of active Administrative employee reference-month hours.
- `RG_Count` = active Revenue Generating employee count.
- `RESERVE_Count` = active Reserve employee count.

Department ratio part:
`RG_Ratio_Part = ROUND(RG_Hours / ADMIN_Hours, 2)`

Administrative ratio part:
`ADMIN_Ratio_Part = 1.00`

Total ratio parts:
`Total_Ratio_Parts = ROUND(RG_Ratio_Part + ADMIN_Ratio_Part, 2)`

Final allocation ratio:
`Allocation_Ratio = ROUND((RG_Ratio_Part / Total_Ratio_Parts) * (ADMIN_Ratio_Part / (RG_Count + RESERVE_Count)), 2)`

Example:
- RG hours = 640
- Administrative hours = 320
- RG employee count = 4
- Reserve employee count = 2
- RG ratio part = 2.00
- Administrative ratio part = 1.00
- Final allocation ratio = ROUND((2/3) × (1/6), 2) = 0.11

## Cost allocations

For each common indirect cost component:
- Annual input → monthly base = ROUND(annual input / 12, 2)
- Monthly input → monthly base = input amount
- Per-employee allocated monthly component = ROUND(monthly base × allocation ratio, 2)

For each fixed asset:
- Annual depreciation = ROUND(asset value × 27%, 2)
- Monthly depreciation = ROUND(annual depreciation / 12, 2)
- Per-employee allocated monthly depreciation = ROUND(monthly depreciation × allocation ratio, 2)

The same per-employee allocation is applied to every employee in RG, Administrative and Reserve departments. The amount is not divided again by employee count.

## Administrative semi-variable cost

`Admin_Cost_Pool = SUM(Admin Direct Cost Monthly) + (Variable Allocated Monthly Per Employee × Admin Count) + (Fixed Depreciation Allocated Monthly Per Employee × Admin Count)`

`Semi_Variable_Per_RG_Employee = ROUND(Admin_Cost_Pool / RG_Count, 2)`

## Revenue Generating FLC

For each active RG employee:
- `Direct_Per_Hour = ROUND(Direct_Cost_Monthly / Reference_Month_Hours, 2)`
- `Indirect_A_Per_Hour = ROUND((Variable_Allocated_Monthly + Fixed_Depreciation_Allocated_Monthly) / Reference_Month_Hours, 2)`
- `Admin_B_Per_Hour = ROUND(Semi_Variable_Per_RG_Employee / Reference_Month_Hours, 2)`
- `FLC_Per_Hour = ROUND(Direct_Per_Hour + Indirect_A_Per_Hour + Admin_B_Per_Hour, 2)`
- `Monthly_Direct = ROUND(Direct_Per_Hour × Reference_Month_Hours, 2)`
- `Monthly_Indirect_A = ROUND(Indirect_A_Per_Hour × Reference_Month_Hours, 2)`
- `Monthly_Admin_B = ROUND(Admin_B_Per_Hour × Reference_Month_Hours, 2)`
- `FLC_Per_Month = ROUND(Monthly_Direct + Monthly_Indirect_A + Monthly_Admin_B, 2)`

## Open finance decision: fixed asset depreciation

The user described a reducing-balance example:
- Asset value ₹100,000
- Year 1 depreciation ₹27,000
- Closing value ₹73,000
- Year 2 depreciation ₹73,000 × 27%

However, the user later said they were not sure whether the input file actually contains original purchase value or remaining value. These are not confirmed requirements.

Finance must confirm:
1. Does File 3 show original purchase value or current written-down value?
2. Should the system calculate WDV depreciation and carry forward closing value automatically?
3. Are asset additions included in the next annual FLC version, and what is the exact cut-off?
4. Is depreciation annual then divided by 12 for the cost model, or is there another period convention?

Until confirmed, the prototype applies 27% to the asset value supplied in File 3 and does not auto-carry forward. Each version retains the uploaded asset values it used.
