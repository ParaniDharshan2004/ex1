# FLC Intelligence — Next-Level Prototype

A browser-based front-end prototype built with **HTML, CSS and vanilla JavaScript**. It redesigns the supplied FLC prototype around the business rules clarified in the requirements discussion.

## Run it

1. Extract the ZIP.
2. Open `index.html` in a modern desktop browser.
3. For Excel (`.xlsx` / `.xls`) parsing, allow the browser to load the SheetJS CDN script (internet connection required). CSV parsing works without that library.
4. Click **Load demo data** on Input files & validation to explore the complete workflow, or upload your own three files.
5. Review/edit the imported rows, validate, select financial year and reference month, then click **Calculate / create new version**.

No build step, Node server, framework, or database is required for this prototype.

## Included files

- `index.html` — application shell and screens.
- `styles.css` — responsive application styling.
- `app.js` — import parsing, validation, editable previews, FLC calculation engine, version snapshots and exports.
- `FLC_File1_Direct_Cost_Template.xlsx` — sample Direct Cost input format.
- `FLC_File2_Indirect_Cost_Template.xlsx` — sample Indirect Cost input format.
- `FLC_File3_Fixed_Assets_Template.xlsx` — sample Fixed Assets input format.
- `CALCULATION_NOTES.md` — calculation assumptions and open policy questions.

## Three input files

### File 1 — Direct Cost

Required columns:
- `employeeId`
- `employeeName`
- `department` (`Revenue Generating`, `Administrative`, or `Reserve`)
- `workingHours` (for the selected reference month)
- Direct cost information, either:
  - `directCostAnnual` or `directCostMonthly`, or
  - employee-level annual/monthly component columns such as `salaryAnnual`, `lifeInsuranceAnnual`, `healthInsuranceAnnual`, `holidayBonusAnnual`, `certificationAnnual`, `resourceAnnual`, `softwareAnnual`.

Optional: `team`, `designation`, `status`.

If an explicit total Direct Cost annual/monthly field is present, it takes precedence. Otherwise, the app sums recognized employee-specific component columns. Annual components are divided by 12.

### File 2 — Indirect Cost

Columns:
- `component`
- `amount`
- `period` (`Annual` or `Monthly`)

Each row is a common company-wide cost component. Annual values are divided by 12; monthly values remain unchanged.

### File 3 — Fixed Assets Cost

Columns:
- `assetName`
- `assetValue`

Upload all existing assets and new assets for the version. The prototype uses the configured 27% rate against the supplied asset value, calculates annual depreciation, then divides by 12 for monthly depreciation.

## Calculation rules implemented

1. Only active employees are included in calculation headcounts and cost pools.
2. RG and Administrative working hours are summed separately. Reserve working hours are excluded from the ratio.
3. Department ratio is calculated as `RG hours / Administrative hours : 1`, rounded to two decimal places.
4. Final allocation ratio is:

   `(rounded RG ratio part / total rounded ratio parts) × (Administrative ratio part / (RG employee count + Reserve employee count))`

   The final allocation ratio is rounded to two decimal places before allocation. For the example in the requirements (640 RG hours, 320 Admin hours, 4 RG employees and 2 Reserve employees), the ratio is `0.11`.
5. The same allocation ratio is applied separately to each Variable Cost component and each Fixed Cost (Depreciation) component. The allocated amount is assigned per employee and is not divided again by department headcount.
6. Fixed asset annual depreciation is `supplied asset value × 27%`; monthly depreciation is annual depreciation divided by 12.
7. Each employee receives the same allocated variable and fixed monthly amount. Direct Cost remains employee-specific.
8. Administrative cost pool = sum of Administrative employees' Direct Cost + allocated Variable Cost + allocated Fixed Depreciation (monthly).
9. Semi-Variable Cost per RG employee = Administrative cost pool / active RG employee count.
10. Hourly FLC for RG employee:
    - Direct per hour = Direct Cost monthly / employee reference-month working hours.
    - Indirect A per hour = (allocated Variable Cost monthly + allocated Fixed Depreciation monthly) / working hours.
    - Admin B per hour = Semi-Variable Cost monthly / working hours.
    - FLC per hour = Direct per hour + Indirect A + Admin B.
11. Monthly FLC = rounded Direct/hour × hours + rounded Indirect A/hour × hours + rounded Admin B/hour × hours.
12. Reserve allocation values are calculated and retained in the calculation detail but excluded from final FLC. Administrative employees have cost details but no separate FLC result.
13. A newly joined employee uses full annualized costs supplied in File 1. The file must contain the employee's reference-month working hours.
14. A new version requires all three complete files and regenerates all calculations. Prior versions remain immutable snapshots.

## Version and storage behaviour

- Versions are stored in browser `localStorage` under `flc_nextlevel_state_v1`.
- Every version stores a copy of all three imported datasets, source file names, financial year, reference month, settings and calculated results.
- All three files must be freshly uploaded for each new version; the previous version's files cannot be reused as the next version's upload.
- Versions are not overwritten; two saved versions can be selected for a comparison view.
- The prototype does not send data to a server.

## Important limitations / production considerations

- This is a front-end prototype, not a production financial system. Browser storage is not a secure database, does not provide multi-user concurrency, and can be cleared by the user/browser.
- Excel parsing uses SheetJS from a CDN. For offline or production use, vendor and pin a reviewed library version locally.
- Input headers should follow the templates. This prototype supports common header aliases but is not a general-purpose arbitrary workbook mapper.
- It reads the first worksheet of each uploaded workbook.
- The fixed asset carry-forward policy is unresolved. The finance team has not confirmed whether File 3 contains original purchase value or written-down value, nor whether the app should carry forward depreciation automatically. This prototype therefore uses the supplied value as the depreciation base and clearly flags the assumption. Do not treat that policy as final.
- The prototype treats 27% as a percentage applied to the supplied value to calculate annual depreciation, then divides by 12. Finance should confirm period conventions and asset-level WDV/SLM treatment before production.
- Role-based access control, server-side validation, audit events, database transactions, encrypted storage, backups, import virus scanning and formal approval workflow are not implemented.
- Production architecture should separate import staging, normalized input records, calculation engine, version snapshots and report generation. All authoritative calculations must be re-run and validated server-side.

## Recommended production stack

Keep this prototype as a UX and calculation reference. For production, use a backend service (for example Node.js/Express), a relational or document database with immutable version snapshots, server-side Excel parsing and a testable calculation module. Keep all calculation rules in one versioned domain service, not scattered through page scripts.

## Uploaded data & calculation workbook

The application now includes a dedicated **Uploaded data & calculations** page, based on the spreadsheet-style experience from the earlier prototype. It combines the three source datasets and the calculated output in one place, using six workbook sheets:

1. Direct Cost — employee register, department, reference-month hours, monthly and annual direct cost.
2. Indirect Cost — source amount, annual/monthly period, normalized monthly value and per-employee allocation.
3. Fixed Assets — asset value, 27% annual depreciation, monthly depreciation and per-employee allocation.
4. Allocation Working — direct, variable, fixed and Administrative semi-variable cost per employee.
5. FLC per Hour — Direct / hr, Indirect A / hr, Admin B / hr and total FLC / hr for RG employees.
6. FLC per Month — rounded hourly components multiplied by reference-month hours.

The first run automatically loads an expanded demonstration dataset containing **60 employees (36 RG, 18 Administrative and 6 Reserve), 35 indirect-cost components and 30 fixed assets**. This is clearly marked as demo data. Use **Input files & validation** to replace it with the three actual source files. The demo preview is not recorded as a historical version until you choose **Calculate / create new version**.
