# Source Prototype Review

## Files reviewed

The supplied ZIP contains the following application files:
- `index.html` and `dashboard.html`
- `upload.html`
- `excel.html`
- `master.html`
- `assets.html`
- `insurance.html`
- `reports.html`
- `script.js`
- `style.css`
- `README.md`
- `text.txt` (database entity relationship diagrams)
- `FLC- Template- 6th Nov.xlsx`

## What was already useful

- A clear finance-oriented navigation model with Dashboard, Excel Upload, Uploaded Excel Data, Reports, Master, Asset Tracking and Insurance.
- Master-data concepts for departments, teams, employees, salaries, certifications, bonuses, resources, software and insurance.
- Resource assignment and return/de-assignment concepts.
- A fixed asset register and a database schema that anticipates asset valuation history and depreciation configuration/history.
- A report view that uses the FLC workbook as a detailed financial presentation.
- A reasonable visual foundation with shared CSS and JavaScript.

## Important implementation gaps identified

1. **Upload workflow was only a single-file selection flow.** The original upload page accepted one workbook, showed selected-file metadata, and navigated to the preview page. It did not parse the file, validate the data, map fields, or stage three separate input files.
2. **The calculation engine was not connected to imported workbook data.** The Excel page rendered embedded/static workbook values from JavaScript arrays. Selecting a workbook did not replace those values with parsed input data.
3. **Allocation ratio was hardcoded in the workbook display.** The original JavaScript `updateEngineParameters()` used `1 / activeHeadcount`, while the agreed FLC rule uses Revenue Generating and Administrative working hours plus Revenue Generating and Reserve employee counts.
4. **Employee and department counts were inferred from table text.** `getActiveHeadcount()` inspected rendered employee rows and fell back to a hardcoded count of 9, rather than using validated normalized employee records.
5. **Working calendar assumptions were hardcoded.** The old prototype used a static holiday-count object and an assumed 8-hour day. The agreed FLC process imports each employee's reference-month working hours from File 1.
6. **Workbook formulas contain hardcoded 160-hour denominators/multipliers.** The uploaded template uses 160 in hourly calculations and monthly reconstruction. The new prototype uses each employee's imported reference-month working hours.
7. **Administrative apportionment contains a hardcoded divisor.** The workbook's Semi-Variable row 62 includes `/5`. The new prototype divides the Administrative monthly cost pool by the current active Revenue Generating headcount.
8. **External workbook dependencies exist.** The FLC workbook references `[1]Component details` for several source values, but the supplied workbook contains only the `Fully Loaded cost -2026` sheet. The new prototype instead expects those source values in the three input files.
9. **No immutable annual version snapshots existed.** The original pages had static report examples for several periods, but no workflow that creates a new full-recalculation version and preserves the prior input/output snapshot.
10. **Persistence was inconsistent.** The original JavaScript persisted asset inventory and calculation parameters in localStorage, while many table edits were direct DOM updates rather than a unified data model.
11. **No formal import validation or audit trail existed.** Duplicate Employee IDs, missing departments, missing working hours, invalid amounts and incomplete input sets were not comprehensively checked.
12. **Fixed asset depreciation policy needs finance confirmation.** The supplied workbook applies 27% to supplied asset values. The user's reducing-balance example suggests WDV, but the user explicitly said the actual input-file value basis was not yet known.

## Improvements in the redesigned prototype

- Reorganized the workflow around annual FLC calculation and three separate input files.
- Added three-file upload staging for Direct Cost, Indirect Cost and Fixed Assets.
- Added Excel/CSV parsing, editable imported tables, validation messages and sample templates.
- Added Employee ID-based matching/identity and department normalization.
- Implemented the confirmed allocation-ratio formula, including ratio rounding and Reserve employee count treatment.
- Implemented per-employee Variable Cost and Fixed Depreciation allocations.
- Implemented the Administrative cost pool and equal Semi-Variable Cost per Revenue Generating employee.
- Implemented direct hourly, indirect A hourly, administrative B hourly, total hourly FLC and monthly FLC based on the reference-month hours.
- Added version snapshots, version history and side-by-side comparison.
- Requires all three files to be freshly uploaded for each new version; saved historical versions are not overwritten.
- Added employee and fixed asset register views, reports, CSV/JSON exports and browser-local persistence.
- Added visible policy warnings for unresolved depreciation carry-forward and production-only requirements.

## Scope note

The redesigned application is a browser-only prototype. It demonstrates the intended user experience and calculation flow, but it is not a secure, multi-user production application. The authoritative production calculation must be implemented and tested on the server, with database transactions, access control, audit logs and versioned input snapshots.


## Follow-up UX enhancement: consolidated workbook page
The updated prototype adds a dedicated Uploaded data & calculation workbook page to address the most important review workflow. It provides six sheet tabs (Direct Cost, Indirect Cost, Fixed Assets, Allocation Working, FLC per Hour and FLC per Month), searchable spreadsheet-style tables, sticky headers, source/version context, and a calculation bridge. The first-time experience preloads a sizeable demo dataset (60 employees, 35 indirect cost components and 30 fixed assets) so the user can inspect populated data and calculated values immediately.

Static validation after this enhancement: JavaScript syntax check passed; all literal JavaScript ID selectors resolve to elements in the HTML; no duplicate HTML IDs; workbook page contains six tabs. The calculation engine was exercised against the expanded demo dataset and returned 36 RG, 18 Administrative and 6 Reserve employees, 5,760 RG hours, 2,880 Administrative hours, and a rounded 0.02 final allocation factor. This is not a full browser end-to-end test.
