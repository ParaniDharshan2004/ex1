/* FLC Intelligence — browser-only functional prototype.
   No backend is connected. Version snapshots are stored in localStorage.
   XLSX parsing uses SheetJS CDN; CSV parsing is native. */
(() => {
"use strict";
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORE_KEY = "flc_nextlevel_state_v2";
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DEPTS = ["Revenue Generating","Administrative","Reserve"];
const fmt = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(n)||0);
const num = v => { if (typeof v==="number") return Number.isFinite(v)?v:0; const x=Number(String(v??"").replace(/[₹,\s]/g,"")); return Number.isFinite(x)?x:0; };
const round2 = n => Math.round((Number(n)+Number.EPSILON)*100)/100;
const esc = v => String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const norm = s => String(s??"").toLowerCase().replace(/[^a-z0-9]/g,"");
const defaultState = () => ({settings:{depreciationRate:27},imports:{direct:null,indirect:null,assets:null},freshUploads:{direct:false,indirect:false,assets:false},versions:[],currentResult:null,selectedVersionId:null});
let state = loadState(), editEmployeeId=null, editAssetIndex=null, toastTimer=null, selectedCompareIds=new Set();
let freshUploads = state.freshUploads || {direct:false, indirect:false, assets:false};
let workbookTab = "direct";

function loadState(){try{const raw=localStorage.getItem(STORE_KEY);if(raw){const v=JSON.parse(raw);return {...defaultState(),...v,settings:{...defaultState().settings,...v.settings}}}}catch(e){}return defaultState()}
function persist(){state.freshUploads=freshUploads;try{localStorage.setItem(STORE_KEY,JSON.stringify(state));}catch(e){notify("Browser storage is full. Export a backup and clear old data.");}}
function notify(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),3000)}
function go(view){$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));$$(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${view}`));$("#breadcrumbCurrent").textContent=({dashboard:"Overview",calculation:"Annual FLC",workbook:"Uploaded data & calculations",imports:"Input files & validation",employees:"Employees",assets:"Fixed assets",versions:"Version history",reports:"Reports & exports",settings:"Calculation settings"})[view]||view;$("#sidebar").classList.remove("open");if(view==="dashboard")renderDashboard();if(view==="employees")renderEmployees();if(view==="assets")renderAssets();if(view==="versions")renderVersions();if(view==="reports")renderReports();if(view==="calculation")renderCalculation();if(view==="workbook")renderWorkbook()}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>go(b.dataset.view)));
$$("[data-goto]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.goto)));
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#resetDemoBtn").addEventListener("click",()=>{if(confirm("Reset this prototype to a clean state? This clears imported data and saved versions in this browser.")){localStorage.removeItem(STORE_KEY);state=defaultState();freshUploads={direct:false,indirect:false,assets:false};persist();clearFileCards();renderAll();notify("Prototype data reset.")}});

function setViewTableEmpty(id,cols,msg){$(id).innerHTML=`<tr><td colspan="${cols}" class="empty-cell">${esc(msg)}</td></tr>`}
function departmentKey(value){const v=norm(value);if(["revenuegenerating","revenue","rg","billable","revenuegeneratingdepartment"].includes(v))return "Revenue Generating";if(["administrative","admin","administrativedepartment","support"].includes(v))return "Administrative";if(["reserve","res","reservedepartment"].includes(v))return "Reserve";return String(value??"").trim()}
function readFile(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(new Error("Could not read file."));reader.onload=e=>{try{const ext=file.name.split(".").pop().toLowerCase();let rows;if(ext==="csv"){rows=parseCSV(String(e.target.result||""))}else{if(!window.XLSX)throw new Error("Excel reader library is not available. Use CSV or connect to the internet to load SheetJS.");const wb=XLSX.read(e.target.result,{type:"array",cellDates:true});const sheet=wb.Sheets[wb.SheetNames[0]];rows=XLSX.utils.sheet_to_json(sheet,{defval:"",raw:true});}resolve({name:file.name,rows})}catch(err){reject(err)}};if(file.name.toLowerCase().endsWith(".csv"))reader.readAsText(file);else reader.readAsArrayBuffer(file)})}
function parseCSV(text){const rows=[];let row=[],cell="",quoted=false;for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'&&quoted&&n==='"'){cell+='"';i++}else if(c==='"'){quoted=!quoted}else if(c===","&&!quoted){row.push(cell);cell=""}else if((c==="\n"||c==="\r")&&!quoted){if(c==="\r"&&n==="\n")i++;row.push(cell);if(row.some(x=>String(x).trim()!==""))rows.push(row);row=[];cell=""}else cell+=c}row.push(cell);if(row.some(x=>String(x).trim()!==""))rows.push(row);if(rows.length<2)return[];const headers=rows.shift().map(x=>String(x).trim());return rows.map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]??""])))}
function valueBy(row, aliases){const map=new Map(Object.keys(row).map(k=>[norm(k),row[k]]));for(const a of aliases){const key=norm(a);if(map.has(key)&&map.get(key)!=="")return map.get(key)}return ""}
function toRows(rows){return rows.filter(r=>r&&Object.keys(r).some(k=>String(r[k]??"").trim()!==""))}
function canonicalDirect(rows){
 return toRows(rows).map((r,i)=>{
  const id=valueBy(r,["employeeId","employee id","empId","empCode","employeeCode","staffId"]);
  const name=valueBy(r,["employeeName","employee name","empName","name"]);
  const dept=departmentKey(valueBy(r,["department","departmentName","deptName","dept"]));
  const hours=num(valueBy(r,["workingHours","referenceMonthHours","monthlyWorkingHours","hours"]));
  const directMonthlyRaw=valueBy(r,["directCostMonthly","totalDirectCostMonthly","directMonthly"]);
  const directAnnualRaw=valueBy(r,["directCostAnnual","totalDirectCostAnnual","directAnnual"]);
  const directMonthly=num(directMonthlyRaw);
  const directAnnual=num(directAnnualRaw);
  let componentMonthly=0,componentAnnual=0,parts=[];
  for(const [key,val] of Object.entries(r)){const k=norm(key);if(!val&&val!==0)continue;
   const looksCost=/(salary|wage|insurance|bonus|certification|reimbursement|resource|software|directcost|benefit|allowance)/.test(k);
   if(!looksCost||/(id|hours|date|effective|status|name|provider|team)/.test(k))continue;
   const v=num(val);if(/monthly|month/.test(k))componentMonthly+=v;else if(/annual|yearly|perannum/.test(k))componentAnnual+=v;else if(!["directcostannual","totaldirectcostannual","directannual","directcostmonthly","totaldirectcostmonthly","directmonthly"].includes(k))componentMonthly+=v;
   parts.push({component:key,value:v});
  }
  // Prefer an explicit total Direct Cost field. Otherwise sum the employee-specific
  // component columns; annual components are converted to monthly values.
  let monthly;
  if(directMonthlyRaw!=="") monthly=directMonthly;
  else if(directAnnualRaw!=="") monthly=round2(directAnnual/12);
  else monthly=round2(componentMonthly+componentAnnual/12);
  if(!monthly&&!directAnnual&&!componentMonthly&&!componentAnnual)monthly=0;
  const annual=directAnnual || round2(monthly*12);
  const directCostSpecified=directMonthlyRaw!==""||directAnnualRaw!==""||parts.length>0;
  return {employeeId:String(id??"").trim(),employeeName:String(name??"").trim(),department:dept,team:String(valueBy(r,["team","teamName"])||"").trim(),designation:String(valueBy(r,["designation","role"])||"").trim(),status:String(valueBy(r,["status","employeeStatus"])||"Active").trim(),workingHours:hours,directCostMonthly:round2(monthly),directCostAnnual:round2(annual),directCostSpecified,costBreakdown:parts,sourceRow:i+2};
 });
}
function canonicalIndirect(rows){return toRows(rows).map((r,i)=>{const periodRaw=valueBy(r,["period","frequency","costPeriod","basis"]);return {component:String(valueBy(r,["component","costComponent","expense","expenseName","particulars","category"])||"").trim(),amount:num(valueBy(r,["amount","value","totalCost","cost","annualAmount","monthlyAmount"])),period:String(periodRaw||"Annual").trim(),periodSpecified:periodRaw!=="",amountSpecified:valueBy(r,["amount","value","totalCost","cost","annualAmount","monthlyAmount"])!=="",sourceRow:i+2}}).map(x=>({...x,period:/month/i.test(x.period)?"Monthly":"Annual",monthlyAmount:round2(x.period==="Annual"?x.amount/12:x.amount)}))}
function canonicalAssets(rows){return toRows(rows).map((r,i)=>{const value=valueBy(r,["assetValue","value","purchaseCost","assetCost","cost","originalCost"]);return {assetName:String(valueBy(r,["assetName","asset","name","assetDescription","particulars"])||"").trim(),assetValue:num(value),assetValueSpecified:value!=="",sourceRow:i+2}})}
const fileConfig={direct:{input:"#directFile",status:"#directStatus",meta:"#directMeta",label:"Direct Cost"},indirect:{input:"#indirectFile",status:"#indirectStatus",meta:"#indirectMeta",label:"Indirect Cost"},assets:{input:"#assetsFile",status:"#assetsStatus",meta:"#assetsMeta",label:"Fixed Assets"}};
Object.entries(fileConfig).forEach(([key,cfg])=>$(cfg.input).addEventListener("change",async e=>{const file=e.target.files?.[0];if(!file)return;try{const parsed=await readFile(file);if(!parsed.rows.length)throw new Error("No data rows found. Ensure the first row contains column headers.");const data=key==="direct"?canonicalDirect(parsed.rows):key==="indirect"?canonicalIndirect(parsed.rows):canonicalAssets(parsed.rows);state.imports[key]={fileName:parsed.name,rows:data,rawRows:parsed.rows};freshUploads[key]=true;$(cfg.status).textContent="Loaded";$(cfg.status).classList.add("ready");$(cfg.meta).textContent=`${parsed.name} · ${data.length} data rows imported`;persist();updateImportReadiness();renderImportTables();notify(`${cfg.label} file loaded.`)}catch(err){notify(err.message);e.target.value=""}}));
function clearFileCards(){Object.entries(fileConfig).forEach(([k,c])=>{const input=$(c.input);if(input)input.value="";$(c.status).textContent="Not uploaded";$(c.status).classList.remove("ready");$(c.meta).textContent=k==="direct"?"Required: Employee ID, name, department, working hours and direct cost components.":k==="indirect"?"Required: Component name, amount and cost period (Annual or Monthly).":"Required: Asset name and asset value. Depreciation ratio: 27%."})}
function updateImportReadiness(){
 const count=["direct","indirect","assets"].filter(k=>freshUploads[k]&&state.imports[k]?.rows?.length).length;
 $("#importReadiness").textContent=count===3?"All three files uploaded for this version":`${count} of 3 files freshly uploaded`;
 $("#importReadinessSub").textContent=count===3?"Review imported data and validate before calculation.":"Every new version requires all three files to be uploaded again; prior-version files cannot be reused.";
 $("#reviewImportBtn").disabled=count!==3;$("#validateInputsBtn").disabled=count!==3;$("#topFY").textContent=`FY ${$("#calcFY").value}`;
 $("#directRowsCount").textContent=state.imports.direct?.rows?.length||0;$("#indirectRowsCount").textContent=state.imports.indirect?.rows?.length||0;$("#assetsRowsCount").textContent=state.imports.assets?.rows?.length||0;
}
$("#reviewImportBtn").addEventListener("click",()=>{$("#importPreview").hidden=false;renderImportTables();$("#importPreview").scrollIntoView({behavior:"smooth",block:"start"})});
$("#validateInputsBtn").addEventListener("click",validateInputs);
$("#clearImportsBtn").addEventListener("click",()=>{if(confirm("Clear the current imported files and unsaved edits? Saved versions will not be affected.")){state.imports={direct:null,indirect:null,assets:null};freshUploads={direct:false,indirect:false,assets:false};persist();clearFileCards();$("#importPreview").hidden=true;$("#validationSummary").hidden=true;updateImportReadiness();renderAll();notify("Current input data cleared.")}});
$$("[data-import-tab]").forEach(b=>b.addEventListener("click",()=>{const tab=b.dataset.importTab;$$("[data-import-tab]").forEach(x=>x.classList.toggle("active",x===b));["direct","indirect","assets"].forEach(k=>{$(`#${k}ImportPanel`).hidden=k!==tab})}));
function renderImportTables(){
 const d=state.imports.direct?.rows||[],i=state.imports.indirect?.rows||[],a=state.imports.assets?.rows||[];
 $("#directImportHead").innerHTML="<tr><th>Employee ID</th><th>Employee name</th><th>Department</th><th>Team</th><th>Working hours</th><th>Direct cost / month</th><th>Status</th></tr>";
 $("#directImportBody").innerHTML=d.map((r,n)=>`<tr data-index="${n}"><td><input data-field="employeeId" value="${esc(r.employeeId)}"></td><td><input class="wide-input" data-field="employeeName" value="${esc(r.employeeName)}"></td><td><select data-field="department">${DEPTS.map(x=>`<option ${x===r.department?"selected":""}>${x}</option>`).join("")}</select></td><td><input data-field="team" value="${esc(r.team)}"></td><td><input type="number" min="0" step=".01" data-field="workingHours" value="${r.workingHours}"></td><td><input type="number" min="0" step=".01" data-field="directCostMonthly" value="${r.directCostMonthly}"></td><td><select data-field="status"><option ${r.status==="Active"?"selected":""}>Active</option><option ${r.status==="Inactive"?"selected":""}>Inactive</option></select></td></tr>`).join("")||`<tr><td colspan="7" class="empty-cell">No direct cost records.</td></tr>`;
 $("#indirectImportHead").innerHTML="<tr><th>Cost component</th><th>Input amount</th><th>Period</th><th>Normalized monthly value</th></tr>";
 $("#indirectImportBody").innerHTML=i.map((r,n)=>`<tr data-index="${n}"><td><input class="wide-input" data-field="component" value="${esc(r.component)}"></td><td><input type="number" min="0" step=".01" data-field="amount" value="${r.amount}"></td><td><select data-field="period"><option ${r.period==="Annual"?"selected":""}>Annual</option><option ${r.period==="Monthly"?"selected":""}>Monthly</option></select></td><td class="computed">${fmt(r.period==="Annual"?r.amount/12:r.amount)}</td></tr>`).join("")||`<tr><td colspan="4" class="empty-cell">No indirect cost records.</td></tr>`;
 $("#assetsImportHead").innerHTML="<tr><th>Asset name</th><th>Asset value</th><th>Depreciation rate</th><th>Annual depreciation</th><th>Monthly depreciation</th></tr>";
 $("#assetsImportBody").innerHTML=a.map((r,n)=>`<tr data-index="${n}"><td><input class="wide-input" data-field="assetName" value="${esc(r.assetName)}"></td><td><input type="number" min="0" step=".01" data-field="assetValue" value="${r.assetValue}"></td><td>27.00%</td><td class="computed">${fmt(r.assetValue*state.settings.depreciationRate/100)}</td><td class="computed">${fmt(r.assetValue*state.settings.depreciationRate/1200)}</td></tr>`).join("")||`<tr><td colspan="5" class="empty-cell">No fixed asset records.</td></tr>`;
}
$("#saveEditsBtn").addEventListener("click",()=>{
 [["direct","directImportBody"],["indirect","indirectImportBody"],["assets","assetsImportBody"]].forEach(([key,id])=>{
  const rows=state.imports[key]?.rows||[];$$("tr[data-index]",$(`#${id}`)).forEach(tr=>{const r=rows[Number(tr.dataset.index)];$$("[data-field]",tr).forEach(el=>{const f=el.dataset.field;let v=el.value;if(["workingHours","directCostMonthly","amount","assetValue"].includes(f))v=num(v);r[f]=v});if(key==="direct"){r.directCostAnnual=round2(r.directCostMonthly*12);r.directCostSpecified=true}if(key==="indirect"){r.monthlyAmount=round2(r.period==="Annual"?r.amount/12:r.amount);r.periodSpecified=true;r.amountSpecified=true}if(key==="assets")r.assetValueSpecified=true});
 });
 persist();renderImportTables();updateImportReadiness();notify("Reviewed input values saved in this browser.")
});
function validateInputs(){
 const errors=[],warnings=[],d=state.imports.direct?.rows||[],i=state.imports.indirect?.rows||[],a=state.imports.assets?.rows||[];
 if(!["direct","indirect","assets"].every(k=>freshUploads[k]))errors.push("A new FLC version requires a fresh upload of all three files: Direct Cost, Indirect Cost and Fixed Assets. Files from a previous version cannot be reused.");
 if(!d.length)errors.push("Direct Cost file has no employee rows.");
 if(!i.length)errors.push("Indirect Cost file has no component rows.");
 if(!a.length)warnings.push("Fixed Assets file has no assets; fixed depreciation will be zero.");
 const ids=new Set();d.forEach((r,n)=>{if(!r.employeeId)errors.push(`Direct Cost row ${n+2}: Employee ID is required.`);else if(ids.has(r.employeeId))errors.push(`Duplicate Employee ID: ${r.employeeId}.`);else ids.add(r.employeeId);if(!r.employeeName)errors.push(`Direct Cost row ${n+2}: Employee name is required.`);if(!DEPTS.includes(r.department))errors.push(`Direct Cost row ${n+2}: Department must be Revenue Generating, Administrative or Reserve.`);if(!(r.workingHours>=0))errors.push(`Direct Cost row ${n+2}: Working hours must be zero or greater.`);if(r.status!=="Inactive"&&r.workingHours<=0)errors.push(`Direct Cost row ${n+2}: Active employee must have positive reference-month working hours.`);if(!r.directCostSpecified)errors.push(`Direct Cost row ${n+2}: Provide directCostAnnual, directCostMonthly or employee-level cost component values.`);if(r.directCostMonthly<0)errors.push(`Direct Cost row ${n+2}: Direct cost cannot be negative.`)});
 i.forEach((r,n)=>{if(!r.component)errors.push(`Indirect Cost row ${n+2}: Component name is required.`);if(!r.amountSpecified)errors.push(`Indirect Cost row ${n+2}: Amount is required.`);if(!r.periodSpecified)errors.push(`Indirect Cost row ${n+2}: Period must be explicitly set to Annual or Monthly.`);if(r.amount<0)errors.push(`Indirect Cost row ${n+2}: Amount cannot be negative.`)});
 a.forEach((r,n)=>{if(!r.assetName)errors.push(`Fixed Assets row ${n+2}: Asset name is required.`);if(!r.assetValueSpecified)errors.push(`Fixed Assets row ${n+2}: Asset value is required.`);if(r.assetValue<0)errors.push(`Fixed Assets row ${n+2}: Asset value cannot be negative.`)});
 const rg=d.filter(x=>x.status!=="Inactive"&&x.department==="Revenue Generating"),ad=d.filter(x=>x.status!=="Inactive"&&x.department==="Administrative"),res=d.filter(x=>x.status!=="Inactive"&&x.department==="Reserve");
 if(!rg.length)errors.push("At least one active Revenue Generating employee is required.");
 if(!ad.length)errors.push("At least one active Administrative employee is required to calculate the allocation ratio and semi-variable cost.");
 if(!res.length)warnings.push("No Reserve employees found. Reserve employee count will be zero in the allocation denominator.");
 const rgHours=rg.reduce((s,x)=>s+x.workingHours,0),adHours=ad.reduce((s,x)=>s+x.workingHours,0);if(adHours<=0)errors.push("Administrative working hours total must be greater than zero.");
 const box=$("#validationSummary");box.hidden=false;box.classList.toggle("good",errors.length===0);box.innerHTML=`<strong>${errors.length?"Validation failed": "Validation passed"} · ${errors.length} error(s), ${warnings.length} warning(s)</strong><ul>${[...errors,...warnings].map(x=>`<li>${esc(x)}</li>`).join("")||"<li>All required checks passed.</li>"}</ul>`;
 if(!errors.length){$("#importPreview").hidden=false;notify("Input validation passed. You can create an annual FLC version.")}else notify("Please fix validation errors before calculation.");
 return errors.length===0;
}
$("#downloadTemplatesBtn").addEventListener("click",downloadTemplates);
function downloadFile(name,content,type="text/csv;charset=utf-8"){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
function downloadTemplates(){downloadFile("FLC_File1_Direct_Cost_Template.csv","employeeId,employeeName,department,team,designation,status,workingHours,directCostAnnual,salaryAnnual,lifeInsuranceAnnual,healthInsuranceAnnual,holidayBonusAnnual,certificationAnnual,resourceAnnual,softwareAnnual\nEMP001,Sample Employee,Revenue Generating,Operations,Analyst,Active,160,420000,360000,6000,12000,6000,6000,12000,18000\n");downloadFile("FLC_File2_Indirect_Cost_Template.csv","component,amount,period\nOffice Rent,654720,Annual\nElectricity,72763.64,Annual\nTravel,72000,Annual\nInternet & Phone,11760,Annual\n");downloadFile("FLC_File3_Fixed_Assets_Template.csv","assetName,assetValue\nLaptop pool,250000\nOffice furniture,120000\nPrinter,26000\n");notify("Three CSV templates downloaded.")}

function loadDemoData(silent=false){
 const firstNames=["Aarav","Aditya","Akash","Arjun","Ashwin","Bala","Bharath","Deepak","Dinesh","Gokul","Hari","Harish","Jeevan","Karthik","Kavin","Madhan","Manoj","Naveen","Pranav","Praveen","Rahul","Ramesh","Rithik","Sanjay","Saravanan","Sathish","Surya","Vignesh","Vikram","Yuvan","Ananya","Divya","Gayathri","Harini","Keerthana","Lakshmi","Meena","Monisha","Nandhini","Pavithra","Priya","Ramya","Sangeetha","Shalini","Swetha","Vaishnavi","Varsha","Yazhini"];
 const lastNames=["Kumar","Rajan","Murugan","Krishnan","Subramanian","Prakash","Mohan","Selvam","Narayanan","Shankar","Ravi","Mani"];
 const teams=["Accounting","Bookkeeping","Taxation","Payroll","Audit Support","Financial Reporting","Accounts Payable","Accounts Receivable"];
 const designations=["Associate","Senior Associate","Analyst","Process Executive","Team Lead","Senior Analyst"];
 const directRows=[];
 for(let i=0;i<60;i++){
  const dept=i<36?"Revenue Generating":i<54?"Administrative":"Reserve";
  const fn=firstNames[i%firstNames.length],ln=lastNames[(i*3+Math.floor(i/4))%lastNames.length];
  const base=dept==="Revenue Generating"?28500+(i%8)*2450:dept==="Administrative"?32000+(i%5)*3100:24500+(i%3)*1800;
  const monthly=round2(base+(i%4)*375.5);
  directRows.push({employeeId:`FLC-${String(i+1).padStart(4,"0")}`,employeeName:`${fn} ${ln}`,department:dept,team:dept==="Revenue Generating"?teams[i%teams.length]:dept==="Administrative"?["Finance Admin","HR & People","IT Support","Management","Facilities","Compliance"][i%6]:"Reserve Pool",designation:designations[i%designations.length],status:"Active",workingHours: i%6===0?152:i%5===0?168:160,directCostMonthly:monthly,directCostAnnual:round2(monthly*12),directCostSpecified:true,costBreakdown:[{component:"Monthly direct cost",value:monthly}]});
 }
 const indirectNames=["Office Rent","Electricity","Water Charges","Internet & Dedicated Line","Mobile & Telephone","Office Maintenance","Housekeeping","Security Services","Office Supplies","Printing & Stationery","Travel & Conveyance","Local Transportation","Professional Fees","Legal & Compliance","Bank Charges","Software Licences","Cloud Hosting","IT Support & AMC","Marketing & Advertisement","Employee Training","Employee Recognition & Rewards","Employee Events & Trips","Business Insurance","Recruitment Expenses","Courier & Postage","Repairs & Maintenance","Canteen & Pantry","Subscriptions & Memberships","Audit & Assurance","Staff Welfare","Postage & Delivery","Learning Platform","Data Security Services","Waste Management","Parking & Facility Charges"];
 const indirectRows=indirectNames.map((component,i)=>{const amount=round2(18000+(i*7913.37)%112000);const period=i%4===0?"Monthly":"Annual";return {component,amount,period,periodSpecified:true,amountSpecified:true,monthlyAmount:round2(period==="Annual"?amount/12:amount),sourceRow:i+2}});
 const assetNames=["Employee Laptops","Desktop Workstations","Monitors","Office Furniture","Conference Room Setup","Air Conditioners","Network Switches","Firewall Appliance","Wi-Fi Access Points","Printers & Scanners","Biometric Attendance System","CCTV Cameras","UPS Systems","Power Generator","Server Rack","NAS Storage","Video Conferencing Equipment","Projectors","Water Dispensers","Reception Furniture","Access Control System","Office Fit-out","Storage Cabinets","Meeting Room Display","Backup Power Units","Document Shredder","Network Cabling","Fire Safety Equipment","Visitor Management Kiosk","Ergonomic Chairs"];
 const assetRows=assetNames.map((assetName,i)=>({assetName,assetValue:round2(18500+((i*17831+5237)%265000)),assetValueSpecified:true,sourceRow:i+2}));
 state.imports={direct:{fileName:"DEMO_42_Employees_Direct_Cost.xlsx",rows:directRows,rawRows:[]},indirect:{fileName:"DEMO_28_Indirect_Costs.xlsx",rows:indirectRows,rawRows:[]},assets:{fileName:"DEMO_22_Fixed_Assets.xlsx",rows:assetRows,rawRows:[]}};
 freshUploads={direct:true,indirect:true,assets:true};
 const fy=$("#calcFY").value||"2026–27",month=$("#referenceMonth").value||"4";
 state.currentResult=calcData(state.imports,state.settings,fy,month);state.demoMode=true;persist();
 Object.entries(fileConfig).forEach(([k,c])=>{$(c.status).textContent="Demo loaded";$(c.status).classList.add("ready");$(c.meta).textContent=`${state.imports[k].fileName} · ${state.imports[k].rows.length} demo rows`});
 updateImportReadiness();$("#importPreview").hidden=false;renderImportTables();validateInputs();renderAll();
 if(!silent)notify("Large demo workbook loaded: 60 employees, 35 indirect cost items and 30 fixed assets.");
}
$("#loadDemoBtn").addEventListener("click",()=>loadDemoData(false));

function calcData(imports,settings,fy,month){
 const employees=imports.direct.rows.filter(x=>x.status!=="Inactive").map(x=>({...x,workingHours:num(x.workingHours),directCostMonthly:round2(num(x.directCostMonthly))}));
 const rg=employees.filter(x=>x.department==="Revenue Generating"),admin=employees.filter(x=>x.department==="Administrative"),reserve=employees.filter(x=>x.department==="Reserve");
 const rgHours=rg.reduce((s,x)=>s+x.workingHours,0),adminHours=admin.reduce((s,x)=>s+x.workingHours,0);
 const rawDeptRatio=adminHours?rgHours/adminHours:0,rgRatioPart=round2(rawDeptRatio),adminRatioPart=1,totalRatio=round2(rgRatioPart+adminRatioPart);
 const allocationRatio=round2(totalRatio?((rgRatioPart/totalRatio)*(adminRatioPart/(rg.length+reserve.length))):0);
 const indirectComponents=imports.indirect.rows.map(x=>({...x,monthlyAmount:round2(x.period==="Annual"?num(x.amount)/12:num(x.amount)),allocatedMonthlyPerEmployee:round2((x.period==="Annual"?num(x.amount)/12:num(x.amount))*allocationRatio)}));
 const variablePerEmployee=round2(indirectComponents.reduce((s,x)=>s+x.allocatedMonthlyPerEmployee,0));
 const depreciationRate=num(settings.depreciationRate);
 const assetComponents=imports.assets.rows.map(x=>{const annualDep=round2(num(x.assetValue)*depreciationRate/100);const monthlyDep=round2(annualDep/12);return {...x,annualDepreciation:annualDep,monthlyDepreciation:monthlyDep,allocatedMonthlyPerEmployee:round2(monthlyDep*allocationRatio)}});
 const fixedPerEmployee=round2(assetComponents.reduce((s,x)=>s+x.allocatedMonthlyPerEmployee,0));
 const directByDept=dept=>round2(employees.filter(x=>x.department===dept).reduce((s,x)=>s+x.directCostMonthly,0));
 const adminDirect=directByDept("Administrative"),adminVariable=round2(variablePerEmployee*admin.length),adminFixed=round2(fixedPerEmployee*admin.length);
 const adminPool=round2(adminDirect+adminVariable+adminFixed);
 const semiVariable=rg.length?round2(adminPool/rg.length):0;
 const employeeCosts=employees.map(e=>{
  const variable=variablePerEmployee,fixed=fixedPerEmployee,baseTotal=round2(e.directCostMonthly+variable+fixed);
  const semi=e.department==="Revenue Generating"?semiVariable:0;
  const totalMonthly=round2(baseTotal+semi);
  const directPerHour=e.workingHours?round2(e.directCostMonthly/e.workingHours):0;
  const indirectA=e.workingHours?round2((variable+fixed)/e.workingHours):0;
  const indirectB=e.workingHours?round2(semi/e.workingHours):0;
  const totalIndirect=round2(indirectA+indirectB),flcPerHour=round2(directPerHour+totalIndirect);
  const directMonthlyFromHour=round2(directPerHour*e.workingHours);
  const indirectAMonthlyFromHour=round2(indirectA*e.workingHours);
  const indirectBMonthlyFromHour=round2(indirectB*e.workingHours);
  const flcPerMonth=round2(directMonthlyFromHour+indirectAMonthlyFromHour+indirectBMonthlyFromHour);
  return {...e,variableMonthly:variable,fixedMonthly:fixed,semiVariableMonthly:semi,baseTotalMonthly:baseTotal,totalMonthly,directPerHour,indirectA,indirectB,totalIndirect,flcPerHour,directMonthlyFromHour,indirectAMonthlyFromHour,indirectBMonthlyFromHour,flcPerMonth,includedInFinalFLC:e.department==="Revenue Generating"};
 });
 const rgResults=employeeCosts.filter(x=>x.department==="Revenue Generating");
 const avgHourly=rgResults.length?round2(rgResults.reduce((s,x)=>s+x.flcPerHour,0)/rgResults.length):0;
 const avgMonthly=rgResults.length?round2(rgResults.reduce((s,x)=>s+x.flcPerMonth,0)/rgResults.length):0;
 const departments=DEPTS.map(dept=>{const list=employeeCosts.filter(x=>x.department===dept);return {department:dept,count:list.length,directMonthly:round2(list.reduce((s,x)=>s+x.directCostMonthly,0)),variableMonthly:round2(list.reduce((s,x)=>s+x.variableMonthly,0)),fixedMonthly:round2(list.reduce((s,x)=>s+x.fixedMonthly,0)),semiVariableMonthly:round2(list.reduce((s,x)=>s+x.semiVariableMonthly,0)),included:dept==="Revenue Generating"?"Final FLC":dept==="Administrative"?"Cost pool only":"Allocation only"}})
 return {fy,referenceMonth:MONTHS[Number(month)-1],referenceMonthNumber:Number(month),createdAt:new Date().toISOString(),depreciationRate,counts:{rg:rg.length,admin:admin.length,reserve:reserve.length,total:employees.length},hours:{rg:round2(rgHours),admin:round2(adminHours)},ratio:{rgPart:rgRatioPart,adminPart:adminRatioPart,totalParts:totalRatio,employeeDenominator:rg.length+reserve.length,final:allocationRatio},indirectComponents,assetComponents,employeeCosts,rgResults,departments,adminPool,semiVariable,variablePerEmployee,fixedPerEmployee,avgHourly,avgMonthly,totals:{rgDirect:directByDept("Revenue Generating"),adminDirect,reserveDirect:directByDept("Reserve"),adminVariable,adminFixed},sourceFiles:{direct:imports.direct.fileName,indirect:imports.indirect.fileName,assets:imports.assets.fileName}};
}
$("#calculateBtn").addEventListener("click",()=>{
 if(!state.imports.direct||!state.imports.indirect||!state.imports.assets){notify("Upload all three input files first.");go("imports");return}
 if(!validateInputs()){go("imports");return}
 const fy=$("#calcFY").value,month=$("#referenceMonth").value;
 const result=calcData(state.imports,state.settings,fy,month);
 const next=(state.versions.filter(v=>v.fy===fy).length)+1;
 const version={id:`${fy.replace("–","")}-V${next}-${Date.now()}`,version:`Version ${next}`,fy,referenceMonth:result.referenceMonth,referenceMonthNumber:Number(month),createdAt:result.createdAt,inputs:JSON.parse(JSON.stringify(state.imports)),result};
 state.versions.unshift(version);state.currentResult=result;state.selectedVersionId=version.id;
 // Lock the snapshot and clear the staging area. The next version must re-upload all three inputs.
 state.imports={direct:null,indirect:null,assets:null};freshUploads={direct:false,indirect:false,assets:false};
 persist();clearFileCards();$("#importPreview").hidden=true;$("#validationSummary").hidden=true;renderAll();notify(`${version.version} saved. All calculations regenerated. Upload all three files again for the next version.`);go("calculation");
});
function renderCalculation(){
 const r=state.currentResult;if(!r){$("#rgHours").textContent="—";$("#adminHours").textContent="—";$("#finalRatio").textContent="—";$("#ratioStatus").textContent="Awaiting input data";return}
 $("#rgHours").textContent=`${r.hours.rg.toLocaleString("en-IN")} hrs`;$("#adminHours").textContent=`${r.hours.admin.toLocaleString("en-IN")} hrs`;$("#rgCount").textContent=`${r.counts.rg} employees`;$("#adminCount").textContent=`${r.counts.admin} employees`;$("#rgPart").textContent=r.ratio.rgPart.toFixed(2);$("#adminPart").textContent=r.ratio.adminPart.toFixed(2);$("#finalRatio").textContent=r.ratio.final.toFixed(2);$("#ratioPercent").textContent=`${(r.ratio.final*100).toFixed(2)}% allocation factor`;$(`#ratioStatus`).textContent="Calculated";
 $("#adminPool").textContent=fmt(r.adminPool);$("#semiVariable").textContent=fmt(r.semiVariable);$("#variableAllocated").textContent=fmt(r.variablePerEmployee);$("#fixedAllocated").textContent=fmt(r.fixedPerEmployee);
 $("#ratioFormula").textContent=`(${r.ratio.rgPart.toFixed(2)} ÷ ${r.ratio.totalParts.toFixed(2)}) × (${r.ratio.adminPart.toFixed(2)} ÷ (${r.counts.rg} RG employees + ${r.counts.reserve} Reserve employees)) = ${r.ratio.final.toFixed(2)}. RG hours ${r.hours.rg} ÷ Admin hours ${r.hours.admin} = ${r.ratio.rgPart.toFixed(2)} : 1.`;
 $("#flcTable tbody").innerHTML=r.rgResults.map(e=>`<tr><td><strong>${esc(e.employeeName)}</strong><br><small>${esc(e.employeeId)}</small></td><td>${e.workingHours}</td><td>${fmt(e.directPerHour)}</td><td>${fmt(e.indirectA)}</td><td>${fmt(e.indirectB)}</td><td><strong>${fmt(e.flcPerHour)}</strong></td><td><strong>${fmt(e.flcPerMonth)}</strong></td></tr>`).join("")||`<tr><td colspan="7" class="empty-cell">No Revenue Generating employees.</td></tr>`;
 $("#departmentCostRows").innerHTML=r.departments.map(d=>`<tr><td><strong>${d.department}</strong></td><td>${d.count}</td><td>${fmt(d.directMonthly)}</td><td>${fmt(d.variableMonthly)}</td><td>${fmt(d.fixedMonthly)}</td><td>${fmt(d.semiVariableMonthly)}</td><td><span class="status-pill ${d.department==="Revenue Generating"?"":"pending"}">${d.included}</span></td></tr>`).join("");
 $("#flcSearch").dispatchEvent(new Event("input"));
}
$("#flcSearch").addEventListener("input",e=>{const q=e.target.value.toLowerCase();$$('#flcTable tbody tr').forEach(tr=>tr.hidden=!tr.textContent.toLowerCase().includes(q))});
function renderDashboard(){
 const v=state.versions[0],r=v?.result||state.currentResult;$("#topFY").textContent=`FY ${$("#calcFY").value||"2026–27"}`;
 if(!r){$("#metricVersion").textContent="Not calculated";$("#metricVersionSub").textContent="Upload three input files to begin";$("#metricRG").textContent="—";$("#metricHourly").textContent="—";$("#metricMonthly").textContent="—";$("#costPeriodTag").textContent="No version yet";$("#costComposition").innerHTML='<div class="empty-state compact">Calculate an FLC version to view cost composition.</div>';$("#departmentMix").innerHTML='<div class="empty-state compact">No employee data loaded.</div>';setViewTableEmpty("#dashboardVersionRows",6,"No versions created yet.");$("#healthList").innerHTML=["Three input files","Employee IDs","Working hours","Cost allocation"].map(x=>`<div class="health-row"><span class="health-bullet muted"></span><span>${x}</span><b>Pending</b></div>`).join("");return}
 $("#metricVersion").textContent=v?.version||"Calculated";$("#metricVersionSub").textContent=`FY ${r.fy} · ${r.referenceMonth}`;$("#metricRG").textContent=r.counts.rg;$("#metricHourly").textContent=fmt(r.avgHourly);$("#metricMonthly").textContent=fmt(r.avgMonthly);$("#costPeriodTag").textContent=`FY ${r.fy} · ${r.referenceMonth}`;
 const direct=r.totals.rgDirect,indirect=round2(r.variablePerEmployee*r.counts.rg),fixed=round2(r.fixedPerEmployee*r.counts.rg),semi=round2(r.semiVariable*r.counts.rg),sum=direct+indirect+fixed+semi;
 const comps=[["RG direct cost",direct,"#3978d8"],["Allocated variable cost",indirect,"#7b65ca"],["Allocated fixed depreciation",fixed,"#1a9870"],["Admin semi-variable cost",semi,"#d49a3d"]];
 $("#costComposition").innerHTML=comps.map(([name,val,color])=>`<div class="composition-row"><span>${name}</span><div class="bar-track"><div class="bar-fill" style="width:${sum?Math.max(1,val/sum*100):0}%;background:${color}"></div></div><strong>${fmt(val)}</strong></div>`).join("");
 const fileCount=["direct","indirect","assets"].filter(k=>r.sourceFiles?.[k]).length;
 $("#healthList").innerHTML=[["Three input files",fileCount===3?"Complete":"Incomplete"],["Employee IDs",r.counts.total?"Validated":"Pending"],["Working hours",r.hours.rg>0&&r.hours.admin>0?"Available":"Check"],["Cost allocation",r.ratio.final>0?"Calculated":"Check"]].map(([name,val])=>`<div class="health-row"><span class="health-bullet ${val==="Complete"||val==="Validated"||val==="Available"||val==="Calculated"?"":"muted"}"></span><span>${name}</span><b>${val}</b></div>`).join("");
 $("#departmentMix").innerHTML=r.departments.map(d=>`<div class="mix-row"><span>${d.department}</span><div class="mix-track"><i style="width:${r.counts.total?d.count/r.counts.total*100:0}%"></i></div><b>${d.count}</b></div>`).join("");
 $("#dashboardVersionRows").innerHTML=state.versions.slice(0,5).map(x=>`<tr><td><strong>${x.version}</strong></td><td>FY ${x.fy}</td><td>${x.referenceMonth}</td><td>${x.result.counts.rg}</td><td>${fmt(x.result.avgHourly)}</td><td>${new Date(x.createdAt).toLocaleDateString("en-IN")}</td><td><span class="status-pill">Saved</span></td></tr>`).join("")||`<tr><td colspan="6" class="empty-cell">No versions created yet.</td></tr>`;
}
function renderEmployees(){
 const rows=state.imports.direct?.rows||state.versions[0]?.inputs?.direct?.rows||[];$("#empTotal").textContent=rows.length;$("#empRG").textContent=rows.filter(x=>x.department==="Revenue Generating").length;$("#empAdmin").textContent=rows.filter(x=>x.department==="Administrative").length;$("#empReserve").textContent=rows.filter(x=>x.department==="Reserve").length;
 const q=($("#employeeSearch").value||"").toLowerCase();$("#employeeRows").innerHTML=rows.filter(x=>(x.employeeId+x.employeeName+x.department+x.team).toLowerCase().includes(q)).map((e,n)=>`<tr><td><strong>${esc(e.employeeId)}</strong></td><td>${esc(e.employeeName)}</td><td>${esc(e.department)}</td><td>${esc(e.team||"—")}</td><td>${e.workingHours}</td><td>${fmt(e.directCostMonthly)}</td><td><span class="status-pill ${e.status==="Inactive"?"pending":""}">${esc(e.status)}</span></td><td><button class="row-action" data-edit-employee="${n}">Edit</button></td></tr>`).join("")||`<tr><td colspan="8" class="empty-cell">No employees imported. Upload File 1 or add an employee.</td></tr>`;
 $$("[data-edit-employee]").forEach(b=>b.addEventListener("click",()=>openEmployeeModal(Number(b.dataset.editEmployee))));
}
$("#employeeSearch").addEventListener("input",renderEmployees);
function openEmployeeModal(index=null){editEmployeeId=index;const form=$("#employeeForm");form.reset();const row=index===null?null:state.imports.direct?.rows[index];$("#employeeModalTitle").textContent=row?"Edit employee":"Add employee";if(row)Object.entries(row).forEach(([k,v])=>{if(form.elements[k])form.elements[k].value=v});$("#employeeModal").hidden=false}
$("#addEmployeeBtn").addEventListener("click",()=>openEmployeeModal());
$("#employeeForm").addEventListener("submit",e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target).entries());data.workingHours=num(data.workingHours);data.directCostMonthly=num(data.directCostMonthly);data.directCostAnnual=round2(data.directCostMonthly*12);data.directCostSpecified=true;data.status=data.status||"Active";if(!state.imports.direct)state.imports.direct={fileName:"Manual employee register",rows:[],rawRows:[]};if(editEmployeeId===null){if(state.imports.direct.rows.some(x=>x.employeeId===data.employeeId)){notify("Employee ID already exists.");return}state.imports.direct.rows.push(data)}else state.imports.direct.rows[editEmployeeId]=data;persist();$("#employeeModal").hidden=true;renderAll();notify("Employee record saved. Recalculate to create a new version.")});

function renderAssets(){const rows=state.imports.assets?.rows||state.versions[0]?.inputs?.assets?.rows||[],rate=num(state.settings.depreciationRate),sum=rows.reduce((s,x)=>s+num(x.assetValue),0),dep=round2(sum*rate/100);$("#assetTotal").textContent=rows.length;$("#assetValueTotal").textContent=fmt(sum);$("#assetDepTotal").textContent=fmt(dep);$("#assetDepMonthly").textContent=fmt(dep/12);const q=($("#assetSearch").value||"").toLowerCase();$("#assetRows").innerHTML=rows.filter(x=>x.assetName.toLowerCase().includes(q)).map((x,n)=>`<tr><td><strong>${esc(x.assetName)}</strong></td><td>${fmt(x.assetValue)}</td><td>${rate.toFixed(2)}%</td><td>${fmt(x.assetValue*rate/100)}</td><td>${fmt(x.assetValue*rate/1200)}</td><td><button class="row-action" data-edit-asset="${n}">Edit</button></td></tr>`).join("")||`<tr><td colspan="6" class="empty-cell">No fixed assets imported.</td></tr>`;$$("[data-edit-asset]").forEach(b=>b.addEventListener("click",()=>openAssetModal(Number(b.dataset.editAsset))))}
$("#assetSearch").addEventListener("input",renderAssets);
function openAssetModal(index=null){editAssetIndex=index;const f=$("#assetForm");f.reset();if(index!==null){f.elements.assetName.value=state.imports.assets.rows[index].assetName;f.elements.assetValue.value=state.imports.assets.rows[index].assetValue}$("#assetModalTitle").textContent=index===null?"Add asset":"Edit asset";$("#assetModal").hidden=false}
$("#addAssetBtn").addEventListener("click",()=>openAssetModal());
$("#assetForm").addEventListener("submit",e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target).entries());d.assetValue=num(d.assetValue);d.assetValueSpecified=true;if(!state.imports.assets)state.imports.assets={fileName:"Manual asset register",rows:[],rawRows:[]};if(editAssetIndex===null)state.imports.assets.rows.push(d);else state.imports.assets.rows[editAssetIndex]=d;persist();$("#assetModal").hidden=true;renderAll();notify("Asset saved. Recalculate to include it in a new version.")});
$$("[data-close-modal]").forEach(b=>b.addEventListener("click",()=>{$("#employeeModal").hidden=true;$("#assetModal").hidden=true}));
$$(".modal-backdrop").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.hidden=true}));

function renderVersions(){
 const fy=$("#versionFYFilter").value;const versions=state.versions.filter(v=>!fy||v.fy===fy);
 $("#versionRows").innerHTML=versions.map(v=>`<tr><td><input aria-label="Select ${v.version} for comparison" type="checkbox" data-compare-version="${v.id}" ${selectedCompareIds.has(v.id)?"checked":""}></td><td><strong>${v.version}</strong></td><td>FY ${v.fy}</td><td>${v.referenceMonth}</td><td>${v.result.counts.total} (${v.result.counts.rg} RG)</td><td>${fmt(v.result.avgHourly)}</td><td>${new Date(v.createdAt).toLocaleString("en-IN")}</td><td><button class="row-action" data-open-version="${v.id}">View</button><button class="row-action" data-export-version="${v.id}">JSON</button></td></tr>`).join("")||`<tr><td colspan="8" class="empty-cell">No versions match this filter.</td></tr>`;
 $$("[data-open-version]").forEach(b=>b.addEventListener("click",()=>showVersion(b.dataset.openVersion)));
 $$("[data-export-version]").forEach(b=>b.addEventListener("click",()=>exportVersion(b.dataset.exportVersion)));
 $$("[data-compare-version]").forEach(b=>b.addEventListener("change",e=>{
  if(e.target.checked){if(selectedCompareIds.size>=2){e.target.checked=false;notify("Select only two versions to compare.");return}selectedCompareIds.add(e.target.dataset.compareVersion)}
  else selectedCompareIds.delete(e.target.dataset.compareVersion);
  $("#compareVersionsBtn").disabled=selectedCompareIds.size!==2;
 }));
 $("#compareVersionsBtn").disabled=selectedCompareIds.size!==2;
}
function compareSelectedVersions(){
 const ids=[...selectedCompareIds];if(ids.length!==2){notify("Select exactly two versions.");return}
 const [a,b]=ids.map(id=>state.versions.find(v=>v.id===id));if(!a||!b)return;
 const ra=a.result,rb=b.result;
 const delta=(x,y)=>round2(y-x);
 const metric=(label,x,y)=>`<tr><td>${label}</td><td>${x}</td><td>${y}</td><td class="${delta(Number(x)||0,Number(y)||0)>=0?"":"danger-text"}">${delta(Number(x)||0,Number(y)||0)>=0?"+":""}${delta(Number(x)||0,Number(y)||0).toFixed(2)}</td></tr>`;
 const empA=new Map(ra.rgResults.map(e=>[e.employeeId,e])),empB=new Map(rb.rgResults.map(e=>[e.employeeId,e]));
 const idsAll=[...new Set([...empA.keys(),...empB.keys()])];
 const employeeRows=idsAll.map(id=>{const x=empA.get(id),y=empB.get(id),name=y?.employeeName||x?.employeeName||id;return `<tr><td><strong>${esc(name)}</strong><br><small>${esc(id)}</small></td><td>${x?fmt(x.flcPerHour):"—"}</td><td>${y?fmt(y.flcPerHour):"—"}</td><td>${x&&y?fmt(round2(y.flcPerHour-x.flcPerHour)):x?"Removed":"New"}</td><td>${x?fmt(x.flcPerMonth):"—"}</td><td>${y?fmt(y.flcPerMonth):"—"}</td></tr>`}).join("");
 $("#versionCompareMeta").textContent=`${a.version} (${a.fy}, ${a.referenceMonth}) compared with ${b.version} (${b.fy}, ${b.referenceMonth}).`;
 $("#versionCompareContent").innerHTML=`<div class="detail-kpis"><div class="detail-kpi"><small>Average hourly FLC · ${a.version}</small><strong>${fmt(ra.avgHourly)}</strong></div><div class="detail-kpi"><small>Average hourly FLC · ${b.version}</small><strong>${fmt(rb.avgHourly)}</strong></div><div class="detail-kpi"><small>Allocation ratio change</small><strong>${ra.ratio.final.toFixed(2)} → ${rb.ratio.final.toFixed(2)}</strong></div><div class="detail-kpi"><small>RG headcount change</small><strong>${ra.counts.rg} → ${rb.counts.rg}</strong></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Metric</th><th>${a.version}</th><th>${b.version}</th><th>Change</th></tr></thead><tbody>${metric("Average FLC per hour",ra.avgHourly,rb.avgHourly)}${metric("Average FLC per month",ra.avgMonthly,rb.avgMonthly)}${metric("RG working hours",ra.hours.rg,rb.hours.rg)}${metric("Administrative working hours",ra.hours.admin,rb.hours.admin)}${metric("Semi-variable cost per RG employee",ra.semiVariable,rb.semiVariable)}</tbody></table></div><h3 style="font:800 12px Manrope;margin:18px 0 9px">Revenue Generating employee comparison</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Employee</th><th>${a.version} · FLC/hr</th><th>${b.version} · FLC/hr</th><th>Hourly change</th><th>${a.version} · FLC/month</th><th>${b.version} · FLC/month</th></tr></thead><tbody>${employeeRows}</tbody></table></div>`;
 $("#versionComparePanel").hidden=false;$("#versionComparePanel").scrollIntoView({behavior:"smooth"});
}
$("#compareVersionsBtn").addEventListener("click",compareSelectedVersions);
$("#closeVersionCompare").addEventListener("click",()=>$("#versionComparePanel").hidden=true);
$("#versionFYFilter").addEventListener("change",renderVersions);
function showVersion(id){const v=state.versions.find(x=>x.id===id);if(!v)return;$("#versionDetailPanel").hidden=false;$("#versionDetailTitle").textContent=`${v.version} · FY ${v.fy}`;$("#versionDetailMeta").textContent=`Reference month: ${v.referenceMonth} · Created ${new Date(v.createdAt).toLocaleString("en-IN")}`;const r=v.result;$("#versionDetailContent").innerHTML=`<div class="detail-kpis"><div class="detail-kpi"><small>Allocation ratio</small><strong>${r.ratio.final.toFixed(2)}</strong></div><div class="detail-kpi"><small>RG employees</small><strong>${r.counts.rg}</strong></div><div class="detail-kpi"><small>Average FLC / hour</small><strong>${fmt(r.avgHourly)}</strong></div><div class="detail-kpi"><small>Average FLC / month</small><strong>${fmt(r.avgMonthly)}</strong></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Employee</th><th>Department</th><th>Hours</th><th>Direct / month</th><th>Variable / month</th><th>Fixed / month</th><th>Semi-variable</th><th>FLC / hour</th><th>FLC / month</th></tr></thead><tbody>${r.employeeCosts.map(e=>`<tr><td>${esc(e.employeeName)}<br><small>${esc(e.employeeId)}</small></td><td>${e.department}</td><td>${e.workingHours}</td><td>${fmt(e.directCostMonthly)}</td><td>${fmt(e.variableMonthly)}</td><td>${fmt(e.fixedMonthly)}</td><td>${fmt(e.semiVariableMonthly)}</td><td>${e.department==="Revenue Generating"?fmt(e.flcPerHour):"—"}</td><td>${e.department==="Revenue Generating"?fmt(e.flcPerMonth):"—"}</td></tr>`).join("")}</tbody></table></div><p class="muted-label">Source files: ${esc(r.sourceFiles.direct)} · ${esc(r.sourceFiles.indirect)} · ${esc(r.sourceFiles.assets)}</p>`;$("#versionDetailPanel").scrollIntoView({behavior:"smooth"})}
$("#closeVersionDetail").addEventListener("click",()=>$("#versionDetailPanel").hidden=true);
function exportVersion(id){const v=state.versions.find(x=>x.id===id);if(v)downloadFile(`FLC_${v.fy}_${v.version.replace(" ","_")}.json`,JSON.stringify(v,null,2),"application/json");}
function exportCurrentJSON(){const v=state.versions.find(x=>x.id===state.selectedVersionId)||state.versions[0];if(!v){notify("No saved version to export.");return}exportVersion(v.id)}
function exportCSV(rows,filename){if(!rows?.length){notify("No rows to export.");return}const keys=Object.keys(rows[0]);const csv=[keys.join(","),...rows.map(r=>keys.map(k=>{const v=String(r[k]??"");return /[",\n]/.test(v)?`"${v.replace(/"/g,'""')}"`:v}).join(","))].join("\n");downloadFile(filename,"\ufeff"+csv)}
function exportFLC(){const r=state.currentResult;if(!r){notify("Calculate FLC first.");return}exportCSV(r.rgResults.map(e=>({employeeId:e.employeeId,employeeName:e.employeeName,department:e.department,workingHours:e.workingHours,directCostMonthly:e.directCostMonthly,variableCostMonthly:e.variableMonthly,fixedDepreciationMonthly:e.fixedMonthly,semiVariableMonthly:e.semiVariableMonthly,directPerHour:e.directPerHour,indirectAperHour:e.indirectA,adminBperHour:e.indirectB,fullyLoadedCostPerHour:e.flcPerHour,fullyLoadedCostPerMonth:e.flcPerMonth})),`FLC_${r.fy}_${r.referenceMonth}_Employee_Report.csv`)}
function exportDept(){const r=state.currentResult;if(!r){notify("Calculate FLC first.");return}exportCSV(r.departments,`FLC_${r.fy}_Department_Allocation.csv`)}
function renderReports(){const r=state.currentResult;if(!r){$("#reportSubtitle").textContent="No calculation has been saved yet.";setViewTableEmpty("#reportRows",6,"No report data available.");return}$("#reportSubtitle").textContent=`FY ${r.fy} · ${r.referenceMonth} reference month · Allocation ratio ${r.ratio.final.toFixed(2)}`;$("#reportRows").innerHTML=r.rgResults.map(e=>`<tr><td>${esc(e.employeeName)}<br><small>${esc(e.employeeId)}</small></td><td>${fmt(e.directPerHour)}</td><td>${fmt(e.indirectA)}</td><td>${fmt(e.indirectB)}</td><td><strong>${fmt(e.flcPerHour)}</strong></td><td><strong>${fmt(e.flcPerMonth)}</strong></td></tr>`).join("")||`<tr><td colspan="6" class="empty-cell">No report data.</td></tr>`}
$("#exportFLCBtn").addEventListener("click",exportFLC);$("#exportReportBtn").addEventListener("click",exportFLC);$("#reportEmployeeExport").addEventListener("click",exportFLC);$("#reportDeptExport").addEventListener("click",exportDept);$("#exportJSONBtn").addEventListener("click",exportCurrentJSON);$("#reportSnapshotExport").addEventListener("click",exportCurrentJSON);
$("#saveSettingsBtn").addEventListener("click",()=>{const rate=num($("#settingDepRate").value);if(rate<0||rate>100){notify("Depreciation percentage must be between 0 and 100.");return}state.settings.depreciationRate=rate;persist();renderAll();notify("Settings saved. Existing versions remain unchanged; new versions use this rate.")});

const workbookSheets={
 direct:{title:"Direct cost · Employee register",description:"Employee-level source data, reference-month hours and direct monthly cost.",columns:[["Employee ID","employeeId"],["Employee name","employeeName"],["Department","department"],["Team","team"],["Designation","designation"],["Hours","workingHours"],["Direct / month","directCostMonthly"],["Direct / year","directCostAnnual"]],money:["directCostMonthly","directCostAnnual"]},
 indirect:{title:"Indirect cost · Common cost pool",description:"Company-wide variable cost inputs normalized to monthly values and allocated per employee.",columns:[["Component","component"],["Period","period"],["Source amount","amount"],["Monthly value","monthlyAmount"],["Allocated / employee","allocatedMonthlyPerEmployee"]],money:["amount","monthlyAmount","allocatedMonthlyPerEmployee"]},
 assets:{title:"Fixed assets · Depreciation schedule",description:"Asset values, annual depreciation at the configured rate and monthly allocated depreciation.",columns:[["Asset name","assetName"],["Asset value","assetValue"],["Depreciation %","rate"],["Annual depreciation","annualDepreciation"],["Monthly depreciation","monthlyDepreciation"],["Allocated / employee","allocatedMonthlyPerEmployee"]],money:["assetValue","annualDepreciation","monthlyDepreciation","allocatedMonthlyPerEmployee"]},
 allocation:{title:"Allocation working · Employee cost build-up",description:"Shows the per-employee variable and fixed allocations, plus the Administrative semi-variable amount for RG employees.",columns:[["Employee ID","employeeId"],["Employee name","employeeName"],["Department","department"],["Direct / month","directCostMonthly"],["Variable allocation","variableMonthly"],["Fixed allocation","fixedMonthly"],["Admin B allocation","semiVariableMonthly"],["Total cost / month","totalMonthly"],["FLC treatment","treatment"]],money:["directCostMonthly","variableMonthly","fixedMonthly","semiVariableMonthly","totalMonthly"]},
 hourly:{title:"FLC per hour · Revenue Generating employees",description:"Hourly FLC components for every RG employee. Reserve and Administrative employees are not included in final FLC output.",columns:[["Employee ID","employeeId"],["Employee name","employeeName"],["Hours","workingHours"],["Direct / hr","directPerHour"],["Indirect A / hr","indirectA"],["Admin B / hr","indirectB"],["Total FLC / hr","flcPerHour"]],money:["directPerHour","indirectA","indirectB","flcPerHour"],total:"flcPerHour"},
 monthly:{title:"FLC per month · Revenue Generating employees",description:"Monthly FLC is calculated from the rounded hourly components multiplied by each employee's reference-month working hours.",columns:[["Employee ID","employeeId"],["Employee name","employeeName"],["Hours","workingHours"],["Direct cost","directMonthlyFromHour"],["Indirect A","indirectAMonthlyFromHour"],["Admin B","indirectBMonthlyFromHour"],["Total FLC / month","flcPerMonth"]],money:["directMonthlyFromHour","indirectAMonthlyFromHour","indirectBMonthlyFromHour","flcPerMonth"],total:"flcPerMonth"}
};
function getWorkbookContext(){
 const hasDraft=["direct","indirect","assets"].every(k=>state.imports[k]?.rows);
 const hasAnyDraft=!!(state.imports.direct||state.imports.indirect||state.imports.assets);
 if(hasDraft){const fy=$("#calcFY").value||"2026–27",month=$("#referenceMonth").value||"4";return {inputs:state.imports,result:calcData(state.imports,state.settings,fy,month),draft:true,source:"Current uploaded files"}}
 if(hasAnyDraft)return {inputs:state.imports,result:null,draft:true,source:"Partial upload · calculation pending"};
 const version=state.versions.find(v=>v.id===state.selectedVersionId)||state.versions[0];
 if(version)return {inputs:version.inputs,result:version.result,draft:false,source:`${version.version} · ${version.inputs.direct.fileName}`};
 return null;
}
function renderWorkbook(){
 const ctx=getWorkbookContext();if(!ctx){$("#workbookSourceBanner").innerHTML='<span class="banner-icon">!</span><div><strong>No workbook data available</strong><p>Load the large demo dataset or upload the three input files to populate this page.</p></div>';$("#workbookHead").innerHTML="";$("#workbookBody").innerHTML='<tr><td class="workbook-empty">No input data has been loaded.</td></tr>';$("#workbookRowCount").textContent="0 rows";return}
 const {inputs,result,draft,source}=ctx;const direct=inputs.direct?.rows||[],indirect=inputs.indirect?.rows||[],assets=inputs.assets?.rows||[];
 const totalMonthlyIndirect=result?result.indirectComponents.reduce((s,x)=>s+x.monthlyAmount,0):indirect.reduce((s,x)=>s+num(x.monthlyAmount||x.amount),0);
 const totalMonthlyFixed=result?result.assetComponents.reduce((s,x)=>s+x.monthlyDepreciation,0):assets.reduce((s,x)=>s+num(x.assetValue)*num(state.settings.depreciationRate)/1200,0);
 $("#wbEmployeeCount").textContent=direct.length;$("#wbEmployeeSplit").textContent=`${direct.filter(x=>x.department==="Revenue Generating").length} RG · ${direct.filter(x=>x.department==="Administrative").length} Admin · ${direct.filter(x=>x.department==="Reserve").length} Reserve`;
 $("#wbIndirectTotal").textContent=fmt(totalMonthlyIndirect);$("#wbFixedTotal").textContent=fmt(totalMonthlyFixed);$("#wbRatio").textContent=result?result.ratio.final.toFixed(2):"—";$("#wbRatioCaption").textContent=result?`${result.ratio.rgPart.toFixed(2)} : ${result.ratio.adminPart.toFixed(2)} · RG/Admin hours`:"Awaiting complete inputs";
 $("#workbookSourceBanner").innerHTML=`<span class="banner-icon">${draft?"i":"✓"}</span><div><strong>${draft?"Live input preview":"Saved immutable version"}</strong><p>${esc(source)} · ${direct.length} employees · ${indirect.length} indirect items · ${assets.length} fixed assets. ${draft?"Review the data and calculation preview; create a version from Annual FLC when ready.":"This view is displaying the input snapshot saved with the selected version."}</p></div>`;
 $("#wbDirectCount").textContent=direct.length;$("#wbIndirectCount").textContent=indirect.length;$("#wbAssetsCount").textContent=assets.length;
 const r=result;const rowsByTab={direct,indirect:r?.indirectComponents||indirect,assets:r?.assetComponents||assets,allocation:r?.employeeCosts.map(e=>({...e,treatment:e.includedInFinalFLC?"Included in final FLC":e.department==="Administrative"?"Admin pool only":"Allocation only"}))||[],hourly:r?.rgResults||[],monthly:r?.rgResults||[]};
 const meta=[`Source: ${source}`,`Financial year: ${r?.fy||"Not selected"}`,`Reference month: ${r?.referenceMonth||"Not calculated"}`];$("#workbookMeta").innerHTML=meta.map(x=>`<span>${esc(x)}</span>`).join("");
 const sheet=workbookSheets[workbookTab]||workbookSheets.direct;const rows=rowsByTab[workbookTab]||[];$("#workbookSheetTitle").textContent=sheet.title;$("#workbookSheetDescription").textContent=sheet.description;$("#workbookRowCount").textContent=`${rows.length} rows`;
 const cols=sheet.columns;$("#workbookHead").innerHTML=`<tr>${cols.map(([label])=>`<th>${esc(label)}</th>`).join("")}</tr>`;
 const q=($("#workbookSearch").value||"").toLowerCase();const visible=rows.filter(row=>cols.some(([,key])=>String(row[key]??(key==="rate"?state.settings.depreciationRate:key==="treatment"?row.includedInFinalFLC?"Included":"Allocation": "")).toLowerCase().includes(q)));
 const cellValue=(row,key)=>{if(key==="rate")return `${num(state.settings.depreciationRate).toFixed(2)}%`;if(key==="treatment")return row.includedInFinalFLC?"Included in final FLC":row.department==="Administrative"?"Admin pool only":"Allocation only";const value=row[key];if(value===undefined||value===null||value==="")return "—";return sheet.money?.includes(key)?fmt(value):typeof value==="number"?value.toLocaleString("en-IN",{maximumFractionDigits:2}):String(value)};
 $("#workbookBody").innerHTML=visible.map(row=>`<tr>${cols.map(([,key])=>`<td class="${sheet.money?.includes(key)?"number-cell":""} ${key===sheet.total?"total-cell":""}">${esc(cellValue(row,key))}</td>`).join("")}</tr>`).join("")||`<tr><td colspan="${cols.length}" class="workbook-empty">No matching rows.</td></tr>`;
 $("#workbookFooterTotal").textContent=sheet.total&&rows.length?`Total: ${fmt(rows.reduce((s,x)=>s+num(x[sheet.total]),0))}`:`Showing ${visible.length} of ${rows.length} rows`;
 $("#workbookFooterNote").textContent=workbookTab==="direct"?"Direct cost values are monthly unless the source file explicitly provides annual values.":workbookTab==="indirect"?"Annual indirect amounts are divided by 12. Monthly amounts remain unchanged.":workbookTab==="assets"?`Depreciation is ${num(state.settings.depreciationRate).toFixed(2)}% per annum; carry-forward basis remains subject to finance confirmation.`:"All displayed calculations use the configured two-decimal rounding policy.";
 $("#wbCalcStatus").textContent=r?draft?"Live calculation preview":"Saved version calculation":"Calculation pending";
 if(r){$("#workbookFormulaGrid").innerHTML=`<div class="formula-step"><small>01 · Department ratio</small><strong>${r.ratio.rgPart.toFixed(2)} : ${r.ratio.adminPart.toFixed(2)}</strong><span>${r.hours.rg.toLocaleString("en-IN")} RG hours ÷ ${r.hours.admin.toLocaleString("en-IN")} Admin hours.</span></div><div class="formula-step"><small>02 · Allocation factor</small><strong>${r.ratio.final.toFixed(2)} (${(r.ratio.final*100).toFixed(2)}%)</strong><span>(${r.ratio.rgPart.toFixed(2)} ÷ ${r.ratio.totalParts.toFixed(2)}) × (${r.ratio.adminPart.toFixed(2)} ÷ (${r.counts.rg} RG + ${r.counts.reserve} Reserve)).</span></div><div class="formula-step"><small>03 · Admin cost pool</small><strong>${fmt(r.adminPool)}</strong><span>Semi-variable cost per RG employee: ${fmt(r.semiVariable)}.</span></div><div class="formula-step"><small>04 · Average RG FLC</small><strong>${fmt(r.avgHourly)} / hour</strong><span>Average monthly FLC: ${fmt(r.avgMonthly)} across ${r.counts.rg} RG employees.</span></div>`}
 $$("[data-workbook-tab]").forEach(b=>b.classList.toggle("active",b.dataset.workbookTab===workbookTab));
}
$$("[data-workbook-tab]").forEach(b=>b.addEventListener("click",()=>{workbookTab=b.dataset.workbookTab;renderWorkbook()}));
$("#workbookSearch").addEventListener("input",renderWorkbook);
$("#workbookExportBtn").addEventListener("click",exportFLC);

function renderAll(){updateImportReadiness();renderDashboard();renderCalculation();renderWorkbook();renderEmployees();renderAssets();renderVersions();renderReports();$("#settingDepRate").value=state.settings.depreciationRate}
function init(){
 const isFirstRun=!localStorage.getItem(STORE_KEY);
 $("#calcFY").addEventListener("change",updateImportReadiness);
 if(state.imports.direct||state.imports.indirect||state.imports.assets){Object.entries(fileConfig).forEach(([k,c])=>{if(state.imports[k]){$(c.status).textContent=freshUploads[k]?"Loaded draft":"Previously imported · re-upload required";$(c.status).classList.toggle("ready",!!freshUploads[k]);$(c.meta).textContent=`${state.imports[k].fileName} · ${state.imports[k].rows.length} rows`}});if(["direct","indirect","assets"].every(k=>state.imports[k])){$("#importPreview").hidden=false;renderImportTables()}}
 if(isFirstRun)loadDemoData(true);
 renderAll();
}
init();
})();