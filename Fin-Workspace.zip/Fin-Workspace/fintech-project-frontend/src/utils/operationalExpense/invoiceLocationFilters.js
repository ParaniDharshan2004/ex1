const CLIENT_LOCATIONS = {
  CRKL: ['USA'],
  MKPL: ['Chennai', 'Bengaluru'],
};

const getClientCode = (client) => {
  const normalizedClient = String(client || '').toUpperCase();
  return Object.keys(CLIENT_LOCATIONS).find((code) =>
    normalizedClient.includes(code),
  );
};

const matchesKnownLocation = (location, canonicalLocation) => {
  const normalizedLocation = String(location || '').toLowerCase();

  if (canonicalLocation === 'USA') {
    return /\busa\b|\bu\.s\.a\b|\bunited states\b/.test(normalizedLocation);
  }
  if (canonicalLocation === 'Chennai') {
    return /\bchennai\b|\bmadras\b/.test(normalizedLocation);
  }
  if (canonicalLocation === 'Bengaluru') {
    return /\bbengaluru\b|\bbangalore\b/.test(normalizedLocation);
  }

  return false;
};

export const getInvoiceLocationFilterValue = (client, location) => {
  const normalizedLocation = String(location || '').trim();
  if (!normalizedLocation) return null;

  const clientCode = getClientCode(client);
  if (!clientCode) return normalizedLocation;

  return (
    CLIENT_LOCATIONS[clientCode].find((canonicalLocation) =>
      matchesKnownLocation(normalizedLocation, canonicalLocation),
    ) || null
  );
};

export const getInvoiceLocationOptions = (
  invoices,
  clients,
  selectedClient = 'all',
) => {
  const clientsToInclude =
    selectedClient === 'all' ? clients : [selectedClient];
  const options = new Set();

  clientsToInclude.forEach((client) => {
    const clientCode = getClientCode(client);
    if (clientCode) {
      CLIENT_LOCATIONS[clientCode].forEach((location) => options.add(location));
      return;
    }

    invoices
      .filter((invoice) => invoice.client === client)
      .forEach((invoice) => {
        const location = getInvoiceLocationFilterValue(
          invoice.client,
          invoice.location,
        );
        if (location) options.add(location);
      });
  });

  return [...options];
};

export const getInvoiceClientOptions = (
  invoices,
  clients,
  selectedLocation = 'all',
) => {
  if (selectedLocation === 'all') return clients;

  const clientsWithLocation = new Set(
    invoices
      .filter(
        (invoice) =>
          getInvoiceLocationFilterValue(invoice.client, invoice.location) ===
          selectedLocation,
      )
      .map((invoice) => invoice.client),
  );

  return clients.filter((client) => clientsWithLocation.has(client));
};
