const categoryFromDescription = (description = '') =>
  String(description).match(/Category:\s*([^|]+)/i)?.[1]?.trim() || '';

const normalizeName = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .split(/\s+/)
    .filter((word) => word && word !== 'and')
    .map((word) =>
      word.endsWith('s') && !word.endsWith('ss') ? word.slice(0, -1) : word,
    )
    .join(' ')
    .trim();

const numericOrder = (value) =>
  value === undefined || value === null || value === ''
    ? null
    : Number.isFinite(Number(value))
      ? Number(value)
      : null;

export const normalizeFixedAssetItem = (item = {}, index = 0) => ({
  ...item,
  id: item._id || item.id || `fixed-${index}`,
  parentCategory:
    item.parentCategory ||
    item.fixedAssetCategory ||
    item.categoryName ||
    item.category?.categoryName ||
    categoryFromDescription(item.description),
  subcomponent: item.itemName || item.assetName || item.description || 'Fixed asset',
  amount: Number(item.amount) || 0,
  componentDisplayOrder: numericOrder(item.componentDisplayOrder),
  subcomponentDisplayOrder: numericOrder(item.subcomponentDisplayOrder),
});

export const mapFixedAssetsToComponents = (
  items = [],
  components = [],
  subComponents = [],
) =>
  items.map((item, index) => {
    const normalized = normalizeFixedAssetItem(item, index);
    const parentName =
      normalized.parentCategory ||
      normalized.fixedAssetCategory ||
      normalized.categoryName ||
      item.category?.categoryName;
    const matchingSubcomponent = subComponents.find(
      (subComponent) =>
        normalizeName(subComponent.subComponentName) ===
        normalizeName(normalized.subcomponent),
    );
    const componentId =
      matchingSubcomponent?.componentId?._id ||
      matchingSubcomponent?.componentId;
    const normalizedParentName = normalizeName(parentName);
    const parentComponent = components.find(
      (component) =>
        (componentId &&
          String(component._id || component.id) === String(componentId)) ||
        (normalizedParentName &&
          normalizeName(component.componentName) === normalizedParentName),
    );

    if (!parentComponent?.componentName) return item;
    const componentDisplayOrder = numericOrder(parentComponent.displayOrder);
    const subcomponentDisplayOrder = numericOrder(
      matchingSubcomponent?.displayOrder,
    );

    const details = String(item.description || '')
      .split('|')
      .map((part) => part.trim())
      .filter(
        (part) =>
          part &&
          !/^Category:/i.test(part) &&
          !/^Tally ledger:/i.test(part),
      );
    const tallyLedger = String(item.description || '')
      .match(/Tally ledger:\s*([^|]+)/i)?.[1]
      ?.trim();

    return {
      ...item,
      parentCategory: parentComponent.componentName,
      fixedAssetCategory: parentComponent.componentName,
      componentDisplayOrder: Number.isFinite(componentDisplayOrder)
        ? componentDisplayOrder
        : null,
      subcomponentDisplayOrder: Number.isFinite(subcomponentDisplayOrder)
        ? subcomponentDisplayOrder
        : null,
      description: [
        `Category: ${parentComponent.componentName}`,
        tallyLedger ? `Tally ledger: ${tallyLedger}` : '',
        ...details,
      ]
        .filter(Boolean)
        .join(' | '),
    };
  });

export const groupFixedAssetsByParent = (items = []) => {
  const groups = new Map();
  items.forEach((item, index) => {
    const normalized = normalizeFixedAssetItem(item, index);
    const key = normalized.parentCategory || 'Fixed Cost';
    if (!groups.has(key)) {
      groups.set(key, {
        parentCategory: key,
        displayOrder: normalized.componentDisplayOrder,
        children: [],
      });
    }
    const group = groups.get(key);
    if (
      Number.isFinite(normalized.componentDisplayOrder) &&
      (!Number.isFinite(group.displayOrder) ||
        normalized.componentDisplayOrder < group.displayOrder)
    ) {
      group.displayOrder = normalized.componentDisplayOrder;
    }
    group.children.push(normalized);
  });
  const compareOrder = (first, second) => {
    const firstHasOrder = Number.isFinite(first);
    const secondHasOrder = Number.isFinite(second);
    if (firstHasOrder !== secondHasOrder) return firstHasOrder ? -1 : 1;
    return firstHasOrder ? first - second : 0;
  };
  return Array.from(groups.values())
    .map((group) => ({
      ...group,
      children: group.children.sort((first, second) =>
        compareOrder(
          first.subcomponentDisplayOrder,
          second.subcomponentDisplayOrder,
        ),
      ),
      total: group.children.reduce((sum, child) => sum + child.amount, 0),
    }))
    .sort((first, second) =>
      compareOrder(first.displayOrder, second.displayOrder),
    );
};

export const isResolvedFixedAssetUnmatchedRow = (row, fixedCosts = []) => {
  const normalize = (value) =>
    normalizeName(value);
  const ledger = normalize(row?.tallyLedgerName || row?.particularName);
  if (!ledger) return false;
  const groups = groupFixedAssetsByParent(fixedCosts);
  return (
    groups.some((group) => normalize(group.parentCategory) === ledger) ||
    fixedCosts.some((item) => {
      const normalized = normalizeFixedAssetItem(item);
      const fixedAssetNames = [
        normalized.parentCategory,
        normalized.fixedAssetCategory,
        normalized.componentName,
        normalized.subcomponent,
        normalized.itemName,
        normalized.assetName,
        normalized.description,
      ]
        .map(normalize)
        .filter(Boolean);

      return fixedAssetNames.some(
        (name) => name === ledger || name.includes(ledger),
      );
    })
  );
};
