import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
 
import './index.css';
 
import App from './app/App.jsx';
import { DataProvider } from './app/providers/DataContext.jsx';
import { AuthProvider } from './app/providers/AuthContext.jsx';
 
const router = createBrowserRouter([
  {
    path: '/*',
    element: (
      <AuthProvider>
        <DataProvider>
          <App />
        </DataProvider>
      </AuthProvider>
    ),
  },
]);
 
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);