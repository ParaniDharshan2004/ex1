import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import ReceiptLongRoundedIcon from '@mui/icons-material/ReceiptLongRounded';
import ConfirmDialog from '../../common-components/ConfirmDialog';
import EntityFormDialog from '../../common-components/EntityFormDialog';

const rowKey = (row) =>
  `${row?._id || ''}-${row?.excelRowNumber ?? ''}-${row?.tallyLedgerName || ''}`;

const getId = (value) => String(value?._id || value?.id || value || '');

export default function OperationalExpenseUnmatchedTallyRows({
  unmatchedRows = [],
  masterComponents = [],
  financialCategories = [],
  financialSubCategories = [],
  canAdd = true,
  busy = false,
  reviewRequested = false,
  onAddToMaster,
  onAddReportOnly,
  onFinancialCategoryChange,
  onReviewRequestHandled,
  onDiscard,
}) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [activeRow, setActiveRow] = useState(null);
  const [formMode, setFormMode] = useState('');
  const [pendingDiscard, setPendingDiscard] = useState(null);
  const [discarding, setDiscarding] = useState(false);
  const previousCount = useRef(0);
  const visibleRows = useMemo(
    () => unmatchedRows.filter((row) => row?.resolutionStatus !== 'ADDED_TO_REPORT'),
    [unmatchedRows],
  );

  useEffect(() => {
    if (canAdd && visibleRows.length > previousCount.current) {
      setDialogOpen(true);
    }
    previousCount.current = visibleRows.length;
  }, [canAdd, visibleRows.length]);

  const closeReviewDialog = () => {
    setDialogOpen(false);
    onReviewRequestHandled?.();
  };

  const categories = useMemo(
    () =>
      financialCategories
        .map((category) => ({
          value: getId(category),
          label: category.categoryName || category.name || '',
        }))
        .filter((category) => category.value),
    [financialCategories],
  );
  const activeMasterComponent = useMemo(() => {
    const ledgerName = String(activeRow?.tallyLedgerName || '')
      .trim()
      .toLocaleLowerCase();
    return masterComponents.find(
      (component) =>
        String(component.componentName || '')
          .trim()
          .toLocaleLowerCase() === ledgerName,
    );
  }, [activeRow, masterComponents]);
  const formFields = useMemo(() => {
    const fields = [
      {
        name: 'financialCategoryId',
        label: 'Financial Category',
        type: 'select',
        options: categories,
        required: true,
        resetFields: ['financialSubCategoryId'],
      },
    ];

    if (financialSubCategories.length > 0) {
      fields.push({
        name: 'financialSubCategoryId',
        label: 'Financial Subcategory',
        type: 'select',
        options: financialSubCategories.map((subCategory) => ({
          label: subCategory.subCategoryName,
          value: getId(subCategory),
        })),
        required: true,
      });
    }

    fields.push(
      {
        name: 'componentName',
        label: 'Component Name',
        type: 'text',
        required: true,
      },
      {
        name: 'description',
        label: 'Description',
        type: 'text',
        multiline: true,
        rows: 2,
      },
      {
        name: 'displayOrder',
        label: 'Display Order',
        type: 'number',
        required: true,
        min: 1,
        step: 1,
      },
      {
        name: 'isPettyCash',
        label: 'Petty Cash',
        type: 'checkbox',
      },
      {
        name: 'isCashFlowAnalysis',
        label: 'Cash Flow Analysis',
        type: 'checkbox',
      },
      {
        name: 'isOperationalExpense',
        label: 'Operational Expense',
        type: 'checkbox',
      },
      {
        name: 'isFullyLoadedCost',
        label: 'Fully Loaded Cost',
        type: 'checkbox',
      },
      {
        name: 'isActive',
        label: 'Status',
        type: 'select',
        required: true,
        options: [
          { label: 'Active', value: true },
          { label: 'Inactive', value: false },
        ],
      },
    );

    return fields;
  }, [categories, financialSubCategories]);
  const initialValues = useMemo(() => {
    const nextDisplayOrder =
      masterComponents.reduce(
        (maxOrder, component) =>
          Math.max(maxOrder, Number(component.displayOrder) || 0),
        0,
      ) + 1;

    return {
      financialCategoryId: getId(
        activeMasterComponent?.financialCategoryId,
      ),
      financialSubCategoryId: getId(
        activeMasterComponent?.financialSubCategoryId,
      ),
      componentName:
        activeMasterComponent?.componentName ||
        activeRow?.tallyLedgerName ||
        '',
      description: activeMasterComponent?.description || '',
      displayOrder:
        Number(activeMasterComponent?.displayOrder) || nextDisplayOrder,
      isPettyCash: activeMasterComponent?.isPettyCash || false,
      isCashFlowAnalysis:
        activeMasterComponent?.isCashFlowAnalysis || false,
      isOperationalExpense:
        activeMasterComponent?.isOperationalExpense ?? true,
      isFullyLoadedCost:
        activeMasterComponent?.isFullyLoadedCost || false,
      isActive: activeMasterComponent?.isActive ?? true,
    };
  }, [activeMasterComponent, activeRow, masterComponents]);

  const openForm = (row, mode) => {
    setActiveRow(row);
    setFormMode(mode);
    const matchingComponent = masterComponents.find(
      (component) =>
        String(component.componentName || '')
          .trim()
          .toLocaleLowerCase() ===
        String(row?.tallyLedgerName || '')
          .trim()
          .toLocaleLowerCase(),
    );
    onFinancialCategoryChange?.(
      getId(matchingComponent?.financialCategoryId),
    );
  };

  const closeForm = () => {
    onFinancialCategoryChange?.('');
    setFormMode('');
    setActiveRow(null);
  };

  const handleSave = async (values) => {
    if (!activeRow) return;

    if (formMode === 'master') {
      if (activeMasterComponent) {
        await onAddReportOnly(
          activeRow,
          activeMasterComponent._id,
          activeMasterComponent,
        );
        closeForm();
        return;
      }
      await onAddToMaster(activeRow, values);
      closeForm();
      return;
    }

    const category = financialCategories.find(
      (item) => getId(item) === String(values.financialCategoryId),
    );
    if (!category) {
      throw new Error('Select a valid financial category.');
    }

    const matchingComponent = masterComponents.find(
      (component) =>
        String(component.componentName || '')
          .trim()
          .toLocaleLowerCase() === values.componentName.trim().toLocaleLowerCase() &&
        getId(component.financialCategoryId) ===
          String(values.financialCategoryId) &&
        (!values.financialSubCategoryId ||
          getId(component.financialSubCategoryId) ===
            String(values.financialSubCategoryId)),
    );
    const reportOnlyComponent = {
      ...(matchingComponent || {}),
      _id: matchingComponent?._id || matchingComponent?.id || null,
      componentName: values.componentName.trim(),
      financialCategoryId: category,
      financialSubCategoryId:
        values.financialSubCategoryId || matchingComponent?.financialSubCategoryId || null,
    };
    await onAddReportOnly(
      activeRow,
      reportOnlyComponent._id,
      reportOnlyComponent,
      values,
    );
    closeForm();
  };

  const handleDiscard = async () => {
    if (!pendingDiscard || discarding) return;
    setDiscarding(true);
    try {
      await onDiscard(pendingDiscard);
      setPendingDiscard(null);
    } finally {
      setDiscarding(false);
    }
  };

  if (!canAdd || !visibleRows.length) return null;

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 1.5 }}>
        <Button
          variant="outlined"
          onClick={() => setDialogOpen(true)}
          disabled={busy || discarding}
        >
          Review unmatched ({visibleRows.length})
        </Button>
      </Box>

      <Dialog
        open={
          visibleRows.length > 0 &&
          (dialogOpen || (canAdd && reviewRequested))
        }
        onClose={closeReviewDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 2,
            fontWeight: 700,
          }}
        >
          <Typography component="span" variant="h6">
            Some Uploaded Values Need Your Attention
          </Typography>
          <IconButton
            aria-label="Close unmatched values"
            onClick={closeReviewDialog}
            size="small"
            sx={{ flexShrink: 0 }}
          >
            <CloseRoundedIcon fontSize="small" />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ overflowX: 'hidden', py: 2.5 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            The following uploaded values could not be matched with existing
            records. Choose whether to add them to your master data or include
            them only in this report.
          </Typography>
          <Stack spacing={1.25}>
            {visibleRows.map((row) => (
              <Box
                key={rowKey(row)}
                sx={{
                  display: 'grid',
                  gridTemplateColumns: {
                    xs: 'minmax(0, 1fr)',
                    md: 'minmax(0, 0.9fr) minmax(0, 1.1fr)',
                  },
                  alignItems: 'center',
                  gap: 2,
                  p: { xs: 1.5, sm: 2 },
                  border: '1px solid',
                  borderColor: 'divider',
                  borderRadius: 1,
                  bgcolor: 'background.paper',
                }}
              >
                <Box
                  sx={{
                    minWidth: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 2,
                  }}
                >
                  <Box sx={{ minWidth: 0 }}>
                    <Typography variant="h6" color="text.secondary">
                      Uploaded value
                    </Typography>
                    <Typography
                      variant="body2"
                      fontWeight={700}
                      sx={{ overflowWrap: 'anywhere' }}
                    >
                      {row.tallyLedgerName || 'Unnamed value'}
                    </Typography>
                  </Box>
                  <Box sx={{ flexShrink: 0, textAlign: 'right' }}>
                    <Typography variant="h6" color="text.secondary">
                      Amount
                    </Typography>
                    <Typography variant="subtitle1" className="amount-value">
                      {(Number(row.amount) || 0).toLocaleString('en-IN')}
                    </Typography>
                  </Box>
                </Box>

                <Box
                  sx={{
                    display: 'grid',
                    gridTemplateColumns: {
                      xs: 'minmax(0, 1fr) minmax(0, 1fr)',
                      sm: '180px 140px 36px',
                    },
                    alignItems: 'center',
                    gap: 1,
                    width: { xs: '100%', sm: 'fit-content' },
                    justifySelf: { xs: 'stretch', sm: 'end' },
                  }}
                >
                  <Button
                    size="small"
                    variant="contained"
                    disableElevation
                    startIcon={<AddRoundedIcon fontSize="small" />}
                    sx={{
                      minWidth: 0,
                      minHeight: 34,
                      whiteSpace: 'normal',
                      lineHeight: 1.2,
                      borderRadius: 1,
                      fontWeight: 700,
                      fontSize: '0.8125rem',
                    }}
                    onClick={() => openForm(row, 'master')}
                    disabled={busy || discarding}
                  >
                    Add to Master Data
                  </Button>
                  <Button
                    size="small"
                    variant="outlined"
                    startIcon={<ReceiptLongRoundedIcon fontSize="small" />}
                    sx={{
                      minWidth: 0,
                      minHeight: 34,
                      whiteSpace: 'normal',
                      lineHeight: 1.2,
                      borderRadius: 1,
                      fontWeight: 600,
                      fontSize: '0.8125rem',
                    }}
                    onClick={() => openForm(row, 'report')}
                    disabled={busy || discarding}
                  >
                    Report Only
                  </Button>
                  <Tooltip
                    title={
                      discarding ? 'Discarding...' : 'Discard unmatched value'
                    }
                  >
                    <Box>
                      <IconButton
                        color="error"
                        aria-label={`Discard ${row.tallyLedgerName || 'unmatched value'}`}
                        onClick={() => setPendingDiscard(row)}
                        disabled={busy || discarding}
                        sx={{
                          width: 36,
                          height: 36,
                          border: '1px solid',
                          borderColor: '#FECACA',
                          borderRadius: 1,
                          bgcolor: '#FFF7F7',
                          '&:hover': {
                            bgcolor: '#FEF2F2',
                            borderColor: 'error.light',
                          },
                        }}
                      >
                        <DeleteOutlineRoundedIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  </Tooltip>
                </Box>
              </Box>
            ))}
          </Stack>
        </DialogContent>
      </Dialog>

      <EntityFormDialog
        open={Boolean(formMode)}
        mode="create"
        title={
          formMode === 'master'
            ? 'Add Component'
            : 'Add Report-only Component'
        }
        fields={formFields}
        initialValues={initialValues}
        loading={busy}
        saveConfirmTitle={(values) =>
          formMode === 'master'
            ? `Add ${values.componentName?.trim() || 'this Component'} to Master Data?`
            : `Add ${values.componentName?.trim() || 'this value'} as a report-only value?`
        }
        saveConfirmMessage=""
        saveConfirmLabel="Submit"
        onFieldChange={(name, value) => {
          if (name === 'financialCategoryId') {
            onFinancialCategoryChange?.(value);
          }
        }}
        onClose={closeForm}
        onSave={handleSave}
      />

      <ConfirmDialog
        open={Boolean(pendingDiscard)}
        title="Discard unmatched value?"
        message={`Are you sure you want to discard "${pendingDiscard?.tallyLedgerName || 'this unmatched value'}" from this report?`}
        confirmLabel={discarding ? 'Discarding...' : 'Yes, discard'}
        confirmColor="error.main"
        onConfirm={handleDiscard}
        onCancel={() => {
          if (!discarding) setPendingDiscard(null);
        }}
      />
    </>
  );
}
