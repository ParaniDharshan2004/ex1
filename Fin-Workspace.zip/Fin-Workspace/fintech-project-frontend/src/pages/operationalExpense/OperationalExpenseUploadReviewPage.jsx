import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Box,
  Alert,
  Snackbar,
  CircularProgress,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from '@mui/material';
import { useNavigate, useParams, useLocation, useBlocker } from 'react-router-dom';
import { buildOperationalExpenseNavigationTarget } from '../../utils/operationalExpense/navigation';
import * as XLSX from 'xlsx';
import { createWorker } from 'tesseract.js';
import * as pdfjsLib from 'pdfjs-dist';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';

import WorkflowStepper from '../../components/operationalExpense/common/WorkflowStepper';
import UploadReviewHeader from '../../components/operationalExpense/uploadReview/UploadReviewHeader';
import FileUploadZone from '../../components/operationalExpense/uploadReview/FileUploadZone';
import ExpensePreviewTable from '../../components/operationalExpense/uploadReview/ExpensePreviewTable';
import OperationalExpenseUnmatchedTallyRows from '../../components/operationalExpense/uploadReview/OperationalExpenseUnmatchedTallyRows';
import UnsavedChangesDialog from '../../components/common-components/UnsavedChangesDialog';
import {
  getOperationalExpenseReport,
  getOperationalExpenseReports,
  generateOperationalExpenseReport,
  updateOperationalExpenseReport,
  updateOperationalExpenseReportStatus,
  deleteOperationalExpenseReport,
} from '../../utils/operationalExpense/operationalExpenseApi';
import {
  calculateSubtotal,
  calculateMarkup,
  calculateTotalBillable,
  calculateOperationalExpenseCategoryTotals,
  calculateOtherExpenseTotal,
  groupExpensesByCategory,
} from '../../utils/operationalExpense/expenseCalculations';
import {
  formatMonthYear,
  getCurrentDate,
} from '../../utils/operationalExpense/date';
import {
  isInvoiceGeneratedStatus,
} from '../../utils/operationalExpense/statusHelpers';
import {
  calculateFixedCostTotal,
  splitTallyRowsByFixedCost,
} from '../../utils/operationalExpense/fixedCostImport';
import {
  isResolvedFixedAssetUnmatchedRow,
  mapFixedAssetsToComponents,
} from '../../utils/operationalExpense/fixedAssetMapping';
import {
  aggregateTallyRowsByHeadComponent,
  calculateMiscellaneousExpenseTotal,
  isUnresolvedTallyRow,
} from '../../utils/operationalExpense/tallyHeadComponentImport';
import { extractTallyRowsFromGrid } from '../../utils/operationalExpense/tallyGridParser';
import api from '../../services/auth-service.js';

const extractPeriodFromGrid = (grid, fileName = '') => {
  const monthNames = {
    jan: 1,
    january: 1,
    feb: 2,
    february: 2,
    mar: 3,
    march: 3,
    apr: 4,
    april: 4,
    may: 5,
    jun: 6,
    june: 6,
    jul: 7,
    july: 7,
    aug: 8,
    august: 8,
    sep: 9,
    sept: 9,
    september: 9,
    oct: 10,
    october: 10,
    nov: 11,
    november: 11,
    dec: 12,
    december: 12,
  };
  const values = [
    ...grid.flat().map((value) => String(value || '').trim()),
    String(fileName || '').replace(/[_-]+/g, ' '),
  ].filter(Boolean);
  const monthYearPattern =
    /\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s*[,./-]?\s*((?:19|20)\d{2})\b/i;
  const yearMonthPattern = /\b((?:19|20)\d{2})[-/](0?[1-9]|1[0-2])\b/;
  const numericDatePattern =
    /\b(?:0?[1-9]|[12]\d|3[01])[-/.](0?[1-9]|1[0-2])[-/.]((?:19|20)?\d{2})\b/;

  for (const value of values) {
    const monthYear = value.match(monthYearPattern);
    if (monthYear) {
      const year = Number(monthYear[2]);
      const month = monthNames[monthYear[1].toLowerCase()];
      return `${year}-${String(month).padStart(2, '0')}`;
    }

    const yearMonth = value.match(yearMonthPattern);
    if (yearMonth)
      return `${yearMonth[1]}-${String(yearMonth[2]).padStart(2, '0')}`;

    const numericDate = value.match(numericDatePattern);
    if (numericDate) {
      const rawYear = numericDate[2];
      const year = rawYear.length === 2 ? `20${rawYear}` : rawYear;
      return `${year}-${String(numericDate[1]).padStart(2, '0')}`;
    }
  }

  return '';
};

const amountAtLineEnd = /(?:₹|Rs\.?|INR)?\s*\(?\d[\d,]*(?:\.\d+)?\)?\s*$/i;

const textToGrid = (text) =>
  String(text || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const amountMatch = line.match(amountAtLineEnd);
      if (!amountMatch) return [line];
      const amount = amountMatch[0].replace(/[^\d().-]/g, '');
      const description = line.slice(0, amountMatch.index).trim();
      return ['', description, amount];
    });

const extractOcrText = async (file) => {
  const worker = await createWorker('eng');
  try {
    const result = await worker.recognize(file);
    const confidence = Number(result?.data?.confidence || 0);
    if (confidence < 55) {
      throw new Error('OCR confidence is too low to validate this report.');
    }
    return result.data.text;
  } finally {
    await worker.terminate();
  }
};

const extractPdfText = async (file) => {
  const buffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
  const pages = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    pages.push(content.items.map((item) => item.str).join(' '));
  }
  return pages.join('\n');
};

const UPLOAD_SESSION_KEY = 'operational-expense-upload-session';

const readUploadSession = () => {
  try {
    return JSON.parse(sessionStorage.getItem(UPLOAD_SESSION_KEY) || 'null');
  } catch {
    return null;
  }
};

export default function OperationalExpenseUploadReviewPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { reportId: paramReportId } = useParams();
  const searchParams = new URLSearchParams(location.search);

  const initialReportId = paramReportId || location.state?.reportId;
  const requestedPeriod =
    location.state?.period || searchParams.get('period') || '';
  const storedUploadSession = readUploadSession();
  const savedUploadSession =
    !initialReportId &&
    (!requestedPeriod || requestedPeriod === storedUploadSession?.period)
      ? storedUploadSession
      : null;
  const [draftReportId, setDraftReportId] = useState(initialReportId || '');
  const reportId = draftReportId;
  const initialPeriod =
    requestedPeriod || savedUploadSession?.period || '';
  const [period, setPeriod] = useState(initialPeriod);
  const [invoiceDate, setInvoiceDate] = useState(
    location.state?.invoiceDate ||
      savedUploadSession?.invoiceDate ||
    getCurrentDate(),
  );
  const [status, setStatus] = useState('Review Pending');
  const [isPersistedReport, setIsPersistedReport] = useState(false);
  const [fileName, setFileName] = useState(savedUploadSession?.fileName || '');
  const [expenses, setExpenses] = useState(savedUploadSession?.expenses || []);
  const [fixedCosts, setFixedCosts] = useState(
    savedUploadSession?.fixedCosts || [],
  );
  const [unmatchedRows, setUnmatchedRows] = useState(
    savedUploadSession?.unmatchedRows || [],
  );
  const [unmatchedReviewRequested, setUnmatchedReviewRequested] = useState(false);
  const [masterComponents, setMasterComponents] = useState([]);
  const [financialCategories, setFinancialCategories] = useState([]);
  const [financialSubCategories, setFinancialSubCategories] = useState([]);
  const financialCategoryRequestRef = useRef('');
  const [loading, setLoading] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const approveInProgressRef = useRef(false);
  const allocationRedirectedRef = useRef(false);
  const [approvalComplete, setApprovalComplete] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [toastMessage, setToastMessage] = useState('');
  const [toastSeverity, setToastSeverity] = useState('success');
  const [validationErrors, setValidationErrors] = useState([]);
  const [existingRecord, setExistingRecord] = useState(null);
  const [existingRecordOpen, setExistingRecordOpen] = useState(false);
  const [pendingExistingUploadFile, setPendingExistingUploadFile] =
    useState(null);
  const [queuedMergeFile, setQueuedMergeFile] = useState(null);
  const [replacementFile, setReplacementFile] = useState(null);
  const [replacementConfirmOpen, setReplacementConfirmOpen] = useState(false);
  const [fileInputResetKey, setFileInputResetKey] = useState(0);
  const [leaveConfirmOpen, setLeaveConfirmOpen] = useState(false);
  const [leaveAction, setLeaveAction] = useState('');
  const [monthMismatchOpen, setMonthMismatchOpen] = useState(false);
  const [removeFileConfirmOpen, setRemoveFileConfirmOpen] = useState(false);
  const [isRemovingFile, setIsRemovingFile] = useState(false);
  const removeFileInProgressRef = useRef(false);
  const handledQueuedMergeFileRef = useRef(null);
  const skipNextNavigationBlockRef = useRef(false);
  const hasUnsavedChanges =
    !isPersistedReport &&
    !approvalComplete &&
    !['Invoices Generated', 'Completed'].includes(status) &&
    Boolean(fileName || expenses.length || fixedCosts.length || unmatchedRows.length);
  const shouldBlockNavigation = useCallback(
    ({ currentLocation, nextLocation }) =>
      !skipNextNavigationBlockRef.current &&
    (isApproving || hasUnsavedChanges) &&
    currentLocation.pathname !== nextLocation.pathname,
    [hasUnsavedChanges, isApproving],
  );
  const navigationBlocker = useBlocker(shouldBlockNavigation);
  const {
    state: navigationBlockerState,
    proceed: proceedNavigation,
    reset: resetNavigation,
  } = navigationBlocker;

  useEffect(() => {
    if (reportId || (masterComponents.length > 0 && financialCategories.length > 0)) {
      return undefined;
    }

    let active = true;
    Promise.all([
      api.get('/api/componentRouter/getAllComponents'),
      api.get('/api/subComponentRouter/getAllSubcomponents'),
      api.get('/api/componentRouter/financial-categories'),
    ])
      .then(([componentsResponse, subComponentsResponse, categoriesResponse]) => {
        if (!active) return;
        const components = Array.isArray(componentsResponse.data?.data)
          ? componentsResponse.data.data.filter(
              (component) =>
                component.isActive !== false &&
                component.isOperationalExpense !== false,
            )
          : [];
        setMasterComponents(components);
        setFinancialSubCategories(
          Array.isArray(subComponentsResponse.data?.data)
            ? subComponentsResponse.data.data.filter(
                (subComponent) => subComponent.isActive !== false,
              )
            : [],
        );
        setFinancialCategories(
          Array.isArray(categoriesResponse.data?.data)
            ? categoriesResponse.data.data
            : [],
        );
      })
      .catch((error) => {
        if (active) {
          console.error('Failed to load unmatched-row master options:', error);
          setToastSeverity('error');
          setToastMessage(
            'Unable to load master options for unmatched rows. Please try again.',
          );
        }
      });

    return () => {
      active = false;
    };
  }, [reportId, masterComponents.length, financialCategories.length]);

  // Fetch report details if reportId is present
  useEffect(() => {
    if (!reportId || approveInProgressRef.current) return;

    let active = true;
    const loadReport = async () => {
      try {
        setLoading(true);
        const [
          response,
          componentsResponse,
          subComponentsResponse,
          categoriesResponse,
        ] =
          await Promise.all([
            getOperationalExpenseReport(reportId),
            api.get('/api/componentRouter/getAllComponents'),
            api.get('/api/subComponentRouter/getAllSubcomponents'),
            api.get('/api/componentRouter/financial-categories'),
          ]);
        console.debug(
          '[OperationalExpense][UploadReview] API response: getOperationalExpenseReport',
          response.data,
        );
        const rep = response.data?.data;
        if (active && rep) {
          if (rep.reportMonth) setPeriod(rep.reportMonth);
          if (rep.reportDate) {
            setInvoiceDate(String(rep.reportDate).slice(0, 10));
          }
          if (isInvoiceGeneratedStatus(rep.status)) {
            setStatus('Invoices Generated');
          } else if (rep.status === 'ALLOCATION_PENDING') {
            setStatus('Allocation Pending');
          } else {
            setStatus('Review Pending');
          }

          // Keep backend-matched rows and explicitly added report-only rows.
          const matchedRows = (rep.rows || []).filter(
            (row) =>
              row.financialCategoryName &&
              ((row.componentId || row.componentCode) &&
                row.hasTallyExpense === true &&
                [
                  'HEAD_COMPONENT_MATCHED',
                  'CALCULATED_FROM_SUBCOMPONENTS',
                ].includes(row.matchStatus)) ||
                (row.rowSource === 'REPORT_ONLY' &&
                  row.matchStatus === 'MANUALLY_ADDED'),
          );
          const rawReportFixedCosts =
            Array.isArray(rep.fixedAssets) && rep.fixedAssets.length > 0
              ? rep.fixedAssets
              : Array.isArray(rep.fixedCosts)
                ? rep.fixedCosts
                : [];
          const managedComponents = Array.isArray(
            componentsResponse.data?.data,
          )
            ? componentsResponse.data.data.filter(
                (component) => component.isActive !== false,
              )
            : [];
          const managedSubComponents = Array.isArray(
            subComponentsResponse.data?.data,
          )
            ? subComponentsResponse.data.data.filter(
                (component) => component.isActive !== false,
              )
            : [];
          setMasterComponents(
            managedComponents.filter(
              (component) => component.isOperationalExpense !== false,
            ),
          );
          setFinancialCategories(
            Array.isArray(categoriesResponse.data?.data)
              ? categoriesResponse.data.data
              : [],
          );
          const reportFixedCosts = mapFixedAssetsToComponents(
              rawReportFixedCosts,
              managedComponents,
              managedSubComponents,
          );
          const reportUnmatchedRows = rep.unmatchedTallyRows || [];
          setIsPersistedReport(true);
          setFixedCosts(reportFixedCosts);
          setUnmatchedRows(reportUnmatchedRows);
          setExpenses(groupExpensesByCategory(matchedRows));
          setFileName(rep.sourceFileName || '');
        }
      } catch (err) {
        if (active) {
          console.error('Failed to load report:', err);
          if (err?.response?.status === 404) {
            navigate('/operational-expense-dashboard', {
              state: {
                notification:
                  'No operational expense report is available for this record.',
              },
            });
            return;
          }
          setErrorMessage('Failed to load report data from the server.');
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    loadReport();
    return () => {
      active = false;
    };
  }, [reportId, navigate]);

  useEffect(() => {
    if (!reportId || !period) return;
    const searchParams = new URLSearchParams(location.search);
    if (searchParams.get('period') === period) return;

    searchParams.set('period', period);
    navigate(
      { pathname: location.pathname, search: `?${searchParams.toString()}` },
      {
        replace: true,
        state: { ...location.state, reportId, period },
      },
    );
  }, [
    location.pathname,
    location.search,
    location.state,
    navigate,
    period,
    reportId,
  ]);

  useEffect(() => {
    if (!hasUnsavedChanges && !isApproving) return undefined;
    const handleBeforeUnload = (event) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges, isApproving]);

  // Handle file parsing
  const handleFileSelect = useCallback(async (
    file,
    confirmReplacement = false,
    mergeWithExisting = false,
  ) => {
    if (!file) return;
    const uploadedAt = getCurrentDate();
    try {
      setLoading(true);
      setErrorMessage('');

      const ext = file.name.toLowerCase().split('.').pop();
      let extractedRows = [];
      let sourceGrid = [];

      if (ext === 'xlsx' || ext === 'xls') {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const grid = XLSX.utils.sheet_to_json(sheet, {
          header: 1,
          defval: '',
          raw: true,
        });
        sourceGrid = grid;
        extractedRows = extractTallyRowsFromGrid(grid);
      } else if (ext === 'pdf') {
        const text = await extractPdfText(file);
        sourceGrid = textToGrid(text);
        extractedRows = extractTallyRowsFromGrid(sourceGrid);
      } else if (['jpg', 'jpeg', 'png', 'webp'].includes(ext)) {
        const text = await extractOcrText(file);
        sourceGrid = textToGrid(text);
        extractedRows = extractTallyRowsFromGrid(sourceGrid);
      } else {
        const text = await file.text();
        const workbook = XLSX.read(text, { type: 'string' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const grid = XLSX.utils.sheet_to_json(sheet, {
          header: 1,
          defval: '',
          raw: true,
        });
        sourceGrid = grid;
        extractedRows = extractTallyRowsFromGrid(grid);
      }

      const extractedPeriod = extractPeriodFromGrid(sourceGrid, file.name);
      if (!extractedPeriod) {
        setErrorMessage(
          'Could not identify the expense month and year from the uploaded report.',
        );
        setLoading(false);
        return;
      }

      const extractedInvoiceDate = uploadedAt;
      if (period && period !== extractedPeriod) {
        setFileName('');
        setMonthMismatchOpen(true);
        setLoading(false);
        return;
      }
      setPeriod(extractedPeriod);
      setInvoiceDate(extractedInvoiceDate);

      if (extractedRows.length === 0) {
        setErrorMessage(
          'Could not extract numeric expense rows from this file. Ensure format has Category, Description, and Amount.',
        );
        setLoading(false);
        return;
      }

      const reportsResponse = await getOperationalExpenseReports();
      const reportsPayload = reportsResponse?.data?.data;
      const existingReports = Array.isArray(reportsPayload)
        ? reportsPayload
        : reportsPayload?.reports || reportsPayload?.items || [];
      const existing = existingReports
        .filter(
          (report) => String(report?.reportMonth || '') === extractedPeriod,
        )
        .sort(
          (first, second) =>
            new Date(second?.updatedAt || second?.createdAt || 0).getTime() -
            new Date(first?.updatedAt || first?.createdAt || 0).getTime(),
        )[0];
      const isCurrentReport =
        existing &&
        reportId &&
        String(existing._id || existing.id) === String(reportId);

      if (
        isCurrentReport &&
        !confirmReplacement &&
        !isInvoiceGeneratedStatus(existing.status)
      ) {
        setReplacementFile(file);
        setReplacementConfirmOpen(true);
        setLoading(false);
        return;
      }

      if (
        existing &&
        (!isCurrentReport || isInvoiceGeneratedStatus(existing.status)) &&
        String(existing.status || '').toUpperCase() !== 'CANCELLED'
      ) {
        setFileName(file.name);
        setPendingExistingUploadFile(file);
        setExistingRecord(existing);
        setExistingRecordOpen(true);
        setLoading(false);
        return;
      }

      setFileName(file.name);

      const [
        componentsResponse,
        categoriesResponse,
        subComponentsResponse,
        fixedAssetsResponse,
        fixedAssetCategoriesResponse,
      ] = await Promise.all([
        api.get('/api/componentRouter/getAllComponents'),
        api.get('/api/componentRouter/financial-categories'),
        api.get('/api/subComponentRouter/getAllSubcomponents'),
        api.get('/api/fixedAssetRouter/getAllFixedAssets'),
        api.get('/api/fixedAssetCategoryRouter/getAllFixedAssetCategories'),
      ]);
      console.debug(
        '[OperationalExpense][UploadReview] API response: getAllComponents',
        componentsResponse.data,
      );
      console.debug(
        '[OperationalExpense][UploadReview] API response: financial-categories',
        categoriesResponse.data,
      );
      console.debug(
        '[OperationalExpense][UploadReview] API response: getAllSubcomponents',
        subComponentsResponse.data,
      );

      const categories = Array.isArray(categoriesResponse.data?.data)
        ? categoriesResponse.data.data
        : [];
      const activeComponents = Array.isArray(componentsResponse.data?.data)
        ? componentsResponse.data.data.filter(
            (component) => component.isActive !== false,
          )
        : [];
      setMasterComponents(
        activeComponents.filter(
          (component) => component.isOperationalExpense !== false,
        ),
      );
      setFinancialCategories(categories);
      const components = activeComponents
        .filter((component) => component.isOperationalExpense !== false)
        .sort(
              (first, second) =>
                Number(first.displayOrder || 0) -
                Number(second.displayOrder || 0),
            );
      const subComponents = Array.isArray(subComponentsResponse.data?.data)
        ? subComponentsResponse.data.data.filter(
            (item) => item.isActive !== false,
          )
        : [];
      const fixedAssets = Array.isArray(fixedAssetsResponse.data?.data)
        ? fixedAssetsResponse.data.data.filter(
            (item) => item.isActive !== false,
          )
        : [];
      const fixedAssetCategories = Array.isArray(
        fixedAssetCategoriesResponse.data?.data,
      )
        ? fixedAssetCategoriesResponse.data.data.filter(
            (item) => item.isActive !== false,
          )
        : [];
      const { fixedCosts: importedFixedCosts, operationalRows } =
        splitTallyRowsByFixedCost(
          extractedRows,
          fixedAssets,
          fixedAssetCategories,
        );
      const fixedCostsWithComponents = mapFixedAssetsToComponents(
        importedFixedCosts,
        components,
        subComponents,
      );

      const { matchedRows, unmatchedRows: parsedUnmatchedRows } =
        aggregateTallyRowsByHeadComponent(
          operationalRows,
          components,
          subComponents,
          categories,
        );
      // Keep every unresolved Tally row visible for manual categorization.
      // Only fixed-asset rows already represented in the fixed-assets section
      // are excluded to avoid displaying the same row twice.
      const importedUnmatchedRows = parsedUnmatchedRows.filter(
        (row) => !isResolvedFixedAssetUnmatchedRow(row, fixedCostsWithComponents),
      );
      console.debug(
        '[OperationalExpense][UploadReview] aggregated Tally rows by head component',
        matchedRows,
      );
      const grouped = groupExpensesByCategory(matchedRows);
      console.debug(
        '[OperationalExpense][UploadReview] transformed uploaded file data',
        grouped,
      );
      const nextExpenses = mergeWithExisting
        ? groupExpensesByCategory([...expenses, ...grouped])
        : grouped;
      const nextFixedCosts = mergeWithExisting
        ? [...fixedCosts, ...fixedCostsWithComponents]
        : fixedCostsWithComponents;
      const nextUnmatchedRows = mergeWithExisting
        ? [
            ...unmatchedRows,
            ...importedUnmatchedRows,
          ]
        : importedUnmatchedRows;
      setExpenses(nextExpenses);
      setFixedCosts(nextFixedCosts);
      setUnmatchedRows(nextUnmatchedRows);
      setIsPersistedReport(false);
      sessionStorage.setItem(
        UPLOAD_SESSION_KEY,
        JSON.stringify({
          period: extractedPeriod,
          invoiceDate: extractedInvoiceDate,
          fileName: file.name,
          expenses: nextExpenses,
          fixedCosts: nextFixedCosts,
          unmatchedRows: nextUnmatchedRows,
        }),
      );
      setToastSeverity('success');
      setToastMessage(
        mergeWithExisting
          ? 'Uploaded data added to the existing report preview.'
          : 'Uploaded Successfully',
      );
    } catch (err) {
      console.error('File parsing error:', err);
      setErrorMessage(
        err?.response?.data?.message ||
          err?.message ||
          'Failed to read and parse the uploaded file.',
      );
    } finally {
      setLoading(false);
    }
  }, [expenses, fixedCosts, unmatchedRows, period, reportId]);

  const confirmFileReplacement = (mergeWithExisting = false) => {
    if (!replacementFile) return;
    const file = replacementFile;
    setReplacementFile(null);
    setReplacementConfirmOpen(false);
    handleFileSelect(file, true, mergeWithExisting);
  };

  const cancelFileReplacement = () => {
    setReplacementFile(null);
    setReplacementConfirmOpen(false);
    setFileInputResetKey((key) => key + 1);
  };

  useEffect(() => {
    if (
      !queuedMergeFile ||
      !reportId ||
      !isPersistedReport ||
      handledQueuedMergeFileRef.current === queuedMergeFile
    ) {
      return;
    }

    handledQueuedMergeFileRef.current = queuedMergeFile;
    handleFileSelect(queuedMergeFile, true, true);
  }, [queuedMergeFile, reportId, isPersistedReport, handleFileSelect]);

  const closeExistingRecordDialog = () => {
    setExistingRecordOpen(false);
    setExistingRecord(null);
    setPendingExistingUploadFile(null);
    setFileName('');
    setFileInputResetKey((key) => key + 1);
  };

  const handleRemoveFile = () => {
    setRemoveFileConfirmOpen(true);
  };

  const confirmRemoveFile = async () => {
    if (removeFileInProgressRef.current) return;
    removeFileInProgressRef.current = true;
    setIsRemovingFile(true);

    try {
      if (reportId) {
        await deleteOperationalExpenseReport(reportId);
      }

      const cachedSession = readUploadSession();
      if (cachedSession?.period === period) {
        sessionStorage.removeItem(UPLOAD_SESSION_KEY);
      }
      setDraftReportId('');
      setIsPersistedReport(false);
      setStatus('Review Pending');
      setApprovalComplete(false);
      setFileName('');
      setInvoiceDate(getCurrentDate());
      setExpenses([]);
      setFixedCosts([]);
      setUnmatchedRows([]);
      setValidationErrors([]);
      setExistingRecord(null);
      setExistingRecordOpen(false);
      setMonthMismatchOpen(false);
      setErrorMessage('');
      setToastMessage('');
      setFileInputResetKey((key) => key + 1);
      setRemoveFileConfirmOpen(false);
      if (reportId) {
        navigate(`/operational-expenses?period=${encodeURIComponent(period)}`, {
          replace: true,
          state: { period },
        });
      }
    } catch (err) {
      console.error('Failed to remove uploaded file:', err);
      setErrorMessage(
        err?.response?.data?.message ||
          'Could not remove the uploaded file and draft. Please try again.',
      );
    } finally {
      removeFileInProgressRef.current = false;
      setIsRemovingFile(false);
    }
  };

  const handleContinueExisting = () => {
    if (!existingRecord) return;
    const id = existingRecord._id || existingRecord.id;
    const existingPeriod = existingRecord.reportMonth || period;
    const existingDate = existingRecord.reportDate
      ? String(existingRecord.reportDate).slice(0, 10)
      : invoiceDate;
    closeExistingRecordDialog();

    if (existingRecord.status === 'ALLOCATION_PENDING') {
      navigate(`/operational-expense-allocation/${id}`, {
        state: {
          reportId: id,
          period: existingPeriod,
          invoiceDate: existingDate,
        },
      });
      return;
    }

    navigate(`/operational-expenses/${id}`, {
      state: {
        reportId: id,
        period: existingPeriod,
        invoiceDate: existingDate,
      },
    });
  };

  const handleAddFileToExistingReport = () => {
    if (!existingRecord || !pendingExistingUploadFile) return;
    const id = existingRecord._id || existingRecord.id;
    if (!id) {
      setErrorMessage('Could not identify the existing report.');
      return;
    }

    setExistingRecordOpen(false);
    setExistingRecord(null);
    setDraftReportId(String(id));
    handledQueuedMergeFileRef.current = null;
    setQueuedMergeFile(pendingExistingUploadFile);
    setPendingExistingUploadFile(null);
  };

  const handleStartOverExisting = async () => {
    if (!existingRecord) return;
    const id = existingRecord._id || existingRecord.id;
    try {
      setLoading(true);
      await deleteOperationalExpenseReport(id);
      closeExistingRecordDialog();
    } catch (err) {
      setErrorMessage(
        err.response?.data?.message || 'Failed to reset the existing draft.',
      );
    } finally {
      setLoading(false);
    }
  };

  const handleViewExistingReport = () => {
    if (!existingRecord) return;
    const existingPeriod = existingRecord.reportMonth || period;
    const [year, month] = existingPeriod.split('-');
    closeExistingRecordDialog();
    navigate(`/operational-expense-reports?year=${year}&month=${month}`, {
      state: { period: existingPeriod },
    });
  };

  const handleViewExistingInvoice = () => {
    if (!existingRecord) return;
    const id = existingRecord._id || existingRecord.id;
    closeExistingRecordDialog();
    navigate(
      `/operational-expense-invoices/${id}?month=${existingRecord.reportMonth || period}`,
      {
        state: { reportId: id, period: existingRecord.reportMonth || period },
      },
    );
  };

  const handleAddUnmatchedRowToReport = (
    row,
    componentId,
    componentOverride = null,
    reportOnlyValues = null,
  ) => {
    const amount = Number(row.amount);
    const component = componentOverride || masterComponents.find(
      (candidate) => String(candidate._id) === String(componentId),
    );
    if (!component || !Number.isFinite(amount) || amount < 0) {
      setToastSeverity('error');
      setToastMessage('Select a valid head component and provide a valid row amount.');
      return;
    }

    const description = String(
      reportOnlyValues?.componentName || row.tallyLedgerName || '',
    ).trim();
    if (!description) {
      setToastSeverity('error');
      setToastMessage('The unmatched row needs a ledger name before it can be added.');
      return;
    }

    const addedExpense = {
      id: `unmatched-${row._id || Date.now()}`,
      componentId: component._id,
      componentCode: component.componentCode,
      category:
        component.financialCategoryId?.categoryName ||
        financialCategories.find(
          (category) =>
            String(category._id) === String(component.financialCategoryId),
        )?.categoryName ||
        '',
      description,
      amount,
      rowSource: 'REPORT_ONLY',
      matchStatus: 'MANUALLY_ADDED',
      hasTallyExpense: false,
      displayOrder: expenses.length,
    };
    const nextExpenses = groupExpensesByCategory([
      ...expenses,
      addedExpense,
    ]);
    const isTargetRow = (candidate) =>
      candidate === row ||
      (row._id && candidate._id && String(candidate._id) === String(row._id));
    const nextUnmatchedRows = unmatchedRows.map((candidate) =>
      isTargetRow(candidate)
        ? {
            ...candidate,
            resolutionStatus: 'ADDED_TO_REPORT',
            resolutionReason: `Added to report under ${component.componentName}.`,
            resolvedAt: new Date().toISOString(),
          }
        : candidate,
    );

    setExpenses(nextExpenses);
    setUnmatchedRows(nextUnmatchedRows);
    setIsPersistedReport(false);
    if (!reportId) {
      sessionStorage.setItem(
        UPLOAD_SESSION_KEY,
        JSON.stringify({
          period,
          invoiceDate,
          fileName,
          expenses: nextExpenses,
          fixedCosts,
          unmatchedRows: nextUnmatchedRows,
        }),
      );
    }
    setToastSeverity('success');
    setToastMessage(
      `Added "${description}" to the report under ${component.componentName}.`,
    );
  };

  const handleDiscardUnmatchedRow = (row) => {
    const isTargetRow = (candidate) =>
      candidate === row ||
      (row._id && candidate._id && String(candidate._id) === String(row._id)) ||
      (row.excelRowNumber != null &&
        String(candidate.excelRowNumber) === String(row.excelRowNumber) &&
        candidate.tallyLedgerName === row.tallyLedgerName);
    const nextUnmatchedRows = unmatchedRows.filter(
      (candidate) => !isTargetRow(candidate),
    );
    setUnmatchedRows(nextUnmatchedRows);
    setIsPersistedReport(false);

    if (!reportId) {
      sessionStorage.setItem(
        UPLOAD_SESSION_KEY,
        JSON.stringify({
          period,
          invoiceDate,
          fileName,
          expenses,
          fixedCosts,
          unmatchedRows: nextUnmatchedRows,
        }),
      );
    }

    setToastSeverity('success');
    setToastMessage(
      `"${row.tallyLedgerName || 'Unmatched value'}" was removed from this report.`,
    );
  };

  const handleFinancialCategoryChange = async (financialCategoryId) => {
    financialCategoryRequestRef.current = financialCategoryId;
    setFinancialSubCategories([]);
    if (!financialCategoryId) return;

    try {
      const response = await api.get(
        `/api/componentRouter/financial-subcategories/${financialCategoryId}`,
      );
      if (financialCategoryRequestRef.current === financialCategoryId) {
        setFinancialSubCategories(
          response.data?.data?.financialSubCategories || [],
        );
      }
    } catch (error) {
      if (financialCategoryRequestRef.current === financialCategoryId) {
        console.error('Failed to load financial subcategories:', error);
        setToastSeverity('error');
        setToastMessage(
          error?.response?.data?.message ||
            'Unable to load Financial Subcategories.',
        );
      }
    }
  };

  const handleAddUnmatchedRowToMaster = async (row, values) => {
    const amount = Number(row.amount);
    if (!Number.isFinite(amount) || amount < 0) {
      throw new Error('The unmatched row has an invalid amount.');
    }

    try {
      const response = await api.post('/api/componentRouter/createComponent', {
        financialCategoryId: values.financialCategoryId || null,
        financialSubCategoryId: values.financialSubCategoryId || null,
        componentName: values.componentName?.trim(),
        description: values.description?.trim() || null,
        isPettyCash: Boolean(values.isPettyCash),
        isCashFlowAnalysis: Boolean(values.isCashFlowAnalysis),
        isOperationalExpense: Boolean(values.isOperationalExpense),
        isFullyLoadedCost: Boolean(values.isFullyLoadedCost),
        displayOrder: Number(values.displayOrder),
        isActive: values.isActive !== false,
      });
      const component = response.data?.data;
      if (!component?._id) {
        throw new Error('The component was not created.');
      }
      setMasterComponents((current) => [...current, component]);
      handleAddUnmatchedRowToReport(row, component._id, component);
      setToastSeverity('success');
      setToastMessage(`"${values.componentName}" was added to master data and this report.`);
    } catch (error) {
      setToastSeverity('error');
      setToastMessage(
        error?.response?.data?.message ||
          error?.message ||
          'Unable to add the unmatched row to master data.',
      );
      throw error;
    }
  };

  // Calculations
  const subtotal = calculateSubtotal(expenses);
  const markup = calculateMarkup(subtotal);
  const { directCostTotal, indirectCostTotal } =
    calculateOperationalExpenseCategoryTotals(expenses);
  const fixedCostTotal = calculateFixedCostTotal(fixedCosts);
  const miscellaneousExpenseTotal =
    calculateMiscellaneousExpenseTotal(expenses);
  const otherExpenseTotal = calculateOtherExpenseTotal(expenses);
  const totalBillable =
    calculateTotalBillable(
      subtotal,
      markup,
      fixedCostTotal + miscellaneousExpenseTotal + otherExpenseTotal,
    );

  // Approve Data and continue to Allocation
  const handleApproveData = () => {
    if (status === 'Allocation Pending' && reportId) {
      if (allocationRedirectedRef.current) return;
      allocationRedirectedRef.current = true;
      navigate(`/operational-expense-allocation/${reportId}?period=${encodeURIComponent(period)}`, {
        state: {
          ...location.state,
          reportId,
          period,
          invoiceDate,
          totalBillable,
        },
      });
      return;
    }

    if (unmatchedRows.some(isUnresolvedTallyRow)) {
      setUnmatchedReviewRequested(true);
      setToastSeverity('warning');
      setToastMessage(
        'Handle all unmatched rows before approving this report.',
      );
      return;
    }

    const errors = [];
    if (!period)
      errors.push(
        'Expense period is missing. Upload a report with a valid month and year.',
      );
    if (!invoiceDate) errors.push('Invoice date is missing.');
    if (
      expenses.length === 0 &&
      fixedCostTotal === 0 &&
      miscellaneousExpenseTotal === 0
    ) {
      errors.push('At least one valid expense amount is required.');
    }
    if (
      ![
        subtotal,
        markup,
        fixedCostTotal,
        miscellaneousExpenseTotal,
        totalBillable,
      ].every(Number.isFinite)
    ) {
      errors.push('One or more calculated amounts are invalid.');
    }
    if (errors.length) {
      setValidationErrors(errors);
      setErrorMessage(
        'Please correct the highlighted validation errors before approval.',
      );
      return;
    }
    setValidationErrors([]);
    approveData();
  };

  const approveData = async () => {
    if (approveInProgressRef.current) return;
    approveInProgressRef.current = true;

    try {
      setIsApproving(true);
      setErrorMessage('');

      // Build payload for backend
      const payloadRows = expenses.map((item, idx) => ({
        componentName: item.description || item.category,
        componentId: item.componentId,
        componentCode: item.componentCode,
        rowSource: item.rowSource || 'TALLY_IMPORT',
        financialCategoryName: item.category,
        amount: item.amount,
        sourceAmount: item.amount,
        displayOrder: idx + 1,
        matchStatus: item.matchStatus || 'HEAD_COMPONENT_MATCHED',
        hasTallyExpense: true,
      }));
      const tallyRows = payloadRows.map((row) => ({
        ledgerName: String(row.componentName || '').trim(),
        amount: Number(row.amount),
      }));
      const invalidTallyRow = tallyRows.find(
        (row) =>
          !row.ledgerName || !Number.isFinite(row.amount) || row.amount < 0,
      );
      if (invalidTallyRow) {
        setValidationErrors([
          'Each Tally row must include a ledger name and a non-negative finite amount.',
        ]);
        setErrorMessage(
          'Please correct the invalid Tally row before approval.',
        );
        return;
      }
      console.debug(
        '[OperationalExpense][UploadReview] API request payload: updateOperationalExpenseReport',
        payloadRows,
      );

      const totals = {
        totalDirectCost: directCostTotal,
        totalIndirectCost: indirectCostTotal,
        subtotal,
        markupAmount: markup,
        fixedCostTotal,
        miscellaneousExpenseTotal,
        otherExpenseTotal,
        operationalExpenseTotal: totalBillable,
      };

      let activeReportId = reportId;
      if (!activeReportId) {
        const createdResponse = await generateOperationalExpenseReport({
          reportMonth: period,
          reportDate: invoiceDate,
          reportCode: `OE-${period}`,
          reportName: `Operational Expense Report ${period}`,
          currencyCode: 'INR',
          sourceType: 'TALLY_IMPORT',
          sourceFileName: fileName,
          tallyRows,
          fixedAssets: fixedCosts,
          markup: { percentage: 20, baseAmount: subtotal, amount: markup },
          totals,
          allocations: [],
        });
        activeReportId =
          createdResponse?.data?.data?._id || createdResponse?.data?.data?.id;
        if (!activeReportId)
          throw new Error('The approved report could not be saved.');
        setDraftReportId(activeReportId);
      }

      if (activeReportId) {
        await updateOperationalExpenseReport(activeReportId, {
          reportDate: invoiceDate,
          rows: payloadRows,
          fixedAssets: fixedCosts,
          unmatchedTallyRows: unmatchedRows,
          markup: { percentage: 20, baseAmount: subtotal, amount: markup },
          totals,
        });

        if (status !== 'Allocation Pending') {
          await updateOperationalExpenseReportStatus(
            activeReportId,
            'ALLOCATION_PENDING',
          );
        }

        const successMessage =
          'Uploaded data approved. Moving to client allocation.';
        setToastSeverity('success');
        setToastMessage(successMessage);
        setApprovalComplete(true);
        skipNextNavigationBlockRef.current = true;
        sessionStorage.removeItem(UPLOAD_SESSION_KEY);
        if (allocationRedirectedRef.current) return;
        allocationRedirectedRef.current = true;
        navigate(`/operational-expense-allocation/${activeReportId}`, {
          viewTransition: true,
          state: {
            reportId: activeReportId,
            period,
            invoiceDate,
            totalBillable,
            notification: successMessage,
          },
        });
      }
    } catch (err) {
      console.error('Approval failed:', err);
      const message =
        err?.response?.data?.message || 'Failed to approve source data.';
      setToastSeverity('error');
      setToastMessage(message);
    } finally {
      approveInProgressRef.current = false;
      setIsApproving(false);
    }
  };

  const handleSaveExit = async () => {
    if (leaveAction) return;
    setLeaveAction('save');
    setErrorMessage('');

    try {
      if (!period || !invoiceDate) {
        throw new Error('Select a valid expense period before saving a draft.');
      }

      const payloadRows = expenses.map((item, idx) => ({
        componentName: item.description || item.category,
        componentId: item.componentId,
        componentCode: item.componentCode,
        rowSource: item.rowSource || 'TALLY_IMPORT',
        financialCategoryName: item.category,
        amount: item.amount,
        sourceAmount: item.amount,
        displayOrder: idx + 1,
        matchStatus: item.matchStatus || 'HEAD_COMPONENT_MATCHED',
        hasTallyExpense: true,
      }));
      const totals = {
        totalDirectCost: directCostTotal,
        totalIndirectCost: indirectCostTotal,
        subtotal,
        markupAmount: markup,
        fixedCostTotal,
        miscellaneousExpenseTotal,
        otherExpenseTotal,
        operationalExpenseTotal: totalBillable,
      };
      let activeReportId = reportId;

      if (!activeReportId) {
        const createdResponse = await generateOperationalExpenseReport({
          reportMonth: period,
          reportDate: invoiceDate,
          reportCode: `OE-${period}`,
          reportName: `Operational Expense Report ${period}`,
          currencyCode: 'INR',
          sourceType: 'TALLY_IMPORT',
          sourceFileName: fileName,
          tallyRows: expenses.map((item) => ({
            ledgerName: item.description || item.category,
            amount: item.amount,
          })),
          fixedAssets: fixedCosts,
          markup: { percentage: 20, baseAmount: subtotal, amount: markup },
          totals,
          allocations: [],
        });
        activeReportId =
          createdResponse?.data?.data?._id || createdResponse?.data?.data?.id;
        if (!activeReportId) {
          throw new Error('The draft could not be saved.');
        }
        setDraftReportId(activeReportId);
      }

      await updateOperationalExpenseReport(activeReportId, {
        reportDate: invoiceDate,
        rows: payloadRows,
        fixedAssets: fixedCosts,
        unmatchedTallyRows: unmatchedRows,
        markup: { percentage: 20, baseAmount: subtotal, amount: markup },
        totals,
      });
      if (['Review Pending', 'Draft'].includes(status)) {
        await updateOperationalExpenseReportStatus(activeReportId, 'DRAFT');
      }

      const cachedSession = readUploadSession();
      if (cachedSession?.period === period) {
        sessionStorage.removeItem(UPLOAD_SESSION_KEY);
      }
      setLeaveConfirmOpen(false);
      setStatus('Draft');
      setIsPersistedReport(true);
      skipNextNavigationBlockRef.current = true;
      if (navigationBlockerState === 'blocked') {
        resetNavigation();
      }
      const target = buildOperationalExpenseNavigationTarget(
        'selectMonth',
        location,
      );
      navigate(target.to, {
        replace: true,
        state: {
          ...target.state,
          notification: 'Draft saved successfully.',
        },
      });
    } catch (err) {
      console.error('Save error:', err);
      setErrorMessage(
        err?.response?.data?.message ||
          err?.message ||
          'Could not save the draft. Please remain on this page and try again.',
      );
    } finally {
      setLeaveAction('');
    }
  };

  const handleBackRequest = () => {
    if (hasUnsavedChanges) {
      setLeaveConfirmOpen(true);
      return;
    }
    const target = buildOperationalExpenseNavigationTarget(
      'selectMonth',
      location,
    );
    navigate(target.to, { state: target.state });
  };

  const discardAndGoBack = async () => {
    if (leaveAction) return;
    setLeaveAction('discard');
    setErrorMessage('');

    try {
      if (reportId && status === 'Review Pending') {
        await deleteOperationalExpenseReport(reportId);
      }

      const cachedSession = readUploadSession();
      if (cachedSession?.period === period) {
        sessionStorage.removeItem(UPLOAD_SESSION_KEY);
      }
      setFileName('');
      setPeriod('');
      setInvoiceDate('');
      setExpenses([]);
      setFixedCosts([]);
      setUnmatchedRows([]);
      setDraftReportId('');
      setStatus('Review Pending');
      setToastMessage('');
      setErrorMessage('');
      setValidationErrors([]);
      setExistingRecord(null);
      setExistingRecordOpen(false);
      setMonthMismatchOpen(false);
      setFileInputResetKey((key) => key + 1);
      setLeaveConfirmOpen(false);
      if (navigationBlockerState === 'blocked') {
        resetNavigation();
      }
      const target = buildOperationalExpenseNavigationTarget(
        'selectMonth',
        location,
      );
      skipNextNavigationBlockRef.current = true;
      navigate(target.to, {
        state: {
          ...target.state,
          notification: 'Changes discarded successfully.',
        },
      });
    } catch (err) {
      console.error('Discard error:', err);
      setErrorMessage(
        err?.response?.data?.message ||
          'Could not discard the draft. Please remain on this page and try again.',
      );
    } finally {
      setLeaveAction('');
    }
  };

  const leaveActionButtonSx = {
    width: { xs: '100%', sm: 'auto' },
    minHeight: 42,
    px: 2,
    borderRadius: '10px',
    textTransform: 'none',
    fontWeight: 700,
    '& .MuiButton-startIcon': { mr: 1 },
  };

  return (
    <Box
      inert={isApproving}
      sx={{
        p: { xs: 2, sm: 3, md: 4 },
        maxWidth: 1500,
        margin: '0 auto',
      }}
    >
      <UploadReviewHeader
        title={
          period
            ? `Create ${formatMonthYear(period)} OPEX Report`
            : 'Create OPEX Report'
        }
        status={status}
        onBack={handleBackRequest}
        backDisabled={isApproving}
      />

      <WorkflowStepper status={status} />

      {errorMessage && (
        <Alert
          severity="error"
          sx={{ mb: 3, borderRadius: '10px' }}
          onClose={() => setErrorMessage('')}
        >
          {errorMessage}
        </Alert>
      )}

      {validationErrors.length > 0 && (
        <Alert severity="warning" sx={{ mb: 3, borderRadius: '10px' }}>
          {validationErrors.map((message) => (
            <Box key={message}>{message}</Box>
          ))}
        </Alert>
      )}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
          <CircularProgress size={36} sx={{ color: '#1769ff' }} />
        </Box>
      ) : (
        <>
          <FileUploadZone
            period={period}
            invoiceDate={invoiceDate}
            fileName={fileName}
            fileInputResetKey={fileInputResetKey}
            onFileSelect={handleFileSelect}
            onRemoveFile={handleRemoveFile}
            disabled={isApproving}
          />

          <OperationalExpenseUnmatchedTallyRows
            unmatchedRows={unmatchedRows.filter(isUnresolvedTallyRow)}
            masterComponents={masterComponents}
            financialCategories={financialCategories}
            financialSubCategories={financialSubCategories}
            reviewRequested={unmatchedReviewRequested}
            onReviewRequestHandled={() => setUnmatchedReviewRequested(false)}
            canAdd={
              status !== 'Allocation Pending' &&
              !isInvoiceGeneratedStatus(status)
            }
            busy={isApproving || loading}
            onAddToMaster={handleAddUnmatchedRowToMaster}
            onAddReportOnly={handleAddUnmatchedRowToReport}
            onFinancialCategoryChange={handleFinancialCategoryChange}
            onDiscard={handleDiscardUnmatchedRow}
          />

          <ExpensePreviewTable
            expenses={expenses}
            fixedCosts={fixedCosts}
            directCostTotal={directCostTotal}
            indirectCostTotal={indirectCostTotal}
            subtotal={subtotal}
            markup={markup}
            totalBillable={totalBillable}
            fixedCostTotal={fixedCostTotal}
            miscellaneousExpenseTotal={miscellaneousExpenseTotal}
            onApprove={handleApproveData}
            isApproving={isApproving}
            approveLabel={
              status === 'Allocation Pending'
                ? 'Continue to Allocation'
                : 'Approve data'
            }
            approveProgressLabel={
              status === 'Allocation Pending'
                ? 'Opening Allocation...'
                : 'Approving...'
            }
            allowEmptyApprove={status === 'Allocation Pending' && Boolean(reportId)}
          />
        </>
      )}

      <Dialog
        open={
          isApproving &&
          navigationBlockerState === 'blocked'
        }
        onClose={() => resetNavigation()}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Action Pending</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Report approval is currently in progress. Leaving this page may
            interrupt the process. Do you want to continue?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => resetNavigation()}>Stay on Page</Button>
          <Button
            color="error"
            variant="contained"
            onClick={() => proceedNavigation()}
          >
            Leave Page
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={existingRecordOpen}
        onClose={closeExistingRecordDialog}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          {isInvoiceGeneratedStatus(existingRecord?.status)
            ? 'Invoices Generated'
            : 'Draft'}
        </DialogTitle>
        <DialogContent>
          {isInvoiceGeneratedStatus(existingRecord?.status)
            ? 'Invoices have already been generated for this month.'
            : 'A draft already exists for this expense period.'}
        </DialogContent>
        <DialogActions>
          <Button onClick={closeExistingRecordDialog}>Cancel</Button>
          {isInvoiceGeneratedStatus(existingRecord?.status) ? (
            <>
              <Button onClick={handleViewExistingReport}>View Report</Button>
              <Button variant="contained" onClick={handleViewExistingInvoice}>
                View Invoice
              </Button>
            </>
          ) : (
            <>
              <Button onClick={handleStartOverExisting}>Start Over</Button>
              {pendingExistingUploadFile &&
                existingRecord?.status !== 'ALLOCATION_PENDING' && (
                  <Button onClick={handleAddFileToExistingReport}>
                    Add selected file
                  </Button>
                )}
              <Button variant="contained" onClick={handleContinueExisting}>
                Continue
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>

      <Dialog
        open={replacementConfirmOpen}
        onClose={() => {
          if (!loading) cancelFileReplacement();
        }}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Replace uploaded Tally data?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Replace the report contents, or add this file's matched and unmatched
            rows to the existing report without removing its current entries.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={cancelFileReplacement} disabled={loading}>
            Cancel
          </Button>
          <Button
            onClick={() => confirmFileReplacement(true)}
            disabled={loading || !replacementFile}
          >
            Add file to report
          </Button>
          <Button
            variant="contained"
            onClick={() => confirmFileReplacement(false)}
            disabled={loading || !replacementFile}
          >
            Replace data
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={removeFileConfirmOpen}
        onClose={() => {
          if (!isRemovingFile) setRemoveFileConfirmOpen(false);
        }}
        maxWidth="xs"
        fullWidth
        sx={{ '& .MuiDialog-paper': { borderRadius: '16px' } }}
      >
        <DialogTitle sx={{ px: { xs: 2.5, sm: 3 }, pt: 2.5, pb: 1 }}>
          Remove uploaded file?
        </DialogTitle>
        <DialogContent sx={{ px: { xs: 2.5, sm: 3 }, pb: 1 }}>
          <DialogContentText sx={{ color: '#566277', lineHeight: 1.6 }}>
            Removing this file will also delete its saved draft, if one exists.
          </DialogContentText>
        </DialogContent>
        <DialogActions
          sx={{
            px: { xs: 2.5, sm: 3 },
            pt: 1.5,
            pb: 2.5,
            gap: 1,
            justifyContent: 'flex-end',
            flexDirection: { xs: 'column', sm: 'row' },
            alignItems: { xs: 'stretch', sm: 'center' },
            '& > :not(style) ~ :not(style)': {
              ml: { xs: 0, sm: 1 },
            },
          }}
        >
          <Button
            variant="outlined"
            disabled={isRemovingFile}
            onClick={() => setRemoveFileConfirmOpen(false)}
            sx={leaveActionButtonSx}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            color="error"
            disabled={isRemovingFile}
            startIcon={
              isRemovingFile ? (
                <CircularProgress size={16} color="inherit" />
              ) : (
                <DeleteOutlineRoundedIcon />
              )
            }
            onClick={confirmRemoveFile}
            sx={leaveActionButtonSx}
          >
            {isRemovingFile ? 'Removing...' : 'Remove file'}
          </Button>
        </DialogActions>
      </Dialog>

      <UnsavedChangesDialog
        open={leaveConfirmOpen || navigationBlockerState === 'blocked'}
        loading={Boolean(leaveAction) || loading}
        loadingAction={leaveAction}
        errorMessage={errorMessage}
        onClose={() => {
          setLeaveConfirmOpen(false);
          if (navigationBlockerState === 'blocked') resetNavigation();
        }}
        onDiscard={discardAndGoBack}
        onSave={handleSaveExit}
      />

      <Dialog
        open={monthMismatchOpen}
        onClose={() => setMonthMismatchOpen(false)}
        maxWidth="sm"
        fullWidth
        slotProps={{
          paper: {
            sx: {
              borderRadius: '16px',
              overflow: 'hidden',
              mx: { xs: 2, sm: 3 },
            },
          },
        }}
      >
        <DialogTitle
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1.5,
            px: { xs: 2.5, sm: 3 },
            pt: { xs: 2.5, sm: 3 },
            pb: 1,
            color: '#182036',
            fontSize: { xs: '17px', sm: '19px' },
            fontWeight: 800,
          }}
        >
          <Box
            sx={{
              width: 40,
              height: 40,
              flexShrink: 0,
              borderRadius: '11px',
              display: 'grid',
              placeItems: 'center',
              color: '#b76a00',
              bgcolor: '#fff4df',
            }}
          >
            <WarningAmberRoundedIcon />
          </Box>
          <Box component="span">Month mismatch detected</Box>
        </DialogTitle>
        <DialogContent sx={{ px: { xs: 2.5, sm: 3 }, pt: 1, pb: 2.5 }}>
          <DialogContentText sx={{ color: '#566277', fontSize: '15px', lineHeight: 1.6 }}>
            The uploaded report does not match the selected expense month.
          </DialogContentText>
        </DialogContent>
        <DialogActions
          sx={{
            px: { xs: 2.5, sm: 3 },
            py: 2,
            gap: 1.25,
            borderTop: '1px solid #e6ebf2',
            flexDirection: { xs: 'column-reverse', sm: 'row' },
            alignItems: { xs: 'stretch', sm: 'center' },
            '& > :not(style) ~ :not(style)': {
              ml: { xs: 0, sm: 1 },
            },
            '& .MuiButton-root': {
              width: { xs: '100%', sm: 'auto' },
              minHeight: 44,
              px: 2.5,
              borderRadius: '10px',
              textTransform: 'none',
              fontWeight: 700,
            },
          }}
        >
          <Button
            variant="outlined"
            onClick={() => {
              setMonthMismatchOpen(false);
              navigate('/operational-expense-dashboard', {
                state: { openPeriodSelector: true },
              });
            }}
            sx={{
              borderColor: '#dde3ed',
              color: '#273653',
              '&:hover': { borderColor: '#b9c8dd', bgcolor: '#f6f8fc' },
            }}
          >
            Change Month
          </Button>
          <Button
            variant="contained"
            onClick={() => {
              const fileInput = document.querySelector('input[type="file"]');
              if (!fileInput) {
                setErrorMessage('Could not open the file picker. Please use Choose report.');
                setMonthMismatchOpen(false);
                return;
              }
              fileInput.value = '';
              fileInput.click();
              setMonthMismatchOpen(false);
            }}
            sx={{
              bgcolor: '#1769ff',
              boxShadow: '0 5px 14px rgba(23, 105, 255, 0.22)',
              '&:hover': { bgcolor: '#1255d6' },
            }}
          >
            Re-upload File
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={Boolean(toastMessage)}
        autoHideDuration={3500}
        onClose={() => setToastMessage('')}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setToastMessage('')}
          severity={toastSeverity}
          variant="filled"
          sx={{
            width: '100%',
            alignItems: 'center',
            color: '#fff',
            '& .MuiAlert-icon': {
              color: '#fff',
              alignItems: 'center',
            },
            '& .MuiAlert-message': {
              display: 'flex',
              alignItems: 'center',
            },
            '& .MuiAlert-action': {
              alignItems: 'center',
              color: '#fff',
            },
          }}
        >
          {toastMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
}
