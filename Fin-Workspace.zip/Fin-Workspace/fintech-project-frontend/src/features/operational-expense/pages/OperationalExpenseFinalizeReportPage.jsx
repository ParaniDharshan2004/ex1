import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Snackbar,
  Stack,
  Typography,
} from '@mui/material';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import WorkflowStepper from '../components/common/WorkflowStepper';
import UploadReviewHeader from '../components/upload-review/UploadReviewHeader';
import FinalizeExpenseSummary from '../components/finalize-report/FinalizeExpenseSummary';
import {
  getOperationalExpenseReport,
  getInvoiceAllocations,
} from '../api/operationalExpenseApi';
import api from '../../../services/api/client';
import {
  calculateSubtotal,
  calculateMarkup,
  calculateOperationalExpenseCategoryTotals,
  calculateOtherExpenseTotal,
} from '../utils/expenseCalculations';
import { calculateFixedCostTotal } from '../utils/fixedCostImport';
import { calculateMiscellaneousExpenseTotal } from '../utils/tallyHeadComponentImport';
import { sortClientAllocationsForPreview } from '../utils/clientAllocationUtils';

const firstArray = (...values) => values.find(Array.isArray) || [];
const INVOICE_GENERATED_STATUSES = ['INVOICE_GENERATED', 'INVOICED'];

export default function OperationalExpenseFinalizeReportPage() {
  const { reportId: paramId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const reportId = paramId || location.state?.reportId;
  const [report, setReport] = useState(null);
  const [allocations, setAllocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [successOpen, setSuccessOpen] = useState(false);

  useEffect(() => {
    let active = true;

    const loadReport = async () => {
      if (!reportId) {
        setError('A report ID is required to finalize a report.');
        setLoading(false);
        return;
      }

      try {
        const [reportResponse, allocationResponse] = await Promise.all([
          getOperationalExpenseReport(reportId),
          getInvoiceAllocations(reportId),
        ]);
        if (!active) return;

        const allocationData = allocationResponse.data?.data;
        setReport(reportResponse.data?.data || {});
        setAllocations(
          Array.isArray(allocationData)
            ? allocationData
            : Array.isArray(allocationData?.allocations)
              ? allocationData.allocations
              : [],
        );
      } catch (requestError) {
        if (active) {
          setError(
            requestError?.response?.data?.message ||
              'Unable to load the report.',
          );
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    loadReport();
    return () => {
      active = false;
    };
  }, [reportId]);

  const totals = report?.totals || {};
  const reportRows = firstArray(
    report?.rows,
    report?.reportRows,
    report?.items,
    report?.expenses,
  );
  const subtotal = Number(
    totals.subtotal ||
      totals.operationalExpenseSubtotal ||
      calculateSubtotal(reportRows),
  );
  const markup = Number(
    totals.markupAmount || totals.markup || calculateMarkup(subtotal),
  );
  const rawFixedCosts = firstArray(report?.fixedCosts, report?.fixedAssets);
  const fixedCostTotal = Number(
    totals.fixedCostTotal || calculateFixedCostTotal(rawFixedCosts),
  );
  const miscellaneousExpenseTotal = Number(
    totals.miscellaneousExpenseTotal ||
      totals.miscExpenseTotal ||
      calculateMiscellaneousExpenseTotal(reportRows),
  );
  const otherExpenseTotal = Number(
    totals.otherExpenseTotal || calculateOtherExpenseTotal(reportRows),
  );
  const totalBillable = Number(
    (
      subtotal +
      markup +
      fixedCostTotal +
      miscellaneousExpenseTotal +
      otherExpenseTotal
    ).toFixed(2),
  );
  const expenses = useMemo(
    () =>
      reportRows
        .map((row, index) => ({
          ...row,
          id: row.id || row._id || index,
          description:
            row.description ||
            row.componentName ||
            row.name ||
            row.ledgerName,
          category:
            row.financialCategoryName ||
            row.financialCategory?.name ||
            row.financialCategoryId?.categoryName ||
            row.category ||
            'Operational Expense',
          amount: Number(row.amount || row.finalizedAmount || 0),
        })),
    [reportRows],
  );
  const { directCostTotal, indirectCostTotal } =
    calculateOperationalExpenseCategoryTotals(expenses);
  const fixedCosts = rawFixedCosts;
  const clientAllocationRows = sortClientAllocationsForPreview(allocations);
  const previewReport = useMemo(
    () => ({
      reportMonth: report?.reportMonth || '',
      expenses: expenses.map((expense) => ({
        ...expense,
        displayOrder:
          expense.displayOrder ?? expense.componentDisplayOrder ?? null,
      })),
      fixedCosts,
      allocations: sortClientAllocationsForPreview(allocations),
      totals: {
        directCostTotal,
        indirectCostTotal,
        subtotal,
        markup,
        fixedCostTotal,
        miscExpensesTotal: miscellaneousExpenseTotal,
        otherExpenseTotal,
        operationalExpenseTotal: totalBillable,
      },
    }),
    [
      allocations,
      directCostTotal,
      expenses,
      fixedCostTotal,
      fixedCosts,
      indirectCostTotal,
      markup,
      miscellaneousExpenseTotal,
      otherExpenseTotal,
      report?.reportMonth,
      subtotal,
      totalBillable,
    ],
  );
  const status = String(report?.status || '').toUpperCase();
  const finalized = INVOICE_GENERATED_STATUSES.includes(status);

  const finalize = async () => {
    try {
      setBusy(true);
      await api.post(
        `/api/operationalExpenseRouter/generateOperationalExpenseInvoices/${encodeURIComponent(reportId)}`,
      );
      setReport((current) => ({ ...current, status: 'INVOICE_GENERATED' }));
      setNotice('Report finalized and invoices generated successfully.');
      setSuccessOpen(true);
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          'Could not finalize the report or generate invoices.',
      );
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ p: 6, textAlign: 'center' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: { xs: 2, sm: 3, md: 4 }, maxWidth: 1500, mx: 'auto' }}>
      <UploadReviewHeader
        title="Finalize Report"
        subtitle="Review the completed expense report before finalization."
        onBack={() => navigate(`/operational-expense-allocation/${reportId}`)}
      />
      <WorkflowStepper
        status={finalized ? 'REPORT_FINALIZED' : 'ALLOCATION_COMPLETE'}
      />
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      

      <FinalizeExpenseSummary
        expenses={expenses}
        fixedCosts={fixedCosts}
        directCostTotal={directCostTotal}
        indirectCostTotal={indirectCostTotal}
        subtotal={subtotal}
        markup={markup}
        fixedCostTotal={fixedCostTotal}
        miscellaneousExpenseTotal={miscellaneousExpenseTotal}
        otherExpenseTotal={otherExpenseTotal}
        totalBillable={totalBillable}
        clientAllocations={clientAllocationRows}
        finalized={finalized}
        busy={busy}
        previewReport={previewReport}
        onFinalize={finalize}
      />

      <Dialog
        open={successOpen}
        onClose={() => setSuccessOpen(false)}
        fullWidth
        maxWidth="xs"
      >
        <DialogTitle sx={{ fontWeight: 800 }}>
          <Stack direction="row" spacing={1} sx={{ alignItems: "center", gap: 1 }}>
            <CheckCircleRoundedIcon color="success" />
            Report Finalized Successfully
          </Stack>
        </DialogTitle>
        <DialogContent>
          <Typography color="text.secondary">
            The report has been finalized, editing is locked, and invoices
            have been generated.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            onClick={() => {
              setSuccessOpen(false);
              navigate('/operational-expense-reports', {
                state: {
                  operationalExpenseReportAction: 'download',
                  reportId,
                },
              });
            }}
          >
            Continue
          </Button>
        </DialogActions>
      </Dialog>
      <Snackbar
        open={Boolean(notice)}
        autoHideDuration={4000}
        onClose={() => setNotice('')}
        message={notice}
      />
    </Box>
  );
}
