import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useBlocker } from 'react-router-dom';
import {
  Box,
  Alert,
  Snackbar,
  CircularProgress,
} from '@mui/material';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { buildOperationalExpenseNavigationTarget } from '../utils/navigation';

import WorkflowStepper from '../components/common/WorkflowStepper';
import {
  isInvoiceGeneratedStatus,
} from '../utils/statusHelpers';
import UploadReviewHeader from '../components/upload-review/UploadReviewHeader';
import AllocationKpis from '../components/allocation/AllocationKpis';
import AllocationSplitForm from '../components/allocation/AllocationSplitForm';
import AllocationInvoicePreview from '../components/allocation/AllocationInvoicePreview';
import LiveCalculationCard from '../components/allocation/LiveCalculationCard';
import UnsavedChangesDialog from '../../../shared/components/dialogs/UnsavedChangesDialog';
import api from '../../../services/api/client';
import {
  getOperationalExpenseReport,
  getInvoiceAllocations,
  saveInvoiceAllocation,
  getClientLocations,
} from '../api/operationalExpenseApi';
import {
  calculateCrklBalance,
  calculateCustomLocationSplit,
  calculateEqualLocationSplit,
  validateAllocationState,
} from '../utils/allocationCalculations';
import {
  calculateSubtotal,
  calculateMarkup,
  calculateTotalBillable,
  calculateOtherExpenseTotal,
} from '../utils/expenseCalculations';
import { calculateFixedCostTotal } from '../utils/fixedCostImport';
import { calculateMiscellaneousExpenseTotal } from '../utils/tallyHeadComponentImport';

export default function OperationalExpenseAllocationPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { reportId: paramReportId } = useParams();

  const reportId = paramReportId || location.state?.reportId;
  const [period, setPeriod] = useState(location.state?.period || '');
  const [invoiceDate, setInvoiceDate] = useState(
    location.state?.invoiceDate || '',
  );
  const [reportStatus, setReportStatus] = useState('REVIEW_PENDING');
  const [hasUploadedReport, setHasUploadedReport] = useState(false);
  const [totalBillable, setTotalBillable] = useState(
    Number(location.state?.totalBillable || 0),
  );
  const [subtotal, setSubtotal] = useState(0);
  const [markup, setMarkup] = useState(0);
  const [fixedCostTotal, setFixedCostTotal] = useState(0);
  const [miscellaneousExpenseTotal, setMiscellaneousExpenseTotal] = useState(0);
  const [otherExpenseTotal, setOtherExpenseTotal] = useState(0);

  // Form values
  const [mkplAmount, setMkplAmount] = useState(0);
  const [splitMethod, setSplitMethod] = useState('equal');
  const [chennaiAmount, setChennaiAmount] = useState(0);
  const [bengaluruAmount, setBengaluruAmount] = useState(0);
  const [savedAllocation, setSavedAllocation] = useState({
    mkplAmount: 0,
    chennaiAmount: 0,
    bengaluruAmount: 0,
    splitMethod: 'equal',
  });
  const savedAllocationRef = useRef(savedAllocation);

  // Clients & Locations metadata
  const [clients, setClients] = useState([]);
  const [mkplLocations, setMkplLocations] = useState([]);

  // UI state
  const [loading, setLoading] = useState(Boolean(reportId));
  const [errorMessage, setErrorMessage] = useState('');
  const [backConfirmationOpen, setBackConfirmationOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState(
    location.state?.notification || '',
  );
  const [leaveAction, setLeaveAction] = useState('');
  const [isSavingAllocation, setIsSavingAllocation] = useState(false);
  const [invoicePreviewOpen, setInvoicePreviewOpen] = useState(false);
  const saveAllocationInProgressRef = useRef(false);
  const discardInProgressRef = useRef(false);
  const skipNextNavigationBlockRef = useRef(false);

  const hasUnsavedChanges =
    reportStatus === 'ALLOCATION_PENDING' &&
    (Math.abs(mkplAmount - savedAllocation.mkplAmount) >= 0.01 ||
      Math.abs(chennaiAmount - savedAllocation.chennaiAmount) >= 0.01 ||
      Math.abs(
        bengaluruAmount - savedAllocation.bengaluruAmount,
      ) >= 0.01 ||
      splitMethod !== savedAllocation.splitMethod);
  const shouldBlockNavigation = useCallback(
    ({ currentLocation, nextLocation }) =>
      !skipNextNavigationBlockRef.current &&
      hasUnsavedChanges &&
      currentLocation.pathname !== nextLocation.pathname,
    [hasUnsavedChanges],
  );
  const navigationBlocker = useBlocker(shouldBlockNavigation);
  const {
    state: navigationBlockerState,
    proceed: proceedNavigation,
    reset: resetNavigation,
  } = navigationBlocker;

  // Fetch report details & clients
  useEffect(() => {
    const initData = async () => {
      try {
        setLoading(true);

        // Fetch active clients from master API
        let activeClients = [];
        try {
          const clientRes = await api.get('/api/clientRouter/getActiveClients');
          activeClients = Array.isArray(clientRes.data?.data)
            ? clientRes.data.data
            : [];
          setClients(activeClients);
        } catch (e) {
          console.warn('Could not load active clients:', e);
        }

        // Find MKPL client and fetch its locations
        const mkplClient = activeClients.find(
          (c) =>
            (c.clientCode || '').toUpperCase().includes('MKPL') ||
            (c.clientName || '').toUpperCase().includes('MKPL'),
        );

        if (mkplClient) {
          try {
            const locRes = await getClientLocations(mkplClient._id);
            setMkplLocations(locRes.data?.data || []);
          } catch (e) {
            console.warn('Could not load MKPL locations:', e);
          }
        }

        // Fetch report data if reportId exists
        if (reportId) {
          const reportRes = await getOperationalExpenseReport(reportId);
          const rep = reportRes.data?.data;
          if (rep) {
            setHasUploadedReport(Boolean(
              rep.sourceFileName ||
              rep.rows?.length ||
              rep.fixedCosts?.length ||
              Number(rep.totals?.operationalExpenseTotal || 0) > 0,
            ));
            if (rep.status) setReportStatus(rep.status);
            setPeriod(rep.reportMonth || '');
            if (rep.reportDate)
              setInvoiceDate(String(rep.reportDate).slice(0, 10));

            const s = Number(
              rep.totals?.subtotal || calculateSubtotal(rep.rows || []),
            );
            const m = Number(rep.totals?.markupAmount || calculateMarkup(s));
            const fixed = Number(
              rep.totals?.fixedCostTotal ||
                calculateFixedCostTotal(rep.fixedAssets || []),
            );
            const miscellaneous = Number(
              rep.totals?.miscellaneousExpenseTotal ||
                calculateMiscellaneousExpenseTotal(rep.rows || []),
            );
            const other = Number(
              rep.totals?.otherExpenseTotal ||
                calculateOtherExpenseTotal(rep.rows || []),
            );
            const t = calculateTotalBillable(
              s,
              m,
              fixed + miscellaneous + other,
            );
            setSubtotal(s);
            setMarkup(m);
            setFixedCostTotal(fixed);
            setMiscellaneousExpenseTotal(miscellaneous);
            setOtherExpenseTotal(other);
            setTotalBillable(t);

            // Fetch existing allocations
            try {
              const allocRes = await getInvoiceAllocations(reportId);
              const allocList = allocRes.data?.data || [];
              const mkplAlloc = allocList.find(
                (a) =>
                  String(a.clientId) === String(mkplClient?._id) ||
                  (a.clientName || '').toUpperCase().includes('MKPL'),
              );

              if (mkplAlloc) {
                const mkplVal = Number(mkplAlloc.clientTotalAmount || 0);
                const locs = mkplAlloc.locationAllocations || [];
                const chennaiLoc = locs.find((l) =>
                  (l.locationName || '').toLowerCase().includes('chennai'),
                );
                const blrLoc = locs.find(
                  (l) =>
                    (l.locationName || '')
                      .toLowerCase()
                      .includes('bengaluru') ||
                    (l.locationName || '').toLowerCase().includes('bangalore'),
                );

                let savedChennaiAmount = 0;
                let savedBengaluruAmount = 0;
                let savedSplitMethod = 'equal';
                if (chennaiLoc && blrLoc) {
                  savedChennaiAmount = Number(chennaiLoc.amount || 0);
                  savedBengaluruAmount = Number(blrLoc.amount || 0);
                  const isEq =
                    Math.abs(
                    Number(chennaiLoc.amount) - Number(blrLoc.amount),
                    ) < 0.02;
                  savedSplitMethod = isEq ? 'equal' : 'custom';
                } else if (mkplVal > 0) {
                  const eq = calculateEqualLocationSplit(mkplVal);
                  savedChennaiAmount = eq.chennai;
                  savedBengaluruAmount = eq.bengaluru;
                }

                setMkplAmount(mkplVal);
                setChennaiAmount(savedChennaiAmount);
                setBengaluruAmount(savedBengaluruAmount);
                setSplitMethod(savedSplitMethod);
                const loadedAllocation = {
                  mkplAmount: mkplVal,
                  chennaiAmount: savedChennaiAmount,
                  bengaluruAmount: savedBengaluruAmount,
                  splitMethod: savedSplitMethod,
                };
                savedAllocationRef.current = loadedAllocation;
                setSavedAllocation(loadedAllocation);
              } else {
                const emptyAllocation = {
                  mkplAmount: 0,
                  chennaiAmount: 0,
                  bengaluruAmount: 0,
                  splitMethod: 'equal',
                };
                setMkplAmount(0);
                setChennaiAmount(0);
                setBengaluruAmount(0);
                setSplitMethod('equal');
                savedAllocationRef.current = emptyAllocation;
                setSavedAllocation(emptyAllocation);
              }
            } catch (allocationError) {
              console.error(
                'Could not load saved allocations:',
                allocationError,
              );
              setErrorMessage(
                allocationError?.response?.data?.message ||
                  'Failed to load saved allocation data.',
              );
            }
          }
        }
      } catch (err) {
        console.error('Initialization error:', err);
        if (err?.response?.status === 404) {
          navigate('/operational-expense-dashboard', {
            state: {
              notification: 'No operational expense report is available for this record.',
            },
          });
          return;
        }
        setErrorMessage('Failed to load allocation data from the server.');
      } finally {
        setLoading(false);
      }
    };

    initData();
  }, [reportId, navigate]);

  useEffect(() => {
    if (!reportId || !period) return;
    const searchParams = new URLSearchParams(location.search);
    if (searchParams.get('period') === period) return;

    searchParams.set('period', period);
    navigate(
      { pathname: location.pathname, search: `?${searchParams.toString()}` },
      {
        replace: true,
        state: { ...location.state, reportId, period },
      },
    );
  }, [
    location.pathname,
    location.search,
    location.state,
    navigate,
    period,
    reportId,
  ]);

  useEffect(() => {
    if (!hasUnsavedChanges) return undefined;
    const handleBeforeUnload = (event) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  // Handle MKPL amount change
  const handleMkplAmountChange = (val) => {
    const num = Math.max(0, parseFloat(val) || 0);
    setMkplAmount(num);

    if (splitMethod === 'equal') {
      const eq = calculateEqualLocationSplit(num);
      setChennaiAmount(eq.chennai);
      setBengaluruAmount(eq.bengaluru);
    } else {
      const split = calculateCustomLocationSplit(
        num,
        chennaiAmount,
        'chennai',
      );
      setChennaiAmount(split.chennai);
      setBengaluruAmount(split.bengaluru);
    }
  };

  // Handle Split Method change
  const handleSplitMethodChange = (method) => {
    setSplitMethod(method);
    if (method === 'equal') {
      const eq = calculateEqualLocationSplit(mkplAmount);
      setChennaiAmount(eq.chennai);
      setBengaluruAmount(eq.bengaluru);
    } else {
      const split = calculateCustomLocationSplit(
        mkplAmount,
        chennaiAmount,
        'chennai',
      );
      setChennaiAmount(split.chennai);
      setBengaluruAmount(split.bengaluru);
    }
  };

  const handleCustomLocationAmountChange = (locationName, value) => {
    const amount = Math.max(0, parseFloat(value) || 0);
    const split = calculateCustomLocationSplit(
      mkplAmount,
      amount,
      locationName,
    );
    setChennaiAmount(split.chennai);
    setBengaluruAmount(split.bengaluru);
  };

  // Calculated CRKL balance
  const crklBalance = useMemo(() => {
    return calculateCrklBalance(totalBillable, mkplAmount);
  }, [totalBillable, mkplAmount]);

  // Validation
  const validationResult = useMemo(() => {
    return validateAllocationState(
      totalBillable,
      mkplAmount,
      chennaiAmount,
      bengaluruAmount,
      splitMethod,
    );
  }, [totalBillable, mkplAmount, chennaiAmount, bengaluruAmount, splitMethod]);

  // Handle draft preview for Chennai or Bengaluru

  const handleReviewAndGenerate = async () => {
    if (!validationResult.isValid) return;
    if (!reportId) {
      setErrorMessage('Report ID is missing. Unable to open the report preview.');
      return;
    }

    setErrorMessage('');
    const saved = await handleSaveAllocation({ showToast: false });
    if (!saved) return;

    skipNextNavigationBlockRef.current = true;
    navigate(`/operational-expense-finalize/${reportId}`, {
      state: { reportId, period, invoiceDate },
    });
  };

  const handleSaveAllocation = async ({ showToast = true } = {}) => {
    if (isInvoiceGeneratedStatus(reportStatus)) {
      setErrorMessage('Allocation cannot be changed after invoices are generated.');
      return false;
    }
    if (saveAllocationInProgressRef.current) return false;

    saveAllocationInProgressRef.current = true;
    setIsSavingAllocation(true);
    setLeaveAction('save');
    setErrorMessage('');
    try {
      if (!reportId) {
        throw new Error('Report ID is missing. Unable to save allocation.');
      }

      const mkplClient = clients.find(
        (client) =>
          (client.clientCode || '').toUpperCase().includes('MKPL') ||
          (client.clientName || '').toUpperCase().includes('MKPL'),
      );
      if (!mkplClient) {
        throw new Error('MKPL client was not found. Unable to save allocation.');
      }
      const chennaiLoc = mkplLocations.find((locationItem) =>
        (locationItem.locationName || '').toLowerCase().includes('chennai'),
      );
      const blrLoc = mkplLocations.find(
        (locationItem) =>
          (locationItem.locationName || '').toLowerCase().includes('bengaluru') ||
          (locationItem.locationName || '').toLowerCase().includes('bangalore'),
      );

      if (!chennaiLoc || !blrLoc) {
        throw new Error(
          'Both Chennai and Bengaluru locations are required to save the allocation.',
        );
      }

      const locationAllocations = [
        { locationId: chennaiLoc._id, amount: chennaiAmount },
        { locationId: blrLoc._id, amount: bengaluruAmount },
      ];
      const allocationResponse = await saveInvoiceAllocation(reportId, {
        clientId: mkplClient._id,
        clientTotalAmount: mkplAmount,
        allocationStatus: 'CONFIRMED',
        locationAllocations,
      });

      const persistedAllocation = allocationResponse.data?.data;
      if (!persistedAllocation) {
        throw new Error('The server did not return the saved allocation.');
      }
      const persistedLocations = persistedAllocation.locationAllocations || [];
      const savedChennai = persistedLocations.find(
        (item) => String(item.locationId) === String(chennaiLoc._id),
      );
      const savedBengaluru = persistedLocations.find(
        (item) => String(item.locationId) === String(blrLoc._id),
      );
      if (!savedChennai || !savedBengaluru) {
        throw new Error(
          'The server response did not include both saved location amounts.',
        );
      }

      const savedAmounts = [
        Number(persistedAllocation.clientTotalAmount),
        Number(savedChennai.amount),
        Number(savedBengaluru.amount),
      ];
      if (!savedAmounts.every(Number.isFinite)) {
        throw new Error('The server returned invalid saved allocation amounts.');
      }

      const completedAllocation = {
        mkplAmount: savedAmounts[0],
        chennaiAmount: savedAmounts[1],
        bengaluruAmount: savedAmounts[2],
        splitMethod,
      };
      setMkplAmount(completedAllocation.mkplAmount);
      setChennaiAmount(completedAllocation.chennaiAmount);
      setBengaluruAmount(completedAllocation.bengaluruAmount);
      savedAllocationRef.current = completedAllocation;
      setSavedAllocation(completedAllocation);
      if (showToast) setToastMessage('Allocation saved successfully.');
      setBackConfirmationOpen(false);
      if (navigationBlockerState === 'blocked') resetNavigation();
      return true;
    } catch (err) {
      console.error('Allocation save error:', err);
      setErrorMessage(
        err?.response?.data?.message ||
          err?.message ||
          'Could not save allocation. Please try again.',
      );
      return false;
    } finally {
      saveAllocationInProgressRef.current = false;
      setIsSavingAllocation(false);
      setLeaveAction('');
    }
  };

  const handleBackRequest = () => {
    if (hasUnsavedChanges) {
      setBackConfirmationOpen(true);
      return;
    }

    const target = buildOperationalExpenseNavigationTarget(
      'uploadReview',
      location,
    );
    navigate(target.to, { state: target.state });
  };

  const handleContinueEditing = () => {
    setBackConfirmationOpen(false);
    if (navigationBlockerState === 'blocked') resetNavigation();
  };

  const handleDiscardAllocation = () => {
    if (leaveAction || discardInProgressRef.current) return;
    discardInProgressRef.current = true;
    setLeaveAction('discard');
    setMkplAmount(savedAllocationRef.current.mkplAmount);
    setChennaiAmount(savedAllocationRef.current.chennaiAmount);
    setBengaluruAmount(savedAllocationRef.current.bengaluruAmount);
    setSplitMethod(savedAllocationRef.current.splitMethod);
    setErrorMessage('');
    if (navigationBlockerState === 'blocked') {
      proceedNavigation();
    }
    setBackConfirmationOpen(false);
    discardInProgressRef.current = false;
    setLeaveAction('');
  };

  return (
    <Box sx={{ p: { xs: 2, sm: 3, md: 4 }, maxWidth: 1500, margin: '0 auto' }}>
   

      <UploadReviewHeader
        title="Allocation"
        subtitle=""
        status="Allocation Pending"
        onSaveExit={handleBackRequest}
        onBack={handleBackRequest}
      />

      <WorkflowStepper status={reportStatus} />

      {errorMessage && (
        <Alert
          severity="error"
          sx={{ mb: 3, borderRadius: '10px' }}
          onClose={() => setErrorMessage('')}
        >
          {errorMessage}
        </Alert>
      )}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
          <CircularProgress size={36} sx={{ color: '#1769ff' }} />
        </Box>
      ) : (
        <>
          {/* KPI Summary Cards */}
          <AllocationKpis
            totalBillable={totalBillable}
            allocatedTotal={mkplAmount}
            remainingBalance={crklBalance}
          />

          {/* Split Layout: Left Form + Right Live Calculation Card */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: {
                xs: '1fr',
                lg: 'minmax(0, 1.35fr) minmax(320px, 0.65fr)',
              },
              gap: 2.5,
              alignItems: 'start',
            }}
          >
            <AllocationSplitForm
              mkplAmount={mkplAmount}
              onMkplAmountChange={handleMkplAmountChange}
              crklBalance={crklBalance}
              splitMethod={splitMethod}
              onSplitMethodChange={handleSplitMethodChange}
              chennaiAmount={chennaiAmount}
              onChennaiAmountChange={(val) =>
                handleCustomLocationAmountChange('chennai', val)
              }
              bengaluruAmount={bengaluruAmount}
              onBengaluruAmountChange={(val) =>
                handleCustomLocationAmountChange('bengaluru', val)
              }
              validationResult={validationResult}
              onReviewAndGenerate={handleReviewAndGenerate}
              onPreviewInvoices={() => setInvoicePreviewOpen(true)}
              isGenerating={isSavingAllocation}
              disabled={!hasUploadedReport || reportStatus !== 'ALLOCATION_PENDING'}
            />

            <LiveCalculationCard
              subtotal={subtotal}
              markup={markup}
              fixedCostTotal={fixedCostTotal}
              miscellaneousExpenseTotal={miscellaneousExpenseTotal}
              otherExpenseTotal={otherExpenseTotal}
              totalBillable={totalBillable}
              mkplAmount={mkplAmount}
              crklBalance={crklBalance}
            />
          </Box>
        </>
      )}

      <Snackbar
        open={Boolean(toastMessage)}
        autoHideDuration={3500}
        onClose={() => setToastMessage('')}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setToastMessage('')}
          severity="success"
          variant="filled"
          sx={{
            width: '100%',
            borderRadius: '12px',
            fontWeight: 700,
            alignItems: 'center',
            color: '#fff',
            '& .MuiAlert-icon': {
              display: 'flex',
              alignItems: 'center',
              color: '#fff',
            },
            '& .MuiAlert-message': {
              display: 'flex',
              alignItems: 'center',
              color: '#fff',
            },
            '& .MuiAlert-action': {
              color: '#fff',
            },
          }}
        >
          {toastMessage}
        </Alert>
      </Snackbar>

      <AllocationInvoicePreview
        open={invoicePreviewOpen}
        onClose={() => setInvoicePreviewOpen(false)}
        reportId={reportId}
        clients={clients}
        mkplLocations={mkplLocations}
        chennaiAmount={chennaiAmount}
        bengaluruAmount={bengaluruAmount}
      />

      <UnsavedChangesDialog
        open={
          backConfirmationOpen || navigationBlockerState === 'blocked'
        }
        loading={Boolean(leaveAction) || isSavingAllocation}
        loadingAction={leaveAction || (isSavingAllocation ? 'save' : '')}
        errorMessage={errorMessage}
        title="Save Allocation Changes?"
        message="Your allocation has unsaved changes. Save them, discard them, or continue editing."
        continueLabel="Continue"
        onClose={handleContinueEditing}
        onContinue={handleContinueEditing}
        onDiscard={handleDiscardAllocation}
        onSave={handleSaveAllocation}
      />
    </Box>
  );
}
