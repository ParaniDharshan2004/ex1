import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box,
  Typography,
  Button,
  CircularProgress,
  Alert,
  Snackbar,
} from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import { useLocation, useNavigate } from 'react-router-dom';
import DashboardKpis from '../components/dashboard/DashboardKpis';
import MonthlyRecordsTable from '../components/dashboard/MonthlyRecordsTable';
import PeriodCheckPage from '../components/dashboard/PeriodCheckModal';
import AuditTrailModal from '../components/reports/AuditTrailModal';
import {
  getOperationalExpenseReports,
  deleteOperationalExpenseReport,
} from '../api/operationalExpenseApi';
import {
  transformReportSummary,
  calculateDashboardKpis,
} from '../utils/reportTransformers';
import { formatDateTime } from '../utils/date';
import {
  isInvoiceGeneratedStatus,
  mapStatusToDisplay,
} from '../utils/statusHelpers';
import { buildOperationalExpenseNavigationTarget } from '../utils/navigation';
import ActionConfirmationDialog from '../../../shared/components/dialogs/ActionConfirmationDialog';

export default function OperationalExpenseDashboardPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [successToast, setSuccessToast] = useState('');

  const [selectedYear, setSelectedYear] = useState('2026');
  const [selectedMonth, setSelectedMonth] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [deleteCandidate, setDeleteCandidate] = useState(null);
  const [startOverCandidate, setStartOverCandidate] = useState(null);
  const [deleteError, setDeleteError] = useState('');
  const [deletingRecordId, setDeletingRecordId] = useState('');
  const [startingRecordId, setStartingRecordId] = useState('');
  const deleteInProgressRef = useRef(false);
  const searchParams = new URLSearchParams(location.search);
  const isPeriodSelection =
    searchParams.get('step') === 'select-month';
  const selectedExpensePeriod = searchParams.get('period') || '';
  const selectedExpenseYear =
    selectedExpensePeriod.slice(0, 4) || searchParams.get('year') || '2026';

  useEffect(() => {
    const shouldOpenPeriodSelector = location.state?.openPeriodSelector;
    const notification = location.state?.notification;
    if (!shouldOpenPeriodSelector && !notification) return undefined;

    const timer = window.setTimeout(() => {
      if (notification) setSuccessToast(notification);
      const params = new URLSearchParams(location.search);
      if (shouldOpenPeriodSelector) {
        params.set('step', 'select-month');
        const period = location.state?.period || '';
        if (period) {
          params.set('period', period);
          params.set('year', period.slice(0, 4));
        }
      }
      const search = params.size ? `?${params.toString()}` : '';
      navigate(
        { pathname: location.pathname, search },
        { replace: true, state: {} },
      );
    }, 0);

    return () => window.clearTimeout(timer);
  }, [location.pathname, location.search, location.state, navigate]);

  // Fetch real reports from backend API
  useEffect(() => {
    let active = true;
    const fetchReports = async () => {
      try {
        setLoading(true);
        setErrorMessage('');
        const response = await getOperationalExpenseReports();
        console.debug('[OperationalExpense][Dashboard] API response: getOperationalExpenseReports', response.data);
        if (active) {
          const rawList = Array.isArray(response.data?.data)
            ? response.data.data
            : [];
          setReports(rawList);
        }
      } catch (err) {
        if (active) {
          console.error('Failed to load operational expense reports:', err);
          setErrorMessage(
            err.response?.data?.message || 'Failed to load operational expense reports from the server.'
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    fetchReports();
    return () => {
      active = false;
    };
  }, []);

  // Transformed reports list
  const transformedList = useMemo(() => {
    return reports.map((r) => transformReportSummary(r));
  }, [reports]);

  // Derived available years
  const availableYears = useMemo(() => {
    const years = new Set();
    transformedList.forEach((r) => {
      if (r.period && r.period.length >= 4) {
        years.add(r.period.slice(0, 4));
      }
    });
    return Array.from(years).sort().reverse();
  }, [transformedList]);

  // Filtered reports by year and search query
  const filteredRecords = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return transformedList.filter((r) => {
      const matchesYear = r.period.startsWith(selectedYear);
      const matchesMonth = selectedMonth === 'all' || r.period.endsWith(`-${selectedMonth}`);
      const matchesSearch =
        !q ||
        r.period.toLowerCase().includes(q) ||
        r.periodFormatted.toLowerCase().includes(q) ||
        r.draftCode.toLowerCase().includes(q) ||
        r.status.toLowerCase().includes(q);
      return matchesYear && matchesMonth && matchesSearch;
    });
  }, [transformedList, selectedYear, selectedMonth, searchTerm]);

  // KPI Calculations
  const kpis = useMemo(() => {
    return calculateDashboardKpis(reports);
  }, [reports]);

  // Handle Create New Record action
  const handleCreateNewRecord = (period) => {
    const state = { period };
    const params = new URLSearchParams(location.search);
    params.delete('step');
    params.delete('reportId');
    params.set('period', period);
    for (const key of ['clientId', 'client', 'locationId', 'location']) {
      const value = location.state?.[key] || params.get(key);
      if (value) state[key] = value;
    }
    navigate(
      { pathname: '/operational-expenses', search: `?${params.toString()}` },
      { state },
    );
  };

  const handleOpenPeriodSelection = () => {
    const params = new URLSearchParams(location.search);
    params.set('step', 'select-month');
    const period = location.state?.period || params.get('period') || '';
    if (period) {
      params.set('period', period);
      params.set('year', period.slice(0, 4));
    }
    navigate(
      { pathname: location.pathname, search: `?${params.toString()}` },
      { state: location.state },
    );
  };

  const handleSelectionPeriodChange = (period, year) => {
    const params = new URLSearchParams(location.search);
    params.set('step', 'select-month');
    if (period) params.set('period', period);
    else params.delete('period');
    if (year) params.set('year', year);
    navigate(
      { pathname: location.pathname, search: `?${params.toString()}` },
      {
        replace: true,
        state: { ...location.state, period: period || undefined },
      },
    );
  };

  const handleBackToDashboard = () => {
    const target = buildOperationalExpenseNavigationTarget(
      'dashboard',
      location,
    );
    navigate(target.to, { state: target.state });
  };

  // Continue existing draft
  const handleContinueDraft = (record) => {
    const reportId = record.id;
    const raw = record.rawReport;
    const routeKey = isInvoiceGeneratedStatus(raw?.status)
      ? 'invoices'
      : raw?.status === 'ALLOCATION_PENDING'
        ? 'allocation'
        : 'uploadReview';
    const target = buildOperationalExpenseNavigationTarget(routeKey, {
      ...location,
      state: { ...location.state, reportId, period: record.period },
    });
    if (isInvoiceGeneratedStatus(raw?.status)) {
      navigate(target.to, { state: target.state });
    } else if (raw?.status === 'ALLOCATION_PENDING') {
      navigate(target.to, { state: target.state });
    } else {
      navigate(target.to, { state: target.state });
    }
  };

  // View locked invoices
  const handleViewLocked = (record) => {
    const target = buildOperationalExpenseNavigationTarget('invoices', {
      ...location,
      state: {
        ...location.state,
        reportId: record.id,
        period: record.period,
      },
    });
    const params = new URLSearchParams(target.to.search);
    params.set('month', record.period);
    navigate(
      { ...target.to, search: `?${params.toString()}` },
      { state: target.state },
    );
  };

  const handleViewReport = (record) => {
    const [year, month] = record.period.split('-');
    navigate(`/operational-expense-reports?year=${year}&month=${month}`, {
      state: { period: record.period },
    });
  };

  // Start Again / Restart
  const handleStartAgain = async (record, period) => {
    if (!['REVIEW_PENDING', 'ALLOCATION_PENDING'].includes(record?.rawStatus)) {
      setErrorMessage('Only pending drafts can be restarted.');
      return;
    }
    try {
      setLoading(true);
      if (!record?.id) {
        throw new Error('Report ID is missing. Unable to restart this report.');
      }

      await deleteOperationalExpenseReport(record.id);
      handleCreateNewRecord(period);
      return true;
    } catch (err) {
      console.error('Failed to restart record:', err);
      setErrorMessage(err.response?.data?.message || 'Failed to reset draft record.');
      setLoading(false);
      return false;
    }
  };

  const handleConfirmStartOver = async () => {
    if (!startOverCandidate || startingRecordId) return;
    setStartingRecordId(startOverCandidate.id);
    const succeeded = await handleStartAgain(
      startOverCandidate,
      startOverCandidate.period,
    );
    setStartingRecordId('');
    if (succeeded) setStartOverCandidate(null);
  };

  const handleRequestDelete = (record) => {
    if (isInvoiceGeneratedStatus(record?.rawStatus)) return;
    setDeleteError('');
    setDeleteCandidate(record);
  };

  const handleConfirmDelete = async () => {
    if (
      !deleteCandidate ||
      isInvoiceGeneratedStatus(deleteCandidate.rawStatus) ||
      deleteInProgressRef.current
    ) {
      return;
    }

    deleteInProgressRef.current = true;
    setDeletingRecordId(deleteCandidate.id);
    setDeleteError('');
    let deleted = false;
    try {
      await deleteOperationalExpenseReport(deleteCandidate.id);
      deleted = true;

      const response = await getOperationalExpenseReports();
      const refreshedReports = Array.isArray(response.data?.data)
        ? response.data.data
        : [];
      setReports(refreshedReports);
      setDeleteCandidate(null);
      setSuccessToast('Draft deleted successfully.');
    } catch (err) {
      console.error('Failed to delete operational expense draft:', err);
      if (deleted) {
        setReports((currentReports) =>
          currentReports.filter(
            (report) =>
              String(report._id || report.id) !== String(deleteCandidate.id),
          ),
        );
        setDeleteCandidate(null);
        setSuccessToast('Draft deleted successfully.');
        setErrorMessage(
          'The draft was deleted, but the records list could not be refreshed.',
        );
      } else {
        setDeleteError(
          err?.response?.data?.message || 'Failed to delete the report.',
        );
      }
    } finally {
      deleteInProgressRef.current = false;
      setDeletingRecordId('');
    }
  };

  // Derive audit events from real reports for integrated audit modal
  const auditEvents = useMemo(() => {
    return reports.map((r) => ({
      time: r.updatedAt ? formatDateTime(r.updatedAt) : formatDateTime(r.createdAt),
      record: r.reportCode || `OE-${r.reportMonth}`,
      action:
        isInvoiceGeneratedStatus(r.status)
          ? 'Invoices Generated'
          : r.status === 'FINALIZED'
          ? 'Allocations Confirmed'
          : 'Report Updated',
      user: r.updatedBy?.username || r.createdBy?.username || 'Finance Operations',
      detail: `Status: ${mapStatusToDisplay(r.status).label}; Total: ₹${Number(r.totals?.operationalExpenseTotal || 0).toLocaleString('en-IN')}`,
    }));
  }, [reports]);

  return (
    <Box sx={{ p: { xs: 2, sm: 3, md: 4 }, maxWidth: 1500, margin: '0 auto' }}>
      {isPeriodSelection ? (
        <>
          {errorMessage && (
            <Alert
              severity="error"
              sx={{ mb: 3, borderRadius: '10px' }}
              onClose={() => setErrorMessage('')}
            >
              {errorMessage}
            </Alert>
          )}
          <PeriodCheckPage
            initialPeriod={selectedExpensePeriod}
            initialYear={selectedExpenseYear}
            records={transformedList}
            loading={loading}
            onPeriodChange={handleSelectionPeriodChange}
            onBack={handleBackToDashboard}
            onCreateNew={handleCreateNewRecord}
            onContinueDraft={handleContinueDraft}
            onViewLocked={handleViewReport}
          />
        </>
      ) : (
        <>
      
      {/* Page Header */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: { xs: 'flex-start', sm: 'center' },
          flexDirection: { xs: 'column', sm: 'row' },
          gap: 2,
          mb: 3,
        }}
      >
        <Box>
          <Typography
            variant="h4"
            
          >
            Operational Expense Dashboard
          </Typography>
          
        </Box>

        <Button
          variant="contained"
          startIcon={<AddRoundedIcon sx={{ fontSize: 18 }} />}
          onClick={handleOpenPeriodSelection}
          sx={{
            bgcolor: 'rgb(23, 105, 255)',
            color: '#fff',
            textTransform: 'none',
            fontWeight: 800,
            fontSize: '13px',
            borderRadius: '9px',
            px: 2.5,
            py: 1.1,
            boxShadow: '0 7px 18px rgba(23, 105, 255, 0.28)',
            '&:hover': { bgcolor: '#1255d6' },
          }}
        >
          Create record
        </Button>
      </Box>

      {/* Error Banner */}
      {errorMessage && (
        <Alert severity="error" sx={{ mb: 3, borderRadius: '10px' }} onClose={() => setErrorMessage('')}>
          {errorMessage}
        </Alert>
      )}

      {/* KPI Cards */}
      <DashboardKpis
        totalRecords={kpis.totalRecords}
        pendingActions={kpis.pendingActions}
        completed={kpis.completed}
        invoicedValue={kpis.invoicedValue}
      />

      {/* Monthly Records Table */}
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
          <CircularProgress size={36} sx={{ color: '#1769ff' }} />
        </Box>
      ) : (
        <MonthlyRecordsTable
          records={filteredRecords}
          selectedYear={selectedYear}
          onYearChange={setSelectedYear}
          selectedMonth={selectedMonth}
          onMonthChange={setSelectedMonth}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          availableYears={availableYears}
          onContinue={handleContinueDraft}
          onView={handleViewLocked}
          onViewReport={handleViewReport}
          onRestart={(r) => setStartOverCandidate(r)}
          onDelete={handleRequestDelete}
          deletingRecordId={deletingRecordId}
        />
      )}

      <ActionConfirmationDialog
        open={Boolean(startOverCandidate)}
        title="Start over?"
        message="This will clear the current progress and restart the process. Continue?"
        confirmLabel="Start over"
        loadingLabel="Starting over..."
        loading={Boolean(startingRecordId)}
        onCancel={() => setStartOverCandidate(null)}
        onConfirm={handleConfirmStartOver}
      />

      <ActionConfirmationDialog
        open={Boolean(deleteCandidate)}
        title="Delete this report?"
        message="This report and its saved draft data will be permanently deleted. Do you want to continue?"
        confirmLabel="Delete report"
        loadingLabel="Deleting..."
        loading={Boolean(deletingRecordId)}
        errorMessage={deleteError}
        onCancel={() => setDeleteCandidate(null)}
        onConfirm={handleConfirmDelete}
      />

      {/* Integrated Audit Trail Modal */}
      <AuditTrailModal
        open={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
        auditEvents={auditEvents}
      />
        </>
      )}

      {/* Success Notification */}
      <Snackbar
        open={Boolean(successToast)}
        autoHideDuration={3500}
        onClose={() => setSuccessToast('')}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setSuccessToast('')}
          severity="success"
          variant="filled"
          sx={{
            width: '100%',
            borderRadius: '12px',
            alignItems: 'center',
            color: '#fff',
            '& .MuiAlert-icon': {
              display: 'flex',
              alignItems: 'center',
              color: '#fff',
            },
            '& .MuiAlert-message': {
              display: 'flex',
              alignItems: 'center',
              color: '#fff',
            },
            '& .MuiAlert-action': {
              color: '#fff',
            },
          }}
        >
          {successToast}
        </Alert>
      </Snackbar>
    </Box>
  );
}
