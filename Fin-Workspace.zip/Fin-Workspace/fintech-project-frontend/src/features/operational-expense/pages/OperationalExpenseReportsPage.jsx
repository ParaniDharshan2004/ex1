import {
  Fragment,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  TextField,
  Typography,
} from '@mui/material';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

import YearMonthCalendar from '../components/reports/YearMonthCalendar';

import {
  getInvoiceAllocations,
  getOperationalExpenseReport,
  getOperationalExpenseReports,
} from '../api/operationalExpenseApi';

import { formatINR } from '../utils/currency';
import {
  calculateOperationalExpenseCategoryTotals,
  calculateOtherExpenseTotal,
} from '../utils/expenseCalculations';
import { formatMonthYear } from '../utils/date';
import {
  groupFixedAssetsByParent,
  mapFixedAssetsToComponents,
  normalizeFixedAssetItem,
} from '../utils/fixedAssetMapping';
import api from '../../../services/api/client.js';

const REPORT_CATEGORY_ORDER = [
  'Direct Cost',
  'Indirect Cost',
  'Misc Expenses',
  'Fixed Cost',
];
const FINALIZED_REPORT_STATUSES = new Set([
  'COMPLETED',
  'FINALIZED',
  'INVOICE_GENERATED',
  'INVOICED',
  'REPORT_FINALIZED',
]);

const isFinalizedReport = (report) =>
  FINALIZED_REPORT_STATUSES.has(String(report?.status || '').toUpperCase());

const CATEGORY_ALIASES = {
  'direct cost': 'Direct Cost',
  direct: 'Direct Cost',

  'indirect cost': 'Indirect Cost',
  indirect: 'Indirect Cost',

  'misc expense': 'Misc Expenses',
  'misc expenses': 'Misc Expenses',
  miscellaneous: 'Misc Expenses',
  'miscellaneous expense': 'Misc Expenses',
  'miscellaneous expenses': 'Misc Expenses',

  'fixed asset': 'Fixed Assets',
  'fixed assets': 'Fixed Assets',
  'fixed cost': 'Fixed Cost',
  'fixed costs': 'Fixed Cost',
};

const normalizeCategoryName = (value) => {
  const category = String(value || '').trim();
  const normalizedCategory = category.toLowerCase();

  return CATEGORY_ALIASES[normalizedCategory] || category || 'Indirect Cost';
};

const getNumericValue = (...values) => {
  const value = values.find(
    (item) =>
      item !== undefined &&
      item !== null &&
      item !== '' &&
      Number.isFinite(Number(item)),
  );

  return Number(value) || 0;
};

const hasNonZeroReportAmount = (value) =>
  Number.isFinite(Number(value)) &&
  Math.round((Number(value) + Number.EPSILON) * 100) !== 0;

const getReportTotal = (report) =>
  getNumericValue(
    report?.totals?.operationalExpenseTotal,
    report?.totals?.totalBillable,
    report?.totals?.grandTotal,
    report?.totalAmount,
  );

const firstNonEmptyArray = (...candidates) =>
  candidates.find(
    (candidate) => Array.isArray(candidate) && candidate.length > 0,
  ) || [];

const getAllocationRows = (response) => {
  const payload = response?.data?.data ?? response?.data ?? response ?? [];

  return firstNonEmptyArray(
    payload,
    payload?.allocations,
    payload?.invoiceAllocations,
    payload?.clients,
    payload?.rows,
    payload?.data,
  );
};

const getClientName = (allocation) =>
  allocation?.clientName ||
  allocation?.clientMaster?.clientName ||
  allocation?.clientId?.clientName ||
  allocation?.client?.name ||
  allocation?.client?.clientName ||
  allocation?.companyName ||
  allocation?.entityName ||
  allocation?.locationName ||
  allocation?.location ||
  allocation?.name ||
  allocation?.code ||
  'Unassigned Client';

const getAllocatedAmount = (allocation) =>
  getNumericValue(
    allocation?.allocatedAmount,
    allocation?.clientTotalAmount,
    allocation?.allocationAmount,
    allocation?.finalAllocatedAmount,
    allocation?.invoiceAmount,
    allocation?.totalAmount,
    allocation?.amount,
    allocation?.value,
  );

const groupAllocationsByClient = (allocations) => {
  const groupedAllocations = new Map();

  allocations.forEach((allocation) => {
    const clientName = getClientName(allocation);
    const amount = getAllocatedAmount(allocation);
    const rawDisplayOrder =
      allocation?.clientMaster?.displayOrder ??
      allocation?.clientId?.displayOrder ??
      allocation?.client?.displayOrder ??
      allocation?.displayOrder;
    const displayOrder =
      rawDisplayOrder !== undefined &&
      rawDisplayOrder !== null &&
      rawDisplayOrder !== '' &&
      Number.isFinite(Number(rawDisplayOrder))
        ? Number(rawDisplayOrder)
        : null;

    const existing = groupedAllocations.get(clientName);
    groupedAllocations.set(clientName, {
      clientName,
      amount: (existing?.amount || 0) + amount,
      displayOrder:
        existing?.displayOrder == null
          ? displayOrder
          : displayOrder == null
            ? existing.displayOrder
            : Math.min(existing.displayOrder, displayOrder),
    });
  });

  return Array.from(groupedAllocations.values())
    .filter((allocation) => allocation.amount !== 0)
    .sort((first, second) => {
      const firstHasOrder = first.displayOrder !== null;
      const secondHasOrder = second.displayOrder !== null;
      if (firstHasOrder !== secondHasOrder) return firstHasOrder ? -1 : 1;
      if (firstHasOrder && first.displayOrder !== second.displayOrder) {
        return first.displayOrder - second.displayOrder;
      }
      return first.clientName.localeCompare(second.clientName);
    })
    .map(({ clientName, amount }) => ({ clientName, amount }));
};

const isSuccessfullyMatchedRow = (row) => {
  const matchStatus = String(
    row?.matchStatus || row?.status || row?.matchingStatus || '',
  ).toUpperCase();
  const isManuallyAddedReportRow =
    String(row?.rowSource || '').toUpperCase() === 'REPORT_ONLY' &&
    matchStatus === 'MANUALLY_ADDED';

  const successfulStatuses = [
    'MATCHED',
    'HEAD_COMPONENT_MATCHED',
    'CALCULATED_FROM_SUBCOMPONENTS',
    'COMPONENT_MATCHED',
    'SUBCOMPONENT_MATCHED',
    'SUCCESS',
    'FINALIZED',
  ];
  const hasExplicitUnmatchedStatus =
    matchStatus &&
    !successfulStatuses.includes(matchStatus) &&
    !isManuallyAddedReportRow;
  if (
    hasExplicitUnmatchedStatus ||
    (row?.hasTallyExpense === false && !isManuallyAddedReportRow)
  )
    return false;

  const hasComponent = Boolean(
    row?.componentName ||
    row?.parentComponentName ||
    row?.headComponentName ||
    row?.component?.name ||
    row?.description ||
    row?.ledgerName,
  );
  const hasAmount = Number.isFinite(
    Number(
      row?.finalizedAmount ??
        row?.componentAmount ??
        row?.amount ??
        row?.monthlyAmount ??
        row?.annualAmount ??
        row?.finalAmount ??
        row?.matchedAmount,
    ),
  );

  return hasComponent && hasAmount;
};

const getParentComponentName = (row) =>
  row?.parentComponentName ||
  row?.headComponentName ||
  row?.componentName ||
  row?.name ||
  row?.component?.name ||
  row?.component?.componentName ||
  row?.financialComponentName ||
  row?.description ||
  row?.ledgerName ||
  'Other Expenses';

const getCategoryName = (row) =>
  normalizeCategoryName(
    row?.financialCategoryName ||
      row?.financialCategory?.name ||
      row?.financialCategoryId?.categoryName ||
      row?.financialCategory ||
      row?.masterCategoryName ||
      row?.categoryName ||
      row?.category,
  );

const getRowAmount = (row) =>
  getNumericValue(
    row?.amount,
    row?.finalizedAmount,
    row?.componentAmount,
    row?.monthlyAmount,
    row?.annualAmount,
    row?.finalAmount,
    row?.matchedAmount,
    row?.tallyAmount,
    row?.value,
  );

const getDisplayOrder = (value) =>
  value === undefined || value === null || value === ''
    ? null
    : Number.isFinite(Number(value))
      ? Number(value)
      : null;

const groupReportRows = (rows, components = []) => {
  const groupedRows = new Map();
  const safeComponents = (Array.isArray(components) ? components : []).filter(Boolean);
  const componentById = new Map(
    safeComponents.map((component) => [
      String(component._id || component.id),
      component,
    ]),
  );
  const componentByName = new Map(
    safeComponents.map((component) => [
      String(component.componentName || component.name || '').toLowerCase(),
      component,
    ]),
  );

  rows.filter(isSuccessfullyMatchedRow).forEach((row) => {
    const category = getCategoryName(row);
    const componentName = getParentComponentName(row);
    const amount = getRowAmount(row);
    const key = `${category}::${componentName}`.toLowerCase();
    const componentId =
      row?.componentId?._id || row?.componentId?.id || row?.componentId ||
      row?.component?._id || row?.component?.id;
    const component =
      componentById.get(String(componentId)) ||
      componentByName.get(componentName.toLowerCase());
    const masterOrder = getDisplayOrder(
      component?.displayOrder ?? row?.componentId?.displayOrder,
    );
    const reportOrder = getDisplayOrder(
      row?.displayOrder ?? row?.component?.displayOrder,
    );
    const displayOrder = masterOrder ?? reportOrder;

    if (import.meta.env.DEV) {
      console.debug('[OperationalExpense][Reports] resolved component order', {
        componentName,
        componentId: component?._id || component?.id || componentId || null,
        displayOrder,
      });
    }

    if (!groupedRows.has(key)) {
      groupedRows.set(key, {
        category,
        description: componentName,
        componentId: component?._id || component?.id || row?.componentId,
        amount: 0,
        displayOrder,
      });
    }

    groupedRows.get(key).amount += amount;
    if (
      Number.isFinite(displayOrder) &&
      (!Number.isFinite(groupedRows.get(key).displayOrder) ||
        displayOrder < groupedRows.get(key).displayOrder)
    ) {
      groupedRows.get(key).displayOrder = displayOrder;
    }
  });

  return Array.from(groupedRows.values()).sort((first, second) => {
    const firstCategoryIndex = REPORT_CATEGORY_ORDER.indexOf(first.category);
    const secondCategoryIndex = REPORT_CATEGORY_ORDER.indexOf(second.category);

    const normalizedFirstIndex =
      firstCategoryIndex === -1
        ? REPORT_CATEGORY_ORDER.length
        : firstCategoryIndex;

    const normalizedSecondIndex =
      secondCategoryIndex === -1
        ? REPORT_CATEGORY_ORDER.length
        : secondCategoryIndex;

    if (normalizedFirstIndex !== normalizedSecondIndex) {
      return normalizedFirstIndex - normalizedSecondIndex;
    }

    const firstHasOrder = Number.isFinite(first.displayOrder);
    const secondHasOrder = Number.isFinite(second.displayOrder);
    if (firstHasOrder !== secondHasOrder) {
      return firstHasOrder ? -1 : 1;
    }
    if (firstHasOrder && first.displayOrder !== second.displayOrder) {
      return first.displayOrder - second.displayOrder;
    }

    return first.description.localeCompare(second.description);
  });
};

const calculateCategoryTotal = (expenses, category) =>
  expenses
    .filter((expense) => expense.category === category)
    .reduce((total, expense) => total + expense.amount, 0);

const buildReportData = (
  reportDetail,
  allocationsResponse,
  fixedAssetMappings,
) => {
  const finalizedItems = reportDetail?.finalizedItems;
  const report = reportDetail?.report || reportDetail;
  const finalizedItemRows = finalizedItems
    ? Object.entries(finalizedItems).flatMap(([category, items]) =>
        (Array.isArray(items) ? items : []).map((item) => ({
          category,
          financialCategoryName: category,
          componentName: item.componentName || item.name,
          componentId: item.componentId,
          displayOrder:
            item.displayOrder ?? item.componentId?.displayOrder,
          amount: item.finalizedAmount ?? item.amount,
          hasTallyExpense: true,
          financialCategoryId: item.financialCategory || category,
          matchStatus: 'HEAD_COMPONENT_MATCHED',
        })),
      )
    : [];
  const sourceRows = firstNonEmptyArray(
    finalizedItemRows,
    reportDetail?.reportRows,
    reportDetail?.rows,
    reportDetail?.items,
    reportDetail?.expenses,
    reportDetail?.reportData,
    reportDetail?.operationalExpenses,
    reportDetail?.finalizedRows,
    reportDetail?.matchedRows,
    report?.reportRows,
    report?.rows,
    report?.items,
    report?.expenses,
    report?.reportData,
    report?.operationalExpenses,
    report?.finalizedRows,
    report?.matchedRows,
  );
  const manuallyAddedRows = [
    reportDetail?.reportRows,
    reportDetail?.rows,
    report?.reportRows,
    report?.rows,
  ]
    .filter(Array.isArray)
    .flat()
    .filter(
      (row) =>
        String(row?.rowSource || '').toUpperCase() === 'REPORT_ONLY' &&
        String(row?.matchStatus || '').toUpperCase() === 'MANUALLY_ADDED',
    );
  const sourceRowIds = new Set(
    sourceRows.map((row) => String(row?._id || row?.id || '')).filter(Boolean),
  );
  const completeSourceRows = [
    ...sourceRows,
    ...manuallyAddedRows.filter((row) => {
      const rowId = String(row?._id || row?.id || '');
      return !sourceRows.includes(row) && (!rowId || !sourceRowIds.has(rowId));
    }),
  ];

  const expenses = groupReportRows(
    completeSourceRows,
    fixedAssetMappings.components,
  );
  const reportFixedAssets =
    Array.isArray(report?.fixedAssets) && report.fixedAssets.length > 0
      ? report.fixedAssets
      : Array.isArray(report?.fixedCosts)
        ? report.fixedCosts
        : [];
  const mappedFixedAssets = Array.isArray(reportFixedAssets)
    ? mapFixedAssetsToComponents(
        reportFixedAssets,
        fixedAssetMappings.components,
        fixedAssetMappings.subComponents,
      )
    : [];
  const fixedCosts = mappedFixedAssets.map((item, index) => ({
    ...normalizeFixedAssetItem(item, index),
    category: 'Fixed Cost',
    subcomponent: item.itemName || item.assetName || 'Fixed asset',
    description: item.itemName || item.assetName || 'Fixed asset',
    fixedAssetCategory: normalizeFixedAssetItem(item, index).parentCategory,
    componentDisplayOrder: getDisplayOrder(item.componentDisplayOrder),
    subcomponentDisplayOrder: getDisplayOrder(item.subcomponentDisplayOrder),
    amount: getNumericValue(item.amount),
  }));
  const expensesWithFixedCosts = [...expenses, ...fixedCosts];
  const allocations = groupAllocationsByClient(
    reportDetail?.clientAllocations || getAllocationRows(allocationsResponse),
  );

  const { directCostTotal, indirectCostTotal } =
    calculateOperationalExpenseCategoryTotals(expensesWithFixedCosts);
  const miscExpensesTotal = calculateCategoryTotal(
    expensesWithFixedCosts,
    'Misc Expenses',
  );
  const fixedCostTotal = calculateCategoryTotal(
    expensesWithFixedCosts,
    'Fixed Cost',
  );

  const calculatedSubtotal = directCostTotal + indirectCostTotal;

  const subtotal = calculatedSubtotal;

  const markup =
    getNumericValue(
      report?.totals?.markupAmount,
      report?.totals?.markup,
      report?.markupAmount,
    ) || subtotal * 0.2;

  const finalFixedCostTotal = fixedCostTotal;

  const finalMiscExpensesTotal = miscExpensesTotal;

  const otherExpenseTotal = calculateOtherExpenseTotal(expenses);

  const calculatedOperationalExpenseTotal =
    subtotal +
    markup +
    finalFixedCostTotal +
    finalMiscExpensesTotal +
    otherExpenseTotal;

  const operationalExpenseTotal = calculatedOperationalExpenseTotal;

  return {
    id: report?._id,
    reportMonth: report?.reportMonth,
    expenses,
    fixedCosts,
    allocations,
    totals: {
      directCostTotal,
      indirectCostTotal,
      subtotal,
      markup,
      fixedCostTotal: finalFixedCostTotal,
      miscExpensesTotal: finalMiscExpensesTotal,
      otherExpenseTotal,
      operationalExpenseTotal,
    },
  };
};

export function OperationalExpenseReportDocument({ report, reportRef }) {
  const rowsByCategory = useMemo(() => {
    const categoryMap = new Map();

    report.expenses
      .filter((expense) => hasNonZeroReportAmount(expense.amount))
      .forEach((expense) => {
        if (!categoryMap.has(expense.category)) {
          categoryMap.set(expense.category, []);
        }

        categoryMap.get(expense.category).push(expense);
      });

    // Keep report preview and the PDF document in backend master order.
    categoryMap.forEach((expenses) => {
      expenses.sort((first, second) => {
        const firstOrder = getDisplayOrder(first.displayOrder);
        const secondOrder = getDisplayOrder(second.displayOrder);

        if (firstOrder === null && secondOrder !== null) return 1;
        if (firstOrder !== null && secondOrder === null) return -1;
        if (firstOrder !== null && firstOrder !== secondOrder) {
          return firstOrder - secondOrder;
        }
        return String(first.description || '').localeCompare(
          String(second.description || ''),
        );
      });
    });

    return categoryMap;
  }, [report.expenses]);
  const additionalCategories = useMemo(
    () =>
      Array.from(rowsByCategory.keys()).filter(
        (category) =>
          ![
            'Direct Cost',
            'Indirect Cost',
            'Misc Expenses',
            'Fixed Cost',
            'Fixed Assets',
          ].includes(category),
      ),
    [rowsByCategory],
  );
  const fixedGroups = useMemo(() => {
    const groups = groupFixedAssetsByParent(report.fixedCosts || []);

    return groups
      .map((group, originalGroupIndex) => {
        const sortedChildren = [...(group.children || [])]
          .filter((child) => hasNonZeroReportAmount(child.amount))
          .map((child, originalChildIndex) => ({
            ...child,
            originalChildIndex,
          }))
          .sort((first, second) => {
            const firstOrder = getDisplayOrder(
              first.subcomponentDisplayOrder ?? first.displayOrder,
            );

            const secondOrder = getDisplayOrder(
              second.subcomponentDisplayOrder ?? second.displayOrder,
            );

            // Subcomponents with displayOrder appear first.
            if (firstOrder !== null && secondOrder === null) {
              return -1;
            }

            if (firstOrder === null && secondOrder !== null) {
              return 1;
            }

            // Sort valid display orders in ascending order.
            if (firstOrder !== null && secondOrder !== null) {
              if (firstOrder !== secondOrder) {
                return firstOrder - secondOrder;
              }
            }

            // Preserve the original order when displayOrder is unavailable.
            return first.originalChildIndex - second.originalChildIndex;
          })
          .map((child) => {
            const rest = { ...child };
            delete rest.originalChildIndex;
            return rest;
          });

        const componentDisplayOrder = getDisplayOrder(
          group.componentDisplayOrder ??
            sortedChildren[0]?.componentDisplayOrder,
        );

        return {
          ...group,
          children: sortedChildren,
          componentDisplayOrder,
          originalGroupIndex,
        };
      })
      .filter((group) => group.children.length > 0)
      .sort((first, second) => {
        const firstOrder = first.componentDisplayOrder;
        const secondOrder = second.componentDisplayOrder;

        // Head components with displayOrder appear first.
        if (firstOrder !== null && secondOrder === null) {
          return -1;
        }

        if (firstOrder === null && secondOrder !== null) {
          return 1;
        }

        // Sort valid display orders in ascending order.
        if (firstOrder !== null && secondOrder !== null) {
          if (firstOrder !== secondOrder) {
            return firstOrder - secondOrder;
          }
        }

        // Preserve the original order when displayOrder is unavailable.
        return first.originalGroupIndex - second.originalGroupIndex;
      })
      .map((group) => {
        const rest = { ...group };
        delete rest.originalGroupIndex;
        return rest;
      });
  }, [report.fixedCosts]);

  return (
    <Box
      ref={reportRef}
      sx={{
        width: '794px',
        minHeight: '1123px',
        bgcolor: '#ffffff',
        color: '#111827',
        px: '46px',
        py: '40px',
        boxSizing: 'border-box',
        fontFamily: '"Arial", "Helvetica", sans-serif',
      }}
    >
      <Box
        sx={{
          textAlign: 'center',
          mb: 2,
          pb: 2,
        }}
      >
        <Typography
          sx={{
            fontSize: 22,
            fontWeight: 700,
            color: '#111827',
            letterSpacing: '0.2px',
          }}
        >
          Operational Expense Summary
        </Typography>

        <Typography
          sx={{
            mt: 0.75,
            fontSize: 13,
            color: '#4b5563',
          }}
        >
          {formatMonthYear(report.reportMonth)}
        </Typography>
      </Box>

      <Box
        component="table"
        sx={{
          width: '100%',
          borderCollapse: 'collapse',
          tableLayout: 'fixed',

          '& th': {
            bgcolor: '#d9e2f3',
            color: '#111827',
            border: '1px solid #9ca3af',
            px: 1.5,
            py: 1.25,
            fontSize: 11,
            fontWeight: 700,
            textAlign: 'left',
          },

          '& td': {
            border: '1px solid #c7cdd6',
            px: 1.5,
            py: 1.1,
            fontSize: 10.5,
            lineHeight: 1.4,
            verticalAlign: 'middle',
          },
        }}
      >
        <Box component="colgroup">
          <Box component="col" sx={{ width: '18%' }} />
          <Box component="col" sx={{ width: '64%' }} />
          <Box component="col" sx={{ width: '18%' }} />
        </Box>

        <Box component="thead">
          <Box component="tr">
            <Box component="th">Category</Box>
            <Box component="th">Description</Box>
            <Box component="th" sx={{ textAlign: 'right !important' }}>
              Annual Amount (<span className="currency-symbol">₹</span>)
            </Box>
          </Box>
        </Box>

        <Box component="tbody">
          {/* Direct Cost */}
          {(rowsByCategory.get('Direct Cost') || []).map(
            (expense, expenseIndex) => (
              <Box
                component="tr"
                key={`direct-cost-${expense.description}-${expenseIndex}`}
              >
                <Box
                  component="td"
                  sx={{
                    fontWeight: expenseIndex === 0 ? 700 : 400,
                  }}
                >
                  {expenseIndex === 0 ? 'Direct Cost' : ''}
                </Box>

                <Box component="td" sx={{ textAlign: 'right' }}>
                  {expense.description}
                </Box>

                <Box
                  component="td"
                  className="opex-currency"
                  sx={{
                    textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {formatINR(expense.amount, { showSymbol: false })}
                </Box>
              </Box>
            ),
          )}

          <ReportTotalRow
            label="Total Direct Cost"
            amount={report.totals.directCostTotal}
            sectionTotal
          />

          {/* Indirect Cost */}
          {(rowsByCategory.get('Indirect Cost') || []).map(
            (expense, expenseIndex) => (
              <Box
                component="tr"
                key={`indirect-cost-${expense.description}-${expenseIndex}`}
              >
                <Box
                  component="td"
                  sx={{
                    fontWeight: expenseIndex === 0 ? 700 : 400,
                  }}
                >
                  {expenseIndex === 0 ? 'Indirect Cost' : ''}
                </Box>

                <Box component="td" sx={{ textAlign: 'right' }}>
                  {expense.description}
                </Box>

                <Box
                  component="td"
                  className="opex-currency"
                  sx={{
                    textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {formatINR(expense.amount, { showSymbol: false })}
                </Box>
              </Box>
            ),
          )}

          <ReportTotalRow
            label="Total Indirect Cost"
            amount={report.totals.indirectCostTotal}
            sectionTotal
          />

          {/* Sub Total */}
          <ReportTotalRow
            label="Sub Total"
            amount={report.totals.subtotal}
            sectionTotal
          />

          {/* Markup */}
          <ReportTotalRow
            label="20% Markup over Sub Total"
            amount={report.totals.markup}
            sectionTotal
          />

          {/* Misc Expenses / Director Remuneration */}
          {(rowsByCategory.get('Misc Expenses') || []).map(
            (expense, expenseIndex) => (
              <Box
                component="tr"
                key={`misc-expenses-${expense.description}-${expenseIndex}`}
              >
                <Box
                  component="td"
                  sx={{
                    fontWeight: expenseIndex === 0 ? 700 : 400,
                  }}
                >
                  {expenseIndex === 0 ? 'Misc Expenses' : ''}
                </Box>

                <Box component="td" sx={{ textAlign: 'right' }}>
                  {expense.description}
                </Box>

                <Box
                  component="td"
                  className="opex-currency"
                  sx={{
                    textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {formatINR(expense.amount, { showSymbol: false })}
                </Box>
              </Box>
            ),
          )}

          {hasNonZeroReportAmount(report.totals.miscExpensesTotal) && (
            <ReportTotalRow
              label="Total Misc expenses"
              amount={report.totals.miscExpensesTotal}
              sectionTotal
            />
          )}

          {additionalCategories.map((category) => {
            const categoryExpenses = rowsByCategory.get(category) || [];
            const categoryTotal = categoryExpenses.reduce(
              (total, expense) => total + expense.amount,
              0,
            );

            return (
              <Fragment key={`additional-category-${category}`}>
                {categoryExpenses.map((expense, expenseIndex) => (
                  <Box
                    component="tr"
                    key={`${category}-${expense.description}-${expenseIndex}`}
                  >
                    <Box component="td" sx={{ fontWeight: expenseIndex === 0 ? 700 : 400 }}>
                      {expenseIndex === 0 ? category : ''}
                    </Box>
                    <Box component="td" sx={{ textAlign: 'right' }}>
                      {expense.description}
                    </Box>
                    <Box
                      component="td"
                      className="opex-currency"
                      sx={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}
                    >
                      {formatINR(expense.amount, { showSymbol: false })}
                    </Box>
                  </Box>
                ))}
                <ReportTotalRow
                  label={`Total ${category}`}
                  amount={categoryTotal}
                  sectionTotal
                />
              </Fragment>
            );
          })}

          {hasNonZeroReportAmount(report.totals.otherExpenseTotal) && (
            <ReportTotalRow
              label="Other Expense Categories Total"
              amount={report.totals.otherExpenseTotal}
              sectionTotal
            />
          )}

          {fixedGroups.length > 0 && (
            <>
              {fixedGroups.map(({ parentCategory, children }, groupIndex) => (
                <Fragment key={`fixed-group-${parentCategory}`}>
                  <Box component="tr">
                    <Box
                      component="td"
                      sx={{
                        fontWeight: groupIndex === 0 ? 700 : 400,
                      }}
                    >
                      {groupIndex === 0 ? 'Fixed Assets' : ''}
                    </Box>
                    <Box component="td" sx={{ textAlign: 'right' }}>
                      {parentCategory}
                    </Box>
                    <Box component="td" />
                  </Box>
                  {children.map((expense, expenseIndex) => (
                    <Box
                      component="tr"
                      key={
                        expense.id ||
                        `${parentCategory}-${expense.subcomponent}-${expenseIndex}`
                      }
                    >
                      <Box component="td" />
                      <Box component="td" sx={{ textAlign: 'right' }}>
                        {expense.subcomponent}
                      </Box>
                      <Box
                        component="td"
                        className="opex-currency"
                        sx={{
                          textAlign: 'right',
                          fontVariantNumeric: 'tabular-nums',
                        }}
                      >
                        {formatINR(expense.amount, { showSymbol: false })}
                      </Box>
                    </Box>
                  ))}
                </Fragment>
              ))}
            </>
          )}

          <ReportTotalRow
            label="Fixed Assets Total"
            amount={report.totals.fixedCostTotal}
            sectionTotal
          />

          {/* Final Operational Expense Total */}
          <ReportTotalRow
            label="Operational Expense Total"
            amount={report.totals.operationalExpenseTotal}
            highlighted
          />

          {/* Client allocation totals */}
          {report.allocations
            .filter((allocation) => hasNonZeroReportAmount(allocation.amount))
            .map((allocation, allocationIndex) => (
              <Box
                component="tr"
                key={`allocation-${allocation.clientName}-${allocationIndex}`}
                sx={{ bgcolor: '#ffffff' }}
              >
                <Box
                  component="td"
                  colSpan={2}
                  sx={{
                    textAlign: 'right',
                    fontWeight: 700,
                  }}
                >
                  Total Amount Charged to {allocation.clientName}
                </Box>

                <Box
                  component="td"
                  className="opex-currency"
                  sx={{
                    textAlign: 'right',
                    fontWeight: 700,
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {formatINR(allocation.amount, { showSymbol: false })}
                </Box>
              </Box>
            ))}
        </Box>
      </Box>

      {report.allocations.some((allocation) =>
        hasNonZeroReportAmount(allocation.amount),
      ) && (
        <Box sx={{ display: 'none' }}>
        <Typography
          sx={{
            mb: 1,
            fontSize: 12,
            fontWeight: 700,
            color: '#111827',
          }}
        >
          Client Allocation Summary
        </Typography>

        <Box
          component="table"
          sx={{
            width: '100%',
            borderCollapse: 'collapse',
            tableLayout: 'fixed',

            '& th': {
              bgcolor: '#d9e2f3',
              border: '1px solid #9ca3af',
              px: 1.5,
              py: 1.15,
              fontSize: 11,
              fontWeight: 700,
              textAlign: 'left',
            },

            '& td': {
              border: '1px solid #c7cdd6',
              px: 1.5,
              py: 1.1,
              fontSize: 10.5,
            },
          }}
        >
          <Box component="thead">
            <Box component="tr">
              <Box component="th">Client</Box>
              <Box component="th" sx={{ textAlign: 'right !important' }}>
                Allocated Amount
              </Box>
            </Box>
          </Box>

          <Box component="tbody">
            {report.allocations
              .filter((allocation) => hasNonZeroReportAmount(allocation.amount))
              .map((allocation) => (
                <Box component="tr" key={allocation.clientName}>
                  <Box component="td">
                    Total Amount Charged to {allocation.clientName}
                  </Box>

                  <Box
                    component="td"
                    className="opex-currency"
                    sx={{
                      textAlign: 'right',
                      fontWeight: 700,
                      fontVariantNumeric: 'tabular-nums',
                    }}
                  >
                    {formatINR(allocation.amount, { showSymbol: false })}
                  </Box>
                </Box>
              ))}
          </Box>
        </Box>
        </Box>
      )}

      <Typography sx={{ display: 'none' }}>
        Operational Expense Report - {formatMonthYear(report.reportMonth)}
      </Typography>
    </Box>
  );
}

function ReportTotalRow({
  label,
  amount,
  stronger = false,
  highlighted = false,
  danger = false,
  markup = false,
  sectionTotal = false,
}) {
  if (!hasNonZeroReportAmount(amount)) return null;

  return (
    <Box
      component="tr"
      sx={{
        bgcolor: markup
          ? '#fff4d6'
          : sectionTotal || highlighted
            ? '#d9e2f3'
            : '#ffffff',
      }}
    >
      <Box
        component="td"
        colSpan={2}
        sx={{
          textAlign: 'right',
          fontWeight: highlighted || stronger ? '700 !important' : 600,
          color: danger ? '#d32f2f' : '#111827',
        }}
      >
        {label}
      </Box>

      <Box
        component="td"
        className="opex-currency"
        sx={{
          textAlign: 'right',
          fontWeight: highlighted || stronger ? '700 !important' : 600,
          color: danger ? '#d32f2f' : highlighted ? '#1456d9' : '#111827',
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        {formatINR(amount, { showSymbol: false })}
      </Box>
    </Box>
  );
}

export default function OperationalExpenseReportsPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reportLoading, setReportLoading] = useState(false);
  const [previewingId, setPreviewingId] = useState('');
  const [downloadingId, setDownloadingId] = useState('');
  const [error, setError] = useState('');

  const [year, setYear] = useState(String(new Date().getFullYear()));

  const [selectedReport, setSelectedReport] = useState(null);
  const [pdfReport, setPdfReport] = useState(null);

  const pdfRef = useRef(null);
  const fixedAssetMappingsRef = useRef(null);
  const handledReportActionRef = useRef('');

  useEffect(() => {
    let active = true;

    const fetchReports = async () => {
      try {
        setLoading(true);
        setError('');

        const response = await getOperationalExpenseReports();
        const payload = response?.data?.data ?? response?.data ?? [];

        const reportList = Array.isArray(payload)
          ? payload
          : payload?.reports || payload?.items || [];

        if (active) {
          setReports(reportList.filter(isFinalizedReport));
        }
      } catch (requestError) {
        if (active) {
          setError(
            requestError?.response?.data?.message ||
              'Unable to load Operational Expense reports.',
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    fetchReports();

    return () => {
      active = false;
    };
  }, []);

  const years = useMemo(() => {
    const availableYears = reports
      .map((report) => String(report?.reportMonth || '').slice(0, 4))
      .filter(Boolean);

    return [
      ...new Set([String(new Date().getFullYear()), ...availableYears]),
    ].sort((first, second) => Number(second) - Number(first));
  }, [reports]);

  const months = useMemo(
    () =>
      Array.from({ length: 12 }, (_, index) => {
        const monthNumber = String(index + 1).padStart(2, '0');
        const reportMonth = `${year}-${monthNumber}`;

        const monthReports = reports.filter(
          (report) => String(report?.reportMonth || '') === reportMonth,
        );

        return {
          monthNum: monthNumber,
          monthName: new Date(Number(year), index, 1).toLocaleString('en-IN', {
            month: 'long',
          }),
          totalAmount: monthReports.reduce(
            (total, report) => total + getReportTotal(report),
            0,
          ),
          reportCount: monthReports.length,
          report: monthReports[0],
        };
      }),
    [reports, year],
  );

  const loadFixedAssetMappings = useCallback(async () => {
    if (!fixedAssetMappingsRef.current) {
      fixedAssetMappingsRef.current = Promise.all([
        api.get('/api/componentRouter/getAllComponents'),
        api.get('/api/subComponentRouter/getAllSubcomponents'),
      ])
        .then(([componentsResponse, subComponentsResponse]) => ({
          components: (componentsResponse.data?.data || []).filter(
            (component) =>
              component.isActive !== false &&
              component.isOperationalExpense === true,
          ),
          subComponents: (subComponentsResponse.data?.data || []).filter(
            (subComponent) =>
              subComponent.isActive !== false &&
              subComponent.isOperationalExpense === true,
          ),
        }))
        .catch((requestError) => {
          fixedAssetMappingsRef.current = null;
          throw requestError;
        });
    }

    return fixedAssetMappingsRef.current;
  }, []);

  const loadFullReport = useCallback(async (report) => {
    const reportId = report?._id || report?.id;

    if (!reportId) {
      throw new Error('The selected report does not have a valid report ID.');
    }

    const [reportResponse, allocationResponse, fixedAssetMappings] =
      await Promise.all([
        getOperationalExpenseReport(reportId),
        getInvoiceAllocations(reportId),
        loadFixedAssetMappings(),
      ]);

    if (import.meta.env.DEV) {
      console.debug(
        '[OperationalExpense][Reports] complete report details response',
        reportResponse,
      );
      console.debug(
        '[OperationalExpense][Reports] complete allocation response',
        allocationResponse,
      );
    }

    const reportDetail =
      reportResponse?.data?.data ?? reportResponse?.data ?? report;

    return buildReportData(
      reportDetail,
      allocationResponse,
      fixedAssetMappings,
    );
  }, [loadFixedAssetMappings]);

  const handlePreview = useCallback(async (report) => {
    const reportId = String(report?._id || report?.id || report?.reportMonth || '');
    try {
      setError('');
      setReportLoading(true);
      setPreviewingId(reportId);

      const reportData = await loadFullReport(report);
      setSelectedReport(reportData);
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          'Unable to load the report preview.',
      );
    } finally {
      setReportLoading(false);
      setPreviewingId('');
    }
  }, [loadFullReport]);

  const createPdf = useCallback(async (reportData) => {
    setPdfReport(reportData);

    await new Promise((resolve) => {
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(resolve);
      });
    });
    await document.fonts.ready;

    if (!pdfRef.current) {
      throw new Error('PDF report layout could not be prepared.');
    }

    const canvas = await html2canvas(pdfRef.current, {
      scale: 2,
      backgroundColor: '#ffffff',
      useCORS: true,
      logging: false,
      windowWidth: 794,
    });

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 10;
    const printableWidth = pageWidth - margin * 2;
    const printableHeight = pageHeight - margin * 2;

    const imageWidth = printableWidth;
    const imageHeight = (canvas.height * imageWidth) / canvas.width;

    const imageData = canvas.toDataURL('image/png', 1);
    const pageCount = Math.max(1, Math.ceil(imageHeight / printableHeight));

    for (let pageIndex = 0; pageIndex < pageCount; pageIndex += 1) {
      if (pageIndex > 0) {
        pdf.addPage();
      }

      const imageY = margin - pageIndex * printableHeight;

      pdf.addImage(
        imageData,
        'PNG',
        margin,
        imageY,
        imageWidth,
        imageHeight,
        undefined,
        'FAST',
      );
    }

    const safeMonth = String(reportData.reportMonth || 'report').replace(
      /[^0-9A-Za-z-]/g,
      '-',
    );

    pdf.save(`Operational_Expense_Summary_${safeMonth}.pdf`);
  }, []);

  const handleDownload = useCallback(async (report) => {
    const reportId = report?._id || report?.id || report?.reportMonth;

    try {
      setError('');
      setDownloadingId(String(reportId));

      const reportData = report?.expenses
        ? report
        : await loadFullReport(report);

      await createPdf(reportData);
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          'Unable to download the report PDF.',
      );
    } finally {
      setPdfReport(null);
      setDownloadingId('');
    }
  }, [createPdf, loadFullReport]);

  const reportActionHandlersRef = useRef({});

  useEffect(() => {
    reportActionHandlersRef.current = { handlePreview, handleDownload };
  }, [handleDownload, handlePreview]);

  useEffect(() => {
    const requestedAction = location.state?.operationalExpenseReportAction;
    const requestedReportId = location.state?.reportId;
    if (!requestedAction || !requestedReportId || loading) return;

    const actionKey = `${requestedAction}:${requestedReportId}`;
    if (handledReportActionRef.current === actionKey) return;
    handledReportActionRef.current = actionKey;

    navigate(`${location.pathname}${location.search}`, {
      replace: true,
      state: null,
    });

    const requestedReport = reports.find(
      (report) =>
        String(report?._id || report?.id || '') === String(requestedReportId),
    );
    if (!requestedReport) {
      queueMicrotask(() =>
        setError('The selected report is not available for preview or download.'),
      );
      return;
    }

    if (requestedAction === 'preview') {
      void reportActionHandlersRef.current.handlePreview(requestedReport);
    } else if (requestedAction === 'download') {
      void reportActionHandlersRef.current.handleDownload(requestedReport);
    }
  }, [
    loading,
    location.pathname,
    location.search,
    location.state,
    navigate,
    reports,
  ]);

  return (
    <Box
      sx={{
        p: { xs: 2, sm: 3, md: 4 },
        width: '100%',
        maxWidth: 1500,
        mx: 'auto',
      }}
    >
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: 'minmax(0, 1fr)', sm: 'minmax(0, 1fr) auto' },
          alignItems: 'center',
          gap: 2,
          mb: 3,
        }}
      >
        <Box>
          <Typography variant="h4" sx={{ lineHeight: 1.2 }}>
            Monthly Operational Expense Reports
          </Typography>
        </Box>

        <TextField
          select
          size="small"
          label="Year"
          value={year}
          onChange={(event) => setYear(event.target.value)}
          sx={{
            width: { xs: '100%' },
            justifySelf: { sm: 'end' },
          }}
        >
          {years.map((availableYear) => (
            <MenuItem key={availableYear} value={availableYear}>
              {availableYear}
            </MenuItem>
          ))}
        </TextField>
      </Box>

      {error && (
        <Alert severity="error" onClose={() => setError('')} sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <YearMonthCalendar
            months={months}
            onPreview={handlePreview}
            onDownload={handleDownload}
            previewingId={previewingId}
            downloadingId={downloadingId}
            actionsDisabled={reportLoading || Boolean(downloadingId)}
          />

          {/*
          <TableContainer
            sx={{
              mt: 3,
              bgcolor: '#ffffff',
              border: '1px solid #dde3ed',
              borderRadius: 2,
              overflowX: 'auto',
            }}
          >
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: '#f5f7fb' }}>
                  <TableCell sx={{ fontWeight: 700 }}>Serial Number</TableCell>

                  <TableCell sx={{ fontWeight: 700 }}>Report Month</TableCell>

                  <TableCell align="right" sx={{ fontWeight: 700 }}>
                    Total Amount
                  </TableCell>

                  <TableCell align="center" sx={{ fontWeight: 700 }}>
                    Actions
                  </TableCell>
                </TableRow>
              </TableHead>

              <TableBody>
                {visibleReports.length ? (
                  visibleReports.map((report, index) => {
                    const reportId =
                      report?._id || report?.id || report?.reportMonth;

                    const isDownloading = downloadingId === String(reportId);

                    return (
                      <TableRow key={reportId} hover>
                        <TableCell>{index + 1}</TableCell>

                        <TableCell sx={{ fontWeight: 700 }}>
                          {formatMonthYear(report.reportMonth)}
                        </TableCell>

                        <TableCell
                          align="right"
                          className="opex-currency opex-currency-with-symbol"
                          sx={{
                            fontWeight: 700,
                            fontVariantNumeric: 'tabular-nums',
                          }}
                        >
                          {formatINR(getReportTotal(report))}
                        </TableCell>

                        <TableCell align="right">
                          <Stack
                            direction={{ xs: 'column', md: 'row' }}
                            spacing={1}
                            sx={{
                              justifyContent: {
                                xs: 'flex-start',
                                md: 'center',
                              },
                            }}
                          >
                            <Button
                              size="small"
                              startIcon={
                                reportLoading ? (
                                  <CircularProgress size={15} />
                                ) : (
                                  <VisibilityOutlinedIcon />
                                )
                              }
                              onClick={() => handlePreview(report)}
                              disabled={reportLoading || isDownloading}
                            >
                              Preview Report
                            </Button>

                            <Button
                              size="small"
                              startIcon={
                                isDownloading ? (
                                  <CircularProgress size={15} />
                                ) : (
                                  <FileDownloadOutlinedIcon />
                                )
                              }
                              onClick={() => handleDownload(report)}
                              disabled={isDownloading || reportLoading}
                            >
                              Download PDF
                            </Button>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={4}
                      align="center"
                      sx={{ py: 5, color: '#647087' }}
                    >
                      No monthly reports found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          */}
        </>
      )}

      <Dialog
        open={Boolean(selectedReport)}
        onClose={() => setSelectedReport(null)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>Operational Expense Report Preview</DialogTitle>

        <DialogContent
          sx={{
            bgcolor: '#eef1f5',
            p: { xs: 1, sm: 2 },
          }}
        >
          {selectedReport && (
            <Box
              sx={{
                overflowX: 'auto',
                py: 2,
              }}
            >
              <Box
                sx={{
                  width: 'fit-content',
                  mx: 'auto',
                  boxShadow: '0 3px 16px rgba(15, 23, 42, 0.16)',
                }}
              >
                <OperationalExpenseReportDocument report={selectedReport} />
              </Box>
            </Box>
          )}
        </DialogContent>

        <DialogActions>
          <Button
            startIcon={<FileDownloadOutlinedIcon />}
            onClick={() => handleDownload(selectedReport)}
            disabled={Boolean(downloadingId)}
          >
            {downloadingId ? 'Generating PDF...' : 'Download PDF'}
          </Button>

          <Button onClick={() => setSelectedReport(null)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Box
        aria-hidden
        sx={{
          position: 'fixed',
          left: '-12000px',
          top: 0,
          width: '794px',
          pointerEvents: 'none',
        }}
      >
        {pdfReport && (
          <OperationalExpenseReportDocument
            report={pdfReport}
            reportRef={pdfRef}
          />
        )}
      </Box>
    </Box>
  );
}
