import { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Typography,
  CircularProgress,
  Alert,
  MenuItem,
  TextField,
} from '@mui/material';
import { useParams, useLocation } from 'react-router-dom';

import InvoiceCardList from '../components/invoices/InvoiceCardList';
import InvoicePreviewModal from '../components/invoices/InvoicePreviewModal';
import {
  getOperationalExpenseReport,
  getAllInvoices,
  getAllCompanies,
} from '../api/operationalExpenseApi';
import { normalizeInvoiceItem } from '../utils/reportTransformers';
import {
  getInvoiceClientOptions,
  getInvoiceLocationFilterValue,
  getInvoiceLocationOptions,
} from '../utils/invoiceLocationFilters';

export default function OperationalExpenseInvoicesPage() {
  const location = useLocation();
  const { reportId: paramReportId } = useParams();

  const reportId = paramReportId || location.state?.reportId;
  const [period, setPeriod] = useState(location.state?.period || '');
  const [invoices, setInvoices] = useState([]);
  const [invoiceCompany, setInvoiceCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [companyErrorMessage, setCompanyErrorMessage] = useState('');
  const [clientFilter, setClientFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');
  const [yearFilter, setYearFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('all');

  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);

  useEffect(() => {
    let active = true;
    const fetchInvoicesData = async () => {
      try {
        setLoading(true);
        setErrorMessage('');

        // Fetch report if reportId is present
        if (reportId) {
          try {
            const reportRes = await getOperationalExpenseReport(reportId);
            const rep = reportRes.data?.data;
            console.debug(
              '[OperationalExpense][Invoices] API response: getOperationalExpenseReport',
              reportRes.data,
            );
            if (active && rep?.reportMonth) {
              setPeriod(rep.reportMonth);
            }
          } catch (e) {
            console.warn('Could not load report metadata:', e);
          }
        }

        const [invoiceResult, companyResult] = await Promise.allSettled([
          getAllInvoices(),
          getAllCompanies(),
        ]);
        if (invoiceResult.status === 'rejected') {
          throw invoiceResult.reason;
        }
        const invRes = invoiceResult.value;
        console.debug(
          '[OperationalExpense][Invoices] API response: getAllInvoices',
          invRes.data,
        );

        if (companyResult.status === 'fulfilled') {
          const companies = companyResult.value.data?.data;
          if (Array.isArray(companies)) {
            if (active) {
              setInvoiceCompany(companies[0] || null);
              setCompanyErrorMessage(
                companies.length
                  ? ''
                  : 'No issuer company details were returned by Company Master.',
              );
            }
          } else {
            console.error(
              'Company Master API returned an invalid response:',
              companyResult.value.data,
            );
            if (active) {
              setInvoiceCompany(null);
              setCompanyErrorMessage(
                'Unable to load invoice issuer details from Company Master.',
              );
            }
          }
        } else {
          console.error(
            'Failed to load invoice issuer details:',
            companyResult.reason,
          );
          if (active) {
            setInvoiceCompany(null);
            setCompanyErrorMessage(
              'Unable to load invoice issuer details from Company Master.',
            );
          }
        }

        const rawInvoices = Array.isArray(invRes.data?.data)
          ? invRes.data.data
          : [];

        // Filter by reportId if provided
        let filtered = rawInvoices;
        if (reportId) {
          filtered = rawInvoices.filter((inv) => {
            const rId =
              inv.operationalExpenseReportId?._id ||
              inv.operationalExpenseReportId;
            return String(rId) === String(reportId);
          });
        }

        if (active) {
          const normalized = filtered.map((inv) => normalizeInvoiceItem(inv));
          setInvoices(normalized);
        }
      } catch (err) {
        if (active) {
          console.error('Failed to load invoices:', err);
          setErrorMessage(
            err?.response?.data?.error ||
              err?.response?.data?.message ||
              err?.message ||
              'Failed to load invoice records from the server.',
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    fetchInvoicesData();
    return () => {
      active = false;
    };
  }, [reportId]);

  const handlePreview = (invoice) => {
    setSelectedInvoice(invoice);
    setPreviewModalOpen(true);
  };

  const handlePrint = (invoice) => {
    setSelectedInvoice(invoice);
    setPreviewModalOpen(true);
    setTimeout(async () => {
      await document.fonts.ready;
      window.print();
    }, 250);
  };

  const clients = useMemo(
    () =>
      Array.from(
        invoices
          .reduce((clientMap, invoice) => {
            if (!invoice.client) return clientMap;

            const current = clientMap.get(invoice.client);
            if (!current || invoice.clientDisplayOrder < current.displayOrder) {
              clientMap.set(invoice.client, {
                name: invoice.client,
                displayOrder: invoice.clientDisplayOrder,
              });
            }

            return clientMap;
          }, new Map())
          .values(),
      )
        .sort((first, second) => {
          const firstOrder = Number.isFinite(first.displayOrder)
            ? first.displayOrder
            : Number.MAX_SAFE_INTEGER;
          const secondOrder = Number.isFinite(second.displayOrder)
            ? second.displayOrder
            : Number.MAX_SAFE_INTEGER;

          return (
            firstOrder - secondOrder || first.name.localeCompare(second.name)
          );
        })
        .map((client) => client.name),
    [invoices],
  );

  const locations = useMemo(
    () => getInvoiceLocationOptions(invoices, clients, clientFilter),
    [invoices, clients, clientFilter],
  );
  const availableClients = useMemo(
    () => getInvoiceClientOptions(invoices, clients, locationFilter),
    [invoices, clients, locationFilter],
  );
  const periodInvoices = useMemo(
    () =>
      invoices.filter(
        (invoice) =>
          (clientFilter === 'all' || invoice.client === clientFilter) &&
          (locationFilter === 'all' ||
            getInvoiceLocationFilterValue(invoice.client, invoice.location) ===
              locationFilter),
      ),
    [invoices, clientFilter, locationFilter],
  );
  const years = useMemo(
    () =>
      [
        ...new Set(
          periodInvoices
            .map((invoice) => String(invoice.period || '').slice(0, 4))
            .filter(Boolean),
        ),
      ].sort((first, second) => Number(second) - Number(first)),
    [periodInvoices],
  );
  const months = useMemo(
    () =>
      [
        ...new Set(
          periodInvoices
            .filter(
              (invoice) =>
                yearFilter === 'all' ||
                String(invoice.period || '').startsWith(yearFilter),
            )
            .map((invoice) => String(invoice.period || '').slice(5, 7))
            .filter((month) => /^\d{2}$/.test(month) && Number(month) >= 1 && Number(month) <= 12),
        ),
      ].sort((first, second) => Number(first) - Number(second)),
    [periodInvoices, yearFilter],
  );

  const activeFilters = [
    clientFilter !== 'all' && `Client: ${clientFilter}`,
    locationFilter !== 'all' && `Location: ${locationFilter}`,
    yearFilter !== 'all' && `Year: ${yearFilter}`,
    monthFilter !== 'all' &&
      `Month: ${new Date(2000, Number(monthFilter) - 1, 1).toLocaleString('en-IN', {
        month: 'long',
      })}`,
  ].filter(Boolean);

  const filteredInvoices = useMemo(
    () =>
      invoices
        .filter((invoice) => {
          const invoicePeriod = String(invoice.period || '');
          return (
            (clientFilter === 'all' || invoice.client === clientFilter) &&
            (locationFilter === 'all' ||
              getInvoiceLocationFilterValue(invoice.client, invoice.location) ===
                locationFilter) &&
            (yearFilter === 'all' || invoicePeriod.startsWith(yearFilter)) &&
            (monthFilter === 'all' || invoicePeriod.endsWith(`-${monthFilter}`))
          );
        })
        .sort((first, second) => {
          const firstOrder = Number.isFinite(first.clientDisplayOrder)
            ? first.clientDisplayOrder
            : Number.MAX_SAFE_INTEGER;
          const secondOrder = Number.isFinite(second.clientDisplayOrder)
            ? second.clientDisplayOrder
            : Number.MAX_SAFE_INTEGER;

          return (
            firstOrder - secondOrder ||
            first.client.localeCompare(second.client)
          );
        }),
    [invoices, clientFilter, locationFilter, yearFilter, monthFilter],
  );

  return (
    <Box sx={{ p: { xs: 2, sm: 3, md: 4 }, maxWidth: 1500, margin: '0 auto' }}>
      {/* Page Header */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0, 1fr)',
          gap: 2,
          mb: 3,
        }}
      >
        <Typography variant="h4">
          Generated invoices
        </Typography>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: {
              xs: '1fr',
              sm: 'repeat(2, minmax(0, 1fr))',
              lg: 'repeat(4, minmax(0, 1fr))',
            },
            gap: 1,
            width: '100%',
            minWidth: 0,
          }}
        >
          <TextField
            select
            size="small"
            label="Client"
            value={clientFilter}
            onChange={(event) => {
              const nextClient = event.target.value;
              setClientFilter(nextClient);
              setYearFilter('all');
              setMonthFilter('all');
            }}
          >
            <MenuItem value="all">All clients</MenuItem>
            {availableClients.map((client) => (
              <MenuItem key={client} value={client}>
                {client}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            select
            size="small"
            label="Location"
            value={locationFilter}
            onChange={(event) => {
              const nextLocation = event.target.value;
              if (nextLocation === 'all' || locations.includes(nextLocation)) {
                setLocationFilter(nextLocation);
                if (
                  clientFilter !== 'all' &&
                  !getInvoiceClientOptions(invoices, clients, nextLocation).includes(
                    clientFilter,
                  )
                ) {
                  setClientFilter('all');
                }
                setYearFilter('all');
                setMonthFilter('all');
              }
            }}
          >
            <MenuItem value="all">All locations</MenuItem>
            {locations.map((locationName) => (
              <MenuItem key={locationName} value={locationName}>
                {locationName}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            select
            size="small"
            label="Year"
            value={yearFilter}
            onChange={(event) => {
              setYearFilter(event.target.value);
              setMonthFilter('all');
            }}
          >
            <MenuItem value="all">All years</MenuItem>
            {years.map((year) => (
              <MenuItem key={year} value={year}>
                {year}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            select
            size="small"
            label="Month"
            value={monthFilter}
            onChange={(event) => setMonthFilter(event.target.value)}
          >
            <MenuItem value="all">All months</MenuItem>
            {months.map((month) => {
              return (
                <MenuItem key={month} value={month}>
                  {new Date(2000, Number(month) - 1, 1).toLocaleString('en-IN', {
                    month: 'long',
                  })}
                </MenuItem>
              );
            })}
          </TextField>
        </Box>
      </Box>

      {activeFilters.length > 0 && (
        <Typography sx={{ mb: 2, color: '#647087', fontSize: '14px' }}>
          Showing invoices filtered by {activeFilters.join(', ')}.
        </Typography>
      )}

      {errorMessage && (
        <Alert
          severity="error"
          sx={{ mb: 3, borderRadius: '10px' }}
          onClose={() => setErrorMessage('')}
        >
          {errorMessage}
        </Alert>
      )}
      {companyErrorMessage && (
        <Alert severity="warning" sx={{ mb: 3, borderRadius: '10px' }}>
          {companyErrorMessage} Invoice amounts are still loaded, but issuer and
          bank details may be unavailable in the preview.
        </Alert>
      )}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
          <CircularProgress size={36} sx={{ color: '#1769ff' }} />
        </Box>
      ) : (
        <>
          <InvoiceCardList
            invoices={filteredInvoices}
            period={period}
            onPreview={handlePreview}
            onPrint={handlePrint}
          />
        </>
      )}

      {/* Invoice Preview Modal */}
      <InvoicePreviewModal
        open={previewModalOpen}
        onClose={() => setPreviewModalOpen(false)}
        invoice={selectedInvoice}
        company={invoiceCompany}
        onPrint={handlePrint}
      />
    </Box>
  );
}
