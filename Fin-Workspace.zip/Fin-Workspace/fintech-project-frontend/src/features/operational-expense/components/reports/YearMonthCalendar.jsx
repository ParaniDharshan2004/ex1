import { Box, CircularProgress, IconButton, Tooltip, Typography } from '@mui/material';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import { formatINR } from '../../utils/currency';

export default function YearMonthCalendar({
  months = [],
  onPreview,
  onDownload,
  previewingId = '',
  downloadingId = '',
  actionsDisabled = false,
}) {
  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: {
          xs: '1fr',
          sm: 'repeat(2, minmax(0, 1fr))',
          md: 'repeat(3, minmax(0, 1fr))',
          lg: 'repeat(4, minmax(0, 1fr))',
        },
        gap: { xs: 1.5, sm: 2 },
        alignItems: 'stretch',
        mb: 3,
      }}
    >
      {months.map((m) => {
        const hasReports = Number(m.reportCount ?? m.invoiceCount ?? 0) > 0;
        const report = m.report;
        const reportId = String(report?._id || report?.id || report?.reportMonth || '');
        const isPreviewing = previewingId === reportId;
        const isDownloading = downloadingId === reportId;

        return (
          <Box
            key={m.monthNum}
            component="div"
            aria-disabled={!hasReports}
            sx={{
              width: '100%',
              p: '16px 18px',
              minHeight: 180,
              display: 'flex',
              flexDirection: 'column',
              border: '1px solid',
              borderColor: hasReports ? '#dde3ed' : '#e5e7eb',
              borderRadius: '11px',
              bgcolor: hasReports ? '#fff' : '#f3f4f6',
              color: hasReports ? 'inherit' : '#a6adb8',
              textAlign: 'left',
              font: 'inherit',
              appearance: 'none',
              boxShadow: '0 4px 12px rgba(26, 42, 82, 0.02)',
              transition: 'all 0.15s ease',
              '&:hover': hasReports
                ? {
                    borderColor: '#1769ff',
                    transform: 'translateY(-1px)',
                  }
                : {},
              '&[aria-disabled="true"]': {
                opacity: 0.72,
              },
              '&:focus-visible': {
                outline: hasReports ? '2px solid #1769ff' : 'none',
                outlineOffset: 2,
              },
            }}
          >
            <Typography
              component="b"
              sx={{
                display: 'block',
                fontWeight: 700,
                fontSize: '13px',
                color: hasReports ? '#182036' : '#8b929d',
              }}
            >
              {m.monthName}
            </Typography>

            <Typography
              component="strong"
              className="opex-currency opex-currency-with-symbol"
              sx={{
                display: 'block',
                fontSize: '17px',
                fontWeight: 800,
                color: hasReports ? '#182036' : '#8b929d',
                mt: 1,
                mb: 1,
              }}
            >
              {formatINR(m.totalAmount)}
            </Typography>

            {hasReports && report && (
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'flex-end',
                  alignItems: 'center',
                  mt: 'auto',
                  pt: 0.5,
                  gap: 0.75,
                }}
              >
                <Tooltip title="Preview report">
                  <span>
                    <IconButton
                      size="small"
                      aria-label="Preview report"
                      disabled={actionsDisabled}
                      onClick={() => {
                        onPreview(report);
                      }}
                    >
                      {isPreviewing ? (
                        <CircularProgress size={18} />
                      ) : (
                        <VisibilityOutlinedIcon fontSize="small" />
                      )}
                    </IconButton>
                  </span>
                </Tooltip>
                <Tooltip title="Download PDF">
                  <span>
                    <IconButton
                      size="small"
                      aria-label="Download PDF"
                      disabled={actionsDisabled}
                      onClick={() => {
                        onDownload(report);
                      }}
                    >
                      {isDownloading ? (
                        <CircularProgress size={18} />
                      ) : (
                        <FileDownloadOutlinedIcon fontSize="small" />
                      )}
                    </IconButton>
                  </span>
                </Tooltip>
              </Box>
            )}
          </Box>
        );
      })}
    </Box>
  );
}
