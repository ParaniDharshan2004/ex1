import { useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Collapse,
  CircularProgress,
  Divider,
  List,
  ListItemButton,
  ListItemText,
  Typography,
} from '@mui/material';
import ReceiptRoundedIcon from '@mui/icons-material/ReceiptRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import ConfirmActionModal from '../common/ConfirmActionModal';
import ModalActionButton from '../common/ModalActionButton';
import InvoiceDocumentTemplate from '../invoices/InvoiceDocumentTemplate';
import {
  getAllCompanies,
  previewOperationalExpenseInvoices,
} from '../../api/operationalExpenseApi';
import { formatMonthYear } from '../../utils/date';

const isNonZero = (amount) =>
  Number.isFinite(Number(amount)) &&
  Math.round((Number(amount) + Number.EPSILON) * 100) !== 0;

const toInvoiceDocument = (preview, reportMonth) => {
  const isCrkl = preview.type === 'CRKL Invoice';
  const location = preview.locationDetails;
  const clientCode = isCrkl ? 'CRKL' : 'MKPL';

  return {
    no: 'PREVIEW',
    client: preview.entityName,
    clientAddress: location?.billingAddress || '',
    clientPinCode: location?.pinCode || '',
    clientState: [location?.stateName, location?.stateCode]
      .filter(Boolean)
      .join(' - '),
    clientTaxDetails: {
      gstin: location?.gstNumber || '',
      pan: location?.panNumber || '',
      tan: location?.tanNumber || '',
    },
    location: location?.locationName || 'Corporate',
    amount: preview.grandTotal,
    taxableAmount: preview.taxableAmount,
    gstAmount: preview.gstAmount,
    gstRate: isCrkl ? undefined : 18,
    grandTotal: preview.grandTotal,
    period: reportMonth,
    periodFormatted: formatMonthYear(reportMonth),
    date: new Date().toLocaleDateString('en-IN'),
    rawInvoice: {
      clientId: { clientCode },
      locationId: location
        ? {
            billingName: location.billingName,
          }
        : null,
    },
    previewBreakdown: {
      expenses: preview.allocatedExpenseBreakdown || [],
      markupAmount: preview.markupAmount,
      totalBillableAmount: preview.totalBillableAmount,
    },
  };
};

export default function AllocationInvoicePreview({
  open,
  onClose,
  reportId,
  clients = [],
  mkplLocations = [],
  chennaiAmount,
  bengaluruAmount,
  headerToClientsSpacing = 2,
  previewTitle = 'Invoice Preview',
  invoicesHeading = 'Invoices',
  previewTitleSx = {},
  previewSubtitleSx = {},
  invoicesHeadingSx = {},
  invoiceCompanyHeaderSx = {},
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [companyWarning, setCompanyWarning] = useState('');
  const [company, setCompany] = useState(null);
  const [reportMonth, setReportMonth] = useState('');
  const [invoices, setInvoices] = useState([]);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [expandedClients, setExpandedClients] = useState({});

  useEffect(() => {
    if (!open) return undefined;

    let active = true;

    const loadPreview = async () => {
      setLoading(true);
      setError('');
      setCompanyWarning('');
      setCompany(null);
      setInvoices([]);
      setSelectedInvoice(null);

      try {
        const mkplClient = clients.find(
          (client) =>
            /MKPL/i.test(client.clientCode || '') ||
            /MKPL/i.test(client.clientName || ''),
        );

        const chennai = mkplLocations.find((item) =>
          /chennai/i.test(item.locationName || ''),
        );

        const bengaluru = mkplLocations.find((item) =>
          /bengaluru|bangalore/i.test(item.locationName || ''),
        );

        if (!reportId || !mkplClient?._id || !chennai?._id || !bengaluru?._id) {
          throw new Error(
            'Report, MKPL client, Chennai, or Bengaluru details are unavailable.',
          );
        }

        const [previewResult, companyResult] = await Promise.allSettled([
          previewOperationalExpenseInvoices(reportId, {
            clientId: mkplClient._id,
            locationAllocations: [
              {
                locationId: chennai._id,
                amount: chennaiAmount,
              },
              {
                locationId: bengaluru._id,
                amount: bengaluruAmount,
              },
            ],
          }),
          getAllCompanies(),
        ]);

        if (!active) return;

        if (previewResult.status === 'rejected') {
          throw previewResult.reason;
        }

        if (companyResult.status === 'rejected') {
          setCompanyWarning(
            'Issuer and bank details may be unavailable because company details could not be loaded.',
          );
        }

        const previewResponse = previewResult.value;
        const previewData = previewResponse.data?.data;

        if (!Array.isArray(previewData?.invoices)) {
          throw new Error('The server did not return invoice preview data.');
        }

        const companies =
          companyResult.status === 'fulfilled'
            ? companyResult.value.data?.data
            : [];

        if (Array.isArray(companies)) {
          const koplCompany = companies.find((item) =>
            /\bKOPL\b|KAMALA\s+OUTSOURCING/i.test(item.companyName || ''),
          );
          setCompany(koplCompany || null);

          if (!koplCompany && companyResult.status === 'fulfilled') {
            setCompanyWarning(
              'KOPL issuer details were not found in Company Master.',
            );
          }
        } else if (companyResult.status === 'fulfilled') {
          setCompanyWarning(
            'Issuer and bank details may be unavailable because Company Master returned an invalid response.',
          );
        }

        setReportMonth(previewData.reportMonth || '');

        const previewInvoices = previewData.invoices
          .filter(
            (invoice) =>
              !/^MKPL Invoice$/i.test(invoice.type || '') &&
              isNonZero(invoice.baseAmount) &&
              isNonZero(invoice.invoiceAmount),
          )
          .map((invoice, index) => ({
            ...invoice,
            listKey: `${invoice.type}-${index}`,
            document: toInvoiceDocument(invoice, previewData.reportMonth),
          }));

        setInvoices(previewInvoices);

        // Do not automatically select the first invoice.
        setSelectedInvoice(null);
      } catch (requestError) {
        if (active) {
          setError(
            requestError?.response?.data?.message ||
              requestError?.message ||
              'Unable to load invoice preview.',
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    loadPreview();

    return () => {
      active = false;
    };
  }, [
    open,
    reportId,
    clients,
    mkplLocations,
    chennaiAmount,
    bengaluruAmount,
  ]);

  const closeAllPreviews = () => {
    setSelectedInvoice(null);
    onClose();
  };

  const invoiceGroups = invoices.reduce((groups, invoice, index) => {
    const clientName =
      invoice.entityName || invoice.invoiceName || invoice.type;

    const existing = groups.find(
      (group) => group.clientName === clientName,
    );

    if (existing) {
      existing.invoices.push({
        ...invoice,
        listKey: `${invoice.type}-${index}`,
      });
    } else {
      groups.push({
        clientName,
        invoices: [
          {
            ...invoice,
            listKey: `${invoice.type}-${index}`,
          },
        ],
      });
    }

    return groups;
  }, []);

  const invoiceLabel = (invoice) =>
    invoice.locationDetails?.locationName ||
    invoice.entityName ||
    invoice.type.replace(/\s+Invoice$/i, '');

  return (
    <ConfirmActionModal
      open={open}
      onClose={closeAllPreviews}
      onHeaderClose={() => {
        if (selectedInvoice) {
          setSelectedInvoice(null);
          return;
        }
        closeAllPreviews();
      }}
      icon={<ReceiptRoundedIcon sx={{ fontSize: 24 }} />}
      title={previewTitle}
      subtitle={reportMonth ? formatMonthYear(reportMonth) : ''}
      dialogWidth="min(900px, 90vw)"
      dialogHeight="min(900px, calc(100dvh - 64px))"
      titleSx={previewTitleSx}
      subtitleSx={previewSubtitleSx}
    >
      {companyWarning && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          {companyWarning}
        </Alert>
      )}

      {loading ? (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            py: 5,
          }}
        >
          <CircularProgress size={32} />
        </Box>
      ) : error ? (
        <Alert severity="error">{error}</Alert>
      ) : invoices.length ? (
        selectedInvoice ? (
          <Box sx={{ width: '100%' }}>
            <Box
              sx={{
                width: '100%',
                overflow: 'auto',
              }}
            >
              <InvoiceDocumentTemplate
                invoice={selectedInvoice.document}
                company={company}
                allowPrint={false}
                companyNameSx={invoiceCompanyHeaderSx}
                hideHeaderBorder
                embedded
              />
            </Box>
          </Box>
        ) : (
          <Box
            component="nav"
            aria-label="Invoices"
            sx={{ width: '100%', mt: headerToClientsSpacing }}
          >
            <Typography
              variant="overline"
              sx={{
                display: 'block',
                px: 1,
                pb: 1,
                color: '#647087',
                fontWeight: 800,
                letterSpacing: '0.08em',
                ...invoicesHeadingSx,
              }}
            >
              {invoicesHeading}
            </Typography>

            <Divider />

            <List dense disablePadding sx={{ py: 1 }}>
              {invoiceGroups.map((group) => {
                const locationInvoices = group.invoices.filter(
                  (invoice) => invoice.locationDetails,
                );

                const hasMultipleLocations =
                  locationInvoices.length > 1;

                if (!hasMultipleLocations) {
                  return group.invoices.map((invoice) => (
                    <Box
                      key={invoice.listKey}
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 1,
                        mx: 1,
                        mb: 0.5,
                      }}
                    >
                      <ListItemButton
                        onClick={() => setSelectedInvoice(invoice)}
                        sx={{ flex: 1, borderRadius: 1.5 }}
                      >
                        <ListItemText
                          primary={invoiceLabel(invoice)}
                          primaryTypographyProps={{
                            fontSize: 13,
                            fontWeight: 500,
                          }}
                        />
                      </ListItemButton>
                      <ModalActionButton
                        startIcon={<VisibilityRoundedIcon sx={{ fontSize: 16 }} />}
                        onClick={() => setSelectedInvoice(invoice)}
                        sx={{ mr: 1 }}
                      >
                        View Invoice
                      </ModalActionButton>
                    </Box>
                  ));
                }

                const expanded =
                  expandedClients[group.clientName] ?? false;

                return (
                  <Box key={group.clientName} sx={{ mb: 0.5 }}>
                    <ListItemButton
                      aria-expanded={expanded}
                      onClick={() =>
                        setExpandedClients((current) => ({
                          ...current,
                          [group.clientName]: !expanded,
                        }))
                      }
                      sx={{
                        mx: 1,
                        borderRadius: 1.5,
                      }}
                    >
                      <ListItemText
                        primary={group.clientName}
                        primaryTypographyProps={{
                          fontSize: 13,
                          fontWeight: 700,
                        }}
                      />
                      {expanded ? (
                        <ExpandMoreRoundedIcon fontSize="small" />
                      ) : (
                        <ChevronRightRoundedIcon fontSize="small" />
                      )}
                    </ListItemButton>

                    <Collapse
                      in={expanded}
                      timeout="auto"
                      unmountOnExit
                    >
                      <List dense disablePadding>
                        {group.invoices.map((invoice) => (
                          <Box
                            key={invoice.listKey}
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: 1,
                              ml: 3,
                              mr: 1,
                              mb: 0.5,
                            }}
                          >
                            <ListItemButton
                              onClick={() => setSelectedInvoice(invoice)}
                              sx={{ flex: 1, borderRadius: 1.5 }}
                            >
                              <ListItemText
                                primary={invoiceLabel(invoice)}
                                primaryTypographyProps={{
                                  fontSize: 13,
                                  fontWeight: 500,
                                }}
                              />
                            </ListItemButton>
                            <ModalActionButton
                              startIcon={
                                <VisibilityRoundedIcon sx={{ fontSize: 16 }} />
                              }
                              onClick={() => setSelectedInvoice(invoice)}
                              sx={{ mr: 1 }}
                            >
                              View Invoice
                            </ModalActionButton>
                          </Box>
                        ))}
                      </List>
                    </Collapse>
                  </Box>
                );
              })}
            </List>
          </Box>
        )
      ) : (
        <Typography>
          No invoices with a non-zero allocation to preview.
        </Typography>
      )}
    </ConfirmActionModal>
  );
}