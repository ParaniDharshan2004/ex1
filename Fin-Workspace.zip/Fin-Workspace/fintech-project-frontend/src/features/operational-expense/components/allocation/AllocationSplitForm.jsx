import {
  Box,
  Typography,
  TextField,
  Select,
  MenuItem,
  Button,
  Divider,
  InputAdornment,
  Stack,
} from '@mui/material';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import { formatINR } from '../../utils/currency';

const isValidAmountInput = (value) => /^\d*\.?\d*$/.test(value);

const preventInvalidAmountKey = (event) => {
  if (['e', 'E', '+', '-'].includes(event.key)) {
    event.preventDefault();
  }
};

const preventInvalidAmountPaste = (event) => {
  const pastedValue = event.clipboardData.getData('text').trim();
  if (!/^\d+(?:\.\d*)?$/.test(pastedValue)) {
    event.preventDefault();
  }
};

export default function AllocationSplitForm({
  mkplAmount,
  onMkplAmountChange,
  crklBalance,
  splitMethod,
  onSplitMethodChange,
  chennaiAmount,
  onChennaiAmountChange,
  bengaluruAmount,
  onBengaluruAmountChange,
  validationResult,
  onReviewAndGenerate,
  isGenerating = false,
  disabled = false,
}) {
  const isCustom = splitMethod === 'custom';
  const { isValid, progressPercent, severity, message } = validationResult;

  return (
    <Box
      sx={{
        bgcolor: '#fff',
        border: '1px solid #dde3ed',
        borderRadius: '15px',
        boxShadow: '0 14px 40px rgba(26, 42, 82, 0.05)',
        p: { xs: 2, sm: 3 },
        filter: disabled ? 'grayscale(1)' : 'none',
        opacity: disabled ? 0.58 : 1,
        pointerEvents: disabled ? 'none' : 'auto',
      }}
    >
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' },
          gap: 2,
          mb: 2.5,
        }}
      >
        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Amount charged to MKPL
          </Typography>
          <TextField
            type="number"
            size="small"
            fullWidth
            placeholder="Enter amount"
            value={mkplAmount === 0 ? '' : mkplAmount}
            onChange={(e) => {
              if (isValidAmountInput(e.target.value)) {
                onMkplAmountChange(e.target.value);
              }
            }}
            slotProps={{
              htmlInput: {
                min: 0,
                className: 'opex-currency',
                onKeyDown: preventInvalidAmountKey,
                onPaste: preventInvalidAmountPaste,
              },
            }}
            sx={{
              '& input[type=number]': { MozAppearance: 'textfield' },
              '& input[type=number]::-webkit-outer-spin-button, & input[type=number]::-webkit-inner-spin-button':
                { WebkitAppearance: 'none', margin: 0 },
              '& .MuiOutlinedInput-root': {
                bgcolor: '#fff',
                borderRadius: '8px',
                fontWeight: 700,
              },
            }}
          />
        </Box>

        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Amount charged to CRKL INC
          </Typography>
          <TextField
            size="small"
            fullWidth
            value={formatINR(crklBalance, { showSymbol: false })}
            slotProps={{
              input: {
                readOnly: true,
                startAdornment: (
                  <InputAdornment
                    position="start"
                    sx={{ mr: 0, color: 'inherit', fontSize: 'inherit' }}
                  >
                    <span className="currency-symbol">₹</span>
                  </InputAdornment>
                ),
              },
              htmlInput: { className: 'opex-currency' },
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: '#f1f4f8',
                borderRadius: '8px',
                color: '#556176',
                fontWeight: 700,
              },
            }}
          />
        </Box>
      </Box>

      <Box sx={{ mb: 2.5 }}>
        <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
          MKPL Allocation Method
        </Typography>
        <Select
          size="small"
          fullWidth
          value={splitMethod}
          onChange={(e) => onSplitMethodChange(e.target.value)}
          sx={{
            borderRadius: '8px',
            bgcolor: '#fff',
            fontSize: '13px',
            fontWeight: 600,
            '& fieldset': { borderColor: '#ccd5e2' },
          }}
        >
          <MenuItem value="equal">Equal split (50 / 50)</MenuItem>
          <MenuItem value="custom">Custom split</MenuItem>
        </Select>
      </Box>

      <Divider sx={{ my: 2.5, borderColor: '#dde3ed' }} />

      <Typography sx={{ fontWeight: 800, fontSize: '14px', color: '#182036', mb: 1.5 }}>
        MKPL Location Breakdown
      </Typography>

      {/* Chennai location row */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'minmax(0, 1fr) 280px' },
          gap: 1.5,
          alignItems: 'flex-end',
          mb: 1.5,
        }}
      >
        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Location
          </Typography>
          <TextField
            size="small"
            fullWidth
            value="Chennai"
            slotProps={{ input: { readOnly: true } }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: '#f1f4f8',
                borderRadius: '8px',
                color: '#556176',
                fontWeight: 600,
              },
            }}
          />
        </Box>

        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Invoice amount
          </Typography>
          <TextField
            type="number"
            size="small"
            fullWidth
            placeholder="Enter amount"
            value={chennaiAmount === 0 ? '' : chennaiAmount}
            onChange={(e) => {
              if (isValidAmountInput(e.target.value)) {
                onChennaiAmountChange(e.target.value);
              }
            }}
            slotProps={{
              input: { readOnly: !isCustom },
              htmlInput: {
                min: 0,
                className: 'opex-currency',
                onKeyDown: preventInvalidAmountKey,
                onPaste: preventInvalidAmountPaste,
              },
            }}
            sx={{
              '& input[type=number]': { MozAppearance: 'textfield' },
              '& input[type=number]::-webkit-outer-spin-button, & input[type=number]::-webkit-inner-spin-button':
                { WebkitAppearance: 'none', margin: 0 },
              '& .MuiOutlinedInput-root': {
                bgcolor: !isCustom ? '#f1f4f8' : '#fff',
                borderRadius: '8px',
                fontWeight: 700,
              },
            }}
          />
        </Box>

      </Box>

      {/* Bengaluru location row */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'minmax(0, 1fr) 280px' },
          gap: 1.5,
          alignItems: 'flex-end',
          mb: 1,
        }}
      >
        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Location
          </Typography>
          <TextField
            size="small"
            fullWidth
            value="Bengaluru"
            slotProps={{ input: { readOnly: true } }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: '#f1f4f8',
                borderRadius: '8px',
                color: '#556176',
                fontWeight: 600,
              },
            }}
          />
        </Box>

        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Invoice amount
          </Typography>
          <TextField
            type="number"
            size="small"
            fullWidth
            placeholder="Enter amount"
            value={bengaluruAmount === 0 ? '' : bengaluruAmount}
            onChange={(e) => {
              if (isValidAmountInput(e.target.value)) {
                onBengaluruAmountChange(e.target.value);
              }
            }}
            slotProps={{
              input: { readOnly: !isCustom },
              htmlInput: {
                min: 0,
                className: 'opex-currency',
                onKeyDown: preventInvalidAmountKey,
                onPaste: preventInvalidAmountPaste,
              },
            }}
            sx={{
              '& input[type=number]': { MozAppearance: 'textfield' },
              '& input[type=number]::-webkit-outer-spin-button, & input[type=number]::-webkit-inner-spin-button':
                { WebkitAppearance: 'none', margin: 0 },
              '& .MuiOutlinedInput-root': {
                bgcolor: !isCustom ? '#f1f4f8' : '#fff',
                borderRadius: '8px',
                fontWeight: 700,
              },
            }}
          />
        </Box>

      </Box>

      {/* Balance message box */}
      <Box
        sx={{
          display: 'flex',
          gap: 1.5,
          alignItems: 'center',
          p: '12px 16px',
          borderRadius: '9px',
          fontSize: '12px',
          lineHeight: 1.4,
          bgcolor: severity === 'ok' ? '#eaf8f3' : severity === 'error' ? '#fff0f1' : '#fff7e8',
          color: severity === 'ok' ? '#116c50' : severity === 'error' ? '#8c2931' : '#76561b',
          border: '1px solid',
          borderColor: severity === 'ok' ? '#bde6d7' : severity === 'error' ? '#f1c1c5' : '#efd7a1',
          mb: 1.5,
        }}
      >
        {severity === 'ok' ? (
          <CheckCircleRoundedIcon sx={{ fontSize: 20, color: '#0c9b6f', flexShrink: 0 }} />
        ) : (
          <WarningAmberRoundedIcon sx={{ fontSize: 20, color: severity === 'error' ? '#d8404c' : '#d78508', flexShrink: 0 }} />
        )}
        <Typography sx={{ fontSize: '12px', fontWeight: 600 }}>
          {message}
        </Typography>
      </Box>

      {/* Progress bar */}
      <Box
        sx={{
          bgcolor: '#e7ecf3',
          height: 8,
          borderRadius: '99px',
          overflow: 'hidden',
          mb: 3,
        }}
      >
        <Box
          sx={{
            height: '100%',
            background: isValid
              ? '#0c9b6f'
              : 'linear-gradient(90deg, #1769ff, #13b9e6)',
            width: `${progressPercent}%`,
            transition: 'width 0.3s ease',
          }}
        />
      </Box>

      {/* Action button */}
      <Stack direction="row" spacing={1.25} sx={{ justifyContent: 'flex-end' }}>
        {/* To restore Preview Invoices, re-add CircularProgress, VisibilityRoundedIcon,
            onPreviewInvoices, and isPreviewing.
        <Button
          variant="outlined"
          size="large"
          disabled={!isValid || isGenerating || isPreviewing}
          startIcon={
            isPreviewing ? (
              <CircularProgress size={16} />
            ) : (
              <VisibilityRoundedIcon sx={{ fontSize: 18 }} />
            )
          }
          onClick={onPreviewInvoices}
          sx={{
            borderColor: '#1769ff',
            color: '#1769ff',
            textTransform: 'none',
            fontWeight: 800,
            fontSize: '13px',
            borderRadius: '9px',
            px: 2,
            py: 1.1,
          }}
        >
          Preview Invoices
        </Button>
        */}
        <Button
          variant="contained"
          disabled={!isValid || isGenerating}
          startIcon={<ArrowForwardRoundedIcon sx={{ fontSize: 18 }} />}
          onClick={onReviewAndGenerate}
          sx={{
            bgcolor: 'rgb(23, 105, 255)',
            color: '#fff',
            textTransform: 'none',
            fontWeight: 800,
            fontSize: '13px',
            borderRadius: '9px',
            px: 2.5,
            py: 1.1,
            boxShadow: '0 7px 18px rgba(23, 105, 255, 0.28)',
            '&:hover': { bgcolor: '#1255d6' },
          }}
        >
          Save & Continue
        </Button>
      </Stack>
    </Box>
  );
}
