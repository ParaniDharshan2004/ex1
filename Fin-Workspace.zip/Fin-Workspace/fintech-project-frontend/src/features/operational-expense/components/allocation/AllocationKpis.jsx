import { Box, Typography } from '@mui/material';
import WalletCardsRoundedIcon from '@mui/icons-material/AccountBalanceWalletRounded';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';
import BalanceRoundedIcon from '@mui/icons-material/BalanceRounded';
import { formatINR } from '../../utils/currency';

export default function AllocationKpis({
  totalBillable = 0,
  allocatedTotal = 0,
  remainingBalance = 0,
}) {
  const cards = [
    {
      label: 'Total Billable',
      value: formatINR(totalBillable),
      subtitle: 'Includes 20% Markup',
      color: '#1769ff',
      tint: '#eaf1ff',
      icon: <WalletCardsRoundedIcon sx={{ fontSize: 20 }} />,
    },
    {
      label: 'Allocated Amount',
      value: formatINR(allocatedTotal),
      subtitle: '',
      color: '#0c9b6f',
      tint: '#e9f8f3',
      icon: <CheckCircleOutlineRoundedIcon sx={{ fontSize: 20 }} />,
    },
    {
      label: 'Remaining Amount',
      value: formatINR(remainingBalance),
      subtitle: '',
      color: '#d78508',
      tint: '#fff4df',
      icon: <BalanceRoundedIcon sx={{ fontSize: 20 }} />,
    },
  ];

  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, 1fr)' },
        gap: 2,
        mb: 3,
      }}
    >
      {cards.map((c, i) => (
        <Box
          key={i}
          sx={{
            p: '18px 20px',
            borderRadius: '13px',
            border: '1px solid #dde3ed',
            bgcolor: '#fff',
            position: 'relative',
            overflow: 'hidden',
            boxShadow: '0 14px 40px rgba(26, 42, 82, 0.04)',
            '&::after': {
              content: '""',
              position: 'absolute',
              width: 70,
              height: 70,
              borderRadius: '50%',
              right: -25,
              top: -25,
              bgcolor: c.tint,
              zIndex: 0,
            },
          }}
        >
          <Box
            sx={{
              position: 'relative',
              zIndex: 1,
              width: 37,
              height: 37,
              borderRadius: '10px',
              display: 'grid',
              placeItems: 'center',
              color: c.color,
              bgcolor: c.tint,
            }}
          >
            {c.icon}
          </Box>
          <Typography
            sx={{
              position: 'relative',
              zIndex: 1,
              display: 'block',
              color: '#647087',
              fontSize: '12px',
              fontWeight: 600,
              mt: '13px',
              mb: '5px',
            }}
          >
            {c.label}
          </Typography>
          <Typography
            className="opex-currency opex-currency-with-symbol"
            sx={{
              position: 'relative',
              zIndex: 1,
              fontSize: '22px',
              fontWeight: '700 !important',
              color: '#182036',
              lineHeight: 1.2,
            }}
          >
            {c.value}
          </Typography>
          <Typography
            sx={{
              position: 'relative',
              zIndex: 1,
              display: 'block',
              fontSize: '11px',
              color: '#647087',
              mt: '6px',
            }}
          >
            {c.subtitle}
          </Typography>
        </Box>
      ))}
    </Box>
  );
}
