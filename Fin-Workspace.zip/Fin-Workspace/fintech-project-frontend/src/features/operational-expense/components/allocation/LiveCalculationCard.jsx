import { Box, Typography } from '@mui/material';
import { formatINR } from '../../utils/currency';

export default function LiveCalculationCard({
  subtotal = 0,
  markup = 0,
  fixedCostTotal = 0,
  miscellaneousExpenseTotal = 0,
  otherExpenseTotal = 0,
  totalBillable = 0,
  mkplAmount = 0,
  crklBalance = 0,
}) {
  const rows = [
    { label: 'Operational expense', value: formatINR(subtotal) },
    { label: 'Markup (20%)', value: formatINR(markup) },
    ...(miscellaneousExpenseTotal > 0
      ? [{ label: 'Misc Expense', value: formatINR(miscellaneousExpenseTotal) }]
      : []),
    ...(fixedCostTotal > 0
      ? [{ label: 'Fixed Assets', value: formatINR(fixedCostTotal) }]
      : []),
    ...(otherExpenseTotal > 0
      ? [{ label: 'Other expense categories', value: formatINR(otherExpenseTotal) }]
      : []),
    { label: 'Total Billable', value: formatINR(totalBillable) },
    { label: 'Allocated to MKPL', value: formatINR(mkplAmount) },
  ];

  return (
    <Box
      sx={{
        background: 'linear-gradient(145deg, #0b1739, #14285d)',
        color: '#fff',
        borderRadius: '15px',
        p: '24px',
        boxShadow: '0 14px 40px rgba(11, 23, 57, 0.25)',
        display: 'flex',
        flexDirection: 'column',
        height: 'fit-content',
      }}
    >
      <Typography
        variant="h6"
        sx={{
          m: 0,
          mb: 2,
          fontSize: '17px',
          fontWeight: 800,
          color: '#fff',
          letterSpacing: '-0.01em',
        }}
      >
        Allocation Summary
      </Typography>

      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        {rows.map((r, i) => (
          <Box
            key={i}
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              py: '11px',
              borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
              fontSize: '13px',
              color: '#d1dcfa',
            }}
          >
            <span>{r.label}</span>
            <Typography component="b" className="opex-currency opex-currency-with-symbol" sx={{color: '#fff', fontSize: '13px' }}>
              {r.value}
            </Typography>
          </Box>
        ))}

        {/* Total CRKL Balance Row */}
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            pt: '14px',
            pb: '4px',
            fontSize: '16px',
            fontWeight: 800,
            color: '#fff',
          }}
        >
          <span> Allocated to CRKL</span>
          <Typography
            component="b"
            className="opex-currency opex-currency-with-symbol"
            sx={{ fontWeight: 800, fontSize: '18px',}}
          >
            {formatINR(crklBalance)}
          </Typography>
        </Box>
      </Box>

      
    </Box>
  );
}
