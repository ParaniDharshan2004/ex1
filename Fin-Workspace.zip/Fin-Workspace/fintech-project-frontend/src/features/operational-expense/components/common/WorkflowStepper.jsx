import { Box, Typography } from '@mui/material';
import CheckRoundedIcon from '@mui/icons-material/CheckRounded';
import { useLocation } from 'react-router-dom';
import { WORKFLOW_STEPS } from '../../utils/statusHelpers';

export default function WorkflowStepper({ status = '' }) {
  const { pathname, search } = useLocation();
  const searchParams = new URLSearchParams(search);
  const isSelectingMonth =
    pathname === '/operational-expense-dashboard' &&
    searchParams.get('step') === 'select-month';
  const isUploadReview = /^\/operational-expenses(?:\/|$)/.test(pathname);
  const isAllocation = /^\/operational-expense-allocation(?:\/|$)/.test(
    pathname,
  );
  const isFinalize = /^\/operational-expense-finalize(?:\/|$)/.test(pathname);
  const normalizedStatus = String(status || '').toUpperCase();
  const currentStep = isSelectingMonth
    ? 0
    : isFinalize ? 3 : isAllocation ||
        (isUploadReview && normalizedStatus === 'ALLOCATION_PENDING')
        ? 2
      : 1;

  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        my: { xs: 2, sm: 3 },
        width: '100%',
      }}
    >
      {WORKFLOW_STEPS.map((step, index) => {
        const isDone = index < currentStep;
        const isCurrent = index === currentStep;

        return (
          <Box
            key={step.label}
            sx={{
              position: 'relative',
              textAlign: 'center',
              color: isCurrent || isDone ? '#182036' : '#7e899a',
              fontSize: '11px',
              fontWeight: 700,
              '&:not(:last-child)::before': {
                content: '""',
                position: 'absolute',
                top: '17px',
                left: '50%',
                width: '100%',
                height: '2px',
                bgcolor: isDone || isCurrent ? '#0c9b6f' : '#dce2eb',
                background: isCurrent
                  ? 'linear-gradient(90deg, #1769ff 50%, #dce2eb 50%)'
                  : undefined,
                zIndex: 0,
              },
            }}
          >
            <Box
              sx={{
                position: 'relative',
                zIndex: 1,
                width: 35,
                height: 35,
                borderRadius: '50%',
                bgcolor: isDone ? '#0c9b6f' : isCurrent ? '#1769ff' : '#e9edf3',
                color: isDone || isCurrent ? '#fff' : '#647087',
                display: 'grid',
                placeItems: 'center',
                margin: '0 auto 7px',
                boxShadow: isCurrent ? '0 0 0 6px rgba(23, 105, 255, 0.12)' : 'none',
                transition: 'all 0.2s ease',
                fontSize: '13px',
                fontWeight: 800,
              }}
            >
              {isDone ? (
                <CheckRoundedIcon sx={{ fontSize: 18 }} />
              ) : (
                step.stepNumber
              )}
            </Box>
            <Typography
              component="span"
              sx={{
                display: { xs: 'none', sm: 'inline-block' },
                fontSize: '11px',
                fontWeight: isCurrent ? 800 : 600,
                color: isCurrent ? '#1769ff' : isDone ? '#0c9b6f' : '#647087',
              }}
            >
              {step.label}
            </Typography>
          </Box>
        );
      })}
    </Box>
  );
}
