import { useRef, useState } from 'react';
import { Box, Typography, Button, TextField, IconButton } from '@mui/material';
import CloudUploadRoundedIcon from '@mui/icons-material/CloudUploadRounded';
import FolderOpenRoundedIcon from '@mui/icons-material/FolderOpenRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { formatMonthYear } from '../../utils/date';

export default function FileUploadZone({
  period,
  invoiceDate,
  fileName,
  fileInputResetKey,
  onFileSelect,
  onRemoveFile,
  disabled = false,
}) {
  const fileInputRef = useRef(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragEnter = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    if (disabled) return;
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleInputChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <Box
      sx={{
        bgcolor: '#fff',
        border: '1px solid #dde3ed',
        borderRadius: '15px',
        boxShadow: '0 14px 40px rgba(26, 42, 82, 0.05)',
        p: { xs: 2, sm: 2.5 },
        mb: 3,
      }}
    >
      {/* <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, 1fr)' },
          gap: 2,
          mb: 3,
        }}
      >
        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Expense Month
          </Typography>
          <TextField
            size="small"
            fullWidth
            value={formatMonthYear(period) || period || ''}
            slotProps={{ input: { readOnly: true } }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: '#f1f4f8',
                borderRadius: '8px',
                color: '#556176',
                fontWeight: 600,
              },
            }}
          />
        </Box>

        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Invoice date
          </Typography>
          <TextField
            type="date"
            size="small"
            fullWidth
            value={invoiceDate || ''}
            slotProps={{ input: { readOnly: true } }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: '#f1f4f8',
                borderRadius: '8px',
                color: '#556176',
                fontWeight: 600,
              },
            }}
          />
        </Box>

        <Box>
          <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
            Markup
          </Typography>
          <TextField
            size="small"
            fullWidth
            value="20%"
            slotProps={{ input: { readOnly: true } }}
            sx={{
              '& .MuiOutlinedInput-root': {
                bgcolor: '#f1f4f8',
                borderRadius: '8px',
                color: '#556176',
                fontWeight: 700,
              },
            }}
          />
        </Box>
      </Box> */}

      {/* Upload Drop Zone */}
      <Box
        onDragEnter={handleDragEnter}
        onDragOver={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        sx={{
            filter: disabled ? 'grayscale(1)' : 'none',
            opacity: disabled ? 0.72 : 1,
            pointerEvents: disabled ? 'none' : 'auto',
            border: '2px dashed',
          borderColor: isDragOver ? '#1769ff' : '#b9c8dd',
          borderRadius: '13px',
          bgcolor: isDragOver ? '#edf4ff' : '#f8fbff',
          textAlign: 'center',
          p: { xs: 3, sm: 4 },
          transition: 'all 0.2s ease',
        }}
      >
        <Box
          sx={{
            width: 52,
            height: 52,
            borderRadius: '14px',
            bgcolor: '#e9f2ff',
            color: '#1769ff',
            display: 'grid',
            placeItems: 'center',
            margin: '0 auto 12px',
          }}
        >
          <CloudUploadRoundedIcon sx={{ fontSize: 28 }} />
        </Box>

        <Typography sx={{ fontSize: '15px', fontWeight: 700, color: '#182036', mb: 0.5 }}>
          Drop Tally report here
        </Typography>
        <Typography sx={{ fontSize: '12px', color: '#647087', mb: 2 }}>
          Supports CSV, TXT, Excel and PDF formats. CSV/Excel is recommended for reliable extraction.
        </Typography>

        <input
          key={fileInputResetKey}
          ref={fileInputRef}
          type="file"
          accept=".csv,.txt,.xlsx,.xls,.pdf,.jpg,.jpeg,.png,.webp"
          onChange={handleInputChange}
          disabled={disabled}
          style={{ display: 'none' }}
        />

        <Button
          variant="contained"
          startIcon={<FolderOpenRoundedIcon sx={{ fontSize: 18 }} />}
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled}
          sx={{
            bgcolor: '#eaf0f8',
            color: '#273653',
            textTransform: 'none',
            fontWeight: 700,
            fontSize: '12px',
            borderRadius: '8px',
            px: 2.5,
            py: 1,
            boxShadow: 'none',
            '&:hover': { bgcolor: '#dde5f0', boxShadow: 'none' },
          }}
        >
          Choose report
        </Button>

        {fileName && (
          <Box sx={{ mt: 2 }}>
            <Box
              sx={{
                display: 'inline-flex',
                gap: 1,
                alignItems: 'center',
                px: 1.5,
                py: 0.75,
                bgcolor: '#e9f8f2',
                color: '#0c9b6f',
                fontSize: '12px',
                fontWeight: 700,
                borderRadius: '8px',
                border: '1px solid #bde6d7',
              }}
            >
              <CheckCircleRoundedIcon sx={{ fontSize: 16 }} />
              {fileName}
              <IconButton
                aria-label="Remove uploaded file"
                size="small"
                onClick={onRemoveFile}
                disabled={disabled}
                sx={{
                  color: '#d32f2f',
                  p: 0.25,
                  '&:hover': { bgcolor: '#ffe5e5', color: '#b71c1c' },
                }}
              >
                <CloseRoundedIcon sx={{ fontSize: 16 }} />
              </IconButton>
            </Box>
          </Box>
        )}
      </Box>
    </Box>
  );
}
