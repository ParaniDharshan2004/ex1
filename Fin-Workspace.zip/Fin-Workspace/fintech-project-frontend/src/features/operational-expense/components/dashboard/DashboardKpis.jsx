import { Box, Typography } from '@mui/material';
import LayersRoundedIcon from '@mui/icons-material/LayersRounded';
import AccessTimeRoundedIcon from '@mui/icons-material/AccessTimeRounded';
import VerifiedRoundedIcon from '@mui/icons-material/VerifiedRounded';
import CurrencyRupeeRoundedIcon from '@mui/icons-material/CurrencyRupeeRounded';
import { formatINR } from '../../utils/currency';

export default function DashboardKpis({
  totalRecords = 0,
  pendingActions = 0,
  completed = 0,
  invoicedValue = 0,
}) {
  const cards = [
    {
      label: 'Total Records',
      value: totalRecords,
      subtitle: 'Monthly expense records',
      color: '#1769ff',
      tint: '#eaf1ff',
      icon: <LayersRoundedIcon sx={{ fontSize: 20 }} />,
    },
    {
      label: 'Pending Actions',
      value: pendingActions,
      subtitle: 'Requires attention',
      color: '#d78508',
      tint: '#fff4df',
      icon: <AccessTimeRoundedIcon sx={{ fontSize: 20 }} />,
    },
    {
      label: 'Completed records',
      value: completed,
      subtitle: 'Completed records',
      color: '#0c9b6f',
      tint: '#e9f8f3',
      icon: <VerifiedRoundedIcon sx={{ fontSize: 20 }} />,
    },
    {
      label: 'Invoiced Value',
      value: formatINR(invoicedValue),
      isCurrency: true,
      subtitle: 'Total invoiced amount',
      color: '#7357e8',
      tint: '#f0edff',
      icon: <CurrencyRupeeRoundedIcon sx={{ fontSize: 20 }} />,
    },
  ];

  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: {
          xs: '1fr',
          sm: 'repeat(2, 1fr)',
          md: 'repeat(4, 1fr)',
        },
        gap: 2,
        mb: 3,
      }}
    >
      {cards.map((c, i) => (
        <Box
          key={i}
          sx={{
            p: '20px',
            borderRadius: 1,
            border: '1px solid #dde3ed',
            bgcolor: '#fff',
            position: 'relative',
            overflow: 'hidden',
            boxShadow: '0 14px 40px rgba(26, 42, 82, 0.04)',
            transition: 'transform 0.15s ease, box-shadow 0.15s ease',
            '&:hover': {
              transform: 'translateY(-2px)',
              boxShadow: '0 18px 45px rgba(26, 42, 82, 0.08)',
            },
            '&::after': {
              content: '""',
              position: 'absolute',
              width: 70,
              height: 70,
              borderRadius: '100%',
              right: -25,
              top: -25,
              bgcolor: c.tint,
              zIndex: 0,
            },
          }}
        >
          <Box
            sx={{
              position: 'relative',
              zIndex: 1,
              width: 37,
              height: 37,
              borderRadius: 1,
              display: 'grid',
              placeItems: 'center',
              color: c.color,
              bgcolor: c.tint,
            }}
          >
            {c.icon}
          </Box>
          <Typography
            sx={{
              position: 'relative',
              zIndex: 1,
              display: 'block',
              color: '#647087',
              fontSize: '12px',
              fontWeight: 600,
              mt: '13px',
              mb: '5px',
            }}
          >
            {c.label}
          </Typography>
          <Typography
            className={
              c.isCurrency
                ? 'opex-currency opex-currency-with-symbol opex-dashboard-kpi-currency'
                : undefined
            }
            sx={{
              position: 'relative',
              zIndex: 1,
              fontSize: '23px',
              fontWeight: 800,
              color: '#182036',
              lineHeight: 1.2,
            }}
          >
            {c.value}
          </Typography>
          {/* <Typography
            sx={{
              position: 'relative',
              zIndex: 1,
              display: 'block',
              fontSize: '11px',
              color: '#647087',
              mt: '6px',
            }}
          >
            {c.subtitle}
          </Typography> */}
        </Box>
      ))}
    </Box>
  );
}
