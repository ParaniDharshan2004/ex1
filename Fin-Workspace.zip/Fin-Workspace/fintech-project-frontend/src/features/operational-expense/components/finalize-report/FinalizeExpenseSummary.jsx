import { Fragment, useState } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import { formatINR } from '../../utils/currency';
import { groupFixedAssetsByParent } from '../../utils/fixedAssetMapping';
import { OperationalExpenseReportDocument } from '../../pages/OperationalExpenseReportsPage';

const hasNonZeroAmount = (value) =>
  Number.isFinite(Number(value)) &&
  Math.round((Number(value) + Number.EPSILON) * 100) !== 0;

export default function FinalizeExpenseSummary({
  expenses = [],
  fixedCosts = [],
  directCostTotal = 0,
  indirectCostTotal = 0,
  subtotal = 0,
  markup = 0,
  fixedCostTotal = 0,
  miscellaneousExpenseTotal = 0,
  otherExpenseTotal = 0,
  totalBillable = 0,
  clientAllocations = [],
  finalized = false,
  busy = false,
  previewReport,
  onFinalize,
}) {
  const [previewOpen, setPreviewOpen] = useState(false);
  const miscellaneousRows = expenses.filter((row) =>
    /\bmisc(?:ellaneous)?\b/i.test(String(row.category || '')) &&
      hasNonZeroAmount(row.amount),
  );
  const operationalRows = expenses.filter(
    (row) =>
      !/\bmisc(?:ellaneous)?\b/i.test(String(row.category || '')) &&
      hasNonZeroAmount(row.amount),
  );
  const fixedAssetGroups = groupFixedAssetsByParent(fixedCosts)
    .map((group) => ({
      ...group,
      children: (group.children || []).filter((item) =>
        hasNonZeroAmount(item.amount),
      ),
    }))
    .filter((group) => group.children.length > 0);
  const visibleAllocations = clientAllocations.filter((allocation) =>
    hasNonZeroAmount(allocation.amount),
  );

  return (
    <Box
      sx={{
        bgcolor: '#fff',
        border: '1px solid #dde3ed',
        borderRadius: '15px',
        boxShadow: '0 14px 40px rgba(26, 42, 82, 0.05)',
        p: { xs: 2, sm: 2.5 },
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: { xs: 'flex-start', sm: 'center' },
          gap: 2,
          mb: 2,
        }}
      >
        <Box>
          <Typography sx={{ fontWeight: 800, fontSize: '15px', color: '#182036' }}>
            Expense report details
          </Typography>
          <Typography sx={{ fontSize: '12px', color: '#647087', mt: 0.25 }}>
            Review the finalized expense values.
          </Typography>
        </Box>
      </Box>

      <TableContainer
        sx={{
          border: '1px solid #dde3ed',
          borderRadius: '11px',
          overflowX: 'auto',
        }}
      >
        <Table sx={{ minWidth: 650 }}>
          <TableHead>
            <TableRow sx={{ bgcolor: '#f5f7fb' }}>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Category
              </TableCell>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Description
              </TableCell>
              <TableCell align="right" sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Monthly amount (<span className="currency-symbol">₹</span>)
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {operationalRows.map((row, index) => {
                const previousCategory =
                  index > 0 ? operationalRows[index - 1].category : null;
                const showCategory =
                  index === 0 || previousCategory !== row.category;
                const nextCategory = operationalRows[index + 1]?.category;
                const category = String(row.category || '').toLowerCase();
                const isLastDirectCost =
                  category.includes('direct') &&
                  !category.includes('indirect') &&
                  nextCategory !== row.category;
                const isLastIndirectCost =
                  category.includes('indirect') &&
                  nextCategory !== row.category;

                return (
                  <Fragment key={`${row.id || index}-group`}>
                    <TableRow hover>
                      <TableCell sx={{ fontWeight: 700, color: '#182036', fontSize: '13px', width: '25%' }}>
                        {showCategory ? row.category : ''}
                      </TableCell>
                      <TableCell align="right" sx={{ color: '#2b3953', fontSize: '13px' }}>
                        {row.description}
                      </TableCell>
                      <TableCell
                        align="right"
                        className="opex-currency"
                        sx={{
                          width: '25%',
                          fontWeight: 400,
                          color: '#182036',
                          fontSize: '13px',
                          fontVariantNumeric: 'tabular-nums',
                        }}
                      >
                        {formatINR(row.amount, { showSymbol: false })}
                      </TableCell>
                    </TableRow>
                    {((isLastDirectCost &&
                      hasNonZeroAmount(directCostTotal)) ||
                      (isLastIndirectCost &&
                        hasNonZeroAmount(indirectCostTotal))) && (
                      <TableRow sx={{ bgcolor: '#e8edf5' }}>
                        <TableCell colSpan={2} align="right" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                          {isLastDirectCost
                            ? 'Total Direct Cost'
                            : 'Total Indirect Cost'}
                        </TableCell>
                        <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                          {formatINR(
                            isLastDirectCost
                              ? directCostTotal
                              : indirectCostTotal,
                            { showSymbol: false },
                          )}
                        </TableCell>
                      </TableRow>
                    )}
                  </Fragment>
                );
              })}

            {hasNonZeroAmount(subtotal) && <TableRow sx={{ bgcolor: '#e8edf5', borderTop: '2px solid #dde3ed' }}>
              <TableCell align="right" colSpan={2} sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                Sub Total
              </TableCell>
              <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                {formatINR(subtotal, { showSymbol: false })}
              </TableCell>
            </TableRow>}
            {hasNonZeroAmount(markup) && <TableRow sx={{ bgcolor: '#e8edf5' }}>
              <TableCell align="right" colSpan={2} sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                20% Markup over Sub Total
              </TableCell>
              <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                {formatINR(markup, { showSymbol: false })}
              </TableCell>
            </TableRow>}

            {miscellaneousRows.map((row, index) => (
              <TableRow key={row.id || `misc-expense-${index}`} hover>
                <TableCell sx={{ fontWeight: 700, color: '#182036', fontSize: '13px', width: '25%' }}>
                  {index === 0 ? 'Misc expenses' : ''}
                </TableCell>
                <TableCell align="right" sx={{ color: '#2b3953', fontSize: '13px' }}>
                  {row.description}
                </TableCell>
                <TableCell
                  align="right"
                  className="opex-currency"
                  sx={{
                    width: '25%',
                    fontWeight: 400,
                    color: '#182036',
                    fontSize: '13px',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {formatINR(row.amount, { showSymbol: false })}
                </TableCell>
              </TableRow>
            ))}

            {hasNonZeroAmount(miscellaneousExpenseTotal) && (
              <TableRow sx={{ bgcolor: '#e8edf5' }}>
                <TableCell colSpan={2} align="right" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                  Total Misc expenses
                </TableCell>
                <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                  {formatINR(miscellaneousExpenseTotal, { showSymbol: false })}
                </TableCell>
              </TableRow>
            )}

            {fixedAssetGroups.map((group, groupIndex) => (
              <Fragment key={`fixed-group-${group.parentCategory}`}>
                <TableRow hover>
                  <TableCell sx={{ fontWeight: groupIndex === 0 ? 700 : 400, color: '#182036', fontSize: '13px', width: '25%' }}>
                    {groupIndex === 0 ? 'Fixed Assets' : ''}
                  </TableCell>
                  <TableCell align="right" sx={{ color: '#2b3953', fontSize: '13px' }}>
                    {group.parentCategory}
                  </TableCell>
                  <TableCell />
                </TableRow>
                {group.children.map((item, itemIndex) => (
                  <TableRow
                    key={item.id || `${group.parentCategory}-${item.subcomponent}-${itemIndex}`}
                    hover
                  >
                    <TableCell />
                    <TableCell align="right" sx={{ color: '#2b3953', fontSize: '13px' }}>
                      {item.subcomponent ||
                        item.itemName ||
                        item.assetName ||
                        'Fixed asset'}
                    </TableCell>
                    <TableCell
                      align="right"
                      className="opex-currency"
                      sx={{
                        width: '25%',
                        color: '#182036',
                        fontSize: '13px',
                        fontWeight: 400,
                        fontVariantNumeric: 'tabular-nums',
                      }}
                    >
                      {formatINR(Number(item.amount) || 0, {
                        showSymbol: false,
                      })}
                    </TableCell>
                  </TableRow>
                ))}
              </Fragment>
            ))}

            {hasNonZeroAmount(fixedCostTotal) && (
              <TableRow sx={{ bgcolor: '#e8edf5' }}>
                <TableCell colSpan={2} align="right" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                  Fixed Assets Total
                </TableCell>
                <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036', fontVariantNumeric: 'tabular-nums' }}>
                  {formatINR(fixedCostTotal, { showSymbol: false })}
                </TableCell>
              </TableRow>
            )}

            {otherExpenseTotal > 0 && (
              <TableRow sx={{ bgcolor: '#e8edf5' }}>
                <TableCell colSpan={2} align="right" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                  Other Expense Categories Total
                </TableCell>
                <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                  {formatINR(otherExpenseTotal, { showSymbol: false })}
                </TableCell>
              </TableRow>
            )}

            {hasNonZeroAmount(otherExpenseTotal) && (
              <TableRow sx={{ bgcolor: '#e8edf5' }}>
                <TableCell colSpan={2} align="right" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                  Other Expense Categories Total
                </TableCell>
                <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                  {formatINR(otherExpenseTotal, { showSymbol: false })}
                </TableCell>
              </TableRow>
            )}

            {hasNonZeroAmount(totalBillable) && <TableRow sx={{ bgcolor: '#dfe7f2' }}>
              <TableCell align="right" colSpan={2} sx={{ fontWeight: 800, fontSize: '14px', color: '#0b1739' }}>
                Operational Expense Total
              </TableCell>
              <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '15px', color: '#1769ff' }}>
                {formatINR(totalBillable, { showSymbol: false })}
              </TableCell>
            </TableRow>}

            {visibleAllocations.map((allocation) => (
              <TableRow key={allocation.id || allocation.clientName}>
                <TableCell colSpan={2} align="right" sx={{ fontWeight: 700, fontSize: '13px', color: '#182036', borderBottom: '1px solid #d7dee9' }}>
                  Total Amount Charged to {allocation.clientName}
                </TableCell>
                <TableCell align="right" className="opex-currency" sx={{ fontSize: '13px', color: '#182036', borderBottom: '1px solid #d7dee9' }}>
                  {formatINR(allocation.amount, { showSymbol: false })}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>Operational Expense Report Preview</DialogTitle>
        <DialogContent
          sx={{
            bgcolor: '#eef1f5',
            p: { xs: 1, sm: 2 },
          }}
        >
          <Box sx={{ overflowX: 'auto', py: 2 }}>
            <Box
              sx={{
                width: 'fit-content',
                mx: 'auto',
                boxShadow: '0 3px 16px rgba(15, 23, 42, 0.16)',
              }}
            >
              <OperationalExpenseReportDocument report={previewReport} />
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Box
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          flexWrap: 'wrap',
          mt: 2,
          gap: 1,
        }}
      >
        <Button
          variant="contained"
          size="large"
          startIcon={<VisibilityRoundedIcon />}
          onClick={() => setPreviewOpen(true)}
        >
          Preview Report
        </Button>
        {!finalized && (
          <Button
            variant="contained"
            disabled={busy}
            startIcon={
              busy ? (
                <CircularProgress size={18} color="inherit" />
              ) : (
                <CheckCircleRoundedIcon />
              )
            }
            onClick={onFinalize}
          >
            Finalize Report
          </Button>
        )}
      </Box>
    </Box>
  );
}
