import { useMemo, useState } from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Chip,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
} from '@mui/material';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import PrintRoundedIcon from '@mui/icons-material/PrintRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import {
  formatINR,
  formatUSD,
  isCrklInvoice,
} from '../../utils/currency';
import { formatMonthYear } from '../../utils/date';

const groupInvoicesByPeriod = (invoices) => {
  const groups = invoices.reduce((periodGroups, invoice) => {
    const period = String(invoice.period || '');
    if (!periodGroups.has(period)) {
      periodGroups.set(period, []);
    }
    periodGroups.get(period).push(invoice);
    return periodGroups;
  }, new Map());

  return [...groups.entries()]
    .sort(([firstPeriod], [secondPeriod]) => {
      if (!firstPeriod) return 1;
      if (!secondPeriod) return -1;
      return secondPeriod.localeCompare(firstPeriod);
    })
    .map(([period, periodInvoices]) => ({
      period,
      label: period
        ? `${formatMonthYear(period)}`
        : 'Period not set',
      invoices: periodInvoices,
    }));
};

export default function InvoiceCardList({ invoices = [], onPreview, onPrint }) {
  const monthGroups = useMemo(
    () => groupInvoicesByPeriod(invoices),
    [invoices],
  );
  const [expandedPeriods, setExpandedPeriods] = useState([]);

  if (monthGroups.length === 0) {
    return (
      <Box
        sx={{
          p: 4,
          textAlign: 'center',
          bgcolor: '#fff',
          borderRadius: '12px',
          border: '1px solid #dde3ed',
          color: '#647087',
        }}
      >
        No generated invoices found for the selected filters.
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
      {monthGroups.map((group) => (
        <Accordion
          key={group.period || 'unknown-period'}
          expanded={expandedPeriods.includes(
            group.period || 'unknown-period',
          )}
          onChange={(_, expanded) => {
            const periodKey = group.period || 'unknown-period';
            setExpandedPeriods((current) =>
              expanded
                ? [...current, periodKey]
                : current.filter((period) => period !== periodKey),
            );
          }}
          sx={{
            overflow: 'hidden',
            '&:before': { display: 'none' },
            borderColor: '#dde3ed',
            borderRadius: '12px',
            boxShadow: '0 4px 12px rgba(26, 42, 82, 0.03)',
            '&.Mui-expanded': { margin: 0 },
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreRoundedIcon />}
            sx={{
              px: { xs: 2, sm: 2.5 },
              minHeight: 76,
              bgcolor: '#f6f8fc',
              '&.Mui-expanded': { minHeight: 76 },
              '& .MuiAccordionSummary-content': {
                my: 1.75,
                alignItems: { xs: 'flex-start', sm: 'center' },
                flexDirection: { xs: 'column', sm: 'row' },
                justifyContent: 'space-between',
                gap: 1,
              },
            }}
          >
            <Box>
              <Typography
                sx={{ fontWeight: 800, color: '#182036', fontSize: '16px' }}
              >
                {group.label}
              </Typography>
              <Typography sx={{ color: '#647087', fontSize: '12px', mt: 0.25 }}>
                {group.invoices.length}{' '}
                {group.invoices.length === 1 ? 'Invoice' : 'Invoices'}
              </Typography>
            </Box>
          </AccordionSummary>

          <AccordionDetails sx={{ p: 0 }}>
            <TableContainer sx={{ overflowX: 'auto' }}>
              <Table
                size="small"
                aria-label={`Invoices for ${group.label}`}
                sx={{ minWidth: 850 }}
              >
                <TableHead>
                  <TableRow sx={{ bgcolor: '#fff' }}>
                    {[
                      'S No.',
                      'Client',
                      'Location',
                      'Invoice Date',
                      'Amount',
                      'Status',
                      'Actions',
                    ].map((heading) => (
                      <TableCell
                        key={heading}
                        align={heading === 'Amount' ? 'right' : 'left'}
                        sx={{
                          py: 1.5,
                          color: '#647087',
                          fontSize: '11px',
                          fontWeight: 800,
                          textTransform: 'uppercase',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {heading}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {group.invoices.map((invoice, index) => (
                    <TableRow
                      key={invoice.id || `${group.period}-${index}`}
                      hover
                      sx={{ '&:last-child td': { borderBottom: 0 } }}
                    >
                      <TableCell
                        sx={{
                          color: '#182036',
                          fontWeight: 700,
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {index + 1}
                      </TableCell>
                      <TableCell
                        sx={{
                          color: '#182036',
                          fontWeight: 600,
                          minWidth: 170,
                        }}
                      >
                        {invoice.client}
                      </TableCell>
                      <TableCell sx={{ color: '#647087', minWidth: 140 }}>
                        {invoice.location}
                      </TableCell>
                      <TableCell
                        sx={{ color: '#647087', whiteSpace: 'nowrap' }}
                      >
                        {invoice.date || '—'}
                      </TableCell>
                      <TableCell
                        align="right"
                         className="opex-currency opex-currency-with-symbol"
                        sx={{
                          color: '#182036',
                          fontWeight: 700,
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {isCrklInvoice(invoice)
                          ? formatUSD(invoice.amount)
                          : formatINR(invoice.amount)}
                      </TableCell>
                      <TableCell>
                        <Chip
                          label="Generated"
                          size="small"
                          sx={{
                            height: 23,
                            bgcolor: '#e6f8f1',
                            color: '#08744f',
                            fontSize: '11px',
                            fontWeight: 700,
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Box
                          sx={{
                            display: 'flex',
                            gap: 0.75,
                            whiteSpace: 'nowrap',
                          }}
                        >
                          <Tooltip title="Preview invoice">
                            <IconButton
                              size="small"
                              aria-label={`Preview invoice for ${invoice.client}`}
                              onClick={() => onPreview(invoice)}
                              sx={{
                                border: '1px solid #dde3ed',
                                borderRadius: 1,
                                color: '#2b3953',
                              }}
                            >
                              <VisibilityRoundedIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Print / save as PDF">
                            <IconButton
                              size="small"
                              aria-label={`Print invoice for ${invoice.client}`}
                              onClick={() => onPrint(invoice)}
                              sx={{
                                borderRadius: '8px',
                                bgcolor: '#eaf0f8',
                                color: '#273653',
                                '&:hover': { bgcolor: '#dde5f0' },
                              }}
                            >
                              <PrintRoundedIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </AccordionDetails>
        </Accordion>
      ))}
    </Box>
  );
}
