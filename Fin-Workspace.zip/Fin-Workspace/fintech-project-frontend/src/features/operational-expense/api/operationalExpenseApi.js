import api from '../../../services/api/client.js';

const BASE_PATH = '/api/operationalExpenseRouter';
export const getClientLocations = async (clientId) => {
  const response = await api.get(
    `/api/clientLocationRouter/client-locations/client/${encodeURIComponent(clientId)}`,
  );
  return {
    ...response,
    data: {
      ...response.data,
      data: Array.isArray(response.data?.data) ? response.data.data : [],
    },
  };
};
const normalizeAllocation = (allocation) => allocation && ({
  ...allocation,
  clientMaster:
    allocation.clientId && typeof allocation.clientId === 'object'
      ? allocation.clientId
      : null,
  clientId: allocation.clientId?._id || allocation.clientId,
  clientName: allocation.clientId?.clientName || allocation.clientName || '',
  clientCode: allocation.clientId?.clientCode || allocation.clientCode || '',
  locationAllocations: (allocation.locationAllocations || allocation.allocations || []).map((item) => ({
    ...item,
    locationId: item.locationId?._id || item.locationId,
    locationName: item.locationId?.locationName || item.locationName || '',
    locationCode: item.locationId?.locationCode || item.locationCode || '',
    billingName: item.locationId?.billingName || item.billingName || '',
    billingAddress: item.locationId?.billingAddress || item.billingAddress || '',
    stateName: item.locationId?.stateName || item.stateName || '',
    stateCode: item.locationId?.stateCode || item.stateCode || '',
    gstin: item.locationId?.gstin || item.gstin || '',
  })),
});
export const getInvoiceAllocation = async (reportId, clientId) => {
  const response = await getInvoiceAllocations(reportId);
  const allocation = response.data.data.find(
    (item) => String(item.clientId) === String(clientId),
  ) || null;
  return {
    ...response,
    data: { ...response.data, data: allocation },
  };
};

export const getInvoiceAllocations = async (reportId) => {
  const response = await api.get(`${BASE_PATH}/${encodeURIComponent(reportId)}/invoice-allocation`);
  const allocations = Array.isArray(response.data?.data?.allocations)
    ? response.data.data.allocations
    : [];
  const normalized = allocations.map((allocation) => {
    const item = normalizeAllocation(allocation);
    if (item && response.data?.data?.calculations) {
      item.backendCalculations = response.data.data.calculations;
      item.availableClientBalance = response.data.data.calculations.clientAllocations
        ?.find((client) => String(client.clientId?._id || client.clientId) === String(item.clientId))?.availableClientBalance;
    }
    return item;
  });
  return { ...response, data: { ...response.data, data: normalized } };
};
export const saveInvoiceAllocation = async (reportId, payload) => {
  const locationAllocations = (payload.allocations || payload.locationAllocations || [])
    .filter((item) => item.locationId && Number.isFinite(Number(item.amount)))
    .map((item) => ({ locationId: item.locationId, amount: Number(item.amount) }));
  const response = await api.put(`${BASE_PATH}/${encodeURIComponent(reportId)}/invoice-allocation`, {
    clientId: payload.clientId,
    clientTotalAmount: Number(payload.clientTotalAmount),
    allocationStatus: payload.allocationStatus || 'CONFIRMED',
    locationAllocations,
  });
  const saved = normalizeAllocation(response.data?.data);
  if (saved && response.data?.automaticAllocation) saved.automaticAllocation = normalizeAllocation(response.data.automaticAllocation);
  return { ...response, data: { ...response.data, data: saved } };
};
export const generateOperationalExpenseInvoice = (reportId, payload) =>
  api.post(`${BASE_PATH}/${encodeURIComponent(reportId)}/invoice`, payload);

export const previewOperationalExpenseInvoices = (reportId, payload) =>
  api.post(
    `${BASE_PATH}/${encodeURIComponent(reportId)}/invoice-preview`,
    payload,
  );

export const generateOperationalExpenseReport = (payload) =>
  api.post(`${BASE_PATH}/generateOperationalExpenseReport`, payload);

export const getOperationalExpenseReports = (params = {}) =>
  api.get(`${BASE_PATH}/getAllOperationalExpenseReports`, { params });

export const getOperationalExpenseReport = (reportId) =>
  api.get(`${BASE_PATH}/getOperationalExpenseReportById/${reportId}`);

export const updateOperationalExpenseReport = (reportId, payload) =>
  api.put(`${BASE_PATH}/updateOperationalExpenseReport/${reportId}`, payload);

export const updateOperationalExpenseReportStatus = (reportId, status) =>
  api.patch(
    `${BASE_PATH}/updateOperationalExpenseReportStatus/${reportId}/status`,
    { status },
  );

export const deleteOperationalExpenseReport = (reportId) =>
  api.delete(`${BASE_PATH}/deleteOperationalExpenseReport/${reportId}`);

export const addOperationalExpenseFixedCost = (reportId, payload) =>
  api.post(
    `${BASE_PATH}/addOperationalExpenseFixedCost/${reportId}/fixed-costs`,
    payload,
  );

export const updateOperationalExpenseFixedCost = (
  reportId,
  fixedCostId,
  payload,
) =>
  api.patch(
    `${BASE_PATH}/updateOperationalExpenseFixedCost/${reportId}/fixed-costs/${fixedCostId}`,
    payload,
  );

export const deleteOperationalExpenseFixedCost = (reportId, fixedCostId) =>
  api.delete(
    `${BASE_PATH}/deleteOperationalExpenseFixedCost/${reportId}/fixed-costs/${fixedCostId}`,
  );

export const getAllInvoices = () =>
  api.get(`${BASE_PATH}/getAllInvoices`);

export const getAllCompanies = () =>
  api.get('/api/companyMasterRouter/getAllCompanies');
