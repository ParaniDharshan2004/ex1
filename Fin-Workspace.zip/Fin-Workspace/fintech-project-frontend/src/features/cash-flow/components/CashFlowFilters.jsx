import {
  Button,
  Grid,
  InputAdornment,
  MenuItem,
  Select,
  TextField,
  useTheme,
} from "@mui/material";

import SearchIcon from "@mui/icons-material/Search";

import { Icons } from "../../../theme/icons.js";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export default function CashFlowEntryFilters({ filters, setFilters, onAdd }) {
  const theme = useTheme();

  return (
    <Grid
      container
      spacing={1.5}
      sx={{
        mb: 2,
      }}
    >
      <Grid
        size={{
          xs: 12,
          md: 3,
          lg: 4,
        }}
      >
        <TextField
          fullWidth
          size="small"
          placeholder="Search by component"
          value={filters.search}
          onChange={(event) =>
            setFilters((previousFilters) => ({
              ...previousFilters,
              search: event.target.value,
            }))
          }
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
        />
      </Grid>

      <Grid
        size={{
          xs: 12,
          sm: 4,
          md: 3,
          lg: 2,
        }}
      >
        <TextField
          fullWidth
          size="small"
          type="date"
          value={filters.date || ""}
          onChange={(event) =>
            setFilters((previousFilters) => ({
              ...previousFilters,
              date: event.target.value,
            }))
          }
        />
      </Grid>

      <Grid
        size={{
          xs: 12,
          sm: 4,
          md: 3,
          lg: 2,
        }}
      >
        <Select
          fullWidth
          size="small"
          value={filters.year || ""}
          onChange={(event) =>
            setFilters((previousFilters) => ({
              ...previousFilters,
              year: event.target.value,
            }))
          }
          displayEmpty
        >
          <MenuItem value="">All Years</MenuItem>

          <MenuItem value="2026">2026</MenuItem>

          <MenuItem value="2027">2027</MenuItem>

          <MenuItem value="2028">2028</MenuItem>
        </Select>
      </Grid>

      <Grid
        size={{
          xs: 12,
          sm: 4,
          md: 3,
          lg: 2,
        }}
      >
        <Select
          fullWidth
          size="small"
          value={filters.month || ""}
          onChange={(event) =>
            setFilters((previousFilters) => ({
              ...previousFilters,
              month: event.target.value,
            }))
          }
          displayEmpty
        >
          <MenuItem value="">All Months</MenuItem>

          {MONTHS.map((month, index) => (
            <MenuItem key={month} value={String(index)}>
              {month}
            </MenuItem>
          ))}
        </Select>
      </Grid>

      <Grid
        size={{
          xs: 12,
          sm: 12,
          md: 12,
          lg: 2,
        }}
      >
        <Button
          fullWidth
          variant="contained"
          startIcon={<Icons.AddIcon />}
          onClick={onAdd}
          sx={{
            height: "40px",
            bgcolor: "primary.main",
            color: "textPrimary",
            textTransform: "none",
            fontWeight: 600,

            "&:hover": {
              bgcolor: theme.palette.primary.main,
            },
          }}
        >
          Add Entry
        </Button>
      </Grid>
    </Grid>
  );
}
