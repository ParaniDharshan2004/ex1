import * as XLSX from "xlsx";
import { createRowId, normalizeText } from "./forecastFormatters.js";
import { IGNORED_ROW_LABELS } from "../../../shared/constants/dummy-data.js";
 
const MONTH_NAME_TO_INDEX = {
  january: 0,
  jan: 0,
  february: 1,
  feb: 1,
  march: 2,
  mar: 2,
  april: 3,
  apr: 3,
  may: 4,
  june: 5,
  jun: 5,
  july: 6,
  jul: 6,
  august: 7,
  aug: 7,
  september: 8,
  sep: 8,
  sept: 8,
  october: 9,
  oct: 9,
  november: 10,
  nov: 10,
  december: 11,
  dec: 11,
};
 
const parseAmount = (value) => {
  if (value === null || value === undefined || value === "") {
    return 0;
  }
 
  if (typeof value === "number") {
    return Number.isFinite(value) ? Math.abs(value) : 0;
  }
 
  let normalizedValue = String(value)
    .replace(/₹/g, "")
    .replace(/,/g, "")
    .replace(/\s/g, "")
    .trim();
 
  const isParenthesized =
    normalizedValue.startsWith("(") && normalizedValue.endsWith(")");
 
  normalizedValue = normalizedValue
    .replace(/[()]/g, "")
    .replace(/(dr|cr)$/i, "");
 
  const numericValue = Number(normalizedValue);
 
  if (!Number.isFinite(numericValue)) {
    return 0;
  }
 
  const signedValue = isParenthesized ? -numericValue : numericValue;
 
  return Math.abs(signedValue);
};
 
const parseTallyDateRange = (value) => {
  if (!value) {
    return null;
  }
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return new Date(value.getFullYear(), value.getMonth(), 1);
  }
  const dateText = String(value).trim().replace(/\s+/g, " ");
  const firstDateText = dateText.split(/\s+to\s+/i)[0]?.trim();
  if (!firstDateText) {
    return null;
  }
  const match = firstDateText.match(
    /^(\d{1,2})-([A-Za-z]{3,9})-(\d{2}|\d{4})$/,
  );
  if (!match) {
    return null;
  }
  const day = Number(match[1]);
  const monthName = match[2].toLowerCase();
  const yearText = match[3];
  const monthIndex = MONTH_NAME_TO_INDEX[monthName];
  if (monthIndex === undefined) {
    return null;
  }
  const parsedYear = Number(yearText);
  const fullYear = yearText.length === 2 ? 2000 + parsedYear : parsedYear;
  const parsedDate = new Date(fullYear, monthIndex, day);
  if (Number.isNaN(parsedDate.getTime())) {
    return null;
  }
  return new Date(parsedDate.getFullYear(), parsedDate.getMonth(), 1);
};
 
export const parseMonthYear = (value) => {
  if (!value) {
    return null;
  }
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return new Date(value.getFullYear(), value.getMonth(), 1);
  }
  const normalizedValue = String(value)
    .trim()
    .replace(/,/g, "")
    .replace(/\s+/g, " ")
    .toLowerCase();
  const match = normalizedValue.match(/^([a-z]+)\s+(\d{4})$/);
  if (!match) {
    return null;
  }
  const monthName = match[1];
  const year = Number(match[2]);
  const monthIndex = MONTH_NAME_TO_INDEX[monthName];
  if (monthIndex === undefined || !Number.isInteger(year)) {
    return null;
  }
  return new Date(year, monthIndex, 1);
};
 
const parseSourceDateValue = (value) => {
  return parseTallyDateRange(value) || parseMonthYear(value);
};
 
export const getPeriodLabel = (date) => {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return "";
  }
 
  return date.toLocaleString("en-US", {
    month: "short",
    year: "numeric",
  });
};
 
export const getFullPeriodLabel = (date) => {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return "";
  }
 
  return date.toLocaleString("en-US", {
    month: "long",
    year: "numeric",
  });
};
 
export const buildForecastMonths = (sourceDate) => {
  if (!sourceDate) {
    return [];
  }
 
  const parsedSourceDate =
    sourceDate instanceof Date ? sourceDate : new Date(sourceDate);
 
  if (Number.isNaN(parsedSourceDate.getTime())) {
    return [];
  }
 
  const normalizedSourceDate = new Date(
    parsedSourceDate.getFullYear(),
    parsedSourceDate.getMonth(),
    1,
  );
 
  return Array.from(
    {
      length: 3,
    },
    (_, index) => {
      const forecastDate = new Date(
        normalizedSourceDate.getFullYear(),
        normalizedSourceDate.getMonth() + index + 1,
        1,
      );
 
      const year = forecastDate.getFullYear();
 
      const monthNumber = forecastDate.getMonth() + 1;
 
      const key = [year, String(monthNumber).padStart(2, "0")].join("-");
 
      return {
        key,
 
        date: forecastDate,
 
        month: forecastDate.toLocaleString("en-IN", {
          month: "long",
        }),
 
        monthShort: forecastDate.toLocaleString("en-IN", {
          month: "short",
        }),
 
        year,
 
        fullLabel: forecastDate.toLocaleString("en-IN", {
          month: "long",
          year: "numeric",
        }),
 
        shortLabel: forecastDate.toLocaleString("en-IN", {
          month: "short",
          year: "numeric",
        }),
      };
    },
  );
};
 
const findParticularsRow = (worksheetRows) => {
  return worksheetRows.findIndex((row) => {
    if (!Array.isArray(row)) {
      return false;
    }
 
    return row.some(
      (cell) => normalizeText(cell).toLowerCase() === "particulars",
    );
  });
};
 
const findColumnIndex = (row, possibleHeaders) => {
  if (!Array.isArray(row)) {
    return -1;
  }
 
  return row.findIndex((cell) => {
    const normalizedCell = normalizeText(cell).toLowerCase();
 
    return possibleHeaders.includes(normalizedCell);
  });
};
 
const detectSourceDate = (worksheetRows, particularsRowIndex) => {
  const searchStart = Math.max(0, particularsRowIndex - 20);
  const searchEnd = Math.min(worksheetRows.length, particularsRowIndex + 3);
  for (
    let rowIndex = particularsRowIndex - 1;
    rowIndex >= searchStart;
    rowIndex -= 1
  ) {
    const row = worksheetRows[rowIndex] || [];
    for (const cellValue of row) {
      const parsedDate = parseSourceDateValue(cellValue);
      if (parsedDate) {
        return parsedDate;
      }
    }
  }
  for (
    let rowIndex = particularsRowIndex;
    rowIndex < searchEnd;
    rowIndex += 1
  ) {
    const row = worksheetRows[rowIndex] || [];
    for (const cellValue of row) {
      const parsedDate = parseSourceDateValue(cellValue);
      if (parsedDate) {
        return parsedDate;
      }
    }
  }
  return null;
};
 
export const parseTallyWorksheet = (worksheet) => {
  const worksheetRows = XLSX.utils.sheet_to_json(worksheet, {
    header: 1,
    defval: "",
    raw: true,
    blankrows: false,
  });
 
  if (!worksheetRows.length) {
    throw new Error("The selected worksheet does not contain any data.");
  }
 
  const particularsRowIndex = findParticularsRow(worksheetRows);
 
  if (particularsRowIndex === -1) {
    throw new Error(
      'Unable to find the "Particulars" column in the worksheet.',
    );
  }
 
  const particularsHeaderRow = worksheetRows[particularsRowIndex] || [];
 
  const particularsColumnIndex = findColumnIndex(particularsHeaderRow, [
    "particulars",
  ]);
 
  if (particularsColumnIndex === -1) {
    throw new Error('Unable to identify the "Particulars" column.');
  }
 
  let debitColumnIndex = -1;
  let debitHeaderRowIndex = -1;
 
  const debitSearchEnd = Math.min(
    worksheetRows.length,
    particularsRowIndex + 6,
  );
 
  for (
    let rowIndex = particularsRowIndex;
    rowIndex < debitSearchEnd;
    rowIndex += 1
  ) {
    const currentRow = worksheetRows[rowIndex] || [];
 
    const detectedDebitColumn = findColumnIndex(currentRow, [
      "debit",
      "debit amount",
      "dr",
    ]);
 
    if (detectedDebitColumn !== -1) {
      debitColumnIndex = detectedDebitColumn;
 
      debitHeaderRowIndex = rowIndex;
 
      break;
    }
  }
 
  if (debitColumnIndex === -1) {
    debitColumnIndex = particularsColumnIndex + 1;
 
    debitHeaderRowIndex = particularsRowIndex + 2;
  }
 
  const sourceDate = detectSourceDate(worksheetRows, particularsRowIndex);
 
  if (!sourceDate || Number.isNaN(sourceDate.getTime())) {
    throw new Error(
      "Unable to identify the report month from the imported Tally worksheet.",
    );
  }
 
  const normalizedSourceDate = new Date(
    sourceDate.getFullYear(),
    sourceDate.getMonth(),
    1,
  );
 
  const dataStartRowIndex = debitHeaderRowIndex + 1;
 
  const parsedRows = [];
 
  for (
    let rowIndex = dataStartRowIndex;
    rowIndex < worksheetRows.length;
    rowIndex += 1
  ) {
    const worksheetRow = worksheetRows[rowIndex] || [];
 
    const rawComponent = worksheetRow[particularsColumnIndex];
 
    const component = normalizeText(rawComponent);
 
    if (!component) {
      continue;
    }
 
    const normalizedComponent = component.toLowerCase();
 
    if (IGNORED_ROW_LABELS.has(normalizedComponent)) {
      continue;
    }
 
    if (
      normalizedComponent === "total" ||
      normalizedComponent.startsWith("total ")
    ) {
      continue;
    }
 
    const rawDebit = worksheetRow[debitColumnIndex];
 
    const amount = parseAmount(rawDebit);
 
    parsedRows.push({
      id: createRowId(component, parsedRows.length),
 
      component,
 
      sourceAmount: amount,
 
      month1: amount,
      month2: amount,
      month3: amount,
 
      isEdited: false,
 
      excelRowNumber: rowIndex + 1,
    });
  }
 
  if (!parsedRows.length) {
    throw new Error(
      "No component and debit amount rows were found in the worksheet.",
    );
  }
 
  return {
    rows: parsedRows,
 
    sourceDate: normalizedSourceDate,
 
    sourceMonth: [
      normalizedSourceDate.getFullYear(),
      String(normalizedSourceDate.getMonth() + 1).padStart(2, "0"),
    ].join("-"),
 
    forecastMonths: buildForecastMonths(normalizedSourceDate),
 
    rawRowCount: worksheetRows.length,
  };
};