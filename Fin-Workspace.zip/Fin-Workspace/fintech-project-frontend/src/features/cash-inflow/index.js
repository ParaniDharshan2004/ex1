export { default as CashInflowPage } from './pages/CashInflowPage.jsx';
