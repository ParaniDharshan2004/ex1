import {
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  Stack,
  Tooltip,
  IconButton,
} from "@mui/material";

import { formatIST } from "../../../shared/utils/dateFormatter";
import { useAuth } from "../../../app/providers/AuthContext";
import { Icons } from "../../../theme/icons";

const CashInflowTable = ({ rows, onEdit, onDeleteRequest }) => {
  const { permissions } = useAuth();

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Date</TableCell>
            <TableCell>Amount</TableCell>
            <TableCell>Description</TableCell>
            {(permissions?.write || permissions?.delete) && (
              <TableCell>Actions</TableCell>
            )}
          </TableRow>
        </TableHead>

        <TableBody>
          {rows.map((row) => (
            <TableRow key={row._id}>
              <TableCell>{formatIST(row.inflowDate)}</TableCell>

              <TableCell>{row.amount}</TableCell>

              <TableCell>{row.remarks}</TableCell>

              {(permissions?.write || permissions?.delete) && (
                <TableCell>
                  <Stack direction="row" spacing={0.5}>
                    {permissions?.write && (
                      <Tooltip title="Edit">
                        <IconButton size="small" onClick={() => onEdit(row)}>
                          <Icons.EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    )}

                    {permissions?.delete && (
                      <Tooltip title="Delete">
                        <IconButton
                          size="small"
                          onClick={() => onDeleteRequest(row)}
                          sx={{ color: "error.main" }}
                        >
                          <Icons.DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    )}
                  </Stack>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default CashInflowTable;
