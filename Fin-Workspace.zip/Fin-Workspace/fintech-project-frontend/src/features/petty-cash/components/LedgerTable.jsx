import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Stack,
  IconButton,
  Tooltip,
} from '@mui/material';
import { Icons } from '../../../theme/icons.js';
import { formatIST } from '../../../shared/utils/dateFormatter.js';
import { useAuth } from '../../../app/providers/AuthContext';

// Currency formatter for Indian Rupees
const currency = (n) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(n);

export default function LedgerTable({ rows, onEdit, onDeleteRequest }) {
  const { permissions } = useAuth();

  const showActions = permissions?.write || permissions?.delete;
  return (
    <TableContainer
      component={Paper}
      sx={{ border: `1px solid ${'textPrimary'}14` }}
    >
      <Table size="small" sx={{}}>
        <TableHead>
          <TableRow sx={{ bgcolor: 'background.default' }}>
            <TableCell>Date</TableCell>
            <TableCell>Component</TableCell>
            {/* <TableCell>Cash Added</TableCell> */}
            <TableCell>Amount</TableCell>
            {/* <TableCell>Balance</TableCell> */}

            {showActions && <TableCell>Actions</TableCell>}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.length === 0 && (
            <TableRow>
              <TableCell
                colSpan={8}
                sx={{ textAlign: 'center', py: 4, color: 'textPrimary' }}
              >
                No transactions match these filters.
              </TableCell>
            </TableRow>
          )}
          {rows.map((row) => {
            return (
              <TableRow key={row._id} hover>
                <TableCell>{formatIST(row.date)}</TableCell>

                <TableCell>{row.component || '-'}</TableCell>

                {/* <TableCell>
                  {row.cashAdded > 0 ? currency(row.cashAdded) : "-"}
                </TableCell> */}

                <TableCell>
                  {row.expense > 0 ? currency(row.expense) : '-'}
                </TableCell>

                {/* <TableCell sx={{ fontWeight: 600 }}>
                  {currency(row.balance)}
                </TableCell> */}
                {(permissions?.write || permissions?.delete) && (
                  <TableCell>
                    {row.source === 'PETTY_CASH' && (
                      <Stack direction="row" spacing={0.5}>
                        {permissions?.write && (
                          <Tooltip title="Edit">
                            <IconButton
                              size="small"
                              onClick={() => onEdit(row)}
                            >
                              <Icons.EditIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}

                        {permissions?.delete && (
                          <Tooltip title="Delete">
                            <IconButton
                              size="small"
                              onClick={() => onDeleteRequest(row)}
                              sx={{ color: 'error.main' }}
                            >
                              <Icons.DeleteIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                      </Stack>
                    )}
                  </TableCell>
                )}
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
