import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Box, Snackbar, Typography } from '@mui/material';

import ClientFilters from '../components/ClientFilters';
import ClientsTable from '../components/ClientsTable';
import ConfirmDialog from '../../../shared/components/dialogs/ConfirmDialog';
import EntityFormDialog from '../../../shared/components/dialogs/EntityFormDialog';
import { useDataContext } from '../../../app/providers/DataContext';

const CLIENT_FIELDS = [
  {
    name: 'clientName',
    label: 'Client Name',
    type: 'text',
    required: true,
  },
  {
    name: 'description',
    label: 'Description',
    type: 'text',
  },
  {
    name: 'displayOrder',
    label: 'Display Order',
    type: 'number',
    required: true,
    min: 1,
  },
  {
    name: 'isActive',
    label: 'Status',
    type: 'select',
    options: [
      { label: 'Active', value: true },
      { label: 'Inactive', value: false },
    ],
  },
];

export default function ClientsPage() {
  const {
    clients = [],
    getClients,
    createClient,
    updateClient,
    deleteClient,
  } = useDataContext();

  const [filters, setFilters] = useState({
    search: '',
    status: '',
  });

  const [formDialog, setFormDialog] = useState({
    open: false,
    mode: 'create',
    initialValues: {},
  });

  const [deleteTarget, setDeleteTarget] = useState(null);

  const [toast, setToast] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  /*
   * This must be declared before the useEffect that uses it.
   * useCallback keeps the function reference stable.
   */
  const showToast = useCallback((message, severity = 'success') => {
    setToast({
      open: true,
      message,
      severity,
    });
  }, []);

  const closeToast = useCallback(() => {
    setToast((current) => ({
      ...current,
      open: false,
    }));
  }, []);

  useEffect(() => {
    let isMounted = true;

    const loadClients = async () => {
      try {
        await getClients();
      } catch (error) {
        if (!isMounted) {
          return;
        }

        showToast(
          error.response?.data?.message || 'Unable to load clients',
          'error',
        );
      }
    };

    loadClients();

    return () => {
      isMounted = false;
    };
  }, [getClients, showToast]);

  const filteredClients = useMemo(() => {
    const search = filters.search.trim().toLowerCase();

    return clients.filter((client) => {
      const matchesSearch =
        !search ||
        [client.clientName, client.description].some((value) =>
          value?.toLowerCase().includes(search),
        );

      const matchesStatus =
        !filters.status ||
        (filters.status === 'Active'
          ? client.isActive === true
          : client.isActive === false);

      return matchesSearch && matchesStatus;
    });
  }, [clients, filters]);

  const openCreateDialog = () => {
    setFormDialog({
      open: true,
      mode: 'create',
      initialValues: {
        clientName: '',
        description: '',
        displayOrder: '',
        isActive: true,
      },
    });
  };

  const openEditDialog = (client) => {
    setFormDialog({
      open: true,
      mode: 'edit',
      initialValues: { ...client },
    });
  };

  const closeDialog = () => {
    setFormDialog((current) => ({
      ...current,
      open: false,
    }));
  };

  const handleSave = async (values) => {
    const isEditing = Boolean(values._id);

    try {
      if (isEditing) {
        await updateClient(values._id, values);
      } else {
        await createClient(values);
      }

      await getClients();

      closeDialog();

      showToast(
        isEditing
          ? 'Client updated successfully'
          : 'Client created successfully',
      );
    } catch (error) {
      showToast(
        error.response?.data?.message || 'Unable to save client',
        'error',
      );

      /*
       * Keep this throw if EntityFormDialog uses the rejected promise
       * to stop loading and keep the form open.
       */
      throw error;
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget?._id) {
      showToast('Unable to identify the client to delete', 'error');
      return;
    }

    try {
      await deleteClient(deleteTarget._id);
      await getClients();

      setDeleteTarget(null);
      showToast('Client deleted successfully');
    } catch (error) {
      showToast(
        error.response?.data?.message || 'Unable to delete client',
        'error',
      );
    }
  };

  return (
    <Box sx={{ p: { xs: 2, sm: 3 } }}>
      <Box sx={{ mt: 3, mb: 1 }}>
        <Typography variant="subtitle2" sx={{ color: 'text.primary' }}>
          Filter Clients
        </Typography>
      </Box>

      <ClientFilters
        filters={filters}
        setFilters={setFilters}
        onAdd={openCreateDialog}
      />

      <ClientsTable
        rows={filteredClients}
        onEdit={openEditDialog}
        onDeleteRequest={setDeleteTarget}
      />

      <EntityFormDialog
        open={formDialog.open}
        mode={formDialog.mode}
        title={formDialog.mode === 'edit' ? 'Edit Client' : 'Add Client'}
        saveConfirmMessage={(values) => {
          const clientName = values.clientName?.trim() || 'this client';

          return formDialog.mode === 'edit'
            ? `Are you sure you want to update ${clientName} details?`
            : `Are you sure you want to save ${clientName} details?`;
        }}
        fields={CLIENT_FIELDS}
        initialValues={formDialog.initialValues}
        onClose={closeDialog}
        onSave={handleSave}
      />

      <ConfirmDialog
        open={deleteTarget !== null}
        title="Delete Client Details?"
        message={
          deleteTarget
            ? `Are you sure you want to delete ${deleteTarget.clientName} client?`
            : ''
        }
        confirmLabel="Delete"
        confirmColor="primary.error"
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <Snackbar
        open={toast.open}
        autoHideDuration={3000}
        onClose={closeToast}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
      >
        <Alert
          severity={toast.severity}
          variant="filled"
          onClose={closeToast}
          sx={{ alignItems: 'center' }}
        >
          {toast.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
