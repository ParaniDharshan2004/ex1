export { default as ClientsPage } from './pages/ClientsPage.jsx';
