import {
  Chip,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Tooltip,
} from '@mui/material';
import { useState } from 'react';
import { Icons } from '../../../theme/icons';
import { useAuth } from '../../../app/providers/AuthContext';

export default function ClientsTable({ rows, onEdit, onDeleteRequest }) {
  const { permissions } = useAuth();
  const showActions = permissions?.write || permissions?.delete;
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const paginatedRows = rows.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage,
  );

  const handleRowsPerPageChange = (event) => {
    setRowsPerPage(Number(event.target.value));
    setPage(0);
  };

  return (
    <TableContainer
      component={Paper}
      sx={{ border: (theme) => `1px solid ${theme.palette.divider}` }}
    >
      <Table size="small">
        <TableHead>
          <TableRow sx={{ bgcolor: 'background.default' }}>
            <TableCell width={70} />
            <TableCell>Client Name</TableCell>
            <TableCell>Status</TableCell>
            {(permissions?.write || permissions?.delete) && (
              <TableCell>Actions</TableCell>
            )}
          </TableRow>
        </TableHead>
        <TableBody>
          {paginatedRows.map((row) => (
            <TableRow hover key={row._id}>
              <TableCell width={50} />

              <TableCell sx={{ width: '100%' }}>{row.clientName}</TableCell>

              <TableCell align="right">
                <Chip
                  label={row.isActive ? 'Active' : 'Inactive'}
                  color={row.isActive ? 'success' : 'error'}
                  size="small"
                />
              </TableCell>

              {showActions && (
                <TableCell align="right">
                  <Stack
                    direction="row"
                    spacing={0.5}
                    justifyContent="flex-end"
                  >
                    {permissions?.write && (
                      <Tooltip title="Edit">
                        <IconButton size="small" onClick={() => onEdit(row)}>
                          <Icons.EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    )}

                    {permissions?.delete && (
                      <Tooltip title="Delete">
                        <IconButton
                          size="small"
                          onClick={() => onDeleteRequest(row)}
                          sx={{ color: 'error.main' }}
                        >
                          <Icons.DeleteOutlineIcon />
                        </IconButton>
                      </Tooltip>
                    )}
                  </Stack>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        component="div"
        count={rows.length}
        page={page}
        onPageChange={(_, newPage) => setPage(newPage)}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleRowsPerPageChange}
        rowsPerPageOptions={[5, 10, 25, 50]}
        showFirstButton
        showLastButton
      />
    </TableContainer>
  );
}
