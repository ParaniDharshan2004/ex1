import { useEffect, useRef, useState } from "react";
import {
  Box,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  Typography,
} from "@mui/material";

import InsightCards from "../../petty-cash/components/InsightCards";
import ReportBarGraph from "../../reports/components/ReportBarGraph";
import ReportPieChart from "../../reports/components/ReportPieChart";
import { useDataContext } from "../../../app/providers/DataContext";

const MONTHS = [
  { value: 1, label: "January" },
  { value: 2, label: "February" },
  { value: 3, label: "March" },
  { value: 4, label: "April" },
  { value: 5, label: "May" },
  { value: 6, label: "June" },
  { value: 7, label: "July" },
  { value: 8, label: "August" },
  { value: 9, label: "September" },
  { value: 10, label: "October" },
  { value: 11, label: "November" },
  { value: 12, label: "December" },
];

const YEARS = [2026, 2025];

export default function DashBoard() {
  const {
    monthlySummary,
    getComponentExpenseSummary,
    getMonthlySummaryByMonth,
  } = useDataContext();

  const [month, setMonth] = useState(9);
  const [year, setYear] = useState(2026);
  const [reportData, setReportData] = useState([]);

  const barChartRef = useRef(null);
  const pieChartRef = useRef(null);

  useEffect(() => {
    let isActive = true;

    const monthString = `${year}-${String(month).padStart(2, "0")}`;

    const reportRequest = Promise.resolve(
      getComponentExpenseSummary(month, year),
    );

    const monthlySummaryRequest = Promise.resolve(
      getMonthlySummaryByMonth(monthString),
    );

    reportRequest
      .then((response) => {
        if (!isActive) {
          return;
        }

        if (response?.success) {
          setReportData(response.data || []);
        } else {
          setReportData([]);
        }
      })
      .catch((error) => {
        if (!isActive) {
          return;
        }

        console.error("Unable to load component expense summary:", error);
        setReportData([]);
      });

    monthlySummaryRequest.catch((error) => {
      if (!isActive) {
        return;
      }

      console.error("Unable to load monthly summary:", error);
    });

    return () => {
      isActive = false;
    };
  }, [
    month,
    year,
    getComponentExpenseSummary,
    getMonthlySummaryByMonth,
  ]);

  const handleMonthChange = (event) => {
    setMonth(Number(event.target.value));
  };

  const handleYearChange = (event) => {
    setYear(Number(event.target.value));
  };

  return (
    <Box>
      <Box
        sx={{
          p: 3,
          display: "flex",
          flexDirection: "column",
          gap: 2,
        }}
      >
        <InsightCards
          openingBalance={monthlySummary?.openingBalance || 0}
          cashAdded={monthlySummary?.totalCashInflow || 0}
          totalExpense={
            monthlySummary?.totalExpenseAndReimbursement || 0
          }
          availableCash={monthlySummary?.closingBalance || 0}
        />

        <Paper sx={{ p: 3 }}>
          <Stack
            direction="row"
            gap={2}
            sx={{
              mb: 3,
              justifyContent: "space-between",
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <Box>
              <Typography variant="h5" fontWeight={600}>
                Dashboard
              </Typography>
            </Box>
          </Stack>

          <Grid container spacing={2} mb={3}>
            <Grid size={{ xs: 12, md: 3 }}>
              <FormControl fullWidth size="small">
                <InputLabel id="dashboard-month-label">
                  Month
                </InputLabel>

                <Select
                  labelId="dashboard-month-label"
                  id="dashboard-month"
                  value={month}
                  label="Month"
                  onChange={handleMonthChange}
                >
                  {MONTHS.map((monthOption) => (
                    <MenuItem
                      key={monthOption.value}
                      value={monthOption.value}
                    >
                      {monthOption.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid size={{ xs: 12, md: 3 }}>
              <FormControl fullWidth size="small">
                <InputLabel id="dashboard-year-label">
                  Year
                </InputLabel>

                <Select
                  labelId="dashboard-year-label"
                  id="dashboard-year"
                  value={year}
                  label="Year"
                  onChange={handleYearChange}
                >
                  {YEARS.map((yearOption) => (
                    <MenuItem key={yearOption} value={yearOption}>
                      {yearOption}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>

          <Grid container spacing={3} sx={{ mt: 2 }}>
            <Grid size={{ xs: 12, md: 12 }}>
              <div ref={barChartRef}>
                <ReportBarGraph
                  title="Expense By Component"
                  data={reportData}
                />
              </div>
            </Grid>

            <Grid size={{ xs: 12, md: 12 }}>
              <div ref={pieChartRef}>
                <ReportPieChart
                  title="Expense Distribution"
                  data={reportData}
                />
              </div>
            </Grid>
          </Grid>
        </Paper>
      </Box>
    </Box>
  );
}