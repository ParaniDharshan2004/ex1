export { default as AddComponentsPage } from './pages/AddComponents.jsx';
