import { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Stack,
  IconButton,
  Tooltip,
  Checkbox,
  Collapse,
  Box,
  Typography,
  TablePagination,
} from "@mui/material";

import DeleteOutlined from "@mui/icons-material/DeleteOutlined";
import { Icons } from "../../../theme/icons";
import { useAuth } from "../../../app/providers/AuthContext";

function ComponentRow({
  row,
  subComponents,
  onEdit,
  onDeleteRequest,
  onEditSubComponent,
  onDeleteSubComponent,
}) {
  const [open, setOpen] = useState(false);
  const { permissions } = useAuth();

  const relatedSubComponents = subComponents.filter((sub) => {
    const componentId =
      typeof sub.componentId === "object"
        ? sub.componentId?._id
        : sub.componentId;

    return String(componentId) === String(row._id);
  });

  const hasSubComponents = relatedSubComponents.length > 0;

  return (
    <>
      <TableRow hover>
        <TableCell width={50}>
          {hasSubComponents && (
            <IconButton size="small" onClick={() => setOpen(!open)}>
              {open ? (
                <Icons.KeyboardArrowUpIcon />
              ) : (
                <Icons.KeyboardArrowDownIcon />
              )}
            </IconButton>
          )}
        </TableCell>

        <TableCell>{row.componentName}</TableCell>

        <TableCell>{row.description || "-"}</TableCell>

        <TableCell>
          <Chip
            label={row.isActive ? "Active" : "Inactive"}
            color={row.isActive ? "success" : "error"}
            size="small"
          />
        </TableCell>

        {(permissions?.write || permissions?.delete) && (
          <TableCell>
            <Stack direction="row" spacing={0.5}>
              {permissions?.write && (
                <Tooltip title="Edit">
                  <IconButton size="small" onClick={() => onEdit(row)}>
                    <Icons.EditIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              )}

              {permissions?.delete && (
                <Tooltip title="Delete">
                  <IconButton
                    size="small"
                    onClick={() => onDeleteRequest(row)}
                    sx={{ color: "error.main" }}
                  >
                    <DeleteOutlined />
                  </IconButton>
                </Tooltip>
              )}
            </Stack>
          </TableCell>
        )}
      </TableRow>

      {hasSubComponents && (
        <TableRow>
          <TableCell
            colSpan={10}
            sx={{
              py: 0,
              borderBottom: 0,
            }}
          >
            <Collapse in={open} timeout="auto" unmountOnExit>
              <Box sx={{ p: 2, bgcolor: "background.default" }}>
                <Typography
                  variant="subtitle2"
                  sx={{
                    mb: 2,
                    fontWeight: 600,
                  }}
                >
                  Sub Components
                </Typography>

                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Sub Component Name</TableCell>

                      <TableCell align="center">Requires Bill</TableCell>

                      <TableCell>Status</TableCell>

                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {relatedSubComponents.length > 0 ? (
                      relatedSubComponents.map((sub) => (
                        <TableRow key={sub._id}>
                          <TableCell>{sub.subComponentName}</TableCell>

                          <TableCell align="center">
                            <Checkbox
                              checked={sub.requiresBill}
                              disabled
                              size="small"
                            />
                          </TableCell>

                          <TableCell>
                            <Chip
                              label={sub.isActive ? "Active" : "Inactive"}
                              color={sub.isActive ? "success" : "error"}
                              size="small"
                            />
                          </TableCell>
                          <TableCell>
                            <Stack direction="row" spacing={0.5}>
                              <Tooltip title="Edit">
                                <IconButton
                                  size="small"
                                  onClick={() => onEditSubComponent(sub)}
                                >
                                  <Icons.EditIcon fontSize="small" />
                                </IconButton>
                              </Tooltip>

                              <Tooltip title="Delete">
                                <IconButton
                                  size="small"
                                  onClick={() => onDeleteSubComponent(sub)}
                                  sx={{ color: "error.main" }}
                                >
                                  <DeleteOutlined />
                                </IconButton>
                              </Tooltip>
                            </Stack>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} align="center">
                          No sub components found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </Box>
            </Collapse>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

export default function ComponentsTable({
  rows,
  subComponents,
  onEdit,
  onDeleteRequest,
  onEditSubComponent,
  onDeleteSubComponent,
}) {
  const { permissions } = useAuth();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  const paginatedRows = rows.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage,
  );

  return (
    <TableContainer
      component={Paper}
      sx={{
        border: (theme) => `1px solid ${theme.palette.divider}`,
      }}
    >
      <Table size="small">
        <TableHead>
          <TableRow sx={{ bgcolor: "background.default" }}>
            <TableCell />
            <TableCell>Component Name</TableCell>
            <TableCell>Description</TableCell>
            <TableCell>Status</TableCell>

            {(permissions?.write || permissions?.delete) && (
              <TableCell>Actions</TableCell>
            )}
          </TableRow>
        </TableHead>

        <TableBody>
          {rows.length === 0 ? (
            <TableRow>
              <TableCell colSpan={10} align="center">
                No Components Found
              </TableCell>
            </TableRow>
          ) : (
            paginatedRows.map((row) => (
              <ComponentRow
                key={row._id}
                row={row}
                subComponents={subComponents}
                onEdit={onEdit}
                onDeleteRequest={onDeleteRequest}
                onEditSubComponent={onEditSubComponent}
                onDeleteSubComponent={onDeleteSubComponent}
              />
            ))
          )}
        </TableBody>
      </Table>
      <TablePagination
        component="div"
        count={rows.length}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        rowsPerPageOptions={[5, 10, 25, 50]}
        showFirstButton
        showLastButton
      />
    </TableContainer>
  );
}
