import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import OperationalExpenseUnmatchedTallyRows from '../features/operational-expense/components/upload-review/OperationalExpenseUnmatchedTallyRows';

describe('Operational Expense unmatched rows', () => {
  it('prefills the editable component name from the uploaded ledger', async () => {
    render(
      <OperationalExpenseUnmatchedTallyRows
        unmatchedRows={[
          {
            _id: 'unmatched-1',
            tallyLedgerName: 'Foreign Currency Converter',
            amount: 1250,
          },
        ]}
        onAddToMaster={vi.fn()}
        onAddReportOnly={vi.fn()}
      />,
    );

    fireEvent.click(
      await screen.findByRole('button', { name: 'Add to Master Data' }),
    );

    const componentName = await screen.findByLabelText('Component Name');
    expect(componentName.value).toBe('Foreign Currency Converter');

    fireEvent.change(componentName, {
      target: { value: 'Edited component name' },
    });
    expect(componentName.value).toBe('Edited component name');
  });
});
