import { describe, expect, it } from 'vitest';
import {
  getInvoiceClientOptions,
  getInvoiceLocationFilterValue,
  getInvoiceLocationOptions,
} from '../features/operational-expense/utils/invoiceLocationFilters';

describe('invoice location filters', () => {
  const invoices = [
    { client: 'CRKL Inc.', location: 'USA' },
    { client: 'MKPL Private Limited', location: 'Chennai' },
    { client: 'MKPL Private Limited', location: 'Bengaluru' },
  ];
  const clients = ['CRKL Inc.', 'MKPL Private Limited'];

  it('limits location choices to the selected client', () => {
    expect(getInvoiceLocationOptions(invoices, clients, 'CRKL Inc.')).toEqual([
      'USA',
    ]);
    expect(
      getInvoiceLocationOptions(invoices, clients, 'MKPL Private Limited'),
    ).toEqual(['Chennai', 'Bengaluru']);
  });

  it('shows locations for available clients when no client is selected', () => {
    expect(getInvoiceLocationOptions(invoices, clients)).toEqual([
      'USA',
      'Chennai',
      'Bengaluru',
    ]);
    expect(
      getInvoiceLocationOptions(invoices, ['MKPL Private Limited']),
    ).toEqual(['Chennai', 'Bengaluru']);
  });

  it('limits client choices to clients with invoices at the selected location', () => {
    expect(getInvoiceClientOptions(invoices, clients, 'USA')).toEqual([
      'CRKL Inc.',
    ]);
    expect(getInvoiceClientOptions(invoices, clients, 'Chennai')).toEqual([
      'MKPL Private Limited',
    ]);
    expect(getInvoiceClientOptions(invoices, clients)).toEqual(clients);
  });

  it('normalizes known locations and rejects invalid client-location pairs', () => {
    expect(getInvoiceLocationFilterValue('MKPL Private Limited', 'Madras')).toBe(
      'Chennai',
    );
    expect(
      getInvoiceLocationFilterValue('MKPL Private Limited', 'Bangalore'),
    ).toBe('Bengaluru');
    expect(
      getInvoiceLocationFilterValue('MKPL Private Limited', 'USA'),
    ).toBeNull();
    expect(
      getInvoiceLocationFilterValue('CRKL Inc.', 'Chennai'),
    ).toBeNull();
  });
});
