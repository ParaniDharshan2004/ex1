import { describe, it, expect } from 'vitest';
import {
  amountInWords,
  amountInWordsUSD,
  formatINR,
  formatUSD,
  isCrklInvoice,
} from '../features/operational-expense/utils/currency';
import {
  calculateSubtotal,
  calculateMarkup,
  calculateTotalBillable,
  calculateOtherExpenseTotal,
  calculateOperationalExpenseCategoryTotals,
  groupExpensesByCategory,
} from '../features/operational-expense/utils/expenseCalculations';
import {
  calculateCrklBalance,
  calculateCustomLocationSplit,
  calculateEqualLocationSplit,
  validateAllocationState,
} from '../features/operational-expense/utils/allocationCalculations';
import { sortClientAllocationsForPreview } from '../features/operational-expense/utils/clientAllocationUtils';
import {
  describeLocations,
  findBengaluruLocation,
  findChennaiLocation,
} from '../features/operational-expense/utils/allocationLocationUtils';
import {
  buildTwelveMonthCalendar,
  normalizeInvoiceItem,
  transformReportSummary,
} from '../features/operational-expense/utils/reportTransformers';
import {
  calculateFixedCostTotal,
  splitTallyRowsByFixedCost,
} from '../features/operational-expense/utils/fixedCostImport';
import {
  aggregateTallyRowsByHeadComponent,
  calculateMiscellaneousExpenseTotal,
  isManagedComponentUnmatchedRow,
  isUnresolvedTallyRow,
} from '../features/operational-expense/utils/tallyHeadComponentImport';
import {
  groupFixedAssetsByParent,
  isResolvedFixedAssetUnmatchedRow,
  mapFixedAssetsToComponents,
} from '../features/operational-expense/utils/fixedAssetMapping';
import { extractTallyRowsFromGrid } from '../features/operational-expense/utils/tallyGridParser';

describe('Operational Expense Calculations and Utilities', () => {
  it('orders preview clients exclusively by Client Master display order', () => {
    const allocations = sortClientAllocationsForPreview([
      {
        clientMaster: { _id: 'xyz', clientName: 'XYZ', displayOrder: 3 },
        clientTotalAmount: 100,
      },
      {
        clientMaster: { _id: 'crkl', clientName: 'CRKL Inc.', displayOrder: 0 },
        clientTotalAmount: 500,
      },
      {
        clientMaster: { _id: 'mkpl', clientName: 'MKPL', displayOrder: 1 },
        clientTotalAmount: 300,
      },
      {
        clientMaster: { _id: 'abc', clientName: 'ABC', displayOrder: 2 },
        clientTotalAmount: 200,
      },
    ]);

    expect(allocations).toEqual([
      { id: 'crkl', clientName: 'CRKL Inc.', amount: 500, displayOrder: 0 },
      { id: 'mkpl', clientName: 'MKPL', amount: 300, displayOrder: 1 },
      { id: 'abc', clientName: 'ABC', amount: 200, displayOrder: 2 },
      { id: 'xyz', clientName: 'XYZ', amount: 100, displayOrder: 3 },
    ]);
  });

  it('does not use frontend-derived order values when Client Master order is missing', () => {
    const allocations = sortClientAllocationsForPreview([
      { clientMaster: { clientName: 'Zulu' }, displayOrder: 1 },
      { clientMaster: { clientName: 'Alpha' }, displayOrder: 0 },
    ]);

    expect(
      allocations.map(({ clientName, displayOrder }) => [
        clientName,
        displayOrder,
      ]),
    ).toEqual([
      ['Zulu', undefined],
      ['Alpha', undefined],
    ]);
  });

  it('filters unmatched rows that exactly match a managed component', () => {
    const managedComponents = [
      {
        componentName: 'Computer & Equipments',
        isOperationalExpense: false,
      },
    ];

    expect(
      isManagedComponentUnmatchedRow(
        { tallyLedgerName: 'Computer and Equipments' },
        managedComponents,
      ),
    ).toBe(true);
    expect(
      isManagedComponentUnmatchedRow(
        { tallyLedgerName: 'Foreign Currency Conversion Loss' },
        managedComponents,
      ),
    ).toBe(false);
  });

  it('formats INR correctly with symbol and decimals', () => {
    expect(formatINR(75000)).toBe('₹ 75,000.00');
    expect(formatINR(0)).toBe('₹ 0.00');
    expect(formatINR(1234.5, { showSymbol: false })).toBe('1,234.50');
  });

  it('converts invoice amounts to Indian currency words', () => {
    expect(amountInWords(10)).toBe('ten rupees only');
    expect(amountInWords(1.25)).toBe('one rupee and twenty five paise only');
    expect(amountInWords(1234567)).toBe('twelve lakh thirty four thousand five hundred sixty seven rupees only');
    expect(amountInWords(-1)).toBe('');
  });

  it('formats CRKL invoice amounts and words in USD', () => {
    expect(formatUSD(400.76)).toBe('$ 400.76');
    expect(formatUSD(1234567.8)).toBe('$ 1,234,567.80');
    expect(amountInWordsUSD(400.76)).toBe(
      'four hundred dollars and seventy-six cents only',
    );
    expect(amountInWordsUSD(1)).toBe('one dollar and zero cents only');
  });

  it('identifies CRKL invoices by client code or name', () => {
    expect(isCrklInvoice({ rawInvoice: { clientId: { clientCode: 'CRKL' } } }))
      .toBe(true);
    expect(isCrklInvoice({ client: 'CRKL Inc.' })).toBe(true);
    expect(isCrklInvoice({ client: 'MKPL Private Limited' })).toBe(false);
  });

  it('does not show unmatched rows that have been added to the report', () => {
    expect(isUnresolvedTallyRow({ resolutionStatus: 'UNRESOLVED' })).toBe(true);
    expect(isUnresolvedTallyRow({ resolutionStatus: 'ADDED_TO_REPORT' })).toBe(
      false,
    );
  });

  it('keeps manually added unmatched rows in the selected report category', () => {
    const expenses = groupExpensesByCategory([
      {
        rowSource: 'REPORT_ONLY',
        matchStatus: 'MANUALLY_ADDED',
        financialCategoryName: 'Direct Cost',
        componentName: 'Unmatched ledger',
        amount: 1250,
      },
    ]);

    expect(expenses).toHaveLength(1);
    expect(expenses[0]).toMatchObject({
      category: 'Direct Cost',
      description: 'Unmatched ledger',
      amount: 1250,
      rowSource: 'REPORT_ONLY',
      matchStatus: 'MANUALLY_ADDED',
    });
  });

  it('calculates subtotal, markup and total billable according to 20% markup rule', () => {
    const expenses = [
      ['Direct Cost', 'Salary', 75000],
      ['Indirect Cost', 'Rent', 25000],
    ];
    const subtotal = calculateSubtotal(expenses);
    expect(subtotal).toBe(100000);

    const markup = calculateMarkup(subtotal);
    expect(markup).toBe(20000);

    const totalBillable = calculateTotalBillable(subtotal, markup);
    expect(totalBillable).toBe(120000);
  });

  it('adds unclassified uploaded categories to billable totals without markup', () => {
    const expenses = [
      { category: 'Direct Cost', amount: 1000 },
      { category: 'Indirect Cost', amount: 500 },
      { category: 'Misc Expenses', amount: 100 },
      { category: 'Fixed Assets', amount: 200 },
      { category: 'Travel Expense', amount: 300 },
    ];
    const subtotal = calculateSubtotal(expenses);
    const markup = calculateMarkup(subtotal);
    const otherExpenseTotal = calculateOtherExpenseTotal(expenses);

    expect(subtotal).toBe(1500);
    expect(markup).toBe(300);
    expect(otherExpenseTotal).toBe(300);
    expect(
      calculateTotalBillable(
        subtotal,
        markup,
        100 + 200 + otherExpenseTotal,
      ),
    ).toBe(2400);
  });

  it('preserves rows from uploaded categories outside the standard buckets', () => {
    const expenses = groupExpensesByCategory([
      {
        financialCategoryName: 'Travel Expense',
        componentName: 'Taxi',
        amount: 300,
      },
    ]);

    expect(expenses).toHaveLength(1);
    expect(expenses[0]).toMatchObject({
      category: 'Travel Expense',
      description: 'Taxi',
      amount: 300,
    });
  });

  it('calculates direct and indirect totals using Upload & Review category rules', () => {
    expect(
      calculateOperationalExpenseCategoryTotals([
        { financialCategoryName: 'Direct Cost', amount: 75000 },
        { category: 'Indirect Cost', amount: 35000 },
        { category: 'Indirect - Travel', amount: 200 },
        { category: 'Misc Expenses', amount: 100 },
      ]),
    ).toEqual({
      directCostTotal: 75000,
      indirectCostTotal: 35200,
    });
  });

  it('includes the formatted month in operational expense dashboard report summaries', () => {
    const report = transformReportSummary({
      _id: 'report-oct-2026',
      reportMonth: '2026-10',
      status: 'DRAFT',
    });

    expect(report.periodFormatted).toBe('October 2026');
    expect(report.periodFormatted.toLowerCase().includes('oct')).toBe(true);
  });

  it('uses all report categories in dashboard billable totals', () => {
    const report = transformReportSummary({
      reportMonth: '2026-10',
      rows: [
        { category: 'Direct Cost', amount: 100 },
        { category: 'Indirect Cost', amount: 50 },
        { category: 'Misc Expenses', amount: 10 },
        { category: 'Travel Expense', amount: 5 },
      ],
      fixedAssets: [{ amount: 20 }],
    });

    expect(report.subtotal).toBe(150);
    expect(report.markup).toBe(30);
    expect(report.totalBillable).toBe(215);
  });

  it('matches uploaded fixed-asset aliases and categories without losing operational rows', () => {
    const result = splitTallyRowsByFixedCost(
      [
        ['Assets', 'Laptop Computer', 50000],
        ['Professional Fees', 'Consulting', 12000],
        ['Building Improvements', 'Renovation', 15000],
        ['Fixed Cost', 'Server Replacement', 8000],
      ],
      [
        {
          assetName: 'Laptop',
          aliases: ['Laptop Computer'],
          categoryId: { categoryName: 'IT Equipment' },
        },
      ],
      [{ categoryName: 'Building Improvements' }],
    );

    expect(result.fixedCosts).toEqual([
      {
        itemName: 'Laptop',
        description: 'Category: IT Equipment | Tally ledger: Laptop Computer',
        amount: 50000,
      },
      {
        itemName: 'Building Improvements',
        description: 'Category: Building Improvements | Tally ledger: Renovation',
        amount: 15000,
      },
      {
        itemName: 'Server Replacement',
        description: 'Tally ledger: Server Replacement',
        amount: 8000,
      },
    ]);
    expect(result.operationalRows).toEqual([
      ['Professional Fees', 'Consulting', 12000],
    ]);
    expect(calculateFixedCostTotal(result.fixedCosts)).toBe(73000);
  });

  it('groups fixed assets under their configured component and resolves its head ledger', () => {
    const mappedAssets = mapFixedAssetsToComponents(
      [
        {
          itemName: 'Laptop',
          description: 'Category: Equipment | Tally ledger: Laptop',
          amount: 90000,
        },
        {
          itemName: 'Mouse',
          description: 'Category: Equipment | Tally ledger: Mouse',
          amount: 100,
        },
      ],
      [{ _id: 'computer', componentName: 'Computer and Equipments' }],
      [
        { componentId: 'computer', subComponentName: 'Laptop' },
        { componentId: 'computer', subComponentName: 'Mouse' },
      ],
    );

    expect(groupFixedAssetsByParent(mappedAssets)).toMatchObject([
      {
        parentCategory: 'Computer and Equipments',
        total: 90100,
        children: [{ subcomponent: 'Laptop' }, { subcomponent: 'Mouse' }],
      },
    ]);
    expect(
      isResolvedFixedAssetUnmatchedRow(
        { tallyLedgerName: 'Computer and Equipments' },
        mappedAssets,
      ),
    ).toBe(true);
  });

  it('sorts fixed asset heads and subcomponents by master display order with missing order last', () => {
    const mappedAssets = mapFixedAssetsToComponents(
      [
        { itemName: 'Mouse', amount: 100 },
        { itemName: 'Laptop', amount: 90000 },
        { itemName: 'Unordered', amount: 50 },
        { itemName: 'Table', amount: 4000 },
      ],
      [
        { _id: 'equipment', componentName: 'Computer and Equipments', displayOrder: 2 },
        { _id: 'furniture', componentName: 'Furniture', displayOrder: 1 },
        { _id: 'unmapped-order', componentName: 'Unmapped order' },
      ],
      [
        { componentId: 'equipment', subComponentName: 'Laptop', displayOrder: 1 },
        { componentId: 'equipment', subComponentName: 'Mouse', displayOrder: 2 },
        { componentId: 'unmapped-order', subComponentName: 'Unordered' },
        { componentId: 'furniture', subComponentName: 'Table', displayOrder: 1 },
      ],
    );

    expect(groupFixedAssetsByParent(mappedAssets).map((group) => ({
      parentCategory: group.parentCategory,
      children: group.children.map((item) => item.subcomponent),
    }))).toEqual([
      { parentCategory: 'Furniture', children: ['Table'] },
      { parentCategory: 'Computer and Equipments', children: ['Laptop', 'Mouse'] },
      { parentCategory: 'Unmapped order', children: ['Unordered'] },
    ]);
  });

  it('shows one head component with the total of its matched subcomponents', () => {
    const { matchedRows } = aggregateTallyRowsByHeadComponent(
      [
        ['Direct Cost', 'Basic Salary', 50000],
        ['Direct Cost', 'House Allowance', 15000],
        ['Direct Cost', 'Medical Allowance', 5000],
      ],
      [
        {
          _id: 'salary',
          componentName: 'Salary',
          componentCode: 'SAL',
          financialCategoryId: { categoryName: 'Direct Cost' },
          displayOrder: 1,
        },
      ],
      [
        { _id: 'basic', subComponentName: 'Basic Salary', componentId: 'salary' },
        { _id: 'house', subComponentName: 'House Allowance', componentId: 'salary' },
        { _id: 'medical', subComponentName: 'Medical Allowance', componentId: 'salary' },
      ],
      [{ _id: 'direct', categoryName: 'Direct Cost' }],
    );

    expect(matchedRows).toEqual([
      {
        componentId: 'salary',
        componentCode: 'SAL',
        componentName: 'Salary',
        category: 'Direct Cost',
        financialCategoryName: 'Direct Cost',
        rowSource: 'TALLY_IMPORT',
        displayOrder: 1,
        description: 'Salary',
        amount: 70000,
        matchStatus: 'CALCULATED_FROM_SUBCOMPONENTS',
        hasTallyExpense: true,
      },
    ]);
  });

  it('uses a direct head-component amount when one exists, as the report backend does', () => {
    const { matchedRows } = aggregateTallyRowsByHeadComponent(
      [
        ['Direct Cost', 'Basic Salary', 50000],
        ['Direct Cost', 'Salary', 70000],
      ],
      [
        {
          _id: 'salary',
          componentName: 'Salary',
          financialCategoryId: { categoryName: 'Direct Cost' },
        },
      ],
      [{ subComponentName: 'Basic Salary', componentId: 'salary' }],
      [{ _id: 'direct', categoryName: 'Direct Cost' }],
    );

    expect(matchedRows).toHaveLength(1);
    expect(matchedRows[0].description).toBe('Salary');
    expect(matchedRows[0].amount).toBe(70000);
    expect(matchedRows[0].matchStatus).toBe('HEAD_COMPONENT_MATCHED');
  });

  it('matches and groups miscellaneous subcomponents under their head without making them unmatched', () => {
    const result = aggregateTallyRowsByHeadComponent(
      [
        ['Miscellaneous Expenses', 'Directors’ Remunerations', 1500],
        ['Miscellaneous Expenses', 'Foreign Currency Conversion Loss', 300],
      ],
      [
        {
          _id: 'misc-head',
          componentName: 'Miscellaneous Expense',
          financialCategoryId: { categoryName: 'Misc Expenses' },
          displayOrder: 10,
        },
      ],
      [
        {
          _id: 'director-sub',
          subComponentName: 'Director Remuneration',
          componentId: 'misc-head',
        },
        {
          _id: 'fx-sub',
          subComponentName: 'Foreign Currency Conversion Loss',
          componentId: 'misc-head',
        },
      ],
      [{ _id: 'misc-cat', categoryName: 'Misc Expenses' }],
    );
    const grouped = groupExpensesByCategory(result.matchedRows);

    expect(result.unmatchedRows).toEqual([]);
    expect(grouped).toHaveLength(1);
    expect(grouped[0]).toMatchObject({
      description: 'Miscellaneous Expense',
      category: 'Misc expenses',
      amount: 1800,
    });
    expect(calculateSubtotal(grouped)).toBe(0);
    expect(calculateMiscellaneousExpenseTotal(grouped)).toBe(1800);
  });

  it('returns uncategorized and unmatched Tally values separately from billable heads', () => {
    const result = aggregateTallyRowsByHeadComponent(
      [
        ['Direct Cost', 'Known subcomponent', 4000],
        ['Miscellaneous', 'Unmapped ledger', 2500],
        ['Other', 'Component without category', 1000],
      ],
      [
        {
          _id: 'known',
          componentName: 'Known head',
          financialCategoryId: { categoryName: 'Direct Cost' },
        },
        {
          _id: 'uncategorized',
          componentName: 'Component',
          financialCategoryId: null,
        },
      ],
      [
        {
          subComponentName: 'Known subcomponent',
          componentId: 'known',
        },
      ],
      [{ _id: 'direct', categoryName: 'Direct Cost' }],
    );

    expect(result.matchedRows).toHaveLength(1);
    expect(result.matchedRows[0].amount).toBe(4000);
    expect(result.unmatchedRows).toEqual([
      {
        tallyLedgerName: 'Unmapped ledger',
        amount: 2500,
        reason: 'No matching head component or subcomponent for category "Miscellaneous".',
        resolutionStatus: 'UNRESOLVED',
      },
      {
        tallyLedgerName: 'Component without category',
        amount: 1000,
        reason: 'Matched component "Component" has no financial category.',
        resolutionStatus: 'UNRESOLVED',
      },
    ]);
  });

  it('keeps matched rows from other financial categories in billable heads', () => {
    const result = aggregateTallyRowsByHeadComponent(
      [['Other', 'Other expense', 1200]],
      [
        {
          _id: 'other',
          componentName: 'Other expense',
          financialCategoryId: { categoryName: 'Other' },
        },
      ],
      [],
      [{ _id: 'other-category', categoryName: 'Other' }],
    );

    expect(result.matchedRows).toHaveLength(1);
    expect(result.matchedRows[0]).toMatchObject({
      componentName: 'Other expense',
      financialCategoryName: 'Other',
      amount: 1200,
    });
    expect(result.unmatchedRows).toEqual([]);
  });

  it('classifies unresolved Tally rows for the miscellaneous expense section', () => {
    expect(isUnresolvedTallyRow({ resolutionStatus: 'UNRESOLVED' })).toBe(true);
    expect(isUnresolvedTallyRow({})).toBe(true);
    expect(isUnresolvedTallyRow({ resolutionStatus: 'MAPPED' })).toBe(false);
    expect(isUnresolvedTallyRow({ resolutionStatus: 'EXCLUDED' })).toBe(false);
  });

  it('calculates matched miscellaneous-category rows without unrelated amounts', () => {
    expect(
      calculateMiscellaneousExpenseTotal([
        {
          tallyLedgerName: 'Directors’ Remuneration',
          financialCategoryName: 'Miscellaneous Expenses',
          amount: 1500,
        },
        {
          tallyLedgerName: 'Foreign Currency Conversion Loss',
          category: 'Misc Expenses',
          amount: 300,
        },
        {
          tallyLedgerName: 'Unrelated component',
          financialCategoryName: 'Indirect Cost',
          amount: 900,
        },
      ]),
    ).toBe(1800);
  });

  it('extracts only rows with a Particulars value and Debit or Credit amount', () => {
    const grid = [
      ['Indirect Expenses'],
      ['Group Summary'],
      ['Oct 2026'],
      ['', '', 'Indirect Expenses'],
      ['Particulars', '', 'Oct 2026'],
      ['', '', 'Transactions'],
      ['', 'Debit', 'Credit'],
      ['Employee Related Events & Trips', 4500, ''],
      ['  Birthday Celebration', 1000, ''],
      ['  Recreation & Team Outings', 1500, ''],
      ['Misc Office Expenses', 100, ''],
      ['Bank Interest', '', 250],
      ['Rows without an amount', '', ''],
    ];

    expect(extractTallyRowsFromGrid(grid)).toEqual([
      ['', 'Employee Related Events & Trips', 4500],
      ['', 'Birthday Celebration', 1000],
      ['', 'Recreation & Team Outings', 1500],
      ['', 'Misc Office Expenses', 100],
      ['', 'Bank Interest', 250],
    ]);
  });

  it('preserves simple category-description-amount imports without Tally headers', () => {
    expect(
      extractTallyRowsFromGrid([
        ['Direct Cost', 'Salary', 75000],
        ['Indirect Cost', 'Rent', '25,000.00'],
      ]),
    ).toEqual([
      ['Direct Cost', 'Salary', 75000],
      ['Indirect Cost', 'Rent', 25000],
    ]);
  });

  it('calculates equal location split for MKPL bills', () => {
    const split = calculateEqualLocationSplit(100000);
    expect(split.chennai).toBe(50000);
    expect(split.bengaluru).toBe(50000);
  });

  it('automatically balances custom location allocations', () => {
    expect(calculateCustomLocationSplit(100000, 60000, 'chennai')).toEqual({
      chennai: 60000,
      bengaluru: 40000,
    });
    expect(calculateCustomLocationSplit(100000, 60000, 'bengaluru')).toEqual({
      chennai: 40000,
      bengaluru: 60000,
    });
    expect(calculateCustomLocationSplit(100000, 120000, 'chennai')).toEqual({
      chennai: 120000,
      bengaluru: 0,
    });
  });

  it('calculates CRKL balance correctly as remaining total', () => {
    const crkl = calculateCrklBalance(338400, 200000);
    expect(crkl).toBe(138400);
  });

  it('validates allocation balance accurately', () => {
    // Balanced allocation
    const validState = validateAllocationState(300000, 200000, 100000, 100000);
    expect(validState.isValid).toBe(true);
    expect(validState.severity).toBe('ok');

    // MKPL exceeds total billable
    const excessState = validateAllocationState(100000, 150000, 75000, 75000);
    expect(excessState.isValid).toBe(false);
    expect(excessState.severity).toBe('error');

    // Location amounts do not equal MKPL
    const unbalanceState = validateAllocationState(300000, 200000, 90000, 100000);
    expect(unbalanceState.isValid).toBe(false);
    expect(unbalanceState.severity).toBe('warn');
  });

  it('rejects a custom location amount that exceeds the MKPL total', () => {
    const state = validateAllocationState(
      200000,
      100000,
      120000,
      0,
      'custom',
    );

    expect(state.isValid).toBe(false);
    expect(state.severity).toBe('error');
    expect(state.message).toContain('cannot exceed the MKPL amount');
  });

  it('matches MKPL locations by city names and location codes', () => {
    const locations = [
      { locationName: 'Chennai Office', locationCode: 'MAA-01' },
      { locationName: 'Bengaluru Branch', locationCode: 'BLR' },
    ];

    expect(findChennaiLocation(locations)).toBe(locations[0]);
    expect(findBengaluruLocation(locations)).toBe(locations[1]);
    expect(describeLocations(locations)).toBe(
      'Chennai Office (MAA-01), Bengaluru Branch (BLR)',
    );
    expect(findChennaiLocation([{ locationName: 'Madras Office' }])).toEqual({
      locationName: 'Madras Office',
    });
  });

  it('normalizes populated invoice client, location, invoice number, and period', () => {
    const invoice = normalizeInvoiceItem({
      _id: 'invoice-id',
      invoiceNo: 'INV-MKPL-001',
      clientId: { clientName: 'MKPL Private Limited' },
      locationId: { locationName: 'Chennai' },
      expensePeriod: '2026-09',
      taxableAmount: 50847.46,
      gstAmount: 9152.54,
      gstRate: 18,
      grandTotal: 60000,
      createdAt: '2026-10-23T00:00:00.000Z',
    });

    expect(invoice.client).toBe('MKPL Private Limited');
    expect(invoice.location).toBe('Chennai');
    expect(invoice.no).toBe('INV-MKPL-001');
    expect(invoice.period).toBe('2026-09');
    expect(invoice).toMatchObject({
      amount: 60000,
      taxableAmount: 50847.46,
      gstAmount: 9152.54,
      gstRate: 18,
      grandTotal: 60000,
      hsnSac: '',
    });
  });

  it('builds 12 months calendar representing January to December', () => {
    const calendar = buildTwelveMonthCalendar('2026', [
      { period: '2026-09', grandTotal: 50000 },
      { period: '2026-09', grandTotal: 50000 },
    ]);
    expect(calendar.length).toBe(12);
    expect(calendar[0].monthName).toBe('January');
    expect(calendar[8].monthName).toBe('September');
    expect(calendar[8].totalAmount).toBe(100000);
    expect(calendar[8].invoiceCount).toBe(2);
    expect(calendar[11].monthName).toBe('December');
  });
});
