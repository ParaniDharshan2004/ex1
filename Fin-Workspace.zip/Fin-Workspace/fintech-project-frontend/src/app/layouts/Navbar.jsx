import { useEffect, useRef, useState } from "react";

import {
  AppBar,
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  IconButton,
  Link,
  Paper,
  Popper,
  Toolbar,
  Typography,
  alpha,
  useTheme,
} from "@mui/material";

import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import NavigateNextRoundedIcon from "@mui/icons-material/NavigateNextRounded";
import LogoutOutlinedIcon from "@mui/icons-material/LogoutOutlined";

import { useLocation, useNavigate } from "react-router-dom";

import { NAV_ITEMS } from "../../shared/constants/dummy-data";
import { useAuth } from "../providers/AuthContext";
import {
  buildOperationalExpenseNavigationTarget,
  getOperationalExpenseBreadcrumbs,
} from "../../features/operational-expense/utils/navigation";

const normalizePath = (path) => {
  if (!path) {
    return "/";
  }

  return path !== "/" && path.endsWith("/") ? path.slice(0, -1) : path;
};

export default function Navbar({ onMenuClick, isMobile }) {
  const theme = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, role, logout } = useAuth();
  const [avatarAnchor, setAvatarAnchor] = useState(null);
  const closeTimerRef = useRef(null);

  const currentPath = normalizePath(location.pathname);

  const currentMenu = NAV_ITEMS.find((item) => {
    const itemPath = normalizePath(item.to);

    const isDirectMatch = itemPath === currentPath;

    const hasMatchingChild = item.children?.some(
      (child) => { const cp = normalizePath(child.to); return cp === currentPath || (cp !== '/' && currentPath.startsWith(cp)); }
    );

    return isDirectMatch || hasMatchingChild;
  });

  const currentChild = currentMenu?.children?.find(
    (child) => { const cp = normalizePath(child.to); return cp === currentPath || (cp !== '/' && currentPath.startsWith(cp)); }
  );

  const currentPageTitle =
    currentChild?.label || currentMenu?.label || "Dashboard";
  const isDashboard = currentPath === "/";
  const operationalBreadcrumbs =
    getOperationalExpenseBreadcrumbs(
      currentPath,
      location.search,
      location.state,
    );

  const avatarMenuOpen = Boolean(avatarAnchor);

  const navigateToDashboard = () => {
    navigate("/");
  };

  const navigateToOperationalBreadcrumb = (routeKey) => {
    const target = buildOperationalExpenseNavigationTarget(
      routeKey,
      location,
    );
    navigate(target.to, { state: target.state });
  };

  const cancelScheduledClose = () => {
    if (closeTimerRef.current) {
      window.clearTimeout(closeTimerRef.current);

      closeTimerRef.current = null;
    }
  };

  const handleAvatarMouseEnter = (event) => {
    cancelScheduledClose();
    setAvatarAnchor(event.currentTarget);
  };

  const scheduleAvatarMenuClose = () => {
    cancelScheduledClose();

    closeTimerRef.current = window.setTimeout(() => {
      setAvatarAnchor(null);
      closeTimerRef.current = null;
    }, 180);
  };

  const handlePopupMouseEnter = () => {
    cancelScheduledClose();
  };

  const handlePopupMouseLeave = () => {
    scheduleAvatarMenuClose();
  };

  const handleAvatarClick = (event) => {
    cancelScheduledClose();

    setAvatarAnchor((currentAnchor) =>
      currentAnchor ? null : event.currentTarget,
    );
  };

  const handleAvatarKeyDown = (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();

      setAvatarAnchor((currentAnchor) =>
        currentAnchor ? null : event.currentTarget,
      );
    }

    if (event.key === "Escape") {
      setAvatarAnchor(null);
    }
  };

  const handleLogout = () => {
    cancelScheduledClose();
    setAvatarAnchor(null);

    logout();

    navigate("/login", {
      replace: true,
    });
  };

  useEffect(() => {
    return () => {
      cancelScheduledClose();
    };
  }, []);

  const avatarInteractionProps = {
    role: "button",
    tabIndex: 0,
    "aria-label": "Open user menu",
    "aria-haspopup": "menu",
    "aria-expanded": avatarMenuOpen,
    onMouseEnter: handleAvatarMouseEnter,
    onMouseLeave: scheduleAvatarMenuClose,
    onClick: handleAvatarClick,
    onKeyDown: handleAvatarKeyDown,
  };

  return (
    <AppBar
      position="sticky"
      elevation={2}
      sx={{
        top: 0,
        zIndex: theme.zIndex.appBar,
        width: "100%",
        minWidth: 0,
        bgcolor: alpha(theme.palette.background.paper, 0.96),
        color: "text.primary",
        borderBottom: "1px solid",
        borderColor: "divider",
        backdropFilter: "blur(12px)",
      }}
    >
      <Toolbar
        sx={{
          width: "100%",
          minWidth: 0,
          minHeight: {
            xs: 72,
            sm: 76,
          },
          boxSizing: "border-box",
          px: {
            xs: 1.5,
            sm: 2.5,
            md: 3,
          },
          py: {
            xs: 1,
            sm: 1.25,
          },
          gap: {
            xs: 1.25,
            sm: 2,
          },
        }}
      >
        {isMobile && (
          <IconButton
            aria-label="Open navigation menu"
            onClick={onMenuClick}
            sx={{
              width: 36,
              height: 36,
              flexShrink: 0,
              border: "1px solid",
              borderColor: "divider",
              borderRadius: 2,
              color: "text.primary",
              bgcolor: "background.paper",

              "&:hover": {
                bgcolor: "action.hover",
              },
            }}
          >
            <MenuRoundedIcon />
          </IconButton>
        )}

        <Box
          sx={{
            flexGrow: 1,
            minWidth: 0,
            overflow: "hidden",
          }}
        >
          {/* {isMobile && (
            <Typography
              variant="subtitle1"
              noWrap
              sx={{
                mb: 0.25,
                fontFamily: '"DM Sans", sans-serif',
                fontWeight: 700,
                color: "text.primary",
              }}
            >
              {currentPageTitle}
            </Typography>
          )} */}

          <Breadcrumbs
            aria-label="Breadcrumb navigation"
            separator={
              <NavigateNextRoundedIcon
                sx={{
                  fontSize: {
                    xs: 16,
                    sm: 18,
                  },
                  color: "text.disabled",
                }}
              />
            }
            sx={{
              minWidth: 0,
              overflow: "hidden",

              "& .MuiBreadcrumbs-ol": {
                flexWrap: "nowrap",
                minWidth: 0,
              },

              "& .MuiBreadcrumbs-li": {
                minWidth: 0,
              },
            }}
          >
            {operationalBreadcrumbs ? (
              operationalBreadcrumbs.map((crumb, index) => {
                const isCurrent = index === operationalBreadcrumbs.length - 1;
                const crumbSx = {
                  flexShrink: 0,
                  fontFamily: '"DM Sans", sans-serif',
                  fontSize: {
                    xs: "0.75rem",
                    sm: "0.875rem",
                  },
                  fontWeight: isCurrent ? 600 : 400,
                };

                return (
                  <Link
                    key={crumb.key}
                    component="button"
                    type="button"
                    underline="hover"
                    color={isCurrent ? "text.primary" : "text.secondary"}
                    aria-current={isCurrent ? "page" : undefined}
                    onClick={() =>
                      navigateToOperationalBreadcrumb(crumb.key)
                    }
                    sx={{
                      ...crumbSx,
                      ...(isCurrent && {
                        minWidth: 0,
                        maxWidth: { xs: 130, sm: 240 },
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }),
                      border: 0,
                      p: 0,
                      bgcolor: "transparent",
                      cursor: "pointer",
                    }}
                  >
                    {crumb.label}
                  </Link>
                );
              })
            ) : (
              [
                <Link
                  key="dashboard"
                  component="button"
                  type="button"
                  underline="hover"
                  color={isDashboard ? "text.primary" : "text.secondary"}
                  onClick={navigateToDashboard}
                  sx={{
                    flexShrink: 0,
                    border: 0,
                    p: 0,
                    bgcolor: "transparent",
                    fontFamily: '"DM Sans", sans-serif',
                    fontSize: {
                      xs: "0.75rem",
                      sm: "0.875rem",
                    },
                    fontWeight: isDashboard ? 600 : 400,
                    cursor: isDashboard ? "default" : "pointer",
                  }}
                >
                  Dashboard
                </Link>,

                !isDashboard && currentPageTitle && (
                  <Typography
                    key="current-page"
                    color="text.primary"
                    noWrap
                    sx={{
                      minWidth: 0,
                      maxWidth: {
                        xs: 130,
                        sm: 240,
                      },
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      fontFamily: '"DM Sans", sans-serif',
                      fontSize: {
                        xs: "0.75rem",
                        sm: "0.875rem",
                      },
                      fontWeight: 600,
                    }}
                  >
                    {currentPageTitle}
                  </Typography>
                ),
              ]
            )}
          </Breadcrumbs>
        </Box>

        {/* <Box
          sx={{
            display: {
              xs: "none",
              md: "flex",
            },
            alignItems: "center",
            gap: 1,
            px: 0.75,
            py: 0.5,
            flexShrink: 0,
            borderRadius: 1,
            transition: "background-color 160ms ease",
            "&:hover": {
              bgcolor: "action.hover",
            },
          }}
        >
          <Avatar
            {...avatarInteractionProps}
            sx={{
              width: 42,
              height: 42,
              bgcolor: "primary.main",
              fontFamily: '"DM Sans", sans-serif',
              fontSize: "1rem",
              fontWeight: 700,
              cursor: "pointer",
              userSelect: "none",
              outline: "none",
              border: "3px solid",
              borderColor: "background.paper",
              boxShadow: `0 0 0 1px ${alpha(
                theme.palette.primary.main,
                0.22,
              )}`,
              transition: "box-shadow 160ms ease, transform 160ms ease",

              "&:hover": {
                transform: "translateY(-1px)",
                boxShadow: "0 4px 12px rgba(15, 23, 42, 0.18)",
              },

              "&:focus-visible": {
                boxShadow: `0 0 0 3px ${alpha(
                  theme.palette.primary.main,
                  0.25,
                )}`,
              },
            }}
          >
            {user?.username?.charAt(0)?.toUpperCase() || "U"}
          </Avatar>

          <Box
            sx={{
              minWidth: 96,
              textAlign: "left",
              display: "flex",
              flexDirection: "column",
              gap: 0.15,
            }}
          >
            <Typography
              variant="subtitle2"
              noWrap
              sx={{
                fontWeight: 700,
                lineHeight: 1.2,
                color: "text.primary",
              }}
            >
              {user?.username || "User"}
            </Typography>

            <Typography
              variant="caption"
              color="text.secondary"
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                lineHeight: 1.2,
              }}
            >
              
              Signed in
            </Typography>
          </Box>
        </Box> */}

        {isMobile && (
          <Avatar
            {...avatarInteractionProps}
            sx={{
              width: 38,
              height: 38,
              flexShrink: 0,
              bgcolor: "primary.main",
              fontFamily: '"DM Sans", sans-serif',
              fontSize: "0.875rem",
              fontWeight: 700,
              cursor: "pointer",
              userSelect: "none",
              outline: "none",

              "&:focus-visible": {
                boxShadow: `0 0 0 3px ${alpha(
                  theme.palette.primary.main,
                  0.25,
                )}`,
              },
            }}
          >
            {user?.username?.charAt(0)?.toUpperCase()}
          </Avatar>
        )}

        {/* Avatar logout popup */}
        <Popper
          open={avatarMenuOpen}
          anchorEl={avatarAnchor}
          placement="bottom-end"
          disablePortal={false}
          modifiers={[
            {
              name: "offset",
              options: {
                offset: [0, 10],
              },
            },
            {
              name: "preventOverflow",
              options: {
                padding: 8,
              },
            },
          ]}
          sx={{
            zIndex: theme.zIndex.tooltip + 1,
          }}
        >
          <Paper
            role="menu"
            elevation={0}
            onMouseEnter={handlePopupMouseEnter}
            onMouseLeave={handlePopupMouseLeave}
            sx={{
              position: "relative",
              minWidth: 150,
              p: 0.75,
              border: "1px solid",
              borderColor: "divider",
              borderRadius: 2,
              bgcolor: "background.paper",
              boxShadow: "0 10px 30px rgba(15, 23, 42, 0.14)",
              "&::before": {
                content: '""',
                position: "absolute",
                top: -5,
                right: 15,
                width: 10,
                height: 10,
                bgcolor: "background.paper",
                borderTop: "1px solid",
                borderLeft: "1px solid",
                borderColor: "divider",
                transform: "rotate(45deg)",
              },
            }}
          >
            <Box
              sx={{
                px: 1.5,
                py: 1,
                display: "flex",
                alignItems: "center",
                gap: 1,
              }}
            >
              <Typography variant="caption" color="text.secondary">
                Role:
              </Typography>

              <Typography variant="caption" fontWeight={700}>
                {role?.roleName || "User"}
              </Typography>
            </Box>
            <Button
              role="menuitem"
              fullWidth
              color="error"
              startIcon={<LogoutOutlinedIcon />}
              onClick={handleLogout}
              sx={{
                minHeight: 40,
                justifyContent: "flex-start",
                px: 1.5,
                borderRadius: 1.5,
                textTransform: "none",
              }}
            >
              Logout
            </Button>
          </Paper>
        </Popper>
      </Toolbar>
    </AppBar>
  );
}
