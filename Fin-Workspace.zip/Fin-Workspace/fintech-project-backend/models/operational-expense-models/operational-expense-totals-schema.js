import mongoose from "mongoose";

const operationalExpenseTotalsSchema = new mongoose.Schema(
  {
    totalDirectCost: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    totalIndirectCost: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    subtotal: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    markupAmount: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    // Legacy value is folded into totalIndirectCost during recalculation.
    directorRemunerationTotal: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    fixedCostTotal: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    miscellaneousExpenseTotal: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    operationalExpenseTotal: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    allocatedTotal: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    unallocatedBalance: {
      type: Number,
      required: true,
      default: 0,
    },
  },
  { _id: false },
);

export default operationalExpenseTotalsSchema;