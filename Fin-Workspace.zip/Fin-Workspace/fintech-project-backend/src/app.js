import dotenv from 'dotenv';
import path from 'path';

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import transactionRouter from './modules/petty-cash/routes/transaction-routes.js';
import cashInflowRouter from './modules/cash-inflow/routes/cash-inflow-routes.js';
import componentRouter from './modules/master-data/routes/component-routes.js';
import subComponentRouter from './modules/master-data/routes/subcomponent-routes.js';

import permissionRouter from './modules/auth/routes/permission-routes.js';
import roleRouter from './modules/auth/routes/role-routes.js';
import userRouter from './modules/auth/routes/user-routes.js';
import authRouter from './modules/auth/routes/auth-routes.js';
import fixedAssetRouter from './modules/master-data/routes/fixed-assets-routes.js';
import fixedAssetCategoryRouter from './modules/master-data/routes/fixed-assets-category-routes.js';
import taxRouter from './modules/master-data/routes/tax-routes.js';
import currencyRouter from './modules/master-data/routes/currency-routes.js';
import reportRouter from './modules/reports/routes/petty-cash-report-routes.js';
import router from './modules/migration/routes/migration-routes.js';
import senderAccountRouter from './modules/accounts/routes/sender-account-routes.js';
import pettyCashAccountRouter from './modules/accounts/routes/cash-account-routes.js';
import summaryRouter from './modules/petty-cash/routes/monthly-summary-routes.js';
import cashFlowRouter from './modules/cash-flow/routes/cash-flow-routes.js';
import clientRouter from './modules/clients/routes/client-routes.js';
import operationalExpenseRouter from './modules/operational-expense/routes/operational-expense-route.js';
import clientLocationRouter from './modules/clients/routes/client-location-routes.js';
import companyMasterRouter from './modules/master-data/routes/company-master-routes.js';

const app = express();

// Security Related Functions
app.disable('x-powered-by');
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(helmet());

// DB Connection Function

// Mount routes
app.use('/api/transactionRouter', transactionRouter);
app.use('/api/cashInflowRouter', cashInflowRouter);
app.use('/api/componentRouter', componentRouter);
app.use('/api/subComponentRouter', subComponentRouter);
app.use('/api/permissionRouter', permissionRouter);
app.use('/api/roleRouter', roleRouter);
app.use('/api/userRouter', userRouter);
app.use('/api/auth', authRouter);
app.use('/api/fixedAssetRouter', fixedAssetRouter);
app.use('/api/fixedAssetCategoryRouter', fixedAssetCategoryRouter);
app.use('/api/taxRouter', taxRouter);
app.use('/api/currencyRouter', currencyRouter);
app.use('/api/reportRouter', reportRouter);
app.use('/api/senderAccountRouter', senderAccountRouter);
app.use('/api/pettyCashAccountRouter', pettyCashAccountRouter);
app.use('/api/summaryRouter', summaryRouter);
app.use('/api/cashFlowRouter', cashFlowRouter);
app.use('/api/clientRouter', clientRouter);
app.use('/api/operationalExpenseRouter', operationalExpenseRouter);
app.use('/api/clientLocationRouter', clientLocationRouter);
app.use('/api/companyMasterRouter', companyMasterRouter);

// Migration route
app.use('/api/migration', router);

app.get('/', (req, res) => {
  res.json('Backend is Running');
});


export default app;
