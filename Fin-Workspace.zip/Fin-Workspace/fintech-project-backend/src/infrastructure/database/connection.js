import mongoose from 'mongoose'
import dns from 'node:dns'

export const connectDB = async () => {
  try {
    dns.setServers(['8.8.8.8', '1.1.1.1']);
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`DB connected successfully`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};