import mongoose from "mongoose";
import AuditLog from "./audit-log-model.js";
import User from "../../modules/auth/models/user-model.js";
import Role from "../../modules/auth/models/role-model.js";

export const createAuditLog = async ({
  req,
  action,
  entityType,
  entityId,
  changedFields = [],
  beforeData = null,
  afterData = null,
  reason = null,
}) => {
  const user = await User.findById(req.user?.userId).populate(
    "roleId",
    "roleName",
  );

  await AuditLog.create({
    eventAt: new Date(),

    actorUserId: req.user?.userId,

    actorType: "USER",

    actorRoleId: user?.roleId?._id || null,

    actorRole: user?.roleId?.roleName || null,

    action,

    entityType,

    entityId,

    changedFields,

    beforeData,

    afterData,

    reason,

    correlationId:
      req.correlationId || new mongoose.Types.ObjectId().toString(),

    result: "SUCCESS",

    ipAddress: req.ip,

    userAgent: req.headers["user-agent"],
  });
};
