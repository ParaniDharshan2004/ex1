import express from "express";

import {
  getMonthlySummary,
  getMonthlySummaryByMonth,
} from "../controllers/monthly-summary-controller.js";

import { authenticateUser } from "../../../shared/middleware/auth-middleware.js";
import { rebuildAllMonthlySummaries } from "../services/monthly-summary-service.js";

const summaryRouter = express.Router();

summaryRouter.get("/monthlySummary", authenticateUser, getMonthlySummary);
summaryRouter.get(
  "/monthlySummary/:month",
  authenticateUser,
  getMonthlySummaryByMonth,
);
summaryRouter.get("/rebuild-all-summaries", async (req, res) => {
  await rebuildAllMonthlySummaries();

  res.json({
    success: true,
    message: "All summaries rebuilt",
  });
});

export default summaryRouter;
