import PettyCash from "../models/pettycash-model.js";
import CashInflow from "../../cash-inflow/models/cash-inflow-model.js";
import MonthlyBalanceSummary from "../models/monthly-balance-summary-model.js";

export const rebuildMonthlySummary = async (month) => {
  try {
    const startDate = new Date(`${month}-01`);

    const endDate = new Date(startDate);

    endDate.setMonth(endDate.getMonth() + 1);

    endDate.setDate(0);

    const previousMonthDate = new Date(startDate);

    previousMonthDate.setMonth(previousMonthDate.getMonth() - 1);

    const previousMonth = previousMonthDate.toISOString().slice(0, 7);

    const previousSummary = await MonthlyBalanceSummary.findOne({
      month: previousMonth,
    });

    const openingBalance = previousSummary?.closingBalance || 0;

    const cashInflows = await CashInflow.aggregate([
      {
        $match: {
          inflowDate: {
            $gte: startDate,
            $lte: endDate,
          },
        },
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: "$amount",
          },
        },
      },
    ]);

    const expenses = await PettyCash.aggregate([
      {
        $match: {
          transactionDate: {
            $gte: startDate,
            $lte: endDate,
          },
          status: "POSTED",
        },
      },
      {
        $group: {
          _id: null,
          totalAmount: {
            $sum: "$amount",
          },
          transactionCount: {
            $sum: 1,
          },
        },
      },
    ]);

    const totalCashInflow = cashInflows[0]?.total || 0;

    const totalExpenseAndReimbursement = expenses[0]?.totalAmount || 0;

    const transactionCount = expenses[0]?.transactionCount || 0;

    const closingBalance =
      openingBalance + totalCashInflow - totalExpenseAndReimbursement;

    console.log("Summary Total:", totalExpenseAndReimbursement);

    await MonthlyBalanceSummary.findOneAndUpdate(
      {
        month,
      },
      {
        month,

        openingBalance,

        totalCashInflow,

        totalExpenseAndReimbursement,

        closingBalance,

        transactionCount,
      },
      {
        new: true,
        upsert: true,
      },
    );
  } catch (error) {
    console.error("Monthly Summary Error:", error);
  }
};

export const rebuildAllMonthlySummaries = async () => {
  try {
    await MonthlyBalanceSummary.deleteMany({});

    const months = await PettyCash.aggregate([
      {
        $project: {
          month: {
            $dateToString: {
              format: "%Y-%m",
              date: "$transactionDate",
            },
          },
        },
      },
      {
        $group: {
          _id: "$month",
        },
      },
      {
        $sort: {
          _id: 1,
        },
      },
    ]);

    for (const item of months) {
      await rebuildMonthlySummary(item._id);

      console.log(`Rebuilt ${item._id}`);
    }

    console.log("All monthly summaries rebuilt successfully");
  } catch (error) {
    console.error(error);
  }
};
