import PettyCash from "../models/pettycash-model.js";
import Component from "../../master-data/models/component-model.js";
import SubComponent from "../../master-data/models/subcomponent-model.js";
// Get Monthly Summary Service Controller
import { rebuildMonthlySummary } from "../services/monthly-summary-service.js";
import { createAuditLog } from "../../../infrastructure/logging/audit-service.js";

// Create New Transaction
export const createTransaction = async (req, res) => {
  try {
    const {
      cashAccountId,
      transactionType,
      transactionDate,
      componentId,
      subComponentId,
      description,
      amount,
      spentByUserId,
      reimbursedToUserId,
      billAvailable,
      balanceBefore,
      balanceAfter,
    } = req.body;

    const component = await Component.findById(componentId);

    if (!component) {
      return res.status(404).json({
        success: false,
        message: "Component not found",
      });
    }

    if (subComponentId) {
      const subComponent = await SubComponent.findById(subComponentId);

      if (!subComponent) {
        return res.status(404).json({
          success: false,
          message: "Sub Component not found",
        });
      }
    }

    const currentYear = new Date().getFullYear();

    const lastTransaction = await PettyCash.findOne({
      entryNo: new RegExp(`^PE-${currentYear}-`),
    })
      .sort({ entryNo: -1 })
      .select("entryNo");

    let nextNumber = 1;

    if (lastTransaction?.entryNo) {
      const currentNumber = Number(lastTransaction.entryNo.split("-")[2]);

      nextNumber = currentNumber + 1;
    }

    const entryNo = `PE-${currentYear}-${String(nextNumber).padStart(6, "0")}`;

    const pettyCash = await PettyCash.create({
      entryNo,
      cashAccountId,
      transactionType,
      transactionDate,
      componentId,
      subComponentId: subComponentId || null,
      description,
      amount,
      spentByUserId,
      reimbursedToUserId: reimbursedToUserId || null,
      billAvailable,
      balanceBefore,
      balanceAfter,

      enteredBy: req.user.userId,
      postedBy: req.user.userId,
      postedAt: new Date(),

      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    });

    const month = new Date(transactionDate).toISOString().slice(0, 7);

    await rebuildMonthlySummary(month);

    // Audit Log
    try {
      await createAuditLog({
        req,
        action: "CREATE",
        entityType: "petty_cash",
        entityId: pettyCash._id,
        changedFields: Object.keys(pettyCash.toObject()),
        beforeData: null,
        afterData: pettyCash.toObject(),
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    return res.status(201).json({
      success: true,
      data: pettyCash,
      message: "Transaction created successfully",
    });
  } catch (error) {
    console.log(error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get All Transactions
export const getAllTransactions = async (req, res) => {
  try {
    const transactions = await PettyCash.find()
      .populate("cashAccountId", "accountCode accountName")
      .populate("componentId", "componentCode componentName")
      .populate("subComponentId", "subComponentCode subComponentName")
      .populate("spentByUserId", "username")
      .populate("reimbursedToUserId", "username")
      .sort({
        transactionDate: -1,
      });

    return res.status(200).json({
      success: true,
      data: transactions,
      message: "Transactions retrieved successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getActivePettyCashComponents = async (req, res) => {
  try {
    const components = await Component.find({
      isPettyCash: true,
      isActive: true,
    })
      .select("componentCode componentName")
      .sort({
        componentName: 1,
      });

    return res.status(200).json({
      success: true,
      count: components.length,
      data: components,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get Single Transaction
export const getTransactionById = async (req, res) => {
  try {
    const transaction = await PettyCash.findById(req.params.id)
      .populate("cashAccountId", "accountCode accountName")
      .populate("componentId", "componentCode componentName")
      .populate("subComponentId", "subComponentCode subComponentName");

    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: "Transaction not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: transaction,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Unable to retrieve transaction",
    });
  }
};

// Update Transaction
export const updateTransaction = async (req, res) => {
  try {
    const oldTransaction = await PettyCash.findById(req.params.id);

    if (!oldTransaction) {
      return res.status(404).json({
        success: false,
        message: "Transaction not found",
      });
    }

    const transaction = await PettyCash.findByIdAndUpdate(
      req.params.id,
      {
        ...req.body,
        updatedBy: req.user.userId,
      },
      {
        new: true,
        runValidators: true,
      },
    );

    const month = new Date(transaction.transactionDate)
      .toISOString()
      .slice(0, 7);

    await rebuildMonthlySummary(month);

    await createAuditLog({
      req,
      action: "UPDATE",
      entityType: "petty_cash",
      entityId: transaction._id,
      changedFields: Object.keys(req.body),
      beforeData: oldTransaction.toObject(),
      afterData: transaction.toObject(),
    });

    return res.status(200).json({
      success: true,
      data: transaction,
      message: "Transaction updated successfully",
    });
  } catch (error) {
    console.error("Update Transaction Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to update transaction",
    });
  }
};

// Delete Transaction
export const deleteTransaction = async (req, res) => {
  try {
    const deletedTransaction = await PettyCash.findByIdAndDelete(req.params.id);

    if (!deletedTransaction) {
      return res.status(404).json({
        success: false,
        message: "Petty cash entry not found",
      });
    }

    const month = new Date(deletedTransaction.transactionDate)
      .toISOString()
      .slice(0, 7);
    await rebuildMonthlySummary(month);

    await createAuditLog({
      req,
      action: "REMOVE",
      entityType: "petty_cash",
      entityId: deletedTransaction._id,
      changedFields: ["deleted"],
      beforeData: deletedTransaction.toObject(),
      afterData: null,
    });

    return res.status(200).json({
      success: true,
      message: "Petty cash entry deleted successfully",
    });
  } catch (error) {
    console.error("Delete Transaction Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to delete petty cash entry",
    });
  }
};
