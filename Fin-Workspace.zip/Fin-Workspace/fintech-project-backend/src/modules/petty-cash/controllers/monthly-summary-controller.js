import MonthlyBalanceSummary from "../models/monthly-balance-summary-model.js";

export const getMonthlySummary = async (req, res) => {
  try {
    const data = await MonthlyBalanceSummary.find().sort({
      month: -1,
    });

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getMonthlySummaryByMonth = async (req, res) => {
  try {
    const { month } = req.params;

    const data = await MonthlyBalanceSummary.findOne({
      month,
    });

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
