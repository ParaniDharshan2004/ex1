import clientRouter from './routes/client-routes.js';
import clientLocationRouter from './routes/client-location-routes.js';

export { clientRouter, clientLocationRouter };
