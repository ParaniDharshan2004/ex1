import express from 'express';
import { authenticateUser } from '../../../shared/middleware/auth-middleware.js';
import {
  createClientLocation,
  deleteClientLocation,
  getClientLocationById,
  getClientLocationsByClient,
  updateClientLocation,
  updateClientLocationStatus,
} from '../controllers/client-location-controller.js';

const clientLocationRouter = express.Router();

clientLocationRouter.post(
  '/client-locations',
  authenticateUser,
  createClientLocation,
);
clientLocationRouter.get(
  '/client-locations/client/:clientId',
  authenticateUser,
  getClientLocationsByClient,
);
clientLocationRouter.get(
  '/client-locations/:locationId',
  authenticateUser,
  getClientLocationById,
);
clientLocationRouter.patch(
  '/client-locations/:locationId',
  authenticateUser,
  updateClientLocation,
);
clientLocationRouter.patch(
  '/client-locations/:locationId/status',
  authenticateUser,
  updateClientLocationStatus,
);
clientLocationRouter.delete(
  '/client-locations/:locationId',
  authenticateUser,
  deleteClientLocation,
);

export default clientLocationRouter;
