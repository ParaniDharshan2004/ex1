import mongoose from "mongoose";
import Client from "../models/client-model.js";
import { createAuditLog } from "../../../infrastructure/logging/audit-service.js";

const parseBoolean = (value, fallback = false) => {
  if (typeof value === "boolean") {
    return value;
  }

  if (typeof value === "string") {
    const normalizedValue = value.trim().toLowerCase();

    if (normalizedValue === "true") {
      return true;
    }

    if (normalizedValue === "false") {
      return false;
    }
  }

  if (value === 1) {
    return true;
  }

  if (value === 0) {
    return false;
  }

  return fallback;
};

const getAuthenticatedUserId = (req) => {
  return req.user?.userId || req.user?._id || req.user?.id || null;
};

const isCrkl = (client) =>
  String(client.clientName || '').trim().toUpperCase() === 'CRKL';

const ensureDefaultClientDisplayOrder = async () => {
  const clients = await Client.collection
    .find({})
    .sort({ createdAt: 1 })
    .toArray();
  if (!clients.length) return;

  const hasManualOrder = clients.some(
    (client) => Number(client.displayOrder) > 1,
  );
  if (hasManualOrder) return;

  const orderedClients = [
    ...clients.filter((client) => !isCrkl(client)),
    ...clients.filter((client) => isCrkl(client)),
  ];
  await Promise.all(
    orderedClients.map((client, index) =>
      Client.collection.updateOne(
        { _id: client._id },
        { $set: { displayOrder: index + 1 } },
      ),
    ),
  );
};

const generateNextClientCode = async () => {
  const lastClient = await Client.findOne({
    clientCode: /^CLT-\d{3}$/,
  })
    .sort({
      clientCode: -1,
    })
    .select("clientCode")
    .lean();

  let nextNumber = 1;

  if (lastClient?.clientCode) {
    nextNumber = Number(lastClient.clientCode.replace("CLT-", "")) + 1;
  }

  return `CLT-${String(nextNumber).padStart(3, "0")}`;
};

export const createClient = async (req, res) => {
  try {
    const userId = getAuthenticatedUserId(req);

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Authenticated user information is unavailable",
      });
    }

    const clientName = req.body.clientName?.trim();

    if (!clientName) {
      return res.status(400).json({
        success: false,
        message: "Client name is required",
      });
    }

    const existingClient = await Client.findOne({
      clientName: {
        $regex: `^${clientName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`,
        $options: "i",
      },
    }).lean();

    if (existingClient) {
      return res.status(409).json({
        success: false,
        message: "A Client with this name already exists",
      });
    }

    const clientCode = await generateNextClientCode();

    const client = await Client.create({
      clientCode,

      clientName,

      description: req.body.description?.trim() || "",

      displayOrder: Number(req.body.displayOrder) || 1,

      isActive:
        req.body.isActive !== undefined
          ? parseBoolean(req.body.isActive, true)
          : true,

      createdBy: userId,

      updatedBy: userId,
    });

    try {
      await createAuditLog({
        req,
        action: "CREATE",
        entityType: "client",
        entityId: client._id,
        changedFields: Object.keys(client.toObject()),
        beforeData: null,
        afterData: client.toObject(),
      });
    } catch (auditError) {
      console.error("Client Audit Log Error:", auditError);
    }

    return res.status(201).json({
      success: true,
      data: client,
      message: "Client created successfully",
    });
  } catch (error) {
    console.error("Create Client Error:", error);

    if (error?.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Client code or Client name already exists",
      });
    }

    if (error?.name === "ValidationError") {
      const message = Object.values(error.errors)
        .map((item) => item.message)
        .join(", ");

      return res.status(400).json({
        success: false,
        message,
      });
    }

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to create Client",
    });
  }
};

export const getAllClients = async (req, res) => {
  try {
    await ensureDefaultClientDisplayOrder();
    const clients = await Client.find()
      .populate('defaultCurrencyId')
      .populate({
        path: "createdBy",
        select: "_id username",
      })
      .populate({
        path: "updatedBy",
        select: "_id username",
      })
      .sort({
        displayOrder: 1,
      });

    return res.status(200).json({
      success: true,
      data: clients,
      message: "Clients retrieved successfully",
    });
  } catch (error) {
    console.error("Get Clients Error:", error);

    return res.status(400).json({
      success: false,
      message: "Unable to fetch Client details",
    });
  }
};

export const getActiveClients = async (req, res) => {
  try {
    await ensureDefaultClientDisplayOrder();
    const clients = await Client.find({
      isActive: true,
    })
      .select("_id clientCode clientName description displayOrder isActive")
      .sort({
        displayOrder: 1,
      })
      .lean();

    return res.status(200).json({
      success: true,
      data: clients,
      message: "Active Clients retrieved successfully",
    });
  } catch (error) {
    console.error("Get Active Clients Error:", error);

    return res.status(400).json({
      success: false,
      message: "Unable to fetch active Client details",
    });
  }
};

export const getClientById = async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Client ID",
      });
    }

    const client = await Client.findById(id)
      .populate({
        path: "createdBy",
        select: "_id username",
      })
      .populate({
        path: "updatedBy",
        select: "_id username",
      });

    if (!client) {
      return res.status(404).json({
        success: false,
        message: "Client not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: client,
      message: "Client retrieved successfully",
    });
  } catch (error) {
    console.error("Get Client Error:", error);

    return res.status(400).json({
      success: false,
      message: "Unable to fetch Client details",
    });
  }
};

export const updateClient = async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Client ID",
      });
    }

    const userId = getAuthenticatedUserId(req);

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Authenticated user information is unavailable",
      });
    }

    const oldClient = await Client.findById(id);

    if (!oldClient) {
      return res.status(404).json({
        success: false,
        message: "Client not found",
      });
    }

    const clientName =
      req.body.clientName !== undefined
        ? String(req.body.clientName).trim()
        : oldClient.clientName;

    if (!clientName) {
      return res.status(400).json({
        success: false,
        message: "Client name is required",
      });
    }

    const duplicateClient = await Client.findOne({
      _id: {
        $ne: id,
      },
      clientName: {
        $regex: `^${clientName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`,
        $options: "i",
      },
    }).lean();

    if (duplicateClient) {
      return res.status(409).json({
        success: false,
        message: "A Client with this name already exists",
      });
    }

    const updateData = {
      clientName,

      description:
        req.body.description !== undefined
          ? String(req.body.description || "").trim()
          : oldClient.description,

      displayOrder:
        req.body.displayOrder !== undefined
          ? Number(req.body.displayOrder)
          : oldClient.displayOrder,

      isActive:
        req.body.isActive !== undefined
          ? parseBoolean(req.body.isActive, oldClient.isActive)
          : oldClient.isActive,

      updatedBy: userId,
    };

    const client = await Client.findByIdAndUpdate(
      id,
      {
        $set: updateData,
      },
      {
        new: true,
        runValidators: true,
      },
    );

    try {
      await createAuditLog({
        req,
        action: "UPDATE",
        entityType: "client",
        entityId: client._id,
        changedFields: Object.keys(updateData),
        beforeData: oldClient.toObject(),
        afterData: client.toObject(),
      });
    } catch (auditError) {
      console.error("Client Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      data: client,
      message: "Client updated successfully",
    });
  } catch (error) {
    console.error("Update Client Error:", error);

    if (error?.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Client code or Client name already exists",
      });
    }

    if (error?.name === "ValidationError") {
      const message = Object.values(error.errors)
        .map((item) => item.message)
        .join(", ");

      return res.status(400).json({
        success: false,
        message,
      });
    }

    return res.status(400).json({
      success: false,
      message: error.message || "Unable to update Client",
    });
  }
};

export const deactivateClient = async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Client ID",
      });
    }

    const userId = getAuthenticatedUserId(req);

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Authenticated user information is unavailable",
      });
    }

    const oldClient = await Client.findById(id);

    if (!oldClient) {
      return res.status(404).json({
        success: false,
        message: "Client not found",
      });
    }

    const client = await Client.findByIdAndUpdate(
      id,
      {
        $set: {
          isActive: false,
          updatedBy: userId,
        },
      },
      {
        new: true,
        runValidators: true,
      },
    );

    try {
      await createAuditLog({
        req,
        action: "UPDATE",
        entityType: "client",
        entityId: client._id,
        changedFields: ["isActive"],
        beforeData: oldClient.toObject(),
        afterData: client.toObject(),
      });
    } catch (auditError) {
      console.error("Client Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      data: client,
      message: "Client deactivated successfully",
    });
  } catch (error) {
    console.error("Deactivate Client Error:", error);

    return res.status(400).json({
      success: false,
      message: error.message || "Unable to deactivate Client",
    });
  }
};

export const deleteClient = async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Client ID",
      });
    }

    const client = await Client.findByIdAndDelete(id);

    if (!client) {
      return res.status(404).json({
        success: false,
        message: "Client not found",
      });
    }

    try {
      await createAuditLog({
        req,
        action: "REMOVE",
        entityType: "client",
        entityId: client._id,
        changedFields: ["deleted"],
        beforeData: client.toObject(),
        afterData: null,
      });
    } catch (auditError) {
      console.error("Client Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      message: "Client deleted successfully",
    });
  } catch (error) {
    console.error("Delete Client Error:", error);

    return res.status(400).json({
      success: false,
      message: error.message || "Unable to delete Client",
    });
  }
};
