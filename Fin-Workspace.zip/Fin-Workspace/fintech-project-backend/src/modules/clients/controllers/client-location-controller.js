import mongoose from 'mongoose';
import Client from '../models/client-model.js';
import ClientLocation from '../models/client-location-model.js';
import CurrencyMaster from '../../master-data/models/currency-master-model.js';
import TaxMaster from '../../master-data/models/tax-master-model.js';
import OperationalExpenseInvoice from '../../operational-expense/models/operational-expense-invoice-model.js';
import OperationalExpenseInvoiceAllocation from '../../operational-expense/models/operational-expense-invoice-allocation-model.js';
import { createAuditLog } from '../../../infrastructure/logging/audit-service.js';

const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;
const editableFields = [
  'locationCode',
  'locationName',
  'gstNumber',
  'panNumber',
  'tanNumber',
  'billingAddress',
  'pinCode',
  'stateName',
  'taxIds',
  'currencyId',
];
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

const audit = async (req, action, location, beforeData, afterData) => {
  try {
    await createAuditLog({
      req,
      action,
      entityType: 'client_location',
      entityId: location._id,
      changedFields: editableFields,
      beforeData,
      afterData,
    });
  } catch (error) {
    console.error('Client details audit error:', error);
  }
};

const validateReferences = async ({ clientId, currencyId, taxIds }) => {
  if (clientId !== undefined) {
    if (!mongoose.Types.ObjectId.isValid(clientId)) {
      return 'Invalid client ID';
    }
    if (!(await Client.exists({ _id: clientId }))) {
      return 'Client not found';
    }
  }

  if (currencyId !== undefined && currencyId !== null) {
    if (
      !mongoose.Types.ObjectId.isValid(currencyId) ||
      !(await CurrencyMaster.exists({ _id: currencyId }))
    ) {
      return 'Currency is invalid';
    }
  }

  if (taxIds !== undefined) {
    if (
      !Array.isArray(taxIds) ||
      taxIds.some((taxId) => !mongoose.Types.ObjectId.isValid(taxId))
    ) {
      return 'Tax IDs must be an array of valid IDs';
    }
    const taxCount = await TaxMaster.countDocuments({ _id: { $in: taxIds } });
    if (taxCount !== new Set(taxIds.map(String)).size) {
      return 'One or more tax IDs are invalid';
    }
  }

  return null;
};

const populateDetails = (query) =>
  query
    .populate('clientId', 'clientCode clientName')
    .populate('taxIds')
    .populate('currencyId');

export const createClientLocation = async (req, res) => {
  try {
    const body = req.body || {};
    const userId = actor(req);
    const { clientId } = body;
    if (!userId) return fail(res, 400, 'User is required');

    const referenceError = await validateReferences({
      clientId,
      currencyId: body.currencyId,
      taxIds: body.taxIds,
    });
    if (referenceError) return fail(res, 400, referenceError);

    const data = Object.fromEntries(
      editableFields
        .filter((field) => body[field] !== undefined)
        .map((field) => [field, body[field]]),
    );
    const location = await ClientLocation.create({
      ...data,
      clientId,
      createdBy: userId,
      updatedBy: userId,
    });
    await audit(req, 'CREATE', location, null, location.toObject());

    return res.status(201).json({
      success: true,
      data: location,
      message: 'Client location created successfully',
    });
  } catch (error) {
    if (error.code === 11000) {
      return fail(res, 409, 'Location code already exists for this client');
    }
    if (error.name === 'ValidationError' || error.name === 'CastError') {
      return fail(res, 400, error.message);
    }
    console.error('Create Client Location Error:', error);
    return fail(res, 500, 'Unable to create client location');
  }
};

export const getClientLocationsByClient = async (req, res) => {
  try {
    const { clientId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(clientId)) {
      return fail(res, 400, 'Invalid client ID');
    }
    const locations = await populateDetails(
      ClientLocation.find({
        clientId,
        ...(req.query.includeInactive === 'true' ? {} : { isActive: true }),
      }).sort({ locationCode: 1 }),
    );

    return res.json({
      success: true,
      count: locations.length,
      data: locations,
      message: locations.length
        ? 'Client locations retrieved successfully'
        : 'No client locations found',
    });
  } catch (error) {
    console.error('Get Client Locations Error:', error);
    return fail(res, 500, 'Unable to fetch client locations');
  }
};

export const getClientLocationById = async (req, res) => {
  try {
    const { locationId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(locationId)) {
      return fail(res, 400, 'Invalid client location ID');
    }
    const location = await populateDetails(ClientLocation.findById(locationId));
    if (!location) return fail(res, 404, 'Client location not found');

    return res.json({
      success: true,
      data: location,
      message: 'Client location retrieved successfully',
    });
  } catch (error) {
    console.error('Get Client Location Error:', error);
    return fail(res, 500, 'Unable to fetch client location');
  }
};

export const updateClientLocation = async (req, res) => {
  try {
    const body = req.body || {};
    const userId = actor(req);
    const { locationId } = req.params;
    if (!userId || !mongoose.Types.ObjectId.isValid(locationId)) {
      return fail(res, 400, 'Valid user and client location ID are required');
    }

    const location = await ClientLocation.findById(locationId);
    if (!location) return fail(res, 404, 'Client location not found');

    const updateData = Object.fromEntries(
      editableFields
        .filter((field) => body[field] !== undefined)
        .map((field) => [field, body[field]]),
    );
    const referenceError = await validateReferences(updateData);
    if (referenceError) return fail(res, 400, referenceError);

    const beforeData = location.toObject();
    Object.assign(location, updateData, { updatedBy: userId });
    await location.save();
    await audit(req, 'UPDATE', location, beforeData, location.toObject());

    return res.json({
      success: true,
      data: location,
      message: 'Client location updated successfully',
    });
  } catch (error) {
    if (error.code === 11000) {
      return fail(res, 409, 'Location code already exists for this client');
    }
    if (error.name === 'ValidationError' || error.name === 'CastError') {
      return fail(res, 400, error.message);
    }
    console.error('Update Client Location Error:', error);
    return fail(res, 500, 'Unable to update client location');
  }
};

export const updateClientLocationStatus = async (req, res) => {
  try {
    const body = req.body || {};
    const userId = actor(req);
    const { locationId } = req.params;
    if (
      !userId ||
      !mongoose.Types.ObjectId.isValid(locationId) ||
      typeof body.isActive !== 'boolean'
    ) {
      return fail(
        res,
        400,
        'Valid client location ID and boolean isActive are required',
      );
    }

    const location = await ClientLocation.findById(locationId);
    if (!location) return fail(res, 404, 'Client location not found');
    const beforeData = location.toObject();
    location.isActive = body.isActive;
    location.updatedBy = userId;
    await location.save();
    await audit(req, 'UPDATE', location, beforeData, location.toObject());

    return res.json({
      success: true,
      data: location,
      message: 'Client location status updated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError') {
      return fail(res, 400, error.message);
    }
    console.error('Update Client Location Status Error:', error);
    return fail(res, 500, 'Unable to update client location status');
  }
};

export const deleteClientLocation = async (req, res) => {
  try {
    const { locationId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(locationId)) {
      return fail(res, 400, 'Invalid client location ID');
    }
    const location = await ClientLocation.findById(locationId);
    if (!location) return fail(res, 404, 'Client location not found');

    const [invoiceExists, allocationExists] = await Promise.all([
      OperationalExpenseInvoice.exists({ locationId }),
      OperationalExpenseInvoiceAllocation.exists({
        'locationAllocations.locationId': locationId,
      }),
    ]);
    if (invoiceExists || allocationExists) {
      return fail(
        res,
        409,
        'Client location cannot be deleted while referenced by invoices or allocations',
      );
    }

    await audit(req, 'REMOVE', location, location.toObject(), null);
    await location.deleteOne();
    return res.json({
      success: true,
      message: 'Client location deleted successfully',
    });
  } catch (error) {
    console.error('Delete Client Location Error:', error);
    return fail(res, 500, 'Unable to delete client location');
  }
};
