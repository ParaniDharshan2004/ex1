import mongoose from "mongoose";
import OperationalExpenseReport from "../models/operational-expense-report-model.js";
import { createAuditLog } from "../../../infrastructure/logging/audit-service.js";
import { recalculateOperationalExpenseTotals } from "../services/operational-expense-calculation-service.js";

const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

const loadDraftReport = async (id, res) => {
  if (!isValidId(id)) {
    res.status(400).json({
      success: false,
      message: "Invalid Operational Expense report ID",
    });
    return null;
  }

  const report = await OperationalExpenseReport.findById(id);
  if (!report) {
    res.status(404).json({
      success: false,
      message: "Operational Expense report not found",
    });
    return null;
  }
  if (report.status === "INVOICE_GENERATED") {
    res.status(409).json({
      success: false,
      message: "Fixed costs cannot be changed after invoices are generated",
    });
    return null;
  }
  return report;
};

const saveAudit = async (req, report, action, beforeData = null) => {
  try {
    await createAuditLog({
      req,
      action,
      entityType: "operational_expense_fixed_cost",
      entityId: report._id,
      changedFields: ["fixedAssets", "totals"],
      beforeData,
      afterData: action === "REMOVE" ? null : report.toObject(),
    });
  } catch (error) {
    console.error("Operational Expense Fixed Cost Audit Log Error:", error);
  }
};

const validateFixedCostFields = ({ itemName, amount }) => {
  if (itemName !== undefined && !String(itemName).trim()) {
    return "Fixed Cost item name is required";
  }
  if (
    amount !== undefined &&
    (!Number.isFinite(Number(amount)) || Number(amount) < 0)
  ) {
    return "Fixed Cost amount must be a non-negative number";
  }
  return null;
};

export const addOperationalExpenseFixedCost = async (req, res) => {
  try {
    const { itemName, description = "", amount } = req.body;
    const validationError = validateFixedCostFields({ itemName, amount });
    if (!itemName || validationError) {
      return res.status(400).json({
        success: false,
        message: validationError || "Fixed Cost item name is required",
      });
    }

    const report = await loadDraftReport(req.params.reportId, res);
    if (!report) return;

    report.fixedAssets.push({
      itemName: String(itemName).trim(),
      description: String(description || "").trim(),
      amount: Number(amount ?? 0),
      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    });
    report.updatedBy = req.user.userId;
    recalculateOperationalExpenseTotals(report);
    await report.save();
    await saveAudit(req, report, "CREATE");

    return res.status(201).json({
      success: true,
      data: report.fixedAssets[report.fixedAssets.length - 1],
      message: "Fixed Cost added successfully",
    });
  } catch (error) {
    if (error.name === "ValidationError" || error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error("Add Operational Expense Fixed Cost Error:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to add Fixed Cost",
    });
  }
};

export const updateOperationalExpenseFixedCost = async (req, res) => {
  try {
    const { itemName, description, amount } = req.body;
    const validationError = validateFixedCostFields({ itemName, amount });
    if (validationError) {
      return res.status(400).json({
        success: false,
        message: validationError,
      });
    }
    if (description !== undefined && typeof description !== "string") {
      return res.status(400).json({
        success: false,
        message: "Fixed Cost description must be a string",
      });
    }

    const report = await loadDraftReport(req.params.reportId, res);
    if (!report) return;
    if (!isValidId(req.params.fixedCostId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Fixed Cost ID",
      });
    }
    const fixedCost = report.fixedAssets.id(req.params.fixedCostId);
    if (!fixedCost) {
      return res.status(404).json({
        success: false,
        message: "Fixed Cost not found",
      });
    }

    const beforeData = report.toObject();
    if (itemName !== undefined) fixedCost.itemName = String(itemName).trim();
    if (description !== undefined) fixedCost.description = description.trim();
    if (amount !== undefined) fixedCost.amount = Number(amount);
    fixedCost.updatedBy = req.user.userId;
    report.updatedBy = req.user.userId;
    recalculateOperationalExpenseTotals(report);
    await report.save();
    await saveAudit(req, report, "UPDATE", beforeData);

    return res.status(200).json({
      success: true,
      data: fixedCost,
      message: "Fixed Cost updated successfully",
    });
  } catch (error) {
    if (error.name === "ValidationError" || error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error("Update Operational Expense Fixed Cost Error:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to update Fixed Cost",
    });
  }
};

export const deleteOperationalExpenseFixedCost = async (req, res) => {
  try {
    const report = await loadDraftReport(req.params.reportId, res);
    if (!report) return;
    if (!isValidId(req.params.fixedCostId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Fixed Cost ID",
      });
    }
    const fixedCost = report.fixedAssets.id(req.params.fixedCostId);
    if (!fixedCost) {
      return res.status(404).json({
        success: false,
        message: "Fixed Cost not found",
      });
    }

    const beforeData = report.toObject();
    fixedCost.deleteOne();
    report.updatedBy = req.user.userId;
    recalculateOperationalExpenseTotals(report);
    await report.save();
    await saveAudit(req, report, "REMOVE", beforeData);

    return res.status(200).json({
      success: true,
      message: "Fixed Cost deleted successfully",
    });
  } catch (error) {
    console.error("Delete Operational Expense Fixed Cost Error:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to delete Fixed Cost",
    });
  }
};