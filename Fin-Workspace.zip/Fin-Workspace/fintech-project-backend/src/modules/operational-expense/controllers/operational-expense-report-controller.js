import mongoose from 'mongoose';
import Component from '../../master-data/models/component-model.js';
import SubComponent from '../../master-data/models/subcomponent-model.js';
import FixedAssetMaster from '../../master-data/models/fixed-assets-model.js';
import FixedAssetCategoryMaster from '../../master-data/models/fixed-assets-category-model.js';
import OperationalExpenseReport from '../models/operational-expense-report-model.js';
import OperationalExpenseInvoiceAllocation from '../models/operational-expense-invoice-allocation-model.js';
import Invoice from '../models/operational-expense-invoice-model.js';
import { createAuditLog } from '../../../infrastructure/logging/audit-service.js';
import {
  getOperationalExpenseCategoryTotals,
  recalculateOperationalExpenseTotals,
} from '../services/operational-expense-calculation-service.js';
import {
  matchOperationalExpenseTallyRows,
  OperationalExpenseInputError,
} from '../services/operational-expense-matching-service.js';
import { isValidOperationalExpenseReportTransition } from '../services/operational-expense-report-status-service.js';

const reportMonthPattern = /^\d{4}-(0[1-9]|1[0-2])$/;
const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);
const normalizeLedgerName = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');

const fixedAssetContainsLedger = (fixedAssets, ledgerName) => {
  const normalizedLedger = normalizeLedgerName(ledgerName);
  if (!normalizedLedger) return false;

  return fixedAssets.some((asset) => {
    const values = [
      asset.itemName,
      asset.assetName,
      asset.parentCategory,
      asset.fixedAssetCategory,
      asset.componentName,
      asset.description,
    ];
    return values.some((value) => {
      const normalizedValue = normalizeLedgerName(value);
      return (
        normalizedValue === normalizedLedger ||
        normalizedValue.includes(normalizedLedger)
      );
    });
  });
};

const recordAudit = async (
  req,
  action,
  report,
  beforeData = null,
  changedFields = null,
) => {
  try {
    await createAuditLog({
      req,
      action,
      entityType: 'operational_expense_report',
      entityId: report._id,
      changedFields:
        changedFields ||
        (beforeData ? ['report'] : Object.keys(report.toObject())),
      beforeData,
      afterData: action === 'REMOVE' ? null : report.toObject(),
    });
  } catch (error) {
    console.error('Operational Expense Audit Log Error:', error);
  }
};

export const generateOperationalExpenseReport = async (req, res) => {
  try {
    const {
      reportMonth,
      reportName,
      reportCode,
      reportDate,
      sourceType = 'TALLY_IMPORT',
      sourceFileName = '',
      tallyRows = [],
      fixedAssets = [],
      markup = {},
      totals = {},
    } = req.body;

    if (!reportMonthPattern.test(String(reportMonth || ''))) {
      return res.status(400).json({
        success: false,
        message: 'Report month must use YYYY-MM format',
      });
    }
    if (!Array.isArray(tallyRows)) {
      return res.status(400).json({
        success: false,
        message: 'Tally rows must be an array',
      });
    }
    if (!Array.isArray(fixedAssets)) {
      return res.status(400).json({
        success: false,
        message: 'Fixed assets must be an array',
      });
    }
    if (!['TALLY_IMPORT', 'MANUAL'].includes(sourceType)) {
      return res.status(400).json({
        success: false,
        message: 'Source type must be TALLY_IMPORT or MANUAL',
      });
    }
    const existing = await OperationalExpenseReport.exists({ reportMonth });
    if (existing) {
      return res.status(409).json({
        success: false,
        message: `An Operational Expense report already exists for ${reportMonth}`,
      });
    }

    const components = await Component.find({
      isOperationalExpense: true,
      isActive: true,
    })
      .populate('financialCategoryId', 'categoryCode categoryName displayOrder')
      .sort({ displayOrder: 1, componentName: 1 })
      .lean();

    const subComponents = await SubComponent.find({
      componentId: { $in: components.map((component) => component._id) },
      isOperationalExpense: true,
      isActive: true,
    }).lean();
    const { componentAmounts, unmatchedTallyRows: unmatchedComponentRows } =
      matchOperationalExpenseTallyRows({
        tallyRows: tallyRows.map((row) => ({
          ...row,
          tallyLedgerName: row.tallyLedgerName || row.particularName,
        })),
        components,
        subComponents,
      });

    const [fixedAssetMasters, fixedAssetCategories] = await Promise.all([
      FixedAssetMaster.find({ isActive: true })
        .populate('categoryId', 'categoryName')
        .lean(),
      FixedAssetCategoryMaster.find({ isActive: true })
        .select('_id categoryName description')
        .lean(),
    ]);
    if (
      components.length === 0 &&
      fixedAssetMasters.length === 0 &&
      fixedAssetCategories.length === 0
    ) {
      return res.status(404).json({
        success: false,
        message:
          'No active Operational Expense components or fixed assets found',
      });
    }

    const assetLookup = new Map();
    for (const asset of fixedAssetMasters) {
      for (const name of [asset.assetName, ...(asset.aliases || [])]) {
        const normalizedName = normalizeLedgerName(name);
        if (normalizedName && !assetLookup.has(normalizedName)) {
          assetLookup.set(normalizedName, asset);
        }
      }
    }
    const categoryLookup = new Map(
      fixedAssetCategories
        .map((category) => [
          normalizeLedgerName(category.categoryName),
          category,
        ])
        .filter(([normalizedName]) => normalizedName),
    );

    const identifiedFixedCosts = [];
    const unmatchedTallyRows = [];
    for (const unmatchedRow of unmatchedComponentRows) {
      const ledgerName = normalizeLedgerName(unmatchedRow.tallyLedgerName);
      const matchedAsset = assetLookup.get(ledgerName);

      if (matchedAsset) {
        const categoryName = matchedAsset.categoryId?.categoryName || '';
        identifiedFixedCosts.push({
          itemName: matchedAsset.assetName,
          description: [
            categoryName ? `Category: ${categoryName}` : '',
            `Tally ledger: ${unmatchedRow.tallyLedgerName}`,
          ]
            .filter(Boolean)
            .join(' | '),
          amount: unmatchedRow.amount,
        });
        continue;
      }

      const matchedCategory = categoryLookup.get(ledgerName);
      if (matchedCategory) {
        identifiedFixedCosts.push({
          itemName: matchedCategory.categoryName,
          description:
            `Category-level fixed asset expense; not split across individual assets. ` +
            `Tally ledger: ${unmatchedRow.tallyLedgerName}`,
          amount: unmatchedRow.amount,
        });
        continue;
      }

      // A ledger already represented in submitted Fixed Cost data must not be
      // persisted again as an unmatched row.
      if (fixedAssetContainsLedger(fixedAssets, unmatchedRow.tallyLedgerName)) {
        continue;
      }

      unmatchedTallyRows.push(unmatchedRow);
    }

    const rows = components
      .map((component, index) => {
        const matched = componentAmounts.get(String(component._id)) || {
          directAmounts: [],
          subComponentAmounts: [],
        };

        const directTotal = matched.directAmounts.reduce(
          (sum, ledger) => sum + (Number(ledger.amount) || 0),
          0,
        );

        const subComponentTotal = matched.subComponentAmounts.reduce(
          (sum, ledger) => sum + (Number(ledger.amount) || 0),
          0,
        );

        const hasDirectMatch = matched.directAmounts.length > 0;

        const hasSubComponentMatch = matched.subComponentAmounts.length > 0;

        const amount = hasDirectMatch ? directTotal : subComponentTotal;

        const matchStatus = hasDirectMatch
          ? 'HEAD_COMPONENT_MATCHED'
          : hasSubComponentMatch
            ? 'CALCULATED_FROM_SUBCOMPONENTS'
            : 'NOT_PRESENT_IN_TALLY';

        return {
          componentId: component._id,
          componentCode: component.componentCode || '',
          componentName: component.componentName,

          rowSource: 'TALLY_IMPORT',

          financialCategoryId: component.financialCategoryId?._id || null,

          financialCategoryCode:
            component.financialCategoryId?.categoryCode || '',

          financialCategoryName:
            component.financialCategoryId?.categoryName || '',

          sourceAmount: amount,
          amount,

          matchStatus,

          hasTallyExpense: hasDirectMatch || hasSubComponentMatch,

          matchedTallyLedgers: [
            ...matched.directAmounts,
            ...matched.subComponentAmounts,
          ],

          isManuallyAdded: false,
          isEdited: false,

          displayOrder: component.displayOrder ?? index + 1,
        };
      })
      .filter(
        (row) =>
          row.matchStatus !== 'NOT_PRESENT_IN_TALLY' && row.hasTallyExpense,
      );

    const { totalDirectCost, totalIndirectCost } =
      getOperationalExpenseCategoryTotals(rows);

    const startingTotals = {
      totalDirectCost,
      totalIndirectCost,
      subtotal: 0,
      markupAmount: 0,
      directorRemunerationTotal: 0,
      fixedCostTotal: 0,
      operationalExpenseTotal: 0,
      allocatedTotal: 0,
      unallocatedBalance: 0,
    };
    const date = reportDate
      ? new Date(reportDate)
      : new Date(`${reportMonth}-01T00:00:00.000Z`);
    if (Number.isNaN(date.getTime())) {
      return res.status(400).json({
        success: false,
        message: 'Report date is invalid',
      });
    }

    const report = new OperationalExpenseReport({
      reportCode: reportCode || `OE-${reportMonth}`,
      reportName: reportName || `Operational Expense Report ${reportMonth}`,
      reportMonth,
      reportDate: date,
      sourceType,
      sourceFileName,
      rows,
      unmatchedTallyRows,
      fixedAssets: [...fixedAssets, ...identifiedFixedCosts],
      markup,
      totals: startingTotals,
      status: 'REVIEW_PENDING',
      generatedBy: req.user.userId,
      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    });

    recalculateOperationalExpenseTotals(report);
    await report.save();
    await recordAudit(req, 'CREATE', report);

    return res.status(201).json({
      success: true,
      data: report,
      message: 'Operational Expense report generated successfully',
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message:
          'An Operational Expense report already exists for this month or code',
      });
    }
    if (
      error.name === 'ValidationError' ||
      error instanceof OperationalExpenseInputError
    ) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error('Generate Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to generate Operational Expense report',
    });
  }
};

export const getAllOperationalExpenseReports = async (req, res) => {
  try {
    const filter = {};
    if (req.query.reportMonth) {
      if (!reportMonthPattern.test(String(req.query.reportMonth))) {
        return res.status(400).json({
          success: false,
          message: 'Report month must use YYYY-MM format',
        });
      }
      filter.reportMonth = req.query.reportMonth;
    }
    if (req.query.status) filter.status = req.query.status;

    const reports = await OperationalExpenseReport.find(filter)
      .sort({ reportMonth: -1 })
      .lean();

    return res.status(200).json({
      success: true,
      data: reports,
      message: 'Operational Expense reports retrieved successfully',
    });
  } catch (error) {
    console.error('Get Operational Expense Reports Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to retrieve Operational Expense reports',
    });
  }
};

export const getOperationalExpenseReportById = async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }

    const report = await OperationalExpenseReport.findById(req.params.id)
      .populate('rows.componentId', 'componentName componentCode displayOrder')
      .lean();
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: report,
      message: 'Operational Expense report retrieved successfully',
    });
  } catch (error) {
    console.error('Get Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to retrieve Operational Expense report',
    });
  }
};

export const updateOperationalExpenseReport = async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }

    const report = await OperationalExpenseReport.findById(req.params.id);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }
    if (report.status === 'INVOICE_GENERATED') {
      return res.status(409).json({
        success: false,
        message: 'Reports cannot be updated after invoices are generated',
      });
    }

    const beforeData = report.toObject();
    const allowedFields = [
      'reportName',
      'reportDate',
      'rows',
      'unmatchedTallyRows',
      'fixedAssets',
      'markup',
      'totals',
    ];
    for (const field of allowedFields) {
      if (Object.hasOwn(req.body, field)) report[field] = req.body[field];
    }
    for (const row of report.unmatchedTallyRows || []) {
      if (row.resolutionStatus === 'ADDED_TO_REPORT' && !row.resolvedBy) {
        row.resolvedBy = req.user.userId;
        row.resolvedAt = row.resolvedAt || new Date();
      }
    }
    report.updatedBy = req.user.userId;
    recalculateOperationalExpenseTotals(report);
    await report.save();
    await recordAudit(req, 'UPDATE', report, beforeData);

    return res.status(200).json({
      success: true,
      data: report,
      message: 'Operational Expense report updated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError') {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error('Update Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to update Operational Expense report',
    });
  }
};

export const updateOperationalExpenseReportStatus = async (req, res) => {
  try {
    const reportId = req.params.reportId || req.params.id;
    if (!isValidId(reportId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }
    const { status } = req.body || {};

    const report = await OperationalExpenseReport.findById(reportId);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }
    if (!isValidOperationalExpenseReportTransition(report.status, status)) {
      return res.status(400).json({
        success: false,
        message:
          'Invalid report status transition. Allowed transitions are REVIEW_PENDING to ALLOCATION_PENDING and ALLOCATION_PENDING to INVOICE_GENERATED.',
      });
    }

    const beforeData = report.toObject();
    report.status = status;
    report.updatedBy = req.user.userId;
    await report.save();
    await recordAudit(req, 'UPDATE', report, beforeData, ['status']);

    return res.status(200).json({
      success: true,
      data: { reportId: report._id, status: report.status },
      message: 'Operational Expense report status updated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error('Update Operational Expense Report Status Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to update Operational Expense report status',
    });
  }
};

export const deleteOperationalExpenseReport = async (req, res) => {
  let session;
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }

    session = await mongoose.startSession();
    let report;
    let deletedAllocationCount = 0;
    let result;

    await session.withTransaction(async () => {
      report = await OperationalExpenseReport.findById(req.params.id).session(
        session,
      );
      if (!report) {
        result = {
          status: 404,
          message: 'Operational Expense report not found',
        };
        return;
      }
      if (report.status === 'INVOICE_GENERATED') {
        result = {
          status: 409,
          message: 'Reports cannot be deleted after invoices are generated',
        };
        return;
      }

      const allocations = await OperationalExpenseInvoiceAllocation.deleteMany(
        { operationalExpenseReportId: report._id },
        { session },
      );
      deletedAllocationCount = allocations.deletedCount;
      await report.deleteOne({ session });
    });

    if (result) {
      return res.status(result.status).json({
        success: false,
        message: result.message,
      });
    }
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }

    await recordAudit(req, 'REMOVE', report);

    return res.status(200).json({
      success: true,
      message: 'Operational Expense report deleted successfully',
      data: { reportId: report._id, deletedAllocationCount },
    });
  } catch (error) {
    console.error('Delete Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to delete Operational Expense report',
    });
  } finally {
    if (session) await session.endSession();
  }
};

export const restartOperationalExpenseReport = async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }

    const report = await OperationalExpenseReport.findById(req.params.id);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }
    if (!['REVIEW_PENDING', 'ALLOCATION_PENDING'].includes(report.status)) {
      return res.status(409).json({
        success: false,
        message: 'Only reports pending review or allocation can be restarted',
      });
    }

    const hasInvoices = await Invoice.exists({
      operationalExpenseReportId: report._id,
    });
    if (hasInvoices) {
      return res.status(409).json({
        success: false,
        message: 'Reports with generated invoices cannot be restarted',
      });
    }

    await OperationalExpenseInvoiceAllocation.deleteMany({
      operationalExpenseReportId: report._id,
    });
    await recordAudit(req, 'REMOVE', report);
    await report.deleteOne();

    return res.status(200).json({
      success: true,
      message: 'Operational Expense report restarted successfully',
      data: { reportId: report._id },
    });
  } catch (error) {
    console.error('Restart Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to restart Operational Expense report',
    });
  }
};
