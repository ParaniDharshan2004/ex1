import operationalExpenseRouter from './routes/operational-expense-route.js';

export { operationalExpenseRouter };
