import companyMasterRouter from './routes/company-master-routes.js';
import componentRouter from './routes/component-routes.js';
import subComponentRouter from './routes/subcomponent-routes.js';
import currencyRouter from './routes/currency-routes.js';
import taxRouter from './routes/tax-routes.js';
import fixedAssetRouter from './routes/fixed-assets-routes.js';
import fixedAssetCategoryRouter from './routes/fixed-assets-category-routes.js';

export {
  companyMasterRouter,
  componentRouter,
  subComponentRouter,
  currencyRouter,
  taxRouter,
  fixedAssetRouter,
  fixedAssetCategoryRouter,
};
