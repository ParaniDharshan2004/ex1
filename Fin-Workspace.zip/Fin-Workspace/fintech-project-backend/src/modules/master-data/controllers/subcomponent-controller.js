import SubComponent from "../models/subcomponent-model.js";
import { createAuditLog } from "../../../infrastructure/logging/audit-service.js";

export const createSubcomponent = async (req, res) => {
  try {
    // Get latest sub component
    const lastSubComponent = await SubComponent.findOne().sort({
      createdAt: -1,
    });

    let nextNumber = 1;

    if (lastSubComponent?.subComponentCode) {
      const currentNumber = parseInt(
        lastSubComponent.subComponentCode.replace("SUB-", ""),
        10,
      );

      nextNumber = currentNumber + 1;
    }

    const subComponentCode = `SUB-${String(nextNumber).padStart(3, "0")}`;

    const subComponent = await SubComponent.create({
      ...req.body,
      subComponentCode,
    });

    try {
      await createAuditLog({
        req,
        action: "CREATE",
        entityType: "sub_component",
        entityId: subComponent._id,
        changedFields: Object.keys(subComponent.toObject()),
        beforeData: null,
        afterData: subComponent.toObject(),
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    res.status(201).json({
      success: true,
      data: subComponent,
      message: "Subcomponent created successfully",
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to create subcomponent. Please try again.",
    });
  }
};

export const getAllSubcomponents = async (req, res) => {
  try {
    const subComponents = await SubComponent.find().populate(
      "componentId",
      "componentName componentCode",
    );

    res.status(200).json({
      success: true,
      data: subComponents,
      message: "Subcomponents retrieved successfully",
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to fetch the subcomponent details",
    });
  }
};

export const getSubComponentsByComponent = async (req, res) => {
  try {
    const { componentId } = req.params;

    const subComponents = await SubComponent.find({
      componentId,
      isActive: true,
    }).sort({
      subComponentName: 1,
    });

    return res.status(200).json({
      success: true,
      count: subComponents.length,
      data: subComponents,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateSubcomponent = async (req, res) => {
  try {
    console.log(req);
    const oldSubComponent = await SubComponent.findById(req.params.id);

    if (!oldSubComponent) {
      return res.status(404).json({
        success: false,
        message: "Subcomponent not found",
      });
    }

    const subComponent = await SubComponent.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      },
    );
    if (!subComponent) {
      return res
        .status(404)
        .json({ success: false, message: "Subcomponent not found" });
    }

    try {
      await createAuditLog({
        req,
        action: "UPDATE",
        entityType: "sub_component",
        entityId: subComponent._id,
        changedFields: Object.keys(req.body),
        beforeData: oldSubComponent.toObject(),
        afterData: subComponent.toObject(),
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }
    res.status(200).json({
      success: true,
      data: subComponent,
      message: "Subcomponent updated successfully",
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to update subcomponent. Please try again.",
    });
  }
};

export const deleteSubcomponent = async (req, res) => {
  try {
    const subComponent = await SubComponent.findByIdAndDelete(req.params.id);
    if (!subComponent) {
      return res
        .status(404)
        .json({ success: false, message: "Subcomponent not found" });
    }
    try {
      await createAuditLog({
        req,
        action: "REMOVE",
        entityType: "sub_component",
        entityId: subComponent._id,
        changedFields: ["deleted"],
        beforeData: subComponent.toObject(),
        afterData: null,
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }
    res
      .status(200)
      .json({ success: true, message: "Subcomponent deleted successfully" });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to delete subcomponent. Please try again.",
    });
  }
};

// import mongoose from "mongoose";

// import SubComponent from "../../models/pettycash-models/subcomponent.js";
// import Component from "../../models/pettycash-models/component-model.js";
// import PettyCash from "../../petty-cash/models/pettycash-model.js";
// import AuditLog from "../../models/auditLog.js";

// const ENTITY_TYPE = "subComponents";
// const COUNTER_KEY = "SUBCOMPONENT_CODE";
// const MAX_PAGE_SIZE = 100;

// const CREATE_FIELDS = [
//   "componentId",
//   "subComponentName",
//   "displayOrder",
//   "isPettyCash",
//   "isCashFlowAnalysis",
//   "isOperationalExpense",
//   "isFullyLoadedCost",
//   "requiresBill",
// ];

// const UPDATE_FIELDS = [
//   "subComponentName",
//   "isPettyCash",
//   "isCashFlowAnalysis",
//   "isOperationalExpense",
//   "isFullyLoadedCost",
//   "billRequirementOverride",
//   "displayOrder",
// ];

// const BOOLEAN_FILTER_FIELDS = [
//   "isActive",
//   "isPettyCash",
//   "isCashFlowAnalysis",
//   "isOperationalExpense",
//   "isFullyLoadedCost",
// ];

// const ALLOWED_SORT_FIELDS = [
//   "subcomponentCode",
//   "subComponentName",
//   "displayOrder",
//   "createdAt",
//   "updatedAt",
// ];

// const BILL_OVERRIDE_VALUES = [
//   "INHERIT",
//   "OPTIONAL",
//   "MANDATORY",
//   "NOT_ALLOWED",
// ];

// const getUserId = (req) => req.user?.userId || req.user?.id;
// const isValidObjectId = (value) => mongoose.Types.ObjectId.isValid(value);

// const pickFields = (source = {}, allowed = []) =>
//   allowed.reduce((result, field) => {
//     if (Object.prototype.hasOwnProperty.call(source, field))
//       result[field] = source[field];
//     return result;
//   }, {});

// const escapeRegex = (value = "") =>
//   value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// const parseBoolean = (value) => {
//   if (value === true || value === "true") return true;
//   if (value === false || value === "false") return false;
//   return undefined;
// };

// const validatePayload = (payload, { creating = false } = {}) => {
//   const errors = [];

//   if (creating && !payload.componentId) errors.push("componentId is required.");
//   if (payload.componentId && !isValidObjectId(payload.componentId)) {
//     errors.push("componentId must be a valid ObjectId.");
//   }

//   if (creating && !payload.subComponentName) {
//     errors.push("subComponentName is required.");
//   }
//   if (payload.subComponentName !== undefined) {
//     const name = payload.subComponentName;
//     if (!name) errors.push("subComponentName cannot be empty.");
//     if (name.length > 150)
//       errors.push("subComponentName cannot exceed 150 characters.");
//   }

//   for (const field of BOOLEAN_FILTER_FIELDS.filter((x) => x !== "isActive")) {
//     if (payload[field] !== undefined && typeof payload[field] !== "boolean") {
//       errors.push(`${field} must be Boolean.`);
//     }
//   }

//   if (
//     payload.billRequirementOverride !== undefined &&
//     !BILL_OVERRIDE_VALUES.includes(payload.billRequirementOverride)
//   ) {
//     errors.push(
//       `billRequirementOverride must be one of: ${BILL_OVERRIDE_VALUES.join(", ")}.`,
//     );
//   }

//   if (payload.displayOrder !== undefined) {
//     const order = Number(payload.displayOrder);
//     if (!Number.isInteger(order) || order < 1) {
//       errors.push("displayOrder must be a positive integer.");
//     }
//   }

//   return errors;
// };

// const getActiveComponent = async (componentId, session = null) => {
//   if (!isValidObjectId(componentId)) return null;
//   let query = Component.findOne({ _id: componentId, isActive: true });
//   if (session) query = query.session(session);
//   return query;
// };

// // To Avoid Duplicates
// const findDuplicate = async ({
//   componentId,
//   subComponentName,
//   excludeId,
//   session,
// }) => {
//   const filter = {
//     componentId,
//     subComponentName: {
//       $regex: `^${escapeRegex(subComponentName)}$`,
//       $options: "i",
//     },
//   };
//   if (excludeId) filter._id = { $ne: excludeId };
//   let query = SubComponent.findOne(filter);
//   if (session) query = query.session(session);
//   return query;
// };

// // SubComponent Code Sequence
// const nextCode = async () => {
//   const lastSubComponent = await SubComponent.findOne(
//     {},
//     { subComponentCode: 1 },
//   )
//     .sort({ subComponentCode: -1 })
//     .lean();

//   if (!lastSubComponent?.subComponentCode) {
//     return "SUB-001";
//   }

//   const currentNumber = parseInt(
//     lastSubComponent.subComponentCode.replace("SUB-", ""),
//     10,
//   );

//   return `SUB-${String(currentNumber + 1).padStart(3, "0")}`;
// };

// // Audit Controller
// const addAudit = async ({
//   req,
//   action,
//   entityId,
//   changedFields,
//   beforeData,
//   afterData,
//   reason,
//   session,
// }) => {
//   await AuditLog.create(
//     [
//       {
//         eventAt: new Date(),
//         actorUserId: getUserId(req),
//         actorType: "USER",
//         action,
//         entityType: ENTITY_TYPE,
//         entityId,
//         changedFields,
//         beforeData,
//         afterData,
//         reason,
//         correlationId:
//           req.correlationId || new mongoose.Types.ObjectId().toString(),
//         result: "SUCCESS",
//       },
//     ],
//     { session },
//   );
// };

// const sendError = (res, error, fallback) => {
//   if (error?.code === 11000) {
//     return res.status(409).json({
//       success: false,
//       code: "DUPLICATE_SUBCOMPONENT",
//       message:
//         "subcomponentCode or subcomponentName already exists for the selected Component.",
//     });
//   }
//   if (error?.name === "ValidationError") {
//     return res.status(422).json({
//       success: false,
//       code: "VALIDATION_ERROR",
//       message: error.message,
//     });
//   }
//   console.error(fallback, error);
//   return res
//     .status(500)
//     .json({ success: false, code: "INTERNAL_SERVER_ERROR", message: fallback });
// };

// export const createSubcomponent = async (req, res) => {
//   const userId = req.user?.userId;

//   if (!userId) {
//     return res.status(401).json({
//       success: false,
//       message: "Authentication is required.",
//     });
//   }

//   const payload = pickFields(req.body, CREATE_FIELDS);

//   const errors = validatePayload(payload, { creating: true });

//   if (errors.length) {
//     return res.status(422).json({
//       success: false,
//       errors,
//     });
//   }

//   payload.subComponentName = payload.subComponentName;

//   payload.displayOrder = Number(payload.displayOrder || 1);

//   const session = await mongoose.startSession();

//   try {
//     let created;

//     await session.withTransaction(async () => {
//       const component = await getActiveComponent(payload.componentId, session);

//       if (!component) {
//         const error = new Error(
//           "The selected Component does not exist or is inactive.",
//         );
//         error.status = 409;
//         throw error;
//       }

//       if (
//         await findDuplicate({
//           componentId: payload.componentId,
//           subComponentName: payload.subComponentName,
//           session,
//         })
//       ) {
//         const error = new Error(
//           "The same Subcomponent already exists under this Component.",
//         );
//         error.status = 409;
//         throw error;
//       }

//       const subComponentCode = await nextCode(session);

//       [created] = await SubComponent.create(
//         [
//           {
//             ...payload,
//             subComponentCode,
//             isActive: true,
//             createdBy: userId,
//             updatedBy: userId,
//           },
//         ],
//         { session },
//       );

//       await addAudit({
//         req,
//         action: "CREATE",
//         entityId: created._id,
//         changedFields: Object.keys(payload),
//         beforeData: null,
//         afterData: created.toObject(),
//         session,
//       });
//     });

//     const data = await SubComponent.findById(created._id)
//       .populate("componentId", "componentCode componentName isActive")
//       .populate("createdBy", "employeeCode displayName")
//       .populate("updatedBy", "employeeCode displayName");

//     return res.status(201).json({
//       success: true,
//       data,
//       message: "Subcomponent created successfully.",
//     });
//   } catch (error) {
//     if (error.status) {
//       return res.status(error.status).json({
//         success: false,
//         message: error.message,
//       });
//     }

//     return sendError(res, error, "Unable to create Subcomponent.");
//   } finally {
//     await session.endSession();
//   }
// };

// export const getAllSubcomponents = async (req, res) => {
//   try {
//     const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
//     const limit = Math.min(
//       Math.max(parseInt(req.query.limit, 10) || 20, 1),
//       MAX_PAGE_SIZE,
//     );
//     const filter = {};

//     if (req.query.componentId) {
//       if (!isValidObjectId(req.query.componentId)) {
//         return res
//           .status(400)
//           .json({ success: false, message: "Invalid Component ID." });
//       }
//       filter.componentId = req.query.componentId;
//     }

//     if (req.query.search?.trim()) {
//       const search = escapeRegex(req.query.search.trim());
//       filter.$or = [
//         { subcomponentCode: { $regex: search, $options: "i" } },
//         { subcomponentName: { $regex: search, $options: "i" } },
//       ];
//     }

//     for (const field of BOOLEAN_FILTER_FIELDS) {
//       const value = parseBoolean(req.query[field]);
//       if (value !== undefined) filter[field] = value;
//     }

//     if (req.query.billRequirementOverride) {
//       if (!BILL_OVERRIDE_VALUES.includes(req.query.billRequirementOverride)) {
//         return res.status(400).json({
//           success: false,
//           message: "Invalid billRequirementOverride.",
//         });
//       }
//       filter.billRequirementOverride = req.query.billRequirementOverride;
//     }

//     const sortBy = ALLOWED_SORT_FIELDS.includes(req.query.sortBy)
//       ? req.query.sortBy
//       : "displayOrder";
//     const direction = req.query.sortOrder === "desc" ? -1 : 1;

//     const [data, totalRecords] = await Promise.all([
//       SubComponent.find(filter)
//         .populate(
//           "componentId",
//           "componentCode componentName isActive isPettyCash",
//         )
//         .sort({ [sortBy]: direction, subcomponentName: 1 })
//         .skip((page - 1) * limit)
//         .limit(limit)
//         .lean(),
//       SubComponent.countDocuments(filter),
//     ]);

//     return res.status(200).json({
//       success: true,
//       data,
//       pagination: {
//         page,
//         limit,
//         totalRecords,
//         totalPages: Math.ceil(totalRecords / limit),
//       },
//       message: "Subcomponents retrieved successfully.",
//     });
//   } catch (error) {
//     return sendError(res, error, "Unable to retrieve Subcomponents.");
//   }
// };

// export const getSubcomponentById = async (req, res) => {
//   try {
//     if (!isValidObjectId(req.params.id)) {
//       return res
//         .status(400)
//         .json({ success: false, message: "Invalid Subcomponent ID." });
//     }
//     const data = await SubComponent.findById(req.params.id)
//       .populate(
//         "componentId",
//         "componentCode componentName isActive isPettyCash",
//       )
//       .populate("createdBy", "employeeCode displayName")
//       .populate("updatedBy", "employeeCode displayName");
//     if (!data)
//       return res
//         .status(404)
//         .json({ success: false, message: "Subcomponent not found." });
//     return res.status(200).json({
//       success: true,
//       data,
//       message: "Subcomponent retrieved successfully.",
//     });
//   } catch (error) {
//     return sendError(res, error, "Unable to retrieve Subcomponent.");
//   }
// };

// export const getSubcomponentsByComponent = async (req, res) => {
//   try {
//     const { componentId } = req.params;
//     const component = await getActiveComponent(componentId);
//     if (!component) {
//       return res
//         .status(404)
//         .json({ success: false, message: "Active Component not found." });
//     }

//     const filter = { componentId, isActive: true };
//     for (const field of BOOLEAN_FILTER_FIELDS.filter((x) => x !== "isActive")) {
//       const value = parseBoolean(req.query[field]);
//       if (value !== undefined) filter[field] = value;
//     }

//     const data = await SubComponent.find(filter)
//       .sort({ displayOrder: 1, subcomponentName: 1 })
//       .lean();

//     return res.status(200).json({
//       success: true,
//       component: {
//         _id: component._id,
//         componentCode: component.componentCode,
//         componentName: component.componentName,
//       },
//       data,
//       message: "Subcomponents retrieved successfully.",
//     });
//   } catch (error) {
//     return sendError(res, error, "Unable to retrieve Component Subcomponents.");
//   }
// };

// export const updateSubcomponent = async (req, res) => {
//   const userId = getUserId(req);
//   if (!userId)
//     return res
//       .status(401)
//       .json({ success: false, message: "Authentication is required." });
//   if (!isValidObjectId(req.params.id)) {
//     return res
//       .status(400)
//       .json({ success: false, message: "Invalid Subcomponent ID." });
//   }

//   const version = Number(req.body.version);
//   if (!Number.isInteger(version) || version < 0) {
//     return res
//       .status(400)
//       .json({ success: false, message: "A valid version is required." });
//   }

//   const payload = pickFields(req.body, UPDATE_FIELDS);
//   const errors = validatePayload(payload);
//   if (errors.length) return res.status(422).json({ success: false, errors });
//   if (!Object.keys(payload).length) {
//     return res
//       .status(400)
//       .json({ success: false, message: "No permitted fields supplied." });
//   }
//   if (payload.subComponentName !== undefined)
//     payload.subComponentName = payload.subComponentName.trim();
//   if (payload.displayOrder !== undefined)
//     payload.displayOrder = Number(payload.displayOrder);

//   const session = await mongoose.startSession();
//   try {
//     let updated;
//     await session.withTransaction(async () => {
//       const existing = await SubComponent.findById(req.params.id).session(
//         session,
//       );
//       if (!existing) {
//         const e = new Error("Subcomponent not found.");
//         e.status = 404;
//         throw e;
//       }

//       if (
//         payload.subComponentName &&
//         (await findDuplicate({
//           componentId: existing.componentId,
//           subComponentName: payload.subComponentName,
//           excludeId: existing._id,
//           session,
//         }))
//       ) {
//         const e = new Error(
//           "The same Subcomponent already exists under this Component.",
//         );
//         e.status = 409;
//         throw e;
//       }

//       const beforeData = existing.toObject();
//       updated = await SubComponent.findOneAndUpdate(
//         { _id: existing._id, version },
//         { $set: { ...payload, updatedBy: userId }, $inc: { version: 1 } },
//         { new: true, runValidators: true, session },
//       );
//       if (!updated) {
//         const e = new Error("Version conflict. Refresh and try again.");
//         e.status = 409;
//         throw e;
//       }

//       await addAudit({
//         req,
//         action: "UPDATE",
//         entityId: updated._id,
//         changedFields: Object.keys(payload),
//         beforeData,
//         afterData: updated.toObject(),
//         session,
//       });
//     });

//     return res.status(200).json({
//       success: true,
//       data: updated,
//       message: "Subcomponent updated successfully.",
//     });
//   } catch (error) {
//     if (error.status)
//       return res
//         .status(error.status)
//         .json({ success: false, message: error.message });
//     return sendError(res, error, "Unable to update Subcomponent.");
//   } finally {
//     await session.endSession();
//   }
// };

// const changeActiveStatus = async (req, res, isActive) => {
//   const userId = getUserId(req);
//   if (!userId)
//     return res
//       .status(401)
//       .json({ success: false, message: "Authentication is required." });
//   if (!isValidObjectId(req.params.id)) {
//     return res
//       .status(400)
//       .json({ success: false, message: "Invalid Subcomponent ID." });
//   }

//   const version = Number(req.body.version);
//   if (!Number.isInteger(version) || version < 0) {
//     return res
//       .status(400)
//       .json({ success: false, message: "A valid version is required." });
//   }
//   if (!isActive && !req.body.reason?.trim()) {
//     return res
//       .status(400)
//       .json({ success: false, message: "A deactivation reason is required." });
//   }

//   const session = await mongoose.startSession();
//   try {
//     let updated;
//     await session.withTransaction(async () => {
//       const existing = await SubComponent.findById(req.params.id).session(
//         session,
//       );
//       if (!existing) {
//         const e = new Error("Subcomponent not found.");
//         e.status = 404;
//         throw e;
//       }
//       if (existing.isActive === isActive) {
//         const e = new Error(
//           `Subcomponent is already ${isActive ? "active" : "inactive"}.`,
//         );
//         e.status = 409;
//         throw e;
//       }
//       if (
//         isActive &&
//         !(await getActiveComponent(existing.componentId, session))
//       ) {
//         const e = new Error("Parent Component is inactive or unavailable.");
//         e.status = 409;
//         throw e;
//       }

//       updated = await SubComponent.findOneAndUpdate(
//         { _id: existing._id, version, isActive: !isActive },
//         { $set: { isActive, updatedBy: userId }, $inc: { version: 1 } },
//         { new: true, runValidators: true, session },
//       );
//       if (!updated) {
//         const e = new Error("Version conflict. Refresh and try again.");
//         e.status = 409;
//         throw e;
//       }

//       await addAudit({
//         req,
//         action: isActive ? "ENABLE" : "DISABLE",
//         entityId: updated._id,
//         changedFields: ["isActive"],
//         beforeData: { isActive: !isActive },
//         afterData: { isActive },
//         reason: req.body.reason?.trim(),
//         session,
//       });
//     });

//     return res.status(200).json({
//       success: true,
//       data: updated,
//       message: `Subcomponent ${isActive ? "activated" : "deactivated"} successfully.`,
//     });
//   } catch (error) {
//     if (error.status)
//       return res
//         .status(error.status)
//         .json({ success: false, message: error.message });
//     return sendError(
//       res,
//       error,
//       `Unable to ${isActive ? "activate" : "deactivate"} Subcomponent.`,
//     );
//   } finally {
//     await session.endSession();
//   }
// };

// export const activateSubcomponent = (req, res) =>
//   changeActiveStatus(req, res, true);
// export const deactivateSubcomponent = (req, res) =>
//   changeActiveStatus(req, res, false);

// export const validateSubcomponentMapping = async (req, res) => {
//   try {
//     const { componentId, subcomponentId } = req.body;
//     if (!isValidObjectId(componentId) || !isValidObjectId(subcomponentId)) {
//       return res.status(400).json({
//         success: false,
//         valid: false,
//         message: "Invalid Component or Subcomponent ID.",
//       });
//     }
//     const data = await SubComponent.findOne({
//       _id: subcomponentId,
//       componentId,
//       isActive: true,
//     }).populate("componentId", "componentCode componentName isActive");
//     if (!data || !data.componentId?.isActive) {
//       return res.status(422).json({
//         success: false,
//         valid: false,
//         message:
//           "Subcomponent does not belong to the Component or is inactive.",
//       });
//     }
//     return res.status(200).json({ success: true, valid: true, data });
//   } catch (error) {
//     return sendError(res, error, "Unable to validate Subcomponent mapping.");
//   }
// };

// export const checkSubcomponentUsage = async (req, res) => {
//   try {
//     if (!isValidObjectId(req.params.id)) {
//       return res
//         .status(400)
//         .json({ success: false, message: "Invalid Subcomponent ID." });
//     }
//     const subcomponent = await SubComponent.findById(req.params.id).select(
//       "_id subcomponentCode subcomponentName isActive",
//     );
//     if (!subcomponent)
//       return res
//         .status(404)
//         .json({ success: false, message: "Subcomponent not found." });
//     const transactionCount = await PettyCash.countDocuments({
//       subcomponentId: req.params.id,
//     });
//     return res.status(200).json({
//       success: true,
//       data: {
//         subcomponent,
//         transactionCount,
//         hasHistoricalUsage: transactionCount > 0,
//         canDeactivate: true,
//         canHardDelete: false,
//       },
//     });
//   } catch (error) {
//     return sendError(res, error, "Unable to check Subcomponent usage.");
//   }
// };

// export const getSubcomponentHistory = async (req, res) => {
//   try {
//     if (!isValidObjectId(req.params.id)) {
//       return res
//         .status(400)
//         .json({ success: false, message: "Invalid Subcomponent ID." });
//     }
//     const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
//     const limit = Math.min(
//       Math.max(parseInt(req.query.limit, 10) || 20, 1),
//       MAX_PAGE_SIZE,
//     );
//     const filter = { entityType: ENTITY_TYPE, entityId: req.params.id };
//     const [data, totalRecords] = await Promise.all([
//       AuditLog.find(filter)
//         .populate("actorUserId", "employeeCode displayName")
//         .sort({ eventAt: -1 })
//         .skip((page - 1) * limit)
//         .limit(limit)
//         .lean(),
//       AuditLog.countDocuments(filter),
//     ]);
//     return res.status(200).json({
//       success: true,
//       data,
//       pagination: {
//         page,
//         limit,
//         totalRecords,
//         totalPages: Math.ceil(totalRecords / limit),
//       },
//     });
//   } catch (error) {
//     return sendError(res, error, "Unable to retrieve Subcomponent history.");
//   }
// };
