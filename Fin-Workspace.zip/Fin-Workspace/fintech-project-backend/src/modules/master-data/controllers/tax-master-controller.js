import TaxMaster from '../models/tax-master-model.js'
const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;

export const createTax = async (req, res) => {
  try {
    const { taxCode, taxName, percentage } = req.body;

    const existingTax = await TaxMaster.findOne({
      taxCode,
    });

    if (existingTax) {
      return res.status(409).json({
        success: false,
        message: 'Tax code already exists',
      });
    }

    const tax = await TaxMaster.create({
      taxCode,
      taxName,
      percentage,
      createdBy: actor(req),
      updatedBy: actor(req),
    });

    return res.status(201).json({
      success: true,
      data: tax,
      message: 'Tax created successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getAllTaxes = async (req, res) => {
  try {
    const taxes = await TaxMaster.find({})
      .sort({ taxCode: 1 });

    return res.status(200).json({
      success: true,
      data: taxes,
      message: 'Taxes fetched successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getTaxById = async (req, res) => {
  try {
    const { taxId } = req.params;

    const tax = await TaxMaster.findById(taxId);

    if (!tax) {
      return res.status(404).json({
        success: false,
        message: 'Tax not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: tax,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateTax = async (req, res) => {
  try {
    const { taxId } = req.params;

    const tax = await TaxMaster.findByIdAndUpdate(
      taxId,
      {
        ...req.body,
        updatedBy: actor(req),
      },
      {
        new: true,
        runValidators: true,
      },
    );

    if (!tax) {
      return res.status(404).json({
        success: false,
        message: 'Tax not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: tax,
      message: 'Tax updated successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const deleteTax = async (req, res) => {
  try {
    const { taxId } = req.params;

    const tax = await TaxMaster.findByIdAndUpdate(
      taxId,
      {
        isActive: false,
        updatedBy: actor(req),
      },
      {
        new: true,
      },
    );

    if (!tax) {
      return res.status(404).json({
        success: false,
        message: 'Tax not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: tax,
      message: 'Tax deactivated successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};