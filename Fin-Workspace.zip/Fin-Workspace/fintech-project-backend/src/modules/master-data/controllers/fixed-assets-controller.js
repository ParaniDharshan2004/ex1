import FixedAssetMaster from '../models/fixed-assets-model.js';

const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

export const createFixedAsset = async (req, res) => {
  try {
    const { assetName, categoryId, description } = req.body;

    if (!assetName?.trim()) return fail(res, 400, 'Asset name is required');

    if (!mongoose.Types.ObjectId.isValid(categoryId))
      return fail(res, 400, 'Valid category ID is required');

    const exists = await FixedAssetMaster.findOne({
      assetName: assetName.trim(),
      categoryId,
    });

    if (exists)
      return fail(res, 409, 'Fixed asset already exists in this category');

    const asset = await FixedAssetMaster.create({
      assetName: assetName.trim(),
      categoryId,
      description,
      createdBy: actor(req),
      updatedBy: actor(req),
    });

    return res.status(201).json({
      success: true,
      data: asset,
      message: 'Fixed asset created successfully',
    });
  } catch (error) {
    return fail(res, 500, error.message || 'Unable to create fixed asset');
  }
};

export const getAllFixedAssets = async (req, res) => {
  try {
    const assets = await FixedAssetMaster.find({})
      .populate('categoryId', 'categoryName')
      .sort({
        assetName: 1,
      });

    return res.json({
      success: true,
      data: assets,
      message: 'Fixed assets retrieved successfully',
    });
  } catch (error) {
    return fail(res, 500, error.message || 'Unable to fetch fixed assets');
  }
};

export const getFixedAssetById = async (req, res) => {
  try {
    const { assetId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(assetId))
      return fail(res, 400, 'Invalid asset ID');

    const asset = await FixedAssetMaster.findById(assetId).populate(
      'categoryId',
      'categoryName',
    );

    if (!asset) return fail(res, 404, 'Fixed asset not found');

    return res.json({
      success: true,
      data: asset,
      message: 'Fixed asset retrieved successfully',
    });
  } catch (error) {
    return fail(res, 500, error.message || 'Unable to fetch fixed asset');
  }
};

export const updateFixedAsset = async (req, res) => {
  try {
    const { assetId } = req.params;
    const { assetName, categoryId, description, isActive } = req.body;

    if (!mongoose.Types.ObjectId.isValid(assetId))
      return fail(res, 400, 'Invalid asset ID');

    if (categoryId && !mongoose.Types.ObjectId.isValid(categoryId))
      return fail(res, 400, 'Invalid category ID');

    const asset = await FixedAssetMaster.findById(assetId);

    if (!asset) return fail(res, 404, 'Fixed asset not found');

    if (assetName !== undefined) asset.assetName = assetName.trim();

    if (categoryId !== undefined) asset.categoryId = categoryId;

    if (description !== undefined) asset.description = description;

    if (typeof isActive === 'boolean') asset.isActive = isActive;

    asset.updatedBy = actor(req);

    await asset.save();

    return res.json({
      success: true,
      data: asset,
      message: 'Fixed asset updated successfully',
    });
  } catch (error) {
    return fail(res, 500, error.message || 'Unable to update fixed asset');
  }
};

export const deleteFixedAsset = async (req, res) => {
  try {
    const { assetId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(assetId))
      return fail(res, 400, 'Invalid asset ID');

    const asset = await FixedAssetMaster.findByIdAndUpdate(
      assetId,
      {
        isActive: false,
        updatedBy: actor(req),
      },
      { new: true },
    );

    if (!asset) return fail(res, 404, 'Fixed asset not found');

    return res.json({
      success: true,
      data: asset,
      message: 'Fixed asset deleted successfully',
    });
  } catch (error) {
    return fail(res, 500, error.message || 'Unable to delete fixed asset');
  }
};
