import express from "express";
import {
  createSubcomponent,
  deleteSubcomponent,
  getAllSubcomponents,
  getSubComponentsByComponent,
  updateSubcomponent,
} from "../controllers/subcomponent-controller.js";
import { authenticateUser } from "../../../shared/middleware/auth-middleware.js";

const subComponentRouter = express.Router();

// subcomponents
subComponentRouter.post(
  "/createSubcomponent",
  authenticateUser,
  createSubcomponent,
);
subComponentRouter.get(
  "/getAllSubcomponents",
  authenticateUser,
  getAllSubcomponents,
);
subComponentRouter.get(
  "/getSubComponentByComponent/:componentId",
  authenticateUser,
  getSubComponentsByComponent,
);
subComponentRouter.patch(
  "/updateSubcomponent/:id",
  authenticateUser,
  updateSubcomponent,
);
subComponentRouter.delete(
  "/deleteSubcomponent/:id",
  authenticateUser,
  deleteSubcomponent,
);

export default subComponentRouter;
