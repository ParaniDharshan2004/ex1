import express from 'express';
import { authenticateUser } from '../../../shared/middleware/auth-middleware.js';
import {
  createFixedAssetCategory,
  getAllFixedAssetCategories,
  getFixedAssetCategoryById,
  updateFixedAssetCategory,
  deleteFixedAssetCategory,
} from '../controllers/fixed-assets-category-controller.js';

const fixedAssetCategoryRouter = express.Router();

fixedAssetCategoryRouter.post(
  '/createFixedAssetCategory',
  authenticateUser,
  createFixedAssetCategory,
);

fixedAssetCategoryRouter.get(
  '/getAllFixedAssetCategories',
  authenticateUser,
  getAllFixedAssetCategories,
);

fixedAssetCategoryRouter.get(
  '/getFixedAssetCategoryById/:categoryId',
  authenticateUser,
  getFixedAssetCategoryById,
);

fixedAssetCategoryRouter.patch(
  '/updateFixedAssetCategory/:categoryId',
  authenticateUser,
  updateFixedAssetCategory,
);

fixedAssetCategoryRouter.delete(
  '/deleteFixedAssetCategory/:categoryId',
  authenticateUser,
  deleteFixedAssetCategory,
);

export default fixedAssetCategoryRouter;
