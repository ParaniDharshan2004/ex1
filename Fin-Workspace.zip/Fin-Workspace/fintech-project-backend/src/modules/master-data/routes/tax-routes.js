import express from 'express';
import { authenticateUser } from '../../../shared/middleware/auth-middleware.js';
import { createTax, deleteTax, getAllTaxes, getTaxById, updateTax } from '../controllers/tax-master-controller.js';

const taxRouter = express.Router();

taxRouter.post('/createTax', authenticateUser, createTax);
taxRouter.get('/getAllTaxes', authenticateUser, getAllTaxes);
taxRouter.get('/getTaxById/:taxId', authenticateUser, getTaxById);
taxRouter.patch('/updateTax/:taxId', authenticateUser, updateTax);
taxRouter.patch('/deleteTax/:taxId', authenticateUser, deleteTax);

export default taxRouter;