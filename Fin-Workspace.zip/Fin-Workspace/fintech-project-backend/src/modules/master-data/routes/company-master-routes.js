import express from 'express';
import { authenticateUser } from '../../../shared/middleware/auth-middleware.js';
import {
  createCompany,
  deleteCompany,
  getAllCompanies,
  getCompanyById,
  updateCompany,
} from '../controllers/company-master-controller.js';

const companyMasterRouter = express.Router();

companyMasterRouter.post('/createCompany', authenticateUser, createCompany);
companyMasterRouter.get('/getAllCompanies', authenticateUser, getAllCompanies);
companyMasterRouter.get(
  '/getCompanyById/:companyId',
  authenticateUser,
  getCompanyById,
);
companyMasterRouter.patch(
  '/updateCompany/:companyId',
  authenticateUser,
  updateCompany,
);
companyMasterRouter.delete(
  '/deleteCompany/:companyId',
  authenticateUser,
  deleteCompany,
);

export default companyMasterRouter;
