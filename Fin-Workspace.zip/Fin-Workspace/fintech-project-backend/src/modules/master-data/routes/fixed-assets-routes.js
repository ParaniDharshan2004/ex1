import express from 'express';
import { authenticateUser } from '../../../shared/middleware/auth-middleware.js';
import {
  createFixedAsset,
  getAllFixedAssets,
  getFixedAssetById,
  updateFixedAsset,
  deleteFixedAsset,
} from '../controllers/fixed-assets-controller.js';

const fixedAssetRouter = express.Router();

fixedAssetRouter.post('/createFixedAsset', authenticateUser, createFixedAsset);
fixedAssetRouter.get('/getAllFixedAssets', authenticateUser, getAllFixedAssets);

fixedAssetRouter.get(
  '/getFixedAssetById/:assetId',
  authenticateUser,
  getFixedAssetById,
);

fixedAssetRouter.patch(
  '/updateFixedAsset/:assetId',
  authenticateUser,
  updateFixedAsset,
);

fixedAssetRouter.delete(
  '/deleteFixedAsset/:assetId',
  authenticateUser,
  deleteFixedAsset,
);

export default fixedAssetRouter;
