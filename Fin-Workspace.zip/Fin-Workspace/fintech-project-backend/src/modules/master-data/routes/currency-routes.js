import express from 'express';
import { authenticateUser } from '../../../shared/middleware/auth-middleware.js';
import {
  createCurrency,
  getAllCurrencies,
  getCurrencyById,
  toggleCurrencyStatus,
  updateCurrency,
} from '../controllers/currency-master-controller.js';

const currencyRouter = express.Router();

currencyRouter.post('/createCurrency', authenticateUser, createCurrency);
currencyRouter.get('/getAllCurrencies', authenticateUser, getAllCurrencies);
currencyRouter.get(
  '/getCurrencyById/:currencyId',
  authenticateUser,
  getCurrencyById,
);
currencyRouter.patch(
  '/updateCurrency/:currencyId',
  authenticateUser,
  updateCurrency,
);
currencyRouter.patch(
  '/toggleCurrencyStatus/:currencyId',
  authenticateUser,
  toggleCurrencyStatus,
);

export default currencyRouter;
