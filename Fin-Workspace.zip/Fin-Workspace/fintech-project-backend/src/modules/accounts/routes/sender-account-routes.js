import express from "express";
import { authenticateUser } from "../../../shared/middleware/auth-middleware.js";

import {
  createSenderAccount,
  getAllSenderAccounts,
  getSenderAccountById,
  updateSenderAccount,
  deleteSenderAccount,
} from "../controllers/sender-account-controller.js";

const senderAccountRouter = express.Router();

senderAccountRouter.post("/createSenderAccount", authenticateUser, createSenderAccount);

senderAccountRouter.get("/getAllSenderAccount", authenticateUser, getAllSenderAccounts);

senderAccountRouter.get("/getSenderAccountById/:id", authenticateUser, getSenderAccountById);

senderAccountRouter.patch("/updateSenderAccount/:id", authenticateUser, updateSenderAccount);

senderAccountRouter.delete("/deleteSenderAccount/:id", authenticateUser, deleteSenderAccount);

export default senderAccountRouter;
