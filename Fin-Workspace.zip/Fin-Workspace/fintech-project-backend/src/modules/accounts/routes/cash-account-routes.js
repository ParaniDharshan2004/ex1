import express from "express";
import { authenticateUser } from "../../../shared/middleware/auth-middleware.js";
import {
  createPettyCashAccount,
  getAllPettyCashAccounts,
  getPettyCashAccountById,
  updatePettyCashAccount,
  deletePettyCashAccount,
} from "../controllers/cash-account-controller.js";

const pettyCashAccountRouter = express.Router();

pettyCashAccountRouter.post(
  "/createPettyCashAccount",
  authenticateUser,
  createPettyCashAccount,
);

pettyCashAccountRouter.get(
  "/getAllPettyCashAccounts",
  authenticateUser,
  getAllPettyCashAccounts,
);

pettyCashAccountRouter.get(
  "/getPettyCashAccountById/:id",
  authenticateUser,
  getPettyCashAccountById,
);

pettyCashAccountRouter.patch(
  "/updatePettyCashAccount/:id",
  authenticateUser,
  updatePettyCashAccount,
);

pettyCashAccountRouter.delete(
  "/deletePettyCashAccount/:id",
  authenticateUser,
  deletePettyCashAccount,
);

export default pettyCashAccountRouter;
