import migrationRouter from './routes/migration-routes.js';

export { migrationRouter };
