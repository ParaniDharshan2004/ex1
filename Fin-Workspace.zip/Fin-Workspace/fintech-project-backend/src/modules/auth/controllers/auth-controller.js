import jwt from "jsonwebtoken";
import User from "../models/user-model.js";

export const login = async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await User.findOne({
      username,
      isActive: true,
    }).populate({
      path: "roleId",
      populate: {
        path: "permissionId",
      },
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid username or password",
      });
    }

    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid username or password",
      });
    }

    const token = jwt.sign(
      {
        userId: user._id,
        username: user.username,
        roleId: user.roleId._id,
      },
      process.env.JWT_SECRET,
      {
        expiresIn: "1d",
      }
    );

    return res.status(200).json({
      success: true,
      token,

      user: {
        userId: user._id,
        username: user.username,
        isActive: user.isActive,

        role: {
          roleId: user.roleId._id,
          roleName: user.roleId.roleName,
        },
      },

      permissions: {
        permissionId: user.roleId.permissionId._id,
        permissionName:
          user.roleId.permissionId.permissionName,

        read: user.roleId.permissionId.read,
        write: user.roleId.permissionId.write,
        delete: user.roleId.permissionId.delete,
      },

      message: "Login successful",
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Unable to login",
    });
  }
};