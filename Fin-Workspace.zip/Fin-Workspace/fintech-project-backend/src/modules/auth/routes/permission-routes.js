import express from "express";

import {
  createPermission,
  getAllPermissions,
  updatePermission,
  deletePermission,
} from "../controllers/permission-controller.js";

const permissionRouter = express.Router();

permissionRouter.post("/createPermission", createPermission);

permissionRouter.get("/getAllPermissions", getAllPermissions);

permissionRouter.patch("/updatePermission/:id", updatePermission);

permissionRouter.delete("/deletePermission/:id", deletePermission);

export default permissionRouter;
