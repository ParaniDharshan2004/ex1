import express from "express";
import {
  createUser,
  getAllUsers,
  updateUser,
  deleteUser,
} from "../controllers/user-controller.js";

const userRouter = express.Router();

userRouter.post("/createUser", createUser);
userRouter.get("/getAllUsers", getAllUsers);
userRouter.put("/updateUser/:id", updateUser);
userRouter.delete("/deleteUser/:id", deleteUser);

export default userRouter;