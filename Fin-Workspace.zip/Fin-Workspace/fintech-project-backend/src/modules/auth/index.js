import authRouter from './routes/auth-routes.js';
import permissionRouter from './routes/permission-routes.js';
import roleRouter from './routes/role-routes.js';
import userRouter from './routes/user-routes.js';

export { authRouter, permissionRouter, roleRouter, userRouter };
