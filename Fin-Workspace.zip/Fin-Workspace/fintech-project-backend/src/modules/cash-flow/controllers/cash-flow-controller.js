import FinancialCategory from "../../master-data/models/financial-category-model.js";
import CashFlowEntry from "../models/cash-flow-model.js";
import Component from "../../master-data/models/component-model.js";
import SubComponent from "../../master-data/models/subcomponent-model.js";
import { createAuditLog } from "../../../infrastructure/logging/audit-service.js";

export const getCashFlowEntryOptions = async (req, res) => {
  try {
    const categories = await FinancialCategory.find({
      isActive: true,
    })
      .sort({
        displayOrder: 1,
        categoryName: 1,
      })
      .lean();

    const components = await Component.find({
      isCashFlowAnalysis: true,
      isActive: true,
    })
      .select(
        "_id componentCode componentName financialCategoryId displayOrder",
      )
      .sort({
        displayOrder: 1,
      })
      .lean();

    const parentCategories = categories.filter(
      (category) => category.parentCategoryId === null,
    );

    const data = parentCategories.map((parent) => {
      const children = categories.filter(
        (category) =>
          category.parentCategoryId &&
          category.parentCategoryId.toString() === parent._id.toString(),
      );

      const formattedChildren = children.map((child) => ({
        _id: child._id,

        categoryCode: child.categoryCode,

        categoryName: child.categoryName,

        displayOrder: child.displayOrder,

        components: components.filter(
          (component) =>
            component.financialCategoryId &&
            component.financialCategoryId.toString() === child._id.toString(),
        ),
      }));

      const directComponents = components.filter(
        (component) =>
          component.financialCategoryId &&
          component.financialCategoryId.toString() === parent._id.toString(),
      );

      return {
        _id: parent._id,
        categoryCode: parent.categoryCode,
        categoryName: parent.categoryName,
        displayOrder: parent.displayOrder,
        children: formattedChildren,
        components: directComponents,
      };
    });

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    console.error("Get Cash Flow Entry options error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch Cash Flow Entry options",
      error: error.message,
    });
  }
};

export const createCashFlowEntry = async (req, res) => {
  try {
    const { entryDate, componentId, subComponentId, description, amount } =
      req.body;
    const component = await Component.findById(componentId);

    if (!component) {
      return res.status(404).json({
        success: false,
        message: "Component not found",
      });
    }

    if (subComponentId) {
      const subComponent = await SubComponent.findById(subComponentId);

      if (!subComponent) {
        return res.status(404).json({
          success: false,
          message: "Sub Component not found",
        });
      }
    }

    const cashFlowEntry = await CashFlowEntry.create({
      entryDate,
      componentId,
      subComponentId: subComponentId || null,
      description: description || null,
      amount,
      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    });

    try {
      await createAuditLog({
        req,
        action: "CREATE",
        entityType: "cash_flow_entry",
        entityId: cashFlowEntry._id,
        changedFields: Object.keys(cashFlowEntry.toObject()),
        beforeData: null,
        afterData: cashFlowEntry.toObject(),
      });
    } catch (auditError) {
      console.error("Cash Flow Entry Audit Log Error:", auditError);
    }

    return res.status(201).json({
      success: true,
      data: cashFlowEntry,
      message: "Cash Flow Entry created successfully",
    });
  } catch (error) {
    console.error("Create Cash Flow Entry Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to create Cash Flow Entry",
    });
  }
};

export const getAllCashFlowEntries = async (req, res) => {
  try {
    const cashFlowEntries = await CashFlowEntry.find()
      .populate({
        path: "componentId",
        select: "componentCode componentName financialCategoryId",
        populate: {
          path: "financialCategoryId",
          select: "categoryCode categoryName parentCategoryId",
        },
      })
      .populate("subComponentId", "subComponentCode subComponentName")
      .populate("createdBy", "username")
      .populate("updatedBy", "username")
      .sort({
        entryDate: -1,
      });

    return res.status(200).json({
      success: true,
      data: cashFlowEntries,
      message: "Cash Flow Entries retrieved successfully",
    });
  } catch (error) {
    console.error("Get Cash Flow Entries Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to retrieve Cash Flow Entries",
    });
  }
};

export const getCashFlowEntryById = async (req, res) => {
  try {
    const cashFlowEntry = await CashFlowEntry.findById(req.params.id)
      .populate({
        path: "componentId",
        select: "componentCode componentName financialCategoryId",
        populate: {
          path: "financialCategoryId",
          select: "categoryCode categoryName parentCategoryId",
        },
      })
      .populate("subComponentId", "subComponentCode subComponentName")
      .populate("createdBy", "username")
      .populate("updatedBy", "username");

    if (!cashFlowEntry) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Entry not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: cashFlowEntry,
      message: "Cash Flow Entry retrieved successfully",
    });
  } catch (error) {
    console.error("Get Cash Flow Entry Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve Cash Flow Entry",
    });
  }
};

export const updateCashFlowEntry = async (req, res) => {
  try {
    const oldCashFlowEntry = await CashFlowEntry.findById(req.params.id);

    if (!oldCashFlowEntry) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Entry not found",
      });
    }

    if (req.body.componentId) {
      const component = await Component.findById(req.body.componentId);
      if (!component) {
        return res.status(404).json({
          success: false,
          message: "Component not found",
        });
      }
    }

    if (req.body.subComponentId) {
      const subComponent = await SubComponent.findById(req.body.subComponentId);

      if (!subComponent) {
        return res.status(404).json({
          success: false,
          message: "Sub Component not found",
        });
      }
    }

    const cashFlowEntry = await CashFlowEntry.findByIdAndUpdate(
      req.params.id,
      {
        ...req.body,
        subComponentId: req.body.subComponentId || null,
        updatedBy: req.user.userId,
      },
      {
        new: true,
        runValidators: true,
      },
    );

    try {
      await createAuditLog({
        req,
        action: "UPDATE",
        entityType: "cash_flow_entry",
        entityId: cashFlowEntry._id,
        changedFields: Object.keys(req.body),
        beforeData: oldCashFlowEntry.toObject(),
        afterData: cashFlowEntry.toObject(),
      });
    } catch (auditError) {
      console.error("Cash Flow Entry Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      data: cashFlowEntry,
      message: "Cash Flow Entry updated successfully",
    });
  } catch (error) {
    console.error("Update Cash Flow Entry Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to update Cash Flow Entry",
    });
  }
};

export const deleteCashFlowEntry = async (req, res) => {
  try {
    const deletedCashFlowEntry = await CashFlowEntry.findByIdAndDelete(
      req.params.id,
    );

    if (!deletedCashFlowEntry) {
      return res.status(404).json({
        success: false,

        message: "Cash Flow Entry not found",
      });
    }
    try {
      await createAuditLog({
        req,
        action: "REMOVE",
        entityType: "cash_flow_entry",
        entityId: deletedCashFlowEntry._id,
        changedFields: ["deleted"],
        beforeData: deletedCashFlowEntry.toObject(),
        afterData: null,
      });
    } catch (auditError) {
      console.error("Cash Flow Entry Delete Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      message: "Cash Flow Entry deleted successfully",
    });
  } catch (error) {
    console.error("Delete Cash Flow Entry Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to delete Cash Flow Entry",
    });
  }
};
