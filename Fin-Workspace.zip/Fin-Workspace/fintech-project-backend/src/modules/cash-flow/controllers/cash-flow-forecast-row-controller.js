import mongoose from "mongoose";

import Component from "../../master-data/models/component-model.js";
import FinancialCategory from "../../master-data/models/financial-category-model.js";
import FinancialSubCategory from "../../master-data/models/financial-subcategory-model.js";
import CashFlowForecast from "../models/cash-flow-forecast-model.js";

export const getAvailableForecastComponents = async (req, res) => {
  try {
    const { forecastId } = req.params;

    const { financialCategoryId, financialSubCategoryId } = req.query;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Forecast ID",
      });
    }

    if (
      !financialCategoryId ||
      !mongoose.Types.ObjectId.isValid(financialCategoryId)
    ) {
      return res.status(400).json({
        success: false,
        message: "A valid Financial Category ID is required",
      });
    }

    if (
      financialSubCategoryId &&
      !mongoose.Types.ObjectId.isValid(financialSubCategoryId)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid Financial Subcategory ID",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId)
      .select("rows.componentId")
      .lean();

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const existingComponentIds = forecast.rows
      .filter((row) => row.componentId)
      .map((row) => row.componentId);

    const componentFilter = {
      _id: {
        $nin: existingComponentIds,
      },
      financialCategoryId,
      isCashFlowAnalysis: true,
      isActive: true,
    };

    if (financialSubCategoryId) {
      componentFilter.financialSubCategoryId = financialSubCategoryId;
    } else {
      componentFilter.financialSubCategoryId = null;
    }

    const components = await Component.find(componentFilter)
      .select(
        [
          "_id",
          "componentCode",
          "componentName",
          "description",
          "financialCategoryId",
          "financialSubCategoryId",
          "displayOrder",
        ].join(" "),
      )
      .sort({
        displayOrder: 1,
        componentName: 1,
      })
      .lean();

    return res.status(200).json({
      success: true,
      data: components,
      message: "Available Components retrieved successfully",
    });
  } catch (error) {
    console.error("Get Available Forecast Components Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve available Components",
    });
  }
};

export const addForecastRow = async (req, res) => {
  try {
    const { forecastId } = req.params;

    const {
      addType,
      componentId,
      itemName,
      description = "",
      financialCategoryId,
      financialSubCategoryId,
      forecastAmounts = [],
      sourceAmount = 0,
      parentComponentId = null,
      tallyLedgerName = "",
      excelRowNumber = null,
    } = req.body;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Forecast ID",
      });
    }

    if (!["MASTER_COMPONENT", "REPORT_ONLY"].includes(addType)) {
      return res.status(400).json({
        success: false,
        message: "Add Type must be MASTER_COMPONENT or REPORT_ONLY",
      });
    }

    if (
      !financialCategoryId ||
      !mongoose.Types.ObjectId.isValid(financialCategoryId)
    ) {
      return res.status(400).json({
        success: false,
        message: "A valid Financial Category is required",
      });
    }

    if (
      financialSubCategoryId &&
      !mongoose.Types.ObjectId.isValid(financialSubCategoryId)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid Financial Subcategory",
      });
    }

    if (!Array.isArray(forecastAmounts)) {
      return res.status(400).json({
        success: false,
        message: "Forecast amounts must be an array",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const category = await FinancialCategory.findOne({
      _id: financialCategoryId,
      isActive: true,
    }).lean();

    if (!category) {
      return res.status(404).json({
        success: false,
        message: "Financial Category not found or inactive",
      });
    }

    let subCategory = null;

    if (financialSubCategoryId) {
      subCategory = await FinancialSubCategory.findOne({
        _id: financialSubCategoryId,
        financialCategoryId,
        isActive: true,
      }).lean();

      if (!subCategory) {
        return res.status(400).json({
          success: false,
          message:
            "The selected Financial Subcategory does not belong to the selected Financial Category",
        });
      }
    }

    const categoryValues = {
      financialCategoryId: category._id,
      financialCategoryCode: category.categoryCode || "",
      financialCategoryName: category.categoryName || "",

      financialSubCategoryId: subCategory?._id || null,
      financialSubCategoryCode: subCategory?.subCategoryCode || "",
      financialSubCategoryName: subCategory?.subCategoryName || "",
    };

    const normalizedAmounts = forecast.forecastMonths.map((month) => {
      const matchingAmount = forecastAmounts.find(
        (item) => item.month === month,
      );

      return {
        month,
        amount: Number(matchingAmount?.amount) || 0,
      };
    });

    let newRow = null;
    const normalizedSourceAmount = Math.max(0, Number(sourceAmount) || 0);
    const unmatchedLedgerName = String(tallyLedgerName || "").trim();

    if (
      parentComponentId &&
      !mongoose.Types.ObjectId.isValid(parentComponentId)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid parent Component",
      });
    }

    if (addType === "MASTER_COMPONENT") {
      if (!componentId || !mongoose.Types.ObjectId.isValid(componentId)) {
        return res.status(400).json({
          success: false,
          message: "Select a valid Component",
        });
      }

      const componentFilter = {
        _id: componentId,
        financialCategoryId,
        financialSubCategoryId: financialSubCategoryId || null,
        isCashFlowAnalysis: true,
        isActive: true,
      };

      const component = await Component.findOne(componentFilter).lean();

      if (!component) {
        return res.status(404).json({
          success: false,
          message:
            "The selected Component was not found or does not belong to this forecast section",
        });
      }

      const componentAlreadyExists = forecast.rows.some(
        (row) =>
          row.componentId && String(row.componentId) === String(componentId),
      );

      if (componentAlreadyExists) {
        return res.status(409).json({
          success: false,
          message:
            "This Component is already available in the current forecast",
        });
      }

      newRow = {
        componentId: component._id,
        componentCode: component.componentCode || "",
        componentName: component.componentName,

        rowSource: "MASTER_COMPONENT",
        isManuallyAdded: true,

        ...categoryValues,

        description: component.description || "",
        displayOrder: Number(component.displayOrder) || 0,
        sourceAmount: normalizedSourceAmount,
        forecastAmounts: normalizedAmounts,

        matchStatus:
          normalizedSourceAmount > 0
            ? "HEAD_COMPONENT_MATCHED"
            : "MANUALLY_ADDED",
        hasTallyExpense: normalizedSourceAmount > 0,
        matchedTallyLedgers: unmatchedLedgerName
          ? [
              {
                tallyLedgerName: unmatchedLedgerName,
                amount: normalizedSourceAmount,
                excelRowNumber,
                matchType: "HEAD_COMPONENT",
              },
            ]
          : [],
        subComponentBreakdown: [],
        isEdited: true,
      };
    }

    if (addType === "REPORT_ONLY") {
      const normalizedItemName = itemName?.trim();

      if (!normalizedItemName) {
        return res.status(400).json({
          success: false,
          message: "Item Name is required",
        });
      }

      const itemAlreadyExists = forecast.rows.some(
        (row) =>
          row.componentName?.trim().toLowerCase() ===
          normalizedItemName.toLowerCase(),
      );

      if (itemAlreadyExists) {
        return res.status(409).json({
          success: false,
          message:
            "An item with this name already exists in the current forecast",
        });
      }

      newRow = {
        componentId: null,
        parentComponentId,
        componentCode: "",
        componentName: normalizedItemName,

        rowSource: "REPORT_ONLY",
        isManuallyAdded: true,

        ...categoryValues,

        description: description?.trim() || "",
        displayOrder: 9999,
        sourceAmount: normalizedSourceAmount,
        forecastAmounts: normalizedAmounts,

        matchStatus: "MANUALLY_ADDED",
        hasTallyExpense: normalizedSourceAmount > 0,
        matchedTallyLedgers: [],
        subComponentBreakdown: [],
        isEdited: true,
      };

      if (parentComponentId) {
        const parentRow = forecast.rows.find(
          (row) => String(row.componentId) === String(parentComponentId),
        );

        if (!parentRow) {
          return res.status(404).json({
            success: false,
            message: "The selected parent Component is not in this forecast",
          });
        }

        newRow.financialCategoryId = parentRow.financialCategoryId;
        newRow.financialCategoryCode = parentRow.financialCategoryCode;
        newRow.financialCategoryName = parentRow.financialCategoryName;
        newRow.financialSubCategoryId = parentRow.financialSubCategoryId;
        newRow.financialSubCategoryCode = parentRow.financialSubCategoryCode;
        newRow.financialSubCategoryName = parentRow.financialSubCategoryName;
        newRow.displayOrder = Number(parentRow.displayOrder) || 0;
      }
    }

    if (!newRow) {
      return res.status(400).json({
        success: false,
        message: "Unable to prepare the forecast row",
      });
    }

    forecast.rows.push(newRow);

    if (unmatchedLedgerName) {
      forecast.unmatchedTallyRows = forecast.unmatchedTallyRows.filter(
        (row) =>
          !(
            String(row.tallyLedgerName || "").trim() === unmatchedLedgerName &&
            (excelRowNumber == null ||
              String(row.excelRowNumber) === String(excelRowNumber))
          ),
      );
    }

    forecast.summary.unmatchedTallyRows = forecast.unmatchedTallyRows.length;
    forecast.summary.totalComponents = forecast.rows.length;
    forecast.summary.matchedHeadComponents = forecast.rows.filter(
      (row) => row.matchStatus === "HEAD_COMPONENT_MATCHED",
    ).length;
    forecast.summary.calculatedFromSubComponents = forecast.rows.filter(
      (row) => row.matchStatus === "CALCULATED_FROM_SUBCOMPONENTS",
    ).length;
    forecast.summary.componentsWithoutExpense = forecast.rows.filter(
      (row) => row.matchStatus === "NOT_PRESENT_IN_TALLY",
    ).length;

    forecast.totals.sourceTotal = forecast.rows.reduce(
      (total, row) => total + (Number(row.sourceAmount) || 0),
      0,
    );

    const monthTotals = forecast.forecastMonths.map((month) =>
      forecast.rows.reduce((total, row) => {
        const amount = row.forecastAmounts.find((item) => item.month === month);
        return total + (Number(amount?.amount) || 0);
      }, 0),
    );

    forecast.totals.month1Total = monthTotals[0] || 0;
    forecast.totals.month2Total = monthTotals[1] || 0;
    forecast.totals.month3Total = monthTotals[2] || 0;
    forecast.totals.forecastTotal = monthTotals.reduce(
      (total, amount) => total + amount,
      0,
    );

    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    const addedRow = forecast.rows[forecast.rows.length - 1];

    return res.status(201).json({
      success: true,
      data: addedRow,
      message:
        addType === "MASTER_COMPONENT"
          ? "Component added to the current forecast"
          : "Report-only item added successfully",
    });
  } catch (error) {
    console.error("Add Forecast Row Error:", error.stack || error);

    if (error.name === "ValidationError") {
      const message = Object.values(error.errors)
        .map((item) => item.message)
        .join(", ");

      return res.status(400).json({
        success: false,
        message,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "One or more submitted IDs are invalid",
      });
    }

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to add the forecast row",
    });
  }
};

export const deleteForecastRow = async (req, res) => {
  try {
    const { forecastId, rowId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Forecast ID",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(rowId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Forecast Row ID",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const forecastRow = forecast.rows.id(rowId);

    if (!forecastRow) {
      return res.status(404).json({
        success: false,
        message: "Forecast row not found",
      });
    }

    const componentName = forecastRow.componentName;

    forecastRow.deleteOne();

    const sourceTotal = forecast.rows.reduce(
      (total, row) => total + (Number(row.sourceAmount) || 0),
      0,
    );

    const monthTotals = forecast.forecastMonths.map((month) =>
      forecast.rows.reduce((total, row) => {
        const forecastAmount = row.forecastAmounts.find(
          (item) => item.month === month,
        );

        return total + (Number(forecastAmount?.amount) || 0);
      }, 0),
    );

    forecast.totals.sourceTotal = sourceTotal;
    forecast.totals.month1Total = monthTotals[0] || 0;
    forecast.totals.month2Total = monthTotals[1] || 0;
    forecast.totals.month3Total = monthTotals[2] || 0;
    forecast.totals.forecastTotal = monthTotals.reduce(
      (total, amount) => total + amount,
      0,
    );

    forecast.summary.totalComponents = forecast.rows.length;

    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    return res.status(200).json({
      success: true,
      data: {
        deletedRowId: rowId,
        totals: forecast.totals,
        summary: forecast.summary,
      },
      message: `${componentName} removed from the current forecast`,
    });
  } catch (error) {
    console.error("Delete Forecast Row Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to remove the forecast row",
    });
  }
};

export const discardUnmatchedTallyRow = async (req, res) => {
  try {
    const { forecastId } = req.params;
    const { tallyLedgerName, excelRowNumber } = req.body;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Forecast ID",
      });
    }

    const normalizedName = String(tallyLedgerName || "").trim();

    if (!normalizedName) {
      return res.status(400).json({
        success: false,
        message: "Tally ledger name is required",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const unmatchedIndex = forecast.unmatchedTallyRows.findIndex(
      (row) =>
        String(row.tallyLedgerName || "").trim() === normalizedName &&
        (excelRowNumber == null ||
          String(row.excelRowNumber) === String(excelRowNumber)),
    );

    if (unmatchedIndex === -1) {
      return res.status(404).json({
        success: false,
        message: "Unmatched Tally value not found",
      });
    }

    forecast.unmatchedTallyRows.splice(unmatchedIndex, 1);
    forecast.summary.unmatchedTallyRows = forecast.unmatchedTallyRows.length;
    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    return res.status(200).json({
      success: true,
      data: {
        unmatchedTallyRows: forecast.unmatchedTallyRows,
        unmatchedCount: forecast.unmatchedTallyRows.length,
      },
      message: "Unmatched Tally value discarded successfully",
    });
  } catch (error) {
    console.error("Discard Unmatched Tally Row Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to discard the unmatched Tally value",
    });
  }
};
