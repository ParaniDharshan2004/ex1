import cashInflowRouter from './routes/cash-inflow-routes.js';

export { cashInflowRouter };
