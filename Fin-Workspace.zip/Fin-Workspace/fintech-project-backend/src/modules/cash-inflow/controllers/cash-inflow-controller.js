import CashInflow from "../models/cash-inflow-model.js";
import { createAuditLog } from "../../../infrastructure/logging/audit-service.js";
import { rebuildMonthlySummary } from "../../petty-cash/services/monthly-summary-service.js";

export const createCashInflow = async (req, res) => {
  try {
    const cashInflow = await CashInflow.create(req.body);

    const month = new Date(cashInflow.inflowDate).toISOString().slice(0, 7);

    await rebuildMonthlySummary(month);

    try {
      await createAuditLog({
        req,
        action: "CREATE",
        entityType: "cash_inflow",
        entityId: cashInflow._id,
        changedFields: Object.keys(cashInflow.toObject()),
        beforeData: null,
        afterData: cashInflow.toObject(),
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      data: cashInflow,
      message: "Cash inflow created successfully.",
    });
  } catch (error) {
    console.error("Create Cash Inflow Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to create cash inflow.",
    });
  }
};

export const getAllCashInflows = async (req, res) => {
  try {
    const cashInflows = await CashInflow.find().sort({
      inflowDate: -1,
    });

    return res.status(200).json({
      success: true,
      data: cashInflows,
      message: "Cash inflows retrieved successfully.",
    });
  } catch (error) {
    console.error("Get Cash Inflows Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve cash inflows.",
    });
  }
};

export const getCashInflowById = async (req, res) => {
  try {
    const cashInflow = await CashInflow.findById(req.params.id);

    if (!cashInflow) {
      return res.status(404).json({
        success: false,
        message: "Cash inflow not found.",
      });
    }

    return res.status(200).json({
      success: true,
      data: cashInflow,
      message: "Cash inflow retrieved successfully.",
    });
  } catch (error) {
    console.error("Get Cash Inflow Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve cash inflow.",
    });
  }
};

export const updateCashInflow = async (req, res) => {
  try {
    const oldCashInflow = await CashInflow.findById(req.params.id);

    if (!oldCashInflow) {
      return res.status(404).json({
        success: false,
        message: "Cash inflow not found.",
      });
    }

    const cashInflow = await CashInflow.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      },
    );

    if (!cashInflow) {
      return res.status(404).json({
        success: false,
        message: "Cash inflow not found.",
      });
    }

    const month = new Date(cashInflow.inflowDate).toISOString().slice(0, 7);

    await rebuildMonthlySummary(month);

    try {
      await createAuditLog({
        req,
        action: "UPDATE",
        entityType: "cash_inflow",
        entityId: cashInflow._id,
        changedFields: Object.keys(req.body),
        beforeData: oldCashInflow.toObject(),
        afterData: cashInflow.toObject(),
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      data: cashInflow,
      message: "Cash inflow updated successfully.",
    });
  } catch (error) {
    console.error("Update Cash Inflow Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to update cash inflow.",
    });
  }
};

export const deleteCashInflow = async (req, res) => {
  try {
    const cashInflow = await CashInflow.findByIdAndDelete(req.params.id);

    if (!cashInflow) {
      return res.status(404).json({
        success: false,
        message: "Cash inflow not found.",
      });
    }

    const month = new Date(cashInflow.inflowDate).toISOString().slice(0, 7);

    await rebuildMonthlySummary(month);

    try {
      await createAuditLog({
        req,
        action: "REMOVE",
        entityType: "cash_inflow",
        entityId: cashInflow._id,
        changedFields: ["deleted"],
        beforeData: cashInflow.toObject(),
        afterData: null,
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      message: "Cash inflow deleted successfully.",
    });
  } catch (error) {
    console.error("Delete Cash Inflow Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to delete cash inflow.",
    });
  }
};
