import express from "express";

import {
  getComponentExpenseSummary,
  getLedger,
} from "../../petty-cash/controllers/petty-cash-report-controller.js";

const reportRouter = express.Router();

reportRouter.get("/componentExpenseSummary", getComponentExpenseSummary);
reportRouter.get("/pettyCashLedger", getLedger);

export default reportRouter;
