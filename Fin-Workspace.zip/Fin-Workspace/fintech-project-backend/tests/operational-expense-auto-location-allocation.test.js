import { calculateEvenLocationAllocations } from '../services/operational-expense-services/operational-expense-allocation-calculation-service.js';

describe('calculateEvenLocationAllocations', () => {
  test('assigns the full amount to a single active location', () => {
    const allocations = calculateEvenLocationAllocations(1000, [
      { _id: 'location-1' },
    ]);

    expect(allocations).toEqual([{ locationId: 'location-1', amount: 1000 }]);
  });

  test('splits the amount equally across two active locations', () => {
    const allocations = calculateEvenLocationAllocations(200000, [
      { _id: 'location-1' },
      { _id: 'location-2' },
    ]);

    expect(allocations).toEqual([
      { locationId: 'location-1', amount: 100000 },
      { locationId: 'location-2', amount: 100000 },
    ]);
  });

  test('assigns any currency rounding remainder to the last location', () => {
    const allocations = calculateEvenLocationAllocations(100000, [
      { _id: 'location-1' },
      { _id: 'location-2' },
      { _id: 'location-3' },
    ]);

    expect(allocations).toEqual([
      { locationId: 'location-1', amount: 33333.33 },
      { locationId: 'location-2', amount: 33333.33 },
      { locationId: 'location-3', amount: 33333.34 },
    ]);
    expect(
      allocations.reduce((sum, allocation) => sum + allocation.amount, 0),
    ).toBe(100000);
  });
});


// MONGO_URI=mongodb+srv://Ajay:za8IhkpQTjCKNAbA@cluster0.w523omf.mongodb.net/petty-cash-data?appName=Cluster0
// JWT_SECRET=pettycash_secret_key
// JWT_EXPIRES_IN=1d
 