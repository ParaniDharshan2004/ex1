import mongoose from "mongoose";
import OperationalExpenseReport from "../src/modules/operational-expense/models/operational-expense-report-model.js";
import { recalculateOperationalExpenseTotals } from "../src/modules/operational-expense/services/operational-expense-calculation-service.js";

describe("recalculateOperationalExpenseTotals", () => {
  const createFinalizedReport = () => {
    const firstAllocationPercentage = (300000 / 336120) * 100;
    return new OperationalExpenseReport({
      reportCode: "OE-2026-10",
      reportName: "Operational Expense Report October 2026",
      reportMonth: "2026-10",
      reportDate: new Date("2026-10-01T00:00:00.000Z"),
      rows: [
        {
          componentName: "Direct Costs",
          financialCategoryName: "Direct Cost",
          amount: 225000,
          displayOrder: 1,
        },
        {
          componentName: "Indirect Costs",
          financialCategoryName: "Indirect Cost",
          amount: 53300,
          displayOrder: 2,
        },
        {
          componentName: "Misc Expenses",
          financialCategoryName: "Misc Expenses",
          amount: 1800,
          displayOrder: 3,
        },
        {
          componentName: "Miscellaneous Head",
          financialCategoryName: "Miscellaneous Expenses",
          amount: 800,
          displayOrder: 4,
        },
      ],
      unmatchedTallyRows: [
        {
          tallyLedgerName: 'Misc Office Expenses',
          amount: 500,
          resolutionStatus: 'UNRESOLVED',
        },
        {
          tallyLedgerName: 'Unmapped unrelated ledger',
          amount: 1000,
          resolutionStatus: 'UNRESOLVED',
        },
        {
          tallyLedgerName: 'Mapped miscellaneous ledger',
          amount: 200,
          resolutionStatus: 'EXCLUDED',
          resolutionReason: 'Excluded in test fixture',
        },
      ],
      fixedAssets: [
        { itemName: 'Equipment', amount: 200 },
      ],
      markup: {
        enabled: true,
        percentage: 20,
        baseType: "SUBTOTAL",
      },
      allocations: [
        {
          clientId: new mongoose.Types.ObjectId(),
          clientName: "Client One",
          allocationPercentage: firstAllocationPercentage,
          amount: 300000,
        },
        {
          clientId: new mongoose.Types.ObjectId(),
          clientName: "Client Two",
          allocationPercentage: 100 - firstAllocationPercentage,
          amount: 36120,
        },
      ],
      status: "REVIEW_PENDING",
      createdBy: new mongoose.Types.ObjectId(),
      updatedBy: new mongoose.Types.ObjectId(),
    });
  };

  test("adds fixed and miscellaneous amounts after markup in the billable total", () => {
    const report = createFinalizedReport();
    recalculateOperationalExpenseTotals(report);

    expect(OperationalExpenseReport.schema.path("fixedAssets")).toBeDefined();
    expect(OperationalExpenseReport.schema.path("fixedCosts")).toBeUndefined();
    expect(report.toObject().fixedAssets).toHaveLength(1);
    expect(report.totals.subtotal).toBe(278300);
    expect(report.totals.fixedCostTotal).toBe(200);
    expect(report.totals.miscellaneousExpenseTotal).toBe(2600);
    expect(report.totals.operationalExpenseTotal).toBe(336760);
  });

  test("allows a report with miscellaneous totals to validate", async () => {
    const report = createFinalizedReport();
    recalculateOperationalExpenseTotals(report);

    await expect(report.validate()).resolves.toBeUndefined();
  });

  test("allows an approved report to enter allocation pending", async () => {
    const report = createFinalizedReport();
    report.status = "ALLOCATION_PENDING";
    recalculateOperationalExpenseTotals(report);

    await expect(report.validate()).resolves.toBeUndefined();
  });
});
