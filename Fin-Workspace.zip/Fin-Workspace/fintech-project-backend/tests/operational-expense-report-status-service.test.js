import mongoose from 'mongoose';
import OperationalExpenseReport from '../src/modules/operational-expense/models/operational-expense-report-model.js';
import {
  isValidOperationalExpenseReportTransition,
  OPERATIONAL_EXPENSE_REPORT_STATUSES,
} from '../src/modules/operational-expense/services/operational-expense-report-status-service.js';

describe('Operational Expense report statuses', () => {
  test('defaults new reports to REVIEW_PENDING and exposes only workflow statuses', () => {
    const id = new mongoose.Types.ObjectId();
    const report = new OperationalExpenseReport({
      reportCode: 'OE-2026-10',
      reportName: 'Operational Expense Report October 2026',
      reportMonth: '2026-10',
      reportDate: new Date('2026-10-01T00:00:00.000Z'),
      createdBy: id,
      updatedBy: id,
    });
    const statusPath = OperationalExpenseReport.schema.path('status');

    expect(report.status).toBe('REVIEW_PENDING');
    expect(statusPath.enumValues).toEqual([
      'REVIEW_PENDING',
      'ALLOCATION_PENDING',
      'INVOICE_GENERATED',
    ]);
  });

  test.each([
    [
      OPERATIONAL_EXPENSE_REPORT_STATUSES.REVIEW_PENDING,
      OPERATIONAL_EXPENSE_REPORT_STATUSES.ALLOCATION_PENDING,
      true,
    ],
    [
      OPERATIONAL_EXPENSE_REPORT_STATUSES.ALLOCATION_PENDING,
      OPERATIONAL_EXPENSE_REPORT_STATUSES.INVOICE_GENERATED,
      true,
    ],
    [
      OPERATIONAL_EXPENSE_REPORT_STATUSES.REVIEW_PENDING,
      OPERATIONAL_EXPENSE_REPORT_STATUSES.INVOICE_GENERATED,
      false,
    ],
    [
      OPERATIONAL_EXPENSE_REPORT_STATUSES.ALLOCATION_PENDING,
      OPERATIONAL_EXPENSE_REPORT_STATUSES.REVIEW_PENDING,
      false,
    ],
    [
      OPERATIONAL_EXPENSE_REPORT_STATUSES.INVOICE_GENERATED,
      OPERATIONAL_EXPENSE_REPORT_STATUSES.ALLOCATION_PENDING,
      false,
    ],
  ])('validates transition %s -> %s', (currentStatus, nextStatus, expected) => {
    expect(
      isValidOperationalExpenseReportTransition(currentStatus, nextStatus),
    ).toBe(expected);
  });
});
