import express from 'express';
import { authenticateUser } from '../../middlewares/auth-middleware.js';
import {
  deleteOperationalExpenseReport,
  generateOperationalExpenseReport,
  getAllOperationalExpenseReports,
  getOperationalExpenseReportById,
  restartOperationalExpenseReport,
  updateOperationalExpenseReport,
  updateOperationalExpenseReportStatus,
} from '../../controllers/operational-expense-controllers/operational-expense-report-controller.js';
import {
  addOperationalExpenseFixedCost,
  deleteOperationalExpenseFixedCost,
  updateOperationalExpenseFixedCost,
} from '../../controllers/operational-expense-controllers/operational-expense-fixed-cost-controller.js';
import {
  deleteOperationalExpenseInvoiceAllocations,
  getOperationalExpenseInvoiceAllocation,
  upsertOperationalExpenseInvoiceAllocation,
} from '../../controllers/operational-expense-controllers/operational-expense-invoice-allocation-controller.js';
import {
  createInvoice,
  generateOperationalExpenseInvoices,
  getAllInvoices,
  updateInvoiceStatus,
} from '../../controllers/operational-expense-controllers/operational-expense-invoice-controller.js';

const operationalExpenseRouter = express.Router();

// CRUD operations for operational expense reports
operationalExpenseRouter.post(
  '/generateOperationalExpenseReport',
  authenticateUser,
  generateOperationalExpenseReport,
);
operationalExpenseRouter.get(
  '/getAllOperationalExpenseReports',
  authenticateUser,
  getAllOperationalExpenseReports,
);
operationalExpenseRouter.get(
  '/getOperationalExpenseReportById/:id',
  authenticateUser,
  getOperationalExpenseReportById,
);
operationalExpenseRouter.put(
  '/updateOperationalExpenseReport/:id',
  authenticateUser,
  updateOperationalExpenseReport,
);
operationalExpenseRouter.delete(
  '/deleteOperationalExpenseReport/:id',
  authenticateUser,
  deleteOperationalExpenseReport,
);
operationalExpenseRouter.delete(
  '/restartOperationalExpenseReport/:id',
  authenticateUser,
  restartOperationalExpenseReport,
);

// API to update the status of an operational expense report
operationalExpenseRouter.patch(
  '/:reportId/status',
  authenticateUser,
  updateOperationalExpenseReportStatus,
);
operationalExpenseRouter.patch(
  '/updateOperationalExpenseReportStatus/:id/status',
  authenticateUser,
  updateOperationalExpenseReportStatus,
);

// CRUD operations for fixed costs
operationalExpenseRouter.post(
  '/addOperationalExpenseFixedCost/:reportId/fixed-costs',
  authenticateUser,
  addOperationalExpenseFixedCost,
);
operationalExpenseRouter.patch(
  '/updateOperationalExpenseFixedCost/:reportId/fixed-costs/:fixedCostId',
  authenticateUser,
  updateOperationalExpenseFixedCost,
);
operationalExpenseRouter.delete(
  '/deleteOperationalExpenseFixedCost/:reportId/fixed-costs/:fixedCostId',
  authenticateUser,
  deleteOperationalExpenseFixedCost,
);

// CRUD - Invoice Allocations
operationalExpenseRouter.get(
  '/:reportId/invoice-allocation',
  authenticateUser,
  getOperationalExpenseInvoiceAllocation,
);

operationalExpenseRouter.put(
  '/:reportId/invoice-allocation',
  authenticateUser,
  upsertOperationalExpenseInvoiceAllocation,
);
operationalExpenseRouter.delete(
  '/:reportId/invoice-allocation',
  authenticateUser,
  deleteOperationalExpenseInvoiceAllocations,
);

// CRUD - Invoices
operationalExpenseRouter.post(
  '/:reportId/invoice',
  authenticateUser,
  createInvoice,
);

operationalExpenseRouter.get(
  '/getAllInvoices',
  authenticateUser,
  getAllInvoices,
);

operationalExpenseRouter.post(
  '/generateOperationalExpenseInvoices/:reportId',
  authenticateUser,
  generateOperationalExpenseInvoices,
);

// API to update the status of an Invoice
operationalExpenseRouter.patch(
  '/updateOperationalExpenseInvoiceStatus/:reportId/invoice/:invoiceId/status',
  authenticateUser,
  updateInvoiceStatus,
);

export default operationalExpenseRouter;
