export const getOperationalExpenseCategoryTotals = (rows) =>
  rows.reduce(
    (totals, row) => {
      const categoryName = String(row.financialCategoryName || "").toLowerCase();
      const amount = Math.max(0, Number(row.amount) || 0);

      if (categoryName.includes("misc")) {
        totals.miscellaneousExpenseTotal += amount;
      } else if (categoryName.includes("indirect")) {
        totals.totalIndirectCost += amount;
      } else {
        totals.totalDirectCost += amount;
      }

      return totals;
    },
    {
      totalDirectCost: 0,
      totalIndirectCost: 0,
      miscellaneousExpenseTotal: 0,
    },
  );

const roundCurrency = (amount) =>
  Math.round((Number(amount) + Number.EPSILON) * 100) / 100;

export const recalculateOperationalExpenseTotals = (report) => {
  const totals = report.totals;
  const markup = report.markup || 0;
  const rows = Array.isArray(report.rows) ? report.rows : [];
  const categoryTotals = getOperationalExpenseCategoryTotals(rows);
  const hasRows = rows.length > 0;

  totals.totalDirectCost = roundCurrency(
    hasRows
      ? categoryTotals.totalDirectCost
      : Math.max(0, Number(totals.totalDirectCost) || 0),
  );
  totals.totalIndirectCost = roundCurrency(
    hasRows
      ? categoryTotals.totalIndirectCost
      : Math.max(0, Number(totals.totalIndirectCost) || 0),
  );
  const directorRemuneration = Math.max(
    0,
    Number(totals.directorRemunerationTotal) || 0,
  );
  totals.totalIndirectCost = roundCurrency(
    totals.totalIndirectCost + directorRemuneration,
  );
  totals.directorRemunerationTotal = 0;
  totals.fixedCostTotal = roundCurrency(
    (report.fixedAssets || []).reduce(
      (total, fixedAsset) => total + (Number(fixedAsset.amount) || 0),
      0,
    ),
  );
  totals.miscellaneousExpenseTotal = roundCurrency(
    hasRows
      ? categoryTotals.miscellaneousExpenseTotal
      : Math.max(0, Number(totals.miscellaneousExpenseTotal) || 0),
  );
  totals.subtotal = roundCurrency(
    totals.totalDirectCost + totals.totalIndirectCost,
  );

  const markupBases = {
    SUBTOTAL: totals.subtotal,
    DIRECT_COST: totals.totalDirectCost,
    INDIRECT_COST: totals.totalIndirectCost,
    CUSTOM: Math.max(0, Number(markup.baseAmount) || 0),
  };

  markup.baseAmount = roundCurrency(
    markup.baseType === "CUSTOM"
      ? Math.max(0, Number(markup.baseAmount) || 0)
      : markupBases[markup.baseType] ?? totals.subtotal,
  );
  markup.amount = markup.enabled
    ? roundCurrency(
        (markup.baseAmount * Math.max(0, Number(markup.percentage) || 0)) / 100,
      )
    : 0;

  totals.markupAmount = markup.amount;
  totals.operationalExpenseTotal = roundCurrency(
    totals.subtotal +
      totals.markupAmount +
      totals.fixedCostTotal +
      totals.miscellaneousExpenseTotal,
  );
  totals.allocatedTotal = roundCurrency(
    (report.allocations || []).reduce(
      (total, allocation) => total + (Number(allocation.amount) || 0),
      0,
    ),
  );
  const unallocatedBalance = roundCurrency(
    totals.operationalExpenseTotal - totals.allocatedTotal,
  );
  totals.unallocatedBalance = Math.abs(unallocatedBalance) <= 0.01
    ? 0
    : unallocatedBalance;

  return totals;
};