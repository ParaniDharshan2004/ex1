export const GST_RATE = 18;
