import { describe, expect, test } from "vitest";

describe("Sample Test", () => {
  test("should pass", () => {
    expect(true).toBe(true);
  });
});