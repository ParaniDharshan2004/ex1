import { describe, expect, test } from 'vitest';
import {
  buildOperationalExpenseNavigationTarget,
  getOperationalExpenseBreadcrumbs,
} from '../utils/operationalExpense/navigation';

describe('Operational Expense navigation', () => {
  test.each([
    [
      '/operational-expenses/report-123',
      ['Clients', 'CRKL', 'OPEX', 'Upload & Review'],
    ],
    [
      '/operational-expense-allocation/report-123',
      ['Clients', 'CRKL', 'OPEX', 'Allocation'],
    ],
    ['/operational-expense-invoices', ['Clients', 'CRKL', 'Invoices']],
    ['/operational-expense-reports', ['Clients', 'CRKL', 'Reports']],
  ])('builds the expected breadcrumb hierarchy for %s', (pathname, labels) => {
    expect(
      getOperationalExpenseBreadcrumbs(pathname).map(({ label }) => label),
    ).toEqual(labels);
  });

  test('preserves report and workflow context in route targets', () => {
    const target = buildOperationalExpenseNavigationTarget('invoices', {
      pathname: '/operational-expense-allocation/report-123',
      search: '?period=2026-03&clientId=client-1&locationId=location-2',
      state: { period: '2026-03', client: 'CRKL', location: 'Chennai' },
    });

    expect(target).toEqual({
      to: {
        pathname: '/operational-expense-invoices/report-123',
        search: '?period=2026-03&clientId=client-1&locationId=location-2',
      },
      state: {
        reportId: 'report-123',
        period: '2026-03',
        clientId: 'client-1',
        client: 'CRKL',
        locationId: 'location-2',
        location: 'Chennai',
      },
    });
  });

  test('derives period from existing year and month query parameters', () => {
    const target = buildOperationalExpenseNavigationTarget('dashboard', {
      pathname: '/operational-expense-invoices',
      search: '?year=2026&month=3',
      state: null,
    });

    expect(target.state.period).toBe('2026-03');
    expect(target.to.search).toBe('?year=2026&month=3');
  });

  test('builds breadcrumbs when navigation state is null', () => {
    expect(
      getOperationalExpenseBreadcrumbs(
        '/operational-expense-reports',
        '',
        null,
      ).map(({ label }) => label),
    ).toEqual(['Clients', 'CRKL', 'Reports']);
  });
});
