export const formatIST = (date) => {
  if (!date) return "-";

  const istDate = new Date(
    new Date(date).toLocaleString("en-US", {
      timeZone: "Asia/Kolkata",
    })
  );

  const day = String(istDate.getDate()).padStart(2, "0");
  const month = String(istDate.getMonth() + 1).padStart(2, "0");
  const year = istDate.getFullYear();

  return `${day}-${month}-${year}`;
};