/**
 * Client and Location Allocation calculations.
 */
import { formatINR } from './currency.js';

export const calculateCrklBalance = (totalBillable, mkplAmount) => {
  const total = Number(totalBillable || 0);
  const mkpl = Math.max(0, Number(mkplAmount || 0));
  return Math.max(0, Number((total - mkpl).toFixed(2)));
};

export const calculateEqualLocationSplit = (totalAmount) => {
  const amount = Math.max(0, Number(totalAmount || 0));
  const half = Number((amount / 2).toFixed(2));
  const remaining = Number((amount - half).toFixed(2));
  return {
    chennai: half,
    bengaluru: remaining,
  };
};

export const calculateCustomLocationSplit = (
  totalAmount,
  enteredAmount,
  editedLocation,
) => {
  const total = Math.max(0, Number(totalAmount) || 0);
  const entered = Math.max(0, Number(enteredAmount) || 0);
  const remaining = Number(Math.max(0, total - entered).toFixed(2));

  return editedLocation === 'chennai'
    ? { chennai: entered, bengaluru: remaining }
    : { chennai: remaining, bengaluru: entered };
};

export const validateAllocationState = (
  totalBillable,
  mkplAmount,
  chennaiAmount,
  bengaluruAmount,
  splitMethod = 'equal',
) => {
  const total = Number(totalBillable || 0);
  const mkpl = Number(mkplAmount || 0);
  const c = Number(chennaiAmount || 0);
  const b = Number(bengaluruAmount || 0);

  if (total <= 0) {
    return {
      isValid: false,
      progressPercent: 0,
      severity: 'warn',
      message: 'No approved billable expenses found to allocate.',
      difference: 0,
    };
  }

  if (mkpl <= 0) {
    return {
      isValid: false,
      progressPercent: 0,
      severity: 'warn',
      message: 'Enter an amount charged to MKPL to begin allocation.',
      difference: 0,
    };
  }

  if (mkpl > total) {
    return {
      isValid: false,
      progressPercent: 100,
      severity: 'error',
      message: `MKPL amount (${formatINR(mkpl)}) cannot exceed total billable (${formatINR(total)}).`,
      difference: mkpl - total,
    };
  }

  if (
    splitMethod === 'custom' &&
    (c - mkpl >= 0.01 || b - mkpl >= 0.01)
  ) {
    const enteredAmount = Math.max(c, b);
    return {
      isValid: false,
      progressPercent: 100,
      severity: 'error',
      message: `Location amount (${formatINR(enteredAmount)}) cannot exceed the MKPL amount (${formatINR(mkpl)}).`,
      difference: enteredAmount - mkpl,
    };
  }

  const locationSum = Number((c + b).toFixed(2));
  const diff = Number((mkpl - locationSum).toFixed(2));
  const isValid = Math.abs(diff) < 0.01;

  const progressPercent = mkpl > 0 ? Math.min(100, Math.max(0, (locationSum / mkpl) * 100)) : 0;

  if (!isValid) {
    return {
      isValid: false,
      progressPercent,
      severity: 'warn',
      message: `Chennai + Bengaluru must equal MKPL. Difference: ${formatINR(diff)}`,
      difference: diff,
    };
  }

  return {
    isValid: true,
    progressPercent: 100,
    severity: 'ok',
    message: 'Allocation is balanced and ready for invoice review.',
    difference: 0,
  };
};
