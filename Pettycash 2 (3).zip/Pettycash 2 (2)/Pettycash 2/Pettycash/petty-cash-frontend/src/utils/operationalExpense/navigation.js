const REPORT_ID_PATHS = [
  /^\/operational-expenses\/([^/]+)\/?$/,
  /^\/operational-expense-allocation\/([^/]+)\/?$/,
  /^\/operational-expense-invoices\/([^/]+)\/?$/,
  /^\/operational-expense-finalize\/([^/]+)\/?$/,
];

export const OPERATIONAL_EXPENSE_ROUTES = {
  clients: {
    label: 'Clients',
    path: '/clients',
  },
  crkl: {
    label: 'CRKL',
    path: '/operational-expense-dashboard',
  },
  dashboard: {
    label: 'Dashboard',
    path: '/operational-expense-dashboard',
  },
  opex: {
    label: 'OPEX',
    path: '/operational-expense-dashboard',
  },
  selectMonth: {
    label: 'Select Month',
    path: '/operational-expense-dashboard',
  },
  uploadReview: {
    label: 'Upload & Review',
    path: '/operational-expenses',
    reportIdPath: true,
  },
  allocation: {
    label: 'Allocation',
    path: '/operational-expense-allocation',
    reportIdPath: true,
  },
  invoices: {
    label: 'Invoices',
    path: '/operational-expense-invoices',
    reportIdPath: true,
  },
  finalize: { label: 'Finalize Report', path: '/operational-expense-finalize', reportIdPath: true },
  reports: {
    label: 'Reports',
    path: '/operational-expense-reports',
  },
};

const getOperationalExpensePage = (pathname = '') => {
  if (/^\/operational-expenses(?:\/[^/]+)?\/?$/.test(pathname)) {
    return 'uploadReview';
  }
  if (/^\/operational-expense-allocation(?:\/[^/]+)?\/?$/.test(pathname)) {
    return 'allocation';
  }
  if (/^\/operational-expense-invoices(?:\/[^/]+)?\/?$/.test(pathname)) {
    return 'invoices';
  }
  if (/^\/operational-expense-finalize(?:\/[^/]+)?\/?$/.test(pathname)) return 'finalize';
  if (/^\/operational-expense-reports?\/?$/.test(pathname)) {
    return 'reports';
  }
  if (pathname === '/operational-expense-dashboard') {
    return 'dashboard';
  }
  return null;
};

export const getOperationalExpenseBreadcrumbs = (
  pathname,
  search = '',
  state = {},
) => {
  const page = getOperationalExpensePage(pathname);
  if (!page) return null;

  const searchParams = new URLSearchParams(search);
  const period = searchParams.get('period') || state?.period || '';
  if (page === 'dashboard' && searchParams.get('step') === 'select-month') {
    return ['clients', 'crkl', 'opex', 'selectMonth'].map((key) => ({
      key,
      ...OPERATIONAL_EXPENSE_ROUTES[key],
    }));
  }

  const routeKeys =
    page === 'uploadReview' || page === 'allocation'
      ? ['clients', 'crkl', 'opex', page]
      : page === 'dashboard'
        ? ['clients', 'crkl', 'opex']
        : ['clients', 'crkl', page];
  return routeKeys.map((key) => {
    const route = OPERATIONAL_EXPENSE_ROUTES[key];
    if (key === 'uploadReview' && period) {
      return {
        key,
        ...route,
        label: `Upload & Review`,
      };
    }
    return { key, ...route };
  });
};

const getReportId = (location) => {
  const pathMatch = REPORT_ID_PATHS.map((pattern) =>
    location.pathname.match(pattern),
  ).find(Boolean);
  const search = new URLSearchParams(location.search);

  return (
    pathMatch?.[1] ||
    location.state?.reportId ||
    search.get('reportId') ||
    ''
  );
};

const getNavigationState = (location, reportId) => {
  const state = {};
  const search = new URLSearchParams(location.search);
  const queryMonth = search.get('month') || '';
  const monthFromYearAndMonth =
    search.get('year') && /^\d{1,2}$/.test(queryMonth)
      ? `${search.get('year')}-${queryMonth.padStart(2, '0')}`
      : '';
  const monthAsPeriod = /^\d{4}-\d{1,2}$/.test(queryMonth)
    ? queryMonth.replace(/-(\d)$/, '-0$1')
    : '';
  const period =
    location.state?.period ||
    search.get('period') ||
    monthFromYearAndMonth ||
    monthAsPeriod;

  if (reportId) state.reportId = reportId;
  if (period) state.period = period;

  for (const key of ['clientId', 'client', 'locationId', 'location']) {
    const value = location.state?.[key] ?? search.get(key);
    if (value) state[key] = value;
  }

  return state;
};

export const buildOperationalExpenseNavigationTarget = (
  routeKey,
  location,
) => {
  const route = OPERATIONAL_EXPENSE_ROUTES[routeKey];
  if (!route) {
    throw new Error(`Unknown Operational Expense route: ${routeKey}`);
  }

  const reportId = getReportId(location);
  const pathname =
    route.reportIdPath && reportId
      ? `${route.path}/${encodeURIComponent(reportId)}`
      : route.path;
  const searchParams = new URLSearchParams(location.search);
  if (routeKey === 'selectMonth') {
    searchParams.set('step', 'select-month');
    const period =
      location.state?.period || searchParams.get('period') || '';
    if (period) {
      searchParams.set('period', period);
      searchParams.set('year', period.slice(0, 4));
    }
  } else {
    searchParams.delete('step');
  }
  const search = searchParams.size ? `?${searchParams.toString()}` : '';

  return {
    to: { pathname, search },
    state: getNavigationState(location, reportId),
  };
};

export const getOperationalExpenseTargetForPath = (path, location) => {
  const normalizedPath = String(path || '').replace(/\/+$/, '') || '/';
  const routeEntry = Object.entries(OPERATIONAL_EXPENSE_ROUTES).find(
    ([, route]) => route.path === normalizedPath,
  );

  return routeEntry
    ? buildOperationalExpenseNavigationTarget(routeEntry[0], location)
    : null;
};
