export const sortClientAllocationsForPreview = (allocations) =>
  allocations
    .map((allocation) => {
      return {
        id: allocation.clientMaster?._id || allocation.clientId,
        clientName: allocation.clientMaster?.clientName || allocation.clientName,
        amount: Number(
          allocation.clientTotalAmount ??
            allocation.allocatedAmount ??
            allocation.amount ??
            0,
        ),
        displayOrder: allocation.clientMaster?.displayOrder,
      };
    })
    .sort(
      (first, second) =>
        (first.displayOrder ?? Number.POSITIVE_INFINITY) -
        (second.displayOrder ?? Number.POSITIVE_INFINITY),
    );
