/**
 * Operational expense calculation helpers matching business rules.
 */

const isMiscellaneousExpense = (item) =>
  /\bmisc(?:ellaneous)?\b/i.test(
    String(
      Array.isArray(item)
        ? item[0]
        : item?.financialCategoryName || item?.category || '',
    ),
  );

const getExpenseCategory = (item) =>
  String(Array.isArray(item) ? item[0] : item?.financialCategoryName || item?.category || '')
    .trim()
    .toLowerCase();

const getExpenseAmount = (item) =>
  Number(Array.isArray(item) ? item[2] : item?.amount ?? item?.sourceAmount ?? 0);

const getCategoryOrder = (category) => {
  const value = String(category || '').trim().toLowerCase();
  if (value.includes('indirect')) return 2;
  if (value.includes('direct')) return 1;
  if (value.includes('fixed')) return 3;
  if (value.includes('misc')) return 4;
  return 5;
};
 
export const calculateSubtotal = (expenses = []) => {
  if (!Array.isArray(expenses)) return 0;
  return expenses.reduce((sum, item) => {
    const category = getExpenseCategory(item);
    if (!category.includes('direct') && !category.includes('indirect')) return sum;
    const amount = getExpenseAmount(item);
    return sum + (Number.isFinite(amount) ? amount : 0);
  }, 0);
};
 
export const calculateMarkup = (subtotal, markupRate = 0.20) => {
  const numericSubtotal = Number(subtotal || 0);
  return Number((numericSubtotal * markupRate).toFixed(2));
};
 
export const calculateTotalBillable = (
  subtotal,
  markupAmount,
  additionalCosts = 0,
) => {
  const s = Number(subtotal || 0);
  const m = markupAmount !== undefined ? Number(markupAmount || 0) : calculateMarkup(s);
  return Number((s + m + Number(additionalCosts || 0)).toFixed(2));
};

export const calculateOtherExpenseTotal = (expenses = []) =>
  Number(
    expenses
      .filter((expense) => {
        const category = getExpenseCategory(expense);
        return (
          category &&
          !category.includes('direct') &&
          !category.includes('indirect') &&
          !isMiscellaneousExpense(expense) &&
          !category.includes('fixed')
        );
      })
      .reduce((total, expense) => {
        const amount = getExpenseAmount(expense);
        return total + (Number.isFinite(amount) ? amount : 0);
      }, 0)
      .toFixed(2),
  );

export const calculateOperationalExpenseCategoryTotals = (expenses = []) =>
  expenses.reduce(
    (totals, expense) => {
      const category = String(
        Array.isArray(expense)
          ? expense[0]
          : expense?.financialCategoryName || expense?.category || '',
      ).toLowerCase();
      const amount = Number(
        Array.isArray(expense)
          ? expense[2]
          : expense?.amount ?? expense?.sourceAmount ?? 0,
      );
      if (!Number.isFinite(amount)) return totals;

      if (category.includes('indirect')) {
        totals.indirectCostTotal += amount;
      } else if (category.includes('direct')) {
        totals.directCostTotal += amount;
      }

      return totals;
    },
    { directCostTotal: 0, indirectCostTotal: 0 },
  );
 
export const groupExpensesByCategory = (expenses = []) => {
  if (!Array.isArray(expenses)) return [];
 
  // Normalize first without changing the backend-provided row order.
  const normalized = expenses.map((item, idx) => {
    if (Array.isArray(item)) {
      const description = item[1] || '';
      return {
        id: `exp-${idx}`,
        category: item[0] || '',
        description,
        amount: Number(item[2]) || 0,
        displayOrder: idx,
      };
    }
    const description = item.componentName || item.description || '';
    return {
      id: item._id || item.id || `exp-${idx}`,
      componentId: item.componentId,
      componentCode: item.componentCode,
      rowSource: item.rowSource,
      matchStatus: item.matchStatus,
      hasTallyExpense: item.hasTallyExpense,
      category: item.financialCategoryName || item.category || '',
      description,
      amount: Number(item.amount ?? item.sourceAmount ?? 0),
      displayOrder: Number.isFinite(
        Number(
          item.displayOrder ??
            item.componentDisplayOrder ??
            item.subComponentDisplayOrder ??
            item.componentId?.displayOrder,
        ),
      )
        ? Number(
            item.displayOrder ??
              item.componentDisplayOrder ??
              item.subComponentDisplayOrder ??
              item.componentId?.displayOrder,
          )
        : idx,
    };
  });
 
  // Keep category order based on the first backend row for that category,
  // while moving all rows belonging to the category under one parent header.
  const categoryGroups = new Map();
  normalized.forEach((row) => {
    if (!row.category) return;
    const normalizedCategory = String(row.category).trim().toLowerCase();
    const groupKey = /\bmisc(?:ellaneous)?\b/.test(normalizedCategory)
      ? 'miscellaneous expenses'
      : normalizedCategory;
    if (!categoryGroups.has(groupKey)) {
      categoryGroups.set(groupKey, { category: row.category, rows: [] });
    }
    categoryGroups.get(groupKey).rows.push(row);
  });

  return Array.from(categoryGroups.entries())
    .sort(([first], [second]) => {
      const orderDifference = getCategoryOrder(first) - getCategoryOrder(second);
      return orderDifference || first.localeCompare(second);
    })
    .flatMap(([, group]) =>
      group.rows
        .sort((first, second) => first.displayOrder - second.displayOrder)
        .map((row) => ({
          ...row,
          category: group.category.toLowerCase().includes('misc')
            ? 'Misc expenses'
            : group.category.toLowerCase().includes('fixed')
              ? 'Fixed Asset'
              : group.category,
        })),
    );
};