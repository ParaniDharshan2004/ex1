const normalizeLedgerName = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .split(/\s+/)
    .map((word) =>
      word.endsWith('s') && !word.endsWith('ss') ? word.slice(0, -1) : word,
    )
    .filter(Boolean)
    .join(' ')
    .trim();

const matchesLedgerName = (ledgerName, masterName) => {
  const normalizedLedger = normalizeLedgerName(ledgerName);
  const normalizedMaster = normalizeLedgerName(masterName);
  return Boolean(
    normalizedLedger &&
      normalizedMaster &&
      (normalizedLedger === normalizedMaster ||
        normalizedLedger.includes(normalizedMaster) ||
        normalizedMaster.includes(normalizedLedger)),
  );
};

const matchesExactLedgerName = (ledgerName, masterName) =>
  normalizeLedgerName(ledgerName) === normalizeLedgerName(masterName);

export const isUnresolvedTallyRow = (row) =>
  !['MAPPED', 'EXCLUDED', 'ADDED_TO_REPORT'].includes(
    row?.resolutionStatus,
  );

export const isManagedComponentUnmatchedRow = (
  row,
  components = [],
  subComponents = [],
) => {
  const normalizeManagedName = (value) =>
    normalizeLedgerName(value)
      .split(/\s+/)
      .filter((word) => word !== 'and')
      .join(' ');
  const ledgerName = normalizeManagedName(
    row?.tallyLedgerName || row?.particularName,
  );
  if (!ledgerName) return false;

  return [...components, ...subComponents].some((item) =>
    [
      item.componentName,
      item.componentCode,
      item.subComponentName,
      item.subComponentCode,
    ]
      .filter(Boolean)
      .some((name) => normalizeManagedName(name) === ledgerName),
  );
};

export const isMiscellaneousExpense = (item) =>
  /\bmisc(?:ellaneous)?\b/i.test(
    String(item?.financialCategoryName || item?.category || ''),
  );

export const calculateMiscellaneousExpenseTotal = (rows = []) =>
  Number(
    rows
      .filter(isMiscellaneousExpense)
      .reduce((total, row) => total + (Number(row.amount) || 0), 0)
      .toFixed(2),
  );

export const aggregateTallyRowsByHeadComponent = (
  tallyRows = [],
  components = [],
  subComponents = [],
  categories = [],
) => {
  const categoryById = new Map(
    categories.map((category) => [String(category._id), category]),
  );
  const totalsByComponent = new Map();
  const unmatchedRows = [];

  tallyRows.forEach(([sourceCategory, description, amount], index) => {
    const exactDirectComponent = components.find((component) =>
      [component.componentName, component.componentCode, component.description]
        .filter(Boolean)
        .some((name) => matchesExactLedgerName(description, name)),
    );
    const exactSubComponent = exactDirectComponent
      ? null
      : subComponents.find((subComponent) =>
          [subComponent.subComponentName, subComponent.subComponentCode]
            .filter(Boolean)
            .some((name) => matchesExactLedgerName(description, name)),
        );
    const matchedSubComponent =
      exactSubComponent ||
      (!exactDirectComponent &&
        subComponents.find((subComponent) =>
          [subComponent.subComponentName, subComponent.subComponentCode]
            .filter(Boolean)
            .some((name) => matchesLedgerName(description, name)),
        ));
    const parentId =
      matchedSubComponent?.componentId?._id || matchedSubComponent?.componentId;
    const directComponent =
      exactDirectComponent ||
      (!matchedSubComponent &&
        components.find((component) =>
          [component.componentName, component.componentCode]
            .filter(Boolean)
            .some((name) => matchesLedgerName(description, name)),
        ));
    const parentComponent =
      directComponent ||
      components.find((component) => String(component._id) === String(parentId)) ||
      null;

    if (!parentComponent) {
      unmatchedRows.push({
        tallyLedgerName: description || sourceCategory || 'Unnamed Tally row',
        amount: Number(amount) || 0,
        reason: `No matching head component or subcomponent${sourceCategory ? ` for category "${sourceCategory}"` : ''}.`,
        resolutionStatus: 'UNRESOLVED',
      });
      return;
    }

    const componentId = String(parentComponent._id);
    if (!totalsByComponent.has(componentId)) {
      const category =
        typeof parentComponent.financialCategoryId === 'object'
          ? parentComponent.financialCategoryId
          : categoryById.get(String(parentComponent.financialCategoryId));
      const categoryName =
        category?.categoryName ||
        categories.find(
          (item) =>
            normalizeLedgerName(item.categoryName) ===
            normalizeLedgerName(sourceCategory),
        )?.categoryName;
      if (!categoryName) {
        unmatchedRows.push({
          tallyLedgerName: description || sourceCategory || 'Unnamed Tally row',
          amount: Number(amount) || 0,
          reason: `Matched component "${parentComponent.componentName}" has no financial category.`,
          resolutionStatus: 'UNRESOLVED',
        });
        return;
      }
      totalsByComponent.set(componentId, {
        componentId: parentComponent._id,
        componentCode: parentComponent.componentCode,
        componentName: parentComponent.componentName,
        category: categoryName,
        financialCategoryName: categoryName,
        rowSource: 'TALLY_IMPORT',
        displayOrder: Number(parentComponent.displayOrder ?? index),
        directAmounts: [],
        subComponentAmounts: [],
      });
    }

    const componentTotal = totalsByComponent.get(componentId);
    const numericAmount = Number(amount) || 0;
    if (directComponent) {
      componentTotal.directAmounts.push(numericAmount);
    } else {
      componentTotal.subComponentAmounts.push(numericAmount);
    }
  });

  const matchedRows = Array.from(totalsByComponent.values())
    .map((component) => {
      const hasDirectMatch = component.directAmounts.length > 0;
      const amounts = hasDirectMatch
        ? component.directAmounts
        : component.subComponentAmounts;

      return {
        componentId: component.componentId,
        componentCode: component.componentCode,
        componentName: component.componentName,
        category: component.category,
        financialCategoryName: component.financialCategoryName,
        rowSource: component.rowSource,
        displayOrder: component.displayOrder,
        description: component.componentName,
        amount: amounts.reduce((total, value) => total + value, 0),
        matchStatus: hasDirectMatch
          ? 'HEAD_COMPONENT_MATCHED'
          : 'CALCULATED_FROM_SUBCOMPONENTS',
        hasTallyExpense: true,
      };
    })
    .sort((first, second) => first.displayOrder - second.displayOrder);

  return { matchedRows, unmatchedRows };
};
