/**
 * Status mapping and styling helpers matching the reference command center.
 */

export const isInvoiceGeneratedStatus = (status) => {
  const raw = String(status || '').toUpperCase();
  return raw === 'INVOICED' || raw === 'INVOICE_GENERATED';
};
export const isReportFinalizedStatus = (status) => String(status || '').toUpperCase() === 'REPORT_FINALIZED';

export const mapStatusToDisplay = (status) => {
  const raw = String(status || '').toUpperCase();

  if (isInvoiceGeneratedStatus(raw)) {
    return {
      label: 'Invoices Generated',
      className: 's-complete',
      color: 'success',
    };
  }
  if (raw === 'REPORT_FINALIZED') return { label: 'Report Finalized', className: 's-complete', color: 'success' };
  if (raw === 'ALLOCATION_COMPLETE') return { label: 'Allocation Complete', className: 's-allocation', color: 'info' };

  if (raw === 'ALLOCATION_PENDING') {
    return {
      label: 'Allocation Pending',
      className: 's-allocation',
      color: 'info',
    };
  }

  if (raw === 'REVIEW_PENDING') {
    return {
      label: 'Review Pending',
      className: 's-review',
      color: 'warning',
    };
  }

  if (raw === 'DRAFT') {
    return {
      label: 'Draft',
      className: 's-review',
      color: 'warning',
    };
  }

  return {
    label: status || 'Unknown status',
    className: 's-review',
    color: 'warning',
  };
};

export const WORKFLOW_STEPS = [
  { label: 'Select Month', stepNumber: 1 },
  { label: 'Upload & Review', stepNumber: 2 },
  { label: 'Allocation', stepNumber: 3 },
  { label: 'Finalize Report', stepNumber: 4 },
];
