/**
 * Validation helpers for operational expense workflow.
 */

export const isValidPeriod = (period) => {
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(String(period || ''));
};

export const isValidDate = (dateString) => {
  if (!dateString) return false;
  const date = new Date(dateString);
  return !Number.isNaN(date.getTime());
};

export const isSupportedReportFileType = (filename) => {
  if (!filename) return false;
  const ext = filename.toLowerCase().split('.').pop();
  return ['csv', 'txt', 'xlsx', 'xls', 'pdf'].includes(ext);
};
