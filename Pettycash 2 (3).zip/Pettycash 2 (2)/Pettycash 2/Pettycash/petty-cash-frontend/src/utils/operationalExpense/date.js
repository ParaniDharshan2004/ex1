/**
 * Date and Month formatting utilities matching the reference command center.
 */

export const formatMonthYear = (period) => {
  if (!period) return '';
  const match = String(period).match(/^(\d{4})-(0[1-9]|1[0-2])$/);
  if (!match) return String(period);
  const year = match[1];
  const month = parseInt(match[2], 10) - 1;
  const date = new Date(year, month, 1);
  return date.toLocaleString('en-IN', { month: 'long', year: 'numeric' });
};

export const formatDate = (dateValue) => {
  if (!dateValue) return '';
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return String(dateValue);
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

export const formatDateTime = (dateValue) => {
  if (!dateValue) return '';
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return String(dateValue);
  return date.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
};

export const getCurrentPeriod = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
};

export const getCurrentDate = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const getProposedInvoiceDate = (period) => {
  if (!period) return '';
  const match = String(period).match(/^(\d{4})-(0[1-9]|1[0-2])$/);
  if (!match) return '';
  let year = parseInt(match[1], 10);
  let month = parseInt(match[2], 10); // 1-12
  // Next month
  month += 1;
  if (month > 12) {
    month = 1;
    year += 1;
  }
  return `${year}-${String(month).padStart(2, '0')}-01`;
};
