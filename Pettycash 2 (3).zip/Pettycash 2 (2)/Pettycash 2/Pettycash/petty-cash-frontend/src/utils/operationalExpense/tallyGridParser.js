const normalizeHeader = (value) =>
  String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z]+/g, '');

const parseAmount = (value) => {
  if (typeof value === 'number') {
    return Number.isFinite(value) && value > 0 ? value : null;
  }

  const text = String(value ?? '').trim();
  if (!text) return null;

  const isNegative = /^\(.*\)$/.test(text);
  const normalized = text
    .replace(/[(),\s₹$€£]/g, '')
    .replace(/,/g, '');
  if (!/^-?\d+(?:\.\d+)?$/.test(normalized)) return null;

  const amount = Number(normalized);
  if (!Number.isFinite(amount) || amount <= 0 || isNegative) return null;
  return amount;
};

const findTallyColumns = (grid) => {
  const scanRows = grid.slice(0, 30);
  let particularsColumn = -1;
  let debitColumn = -1;
  let creditColumn = -1;

  scanRows.forEach((row) => {
    row.forEach((cell, column) => {
      const header = normalizeHeader(cell);
      if (header === 'particular' || header === 'particulars') {
        particularsColumn = column;
      } else if (header === 'debit') {
        debitColumn = column;
      } else if (header === 'credit') {
        creditColumn = column;
      }
    });
  });

  return particularsColumn >= 0 && (debitColumn >= 0 || creditColumn >= 0)
    ? { particularsColumn, debitColumn, creditColumn }
    : null;
};

export const extractTallyRowsFromGrid = (grid = []) => {
  const columns = findTallyColumns(grid);
  if (columns) {
    return grid.flatMap((row) => {
      const description = String(row[columns.particularsColumn] ?? '').trim();
      if (!description || normalizeHeader(description) === 'particulars') {
        return [];
      }

      const debit = parseAmount(row[columns.debitColumn]);
      const credit = parseAmount(row[columns.creditColumn]);
      const amount = debit ?? credit;
      return amount === null ? [] : [['', description, amount]];
    });
  }

  return grid.flatMap((row) => {
    if (!Array.isArray(row) || row.length < 2) return [];
    const amount = parseAmount(row[row.length - 1]);
    if (amount === null) return [];

    const category = row.length > 2 ? String(row[0] ?? '').trim() : '';
    const description = row
      .slice(row.length > 2 ? 1 : 0, -1)
      .map((value) => String(value ?? '').trim())
      .filter(Boolean)
      .join(' ');
    return description ? [[category, description, amount]] : [];
  });
};
