const normalizeLedgerName = (value) =>
  String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

const findFixedCostMatch = (ledgerName, assets, categories) => {
  const normalizedLedger = normalizeLedgerName(ledgerName);
  if (!normalizedLedger) return null;

  const asset = assets.find(({ assetName, aliases = [] }) =>
    [assetName, ...aliases].some(
      (name) => normalizeLedgerName(name) === normalizedLedger,
    ),
  );
  if (asset) return { itemName: asset.assetName, categoryName: asset.categoryId?.categoryName || '' };

  const category = categories.find(
    (item) => normalizeLedgerName(item.categoryName) === normalizedLedger,
  );
  return category
    ? { itemName: category.categoryName, categoryName: category.categoryName }
    : null;
};

export const splitTallyRowsByFixedCost = (
  rows = [],
  assets = [],
  categories = [],
) => {
  const fixedCosts = [];
  const operationalRows = [];

  rows.forEach(([sourceCategory, description, amount]) => {
    const matched =
      findFixedCostMatch(description, assets, categories) ||
      findFixedCostMatch(sourceCategory, assets, categories) ||
      (normalizeLedgerName(sourceCategory) === 'fixed cost'
        ? { itemName: description || 'Fixed Cost', categoryName: '' }
        : null);

    if (!matched) {
      operationalRows.push([sourceCategory, description, amount]);
      return;
    }

    fixedCosts.push({
      itemName: matched.itemName,
      description: [
        matched.categoryName ? `Category: ${matched.categoryName}` : '',
        `Tally ledger: ${description || sourceCategory}`,
      ]
        .filter(Boolean)
        .join(' | '),
      amount: Number(amount) || 0,
    });
  });

  return { fixedCosts, operationalRows };
};

export const calculateFixedCostTotal = (fixedCosts = []) =>
  Number(
    fixedCosts
      .reduce((total, item) => total + (Number(item.amount) || 0), 0)
      .toFixed(2),
  );
