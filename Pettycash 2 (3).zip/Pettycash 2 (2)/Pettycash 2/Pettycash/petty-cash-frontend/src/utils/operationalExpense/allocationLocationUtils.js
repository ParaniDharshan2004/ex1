const locationMatches = (location, cityNames, locationCodes) => {
  const name = String(location?.locationName || '').toLowerCase();
  const code = String(location?.locationCode || '').toUpperCase();
  const codeTokens = code.split(/[^A-Z0-9]+/).filter(Boolean);

  return (
    cityNames.some((city) => name.includes(city)) ||
    codeTokens.some((token) =>
      locationCodes.some((locationCode) => token.startsWith(locationCode)),
    )
  );
};

export const findChennaiLocation = (locations = []) =>
  locations.find((location) =>
    locationMatches(location, ['chennai', 'madras'], ['CHN', 'MAA']),
  ) || null;

export const findBengaluruLocation = (locations = []) =>
  locations.find((location) =>
    locationMatches(location, ['bengaluru', 'bangalore'], ['BLR']),
  ) || null;

export const describeLocations = (locations = []) =>
  locations.length
    ? locations
        .map(({ locationName, locationCode }) =>
          locationCode
            ? `${locationName || 'Unnamed location'} (${locationCode})`
            : locationName || 'Unnamed location',
        )
        .join(', ')
    : 'none returned';
