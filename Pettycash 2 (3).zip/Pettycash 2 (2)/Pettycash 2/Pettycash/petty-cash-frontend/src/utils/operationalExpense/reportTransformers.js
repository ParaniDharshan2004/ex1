/**
 * Transformers for reports, invoices, calendar, and KPIs.
 */
import { formatMonthYear, formatDateTime, formatDate } from './date.js';
import { isInvoiceGeneratedStatus, mapStatusToDisplay } from './statusHelpers.js';
import {
  calculateSubtotal,
  calculateMarkup,
  calculateOtherExpenseTotal,
  calculateTotalBillable,
} from './expenseCalculations.js';
import { calculateFixedCostTotal } from './fixedCostImport.js';
import { calculateMiscellaneousExpenseTotal } from './tallyHeadComponentImport.js';

const calculateReportBillable = (report) => {
  const rows =
    [report.rows, report.reportRows, report.items, report.expenses].find(
      (candidate) => Array.isArray(candidate) && candidate.length > 0,
    ) || [];
  const fixedAssets =
    [report.fixedAssets, report.fixedCosts].find(
      (candidate) => Array.isArray(candidate) && candidate.length > 0,
    ) || [];
  const hasDetailData = rows.length > 0 || fixedAssets.length > 0;
  const calculatedSubtotal = calculateSubtotal(rows);
  const subtotal = hasDetailData
    ? Math.max(Number(report.totals?.subtotal) || 0, calculatedSubtotal)
    : Number(report.totals?.subtotal ?? calculatedSubtotal);
  const markup = Number(
    report.totals?.markupAmount || calculateMarkup(subtotal),
  );
  const fixedCostTotal = Number(
    hasDetailData
      ? Math.max(
          Number(report.totals?.fixedCostTotal) || 0,
          calculateFixedCostTotal(fixedAssets),
        )
      : report.totals?.fixedCostTotal ??
          calculateFixedCostTotal(fixedAssets),
  );
  const miscellaneousExpenseTotal = Number(
    hasDetailData
      ? Math.max(
          Number(
            report.totals?.miscellaneousExpenseTotal ??
              report.totals?.miscExpensesTotal,
          ) || 0,
          calculateMiscellaneousExpenseTotal(rows),
        )
      : report.totals?.miscellaneousExpenseTotal ??
          report.totals?.miscExpensesTotal ??
          calculateMiscellaneousExpenseTotal(rows),
  );
  const otherExpenseTotal = Number(
    hasDetailData
      ? Math.max(
          Number(report.totals?.otherExpenseTotal) || 0,
          calculateOtherExpenseTotal(rows),
        )
      : report.totals?.otherExpenseTotal ??
          calculateOtherExpenseTotal(rows),
  );

  const calculatedBillable = calculateTotalBillable(
    subtotal,
    markup,
    fixedCostTotal + miscellaneousExpenseTotal + otherExpenseTotal,
  );
  return hasDetailData
    ? calculatedBillable
    : Number(
        report.totals?.operationalExpenseTotal ??
          report.totals?.totalBillable ??
          calculatedBillable,
      );
};

export const transformReportSummary = (report) => {
  if (!report) return null;
  const id = report._id || report.id;
  const period = report.reportMonth || (report.reportDate ? String(report.reportDate).slice(0, 7) : '');
  const draftCode = report.reportCode || `OE-${period}`;
  const version = report.version || 1;

  const rows =
    [report.rows, report.reportRows, report.items, report.expenses].find(
      (candidate) => Array.isArray(candidate) && candidate.length > 0,
    ) || [];
  const subtotal = Number(
    report.totals?.subtotal || calculateSubtotal(rows),
  );
  const markup = Number(
    report.totals?.markupAmount || calculateMarkup(subtotal),
  );
  const totalBillable = calculateReportBillable(report);

  const statusInfo = mapStatusToDisplay(report.status);
  const updated = report.updatedAt ? formatDateTime(report.updatedAt) : (report.createdAt ? formatDateTime(report.createdAt) : 'Recently');

  return {
    id,
    period,
    periodFormatted: formatMonthYear(period),
    draftCode,
    version,
    subtotal,
    markup,
    totalBillable,
    status: statusInfo.label,
    rawStatus: report.status,
    statusClass: statusInfo.className,
    updated,
    rawReport: report,
  };
};

export const calculateDashboardKpis = (reports = []) => {
  const activeReports = reports;
  const completed = activeReports.filter((report) =>
    isInvoiceGeneratedStatus(report.status),
  );
  const pending = activeReports.length - completed.length;

  const invoicedValue = completed.reduce((sum, r) => {
    const val = calculateReportBillable(r);
    return sum + (Number.isFinite(val) ? val : 0);
  }, 0);

  return {
    totalRecords: activeReports.length,
    pendingActions: pending,
    completed: completed.length,
    invoicedValue,
  };
};

export const buildTwelveMonthCalendar = (selectedYear, allInvoices = []) => {
  const yearStr = String(selectedYear || new Date().getFullYear());
  const months = [];

  for (let i = 0; i < 12; i++) {
    const monthNum = String(i + 1).padStart(2, '0');
    const period = `${yearStr}-${monthNum}`;
    const monthDate = new Date(Number(yearStr), i, 1);
    const monthName = monthDate.toLocaleString('en-IN', { month: 'long' });

    const monthInvoices = allInvoices.filter((inv) => {
      const p = inv.period || inv.reportMonth || (inv.operationalExpenseReportId?.reportMonth);
      return p === period;
    });

    const totalAmount = monthInvoices.reduce((s, inv) => s + (Number(inv.grandTotal ?? inv.amount) || 0), 0);
    const invoiceCount = monthInvoices.length;

    months.push({
      monthNum,
      period,
      monthName,
      totalAmount,
      invoiceCount,
      hasRecords: invoiceCount > 0,
    });
  }

  return months;
};

export const normalizeInvoiceItem = (inv) => {
  const id = inv._id || inv.id;
  const no = inv.invoiceNo || inv.invoiceNumber || inv.no || (id ? `INV-${String(id).slice(-6).toUpperCase()}` : 'DRAFT');
  const client = inv.clientId?.clientName || inv.clientName || inv.client || 'Client';
  const clientDisplayOrder = Number(
    inv.clientId?.displayOrder ?? inv.client?.displayOrder ?? inv.displayOrder,
  );
  const location = inv.locationId?.locationName || inv.locationName || inv.location || 'Corporate';
  const gstin =
    inv.clientTaxDetails?.gstin ||
    inv.locationId?.gstNumber ||
    inv.locationId?.gstin ||
    inv.gstin ||
    '';
  const amount = Number(inv.grandTotal ?? inv.amount ?? 0);
  const taxableAmount = Number(inv.taxableAmount);
  const gstAmount = Number(inv.gstAmount);
  const gstRate = Number(inv.gstRate);
  const period = inv.period || inv.expensePeriod || inv.operationalExpenseReportId?.reportMonth || '';
  const date = inv.invoiceDate ? formatDate(inv.invoiceDate) : (inv.createdAt ? formatDate(inv.createdAt) : '');
  const status = inv.status || 'GENERATED';

  return {
    id,
    no,
    client,
    clientDisplayOrder: Number.isFinite(clientDisplayOrder) ? clientDisplayOrder : null,
    location,
    amount,
    taxableAmount,
    gstAmount,
    gstRate,
    grandTotal: amount,
    period,
    periodFormatted: formatMonthYear(period),
    date,
    status,
    clientAddress:
      inv.clientAddress || inv.locationId?.billingAddress || '',
    clientPinCode: inv.clientPinCode || inv.locationId?.pinCode || '',
    clientState:
      inv.clientState ||
      [inv.locationId?.stateName, inv.locationId?.stateCode]
        .filter(Boolean)
        .join(' - '),
    gstin,
    clientTaxDetails: {
      gstin,
      pan: inv.clientTaxDetails?.pan || inv.locationId?.panNumber || '',
      tan: inv.clientTaxDetails?.tan || inv.locationId?.tanNumber || '',
    },
    hsnSac: inv.hsnSac || '',
    rawInvoice: inv,
  };
};
