/**
 * INR Currency formatting utilities matching the reference command center.
 */

export const formatINR = (amount, options = {}) => {
  const numeric = Number(amount || 0);
  if (!Number.isFinite(numeric)) return '₹ 0.00';

  const {
    minimumFractionDigits = 2,
    maximumFractionDigits = 2,
    showSymbol = true,
  } = options;

  const formatted = numeric.toLocaleString('en-IN', {
    minimumFractionDigits,
    maximumFractionDigits,
  });

  return showSymbol ? `₹ ${formatted}` : formatted;
};

export const formatUSD = (amount, options = {}) => {
  const numeric = Number(amount || 0);
  if (!Number.isFinite(numeric)) return '$ 0.00';

  const {
    minimumFractionDigits = 2,
    maximumFractionDigits = 2,
    showSymbol = true,
  } = options;

  const formatted = numeric.toLocaleString('en-US', {
    minimumFractionDigits,
    maximumFractionDigits,
  });

  return showSymbol ? `$ ${formatted}` : formatted;
};

export const isCrklInvoice = (invoice) => {
  const clientCode =
    invoice?.clientCode ||
    invoice?.rawInvoice?.clientId?.clientCode ||
    invoice?.clientId?.clientCode ||
    '';
  const clientName =
    invoice?.client ||
    invoice?.clientName ||
    invoice?.rawInvoice?.clientId?.clientName ||
    invoice?.clientId?.clientName ||
    '';

  return /CRKL/i.test(String(clientCode)) || /CRKL/i.test(String(clientName));
};

export const parseNumber = (value) => {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
  if (!value) return 0;
  const cleaned = String(value).replace(/[^0-9.-]/g, '');
  const parsed = parseFloat(cleaned);
  return Number.isFinite(parsed) ? parsed : 0;
};

const wordsBelowHundred = (number) => {
  const ones = [
    'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight',
    'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen',
    'sixteen', 'seventeen', 'eighteen', 'nineteen',
  ];
  const tens = [
    '', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy',
    'eighty', 'ninety',
  ];

  if (number < 20) return ones[number];
  return `${tens[Math.floor(number / 10)]}${number % 10 ? ` ${ones[number % 10]}` : ''}`;
};

const integerToWords = (number) => {
  if (number < 100) return wordsBelowHundred(number);
  if (number < 1000) {
    const remainder = number % 100;
    return `${wordsBelowHundred(Math.floor(number / 100))} hundred${remainder ? ` ${integerToWords(remainder)}` : ''}`;
  }

  for (const [scale, label] of [[10000000, 'crore'], [100000, 'lakh'], [1000, 'thousand']]) {
    if (number >= scale) {
      const remainder = number % scale;
      return `${integerToWords(Math.floor(number / scale))} ${label}${remainder ? ` ${integerToWords(remainder)}` : ''}`;
    }
  }

  return integerToWords(number);
};

const usdWordsBelowHundred = (number) => {
  if (number < 20) return integerToWords(number);

  const tens = [
    '', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy',
    'eighty', 'ninety',
  ];

  return `${tens[Math.floor(number / 10)]}${number % 10 ? `-${integerToWords(number % 10)}` : ''}`;
};

const integerToUSDWords = (number) => {
  if (number < 100) return usdWordsBelowHundred(number);
  if (number < 1000) {
    const remainder = number % 100;
    return `${integerToUSDWords(Math.floor(number / 100))} hundred${remainder ? ` ${integerToUSDWords(remainder)}` : ''}`;
  }

  for (const [scale, label] of [
    [1000000000000, 'trillion'],
    [1000000000, 'billion'],
    [1000000, 'million'],
    [1000, 'thousand'],
  ]) {
    if (number >= scale) {
      const remainder = number % scale;
      return `${integerToUSDWords(Math.floor(number / scale))} ${label}${remainder ? ` ${integerToUSDWords(remainder)}` : ''}`;
    }
  }

  return integerToUSDWords(number);
};

export const amountInWords = (value) => {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0) return '';

  const roundedAmount = Math.round((amount + Number.EPSILON) * 100) / 100;
  const rupees = Math.floor(roundedAmount);
  const paise = Math.round((roundedAmount - rupees) * 100);
  const rupeeWords = `${integerToWords(rupees)} ${rupees === 1 ? 'rupee' : 'rupees'}`;

  return `${rupeeWords}${paise ? ` and ${integerToWords(paise)} ${paise === 1 ? 'paisa' : 'paise'}` : ''} only`;
};

export const amountInWordsUSD = (value) => {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0) return '';

  const totalCents = Math.round((amount + Number.EPSILON) * 100);
  const dollars = Math.floor(totalCents / 100);
  const cents = totalCents % 100;

  return `${integerToUSDWords(dollars)} ${dollars === 1 ? 'dollar' : 'dollars'} and ${integerToUSDWords(cents)} ${cents === 1 ? 'cent' : 'cents'} only`;
};
