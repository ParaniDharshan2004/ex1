export const roundCurrency = (value) => Math.round((Number(value) + Number.EPSILON) * 100) / 100;
export const isWithinCurrencyTolerance = (value) => Math.abs(roundCurrency(value)) <= 0.01;
