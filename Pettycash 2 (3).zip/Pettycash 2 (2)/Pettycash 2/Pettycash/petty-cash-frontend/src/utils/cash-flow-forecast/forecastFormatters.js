export const formatINRNumber = (value) => {
  const numericValue = Number(value) || 0;

  return numericValue.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

export const formatINR = (value) => {
  return `₹${formatINRNumber(value)}`;
};

export const formatCompactAmount = (value) => {
  const numericValue = Number(value) || 0;
  const absoluteValue = Math.abs(numericValue);
  const units = [
    { threshold: 1e12, suffix: 'Tr' },
    { threshold: 1e9, suffix: 'B' },
  ];
  const unit = units.find(({ threshold }) => absoluteValue >= threshold);

  if (!unit) {
    return numericValue.toLocaleString('en-IN');
  }

  const compactValue = numericValue / unit.threshold;
  const formattedValue = compactValue.toFixed(compactValue >= 100 ? 0 : 2);

  return `${Number(formattedValue)}${unit.suffix}`;
};

export const normalizeText = (value) => {
  return String(value ?? "")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
};

export const normalizeComponentName = (value) => {
  return normalizeText(value)
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
};

export const createRowId = (
  component,
  index,
) => {
  const normalizedComponent =
    normalizeComponentName(component)
      .replace(/\s+/g, "-")
      .replace(/^-+|-+$/g, "");

  return `${
    normalizedComponent || "component"
  }-${index}`;
};

export const parseAmount = (value) => {
  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return 0;
  }

  if (typeof value === "number") {
    return Number.isFinite(value)
      ? Math.abs(value)
      : 0;
  }

  let normalizedValue = String(value)
    .replace(/₹/g, "")
    .replace(/,/g, "")
    .replace(/\s/g, "")
    .trim();

  const isParenthesized =
    normalizedValue.startsWith("(") &&
    normalizedValue.endsWith(")");

  normalizedValue = normalizedValue
    .replace(/[()]/g, "")
    .replace(/(dr|cr)$/i, "")
    .trim();

  const numericValue = Number(normalizedValue);

  if (!Number.isFinite(numericValue)) {
    return 0;
  }

  const finalValue = isParenthesized
    ? -numericValue
    : numericValue;

  return Math.abs(finalValue);
};

export const sanitizeEditableAmount = (
  value,
) => {
  if (value === "") {
    return "";
  }

  const numericValue = Number(value);

  if (!Number.isFinite(numericValue)) {
    return "";
  }

  return Math.max(0, numericValue);
};

export const getSafeFileName = (value) => {
  return normalizeText(value)
    .replace(/[^a-zA-Z0-9-_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "");
};