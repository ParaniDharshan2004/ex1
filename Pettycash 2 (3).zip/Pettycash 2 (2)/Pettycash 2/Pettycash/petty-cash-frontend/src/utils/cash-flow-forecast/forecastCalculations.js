import { PDF_ROWS_PER_PAGE } from "../../data/dummy-data";

import { sanitizeEditableAmount } from "./forecastFormatters";

export const calculateRowForecastTotal = (row) => {
  return (
    (Number(row?.month1) || 0) +
    (Number(row?.month2) || 0) +
    (Number(row?.month3) || 0)
  );
};

export const calculateForecastTotals = (rows = []) => {
  return rows.reduce(
    (totals, row) => {
      const sourceAmount = Number(row?.sourceAmount) || 0;

      const month1 = Number(row?.month1) || 0;

      const month2 = Number(row?.month2) || 0;

      const month3 = Number(row?.month3) || 0;

      return {
        source: totals.source + sourceAmount,
        month1: totals.month1 + month1,
        month2: totals.month2 + month2,
        month3: totals.month3 + month3,
        forecast: totals.forecast + month1 + month2 + month3,
      };
    },
    {
      source: 0,
      month1: 0,
      month2: 0,
      month3: 0,
      forecast: 0,
    },
  );
};

export const updateForecastCell = (rows, rowId, field, value) => {
  const allowedFields = ["month1", "month2", "month3"];

  if (!allowedFields.includes(field)) {
    return rows;
  }

  const updatedValue = sanitizeEditableAmount(value);

  return rows.map((row) => {
    if (row.id !== rowId) {
      return row;
    }

    return {
      ...row,
      [field]: updatedValue,
      isEdited: true,
    };
  });
};

export const resetForecastRow = (rows, rowId) => {
  return rows.map((row) => {
    if (row.id !== rowId) {
      return row;
    }

    const sourceAmount = Number(row.sourceAmount) || 0;

    return {
      ...row,
      month1: sourceAmount,
      month2: sourceAmount,
      month3: sourceAmount,
      isEdited: false,
    };
  });
};

export const splitForecastRowsIntoPages = (
  rows = [],
  rowsPerPage = PDF_ROWS_PER_PAGE,
) => {
  if (!rows.length) {
    return [];
  }

  const safePageSize = Number(rowsPerPage) > 0 ? Number(rowsPerPage) : 15;

  const pages = [];

  for (let rowIndex = 0; rowIndex < rows.length; rowIndex += safePageSize) {
    pages.push(rows.slice(rowIndex, rowIndex + safePageSize));
  }

  return pages;
};
