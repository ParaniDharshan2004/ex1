import {
  TextField,
  InputAdornment,
  Select,
  MenuItem,
  Button,
  useTheme,
  Grid,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { Icons } from "../../theme/icons";

export default function FilterToolbar({
  filters,
  setFilters,
  onAdd,
}) {
  const theme = useTheme();

  return (
    <Grid container spacing={1.5} sx={{ mb: 2 }}>
      {/* Search */}
      <Grid size={{ xs: 12, md: 3, lg: 4 }}>
        <TextField
          fullWidth
          size="small"
          placeholder="Search by components"
          value={filters.search}
          onChange={(e) =>
            setFilters((f) => ({
              ...f,
              search: e.target.value,
            }))
          }
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
        />
      </Grid>

      {/* Date */}
      <Grid size={{ xs: 12, sm: 4, md: 3, lg: 2 }}>
        <TextField
          fullWidth
          size="small"
          type="date"
          value={filters.date || ""}
          onChange={(e) =>
            setFilters((f) => ({
              ...f,
              date: e.target.value,
            }))
          }
        />
      </Grid>

      {/* Year */}
      <Grid size={{ xs: 12, sm: 4, md: 3, lg: 2 }}>
        <Select
          fullWidth
          size="small"
          value={filters.year || ""}
          onChange={(e) =>
            setFilters((f) => ({
              ...f,
              year: e.target.value,
            }))
          }
          displayEmpty
        >
          <MenuItem value="">All Years</MenuItem>
          <MenuItem value="2026">2026</MenuItem>
          <MenuItem value="2027">2027</MenuItem>
          <MenuItem value="2028">2028</MenuItem>
        </Select>
      </Grid>

      {/* Month */}
      <Grid size={{ xs: 12, sm: 4, md: 3, lg: 2 }}>
        <Select
          fullWidth
          size="small"
          value={filters.month || ""}
          onChange={(e) =>
            setFilters((f) => ({
              ...f,
              month: e.target.value,
            }))
          }
          displayEmpty
        >
          <MenuItem value="">All Months</MenuItem>
          <MenuItem value="0">January</MenuItem>
          <MenuItem value="1">February</MenuItem>
          <MenuItem value="2">March</MenuItem>
          <MenuItem value="3">April</MenuItem>
          <MenuItem value="4">May</MenuItem>
          <MenuItem value="5">June</MenuItem>
          <MenuItem value="6">July</MenuItem>
          <MenuItem value="7">August</MenuItem>
          <MenuItem value="8">September</MenuItem>
          <MenuItem value="9">October</MenuItem>
          <MenuItem value="10">November</MenuItem>
          <MenuItem value="11">December</MenuItem>
        </Select>
      </Grid>

      {/* Add Button */}
      <Grid size={{ xs: 12, sm: 12, md: 12, lg: 2 }}>
        <Button
          fullWidth
          variant="contained"
          startIcon={<Icons.AddIcon />}
          onClick={onAdd}
          sx={{
            height: "40px",
            bgcolor: "primary.main",
            color: "textPrimary",
            "&:hover": {
              bgcolor: theme.palette.primary.main,
            },
          }}
        >
          Add Transaction
        </Button>
      </Grid>
    </Grid>
  );
}
