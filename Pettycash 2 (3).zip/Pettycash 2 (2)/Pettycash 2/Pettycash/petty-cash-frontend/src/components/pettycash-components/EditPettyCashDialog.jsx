import { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  TextField,
  MenuItem,
  Button,
} from "@mui/material";

const initialState = {
  expenseDate: "",
  category: "",
  description: "",
  amount: "",
  paidTo: "",
  paymentMode: "",
  remarks: "",
};

const EditPettyCashDialog = ({ open, handleClose, selectedEntry }) => {
  const [formData, setFormData] = useState(initialState);

  const set = (name, value) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSave = async () => {
    try {
      const response = await fetch(
        "http://localhost:3000/api/petty-cash/create",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        },
      );

      const result = await response.json();

      console.log(result);

      handleClose();
    } catch (error) {
      console.error(error);
    }
  };

  const handleDialogClose = () => {
    setFormData(initialState);
    handleClose();
  };

  useEffect(() => {
    if (selectedEntry) {
      setFormData(selectedEntry);
    }
  }, [selectedEntry]);

  return (
    <Dialog open={open} onClose={handleDialogClose} maxWidth="md" fullWidth>
      <DialogTitle>Add Petty Cash Entry</DialogTitle>

      <DialogContent dividers>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              fullWidth
              required
              type="date"
              name="expenseDate"
              value={formData.expenseDate}
              onChange={(e) => set("expenseDate", e.target.value)}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              select
              fullWidth
              required
              label="Category"
              name="category"
              value={formData.category}
              onChange={(e) => set("category", e.target.value)}
            >
              <MenuItem value="Travel">Travel</MenuItem>
              <MenuItem value="Food">Food</MenuItem>
              <MenuItem value="Office">Office</MenuItem>
              <MenuItem value="Fuel">Fuel</MenuItem>
              <MenuItem value="Maintenance">Maintenance</MenuItem>
              <MenuItem value="Miscellaneous">Miscellaneous</MenuItem>
            </TextField>
          </Grid>

          <Grid size={12}>
            <TextField
              fullWidth
              required
              type="text"
              label="Description"
              name="description"
              value={formData.description}
              onChange={(e) => set("description", e.target.value)}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              fullWidth
              required
              type="number"
              label="Amount"
              name="amount"
              value={formData.amount}
              onChange={(e) => set("amount", e.target.value)}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 6 }}>
            <TextField
              fullWidth
              label="Paid To"
              name="paidTo"
              value={formData.paidTo}
              onChange={(e) => set("paidTo", e.target.value)}
            />
          </Grid>

          <Grid size={12}>
            <TextField
              select
              fullWidth
              label="Payment Mode"
              name="paymentMode"
              value={formData.paymentMode}
              onChange={(e) => set("paymentMode", e.target.value)}
            >
              <MenuItem value="Cash">Cash</MenuItem>
              <MenuItem value="UPI">UPI</MenuItem>
              <MenuItem value="Card">Card</MenuItem>
              <MenuItem value="Bank Transfer">Bank Transfer</MenuItem>
            </TextField>
          </Grid>

          <Grid size={12}>
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Remarks"
              name="remarks"
              value={formData.remarks}
              onChange={(e) => set("remarks", e.target.value)}
            />
          </Grid>
        </Grid>
      </DialogContent>

      <DialogActions sx={{ p: 2 }}>
        <Button variant="outlined" onClick={handleDialogClose}>
          Cancel
        </Button>

        <Button variant="contained" onClick={handleSave}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditPettyCashDialog;
