import {
  Stack,
  TextField,
  InputAdornment,
  Select,
  MenuItem,
  Button,
  useTheme,
} from "@mui/material";
import { useMediaQuery } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { Icons } from "../../theme/icons";

export default function ComponentFilter({ filters, setFilters, onAddComponent, onAddSubComponent }) {
  const theme = useTheme();
  const isMobile = useMediaQuery("(max-width:600px)");
  return (
    <Stack
      direction={isMobile ? "column" : "row"}
      spacing={1.5}
      alignItems={isMobile ? "stretch" : "center"}
      sx={{ mb: 2 }}
    >
      <TextField
        size="small"
        placeholder="Search by component name"
        value={filters.search}
        onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon fontSize="small" />
            </InputAdornment>
          ),
        }}
        sx={{ flex: 1 }}
      />
      <Select
        size="small"
        value={filters.status}
        onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
        displayEmpty
        sx={{ minWidth: 140 }}
      >
        <MenuItem value="">Both</MenuItem>
        <MenuItem value="Active">Active</MenuItem>
        <MenuItem value="Inactive">Inactive</MenuItem>
      </Select>
      <Button
        variant="contained"
        startIcon={<Icons.AddIcon />}
        onClick={onAddComponent}
        sx={{
          bgcolor: "primary.main",
          color: "textPrimary",
          "&:hover": { bgcolor: `${(theme.palette.primary.main, 1)}` },
          whiteSpace: "nowrap",
        }}
      >
        Component
      </Button>
      <Button
        variant="contained"
        startIcon={<Icons.AddIcon />}
        onClick={onAddSubComponent}
        sx={{
          bgcolor: "primary.main",
          color: "textPrimary",
          "&:hover": { bgcolor: `${(theme.palette.primary.main, 1)}` },
          whiteSpace: "nowrap",
        }}
      >
        Sub component
      </Button>
    </Stack>
  );
}
