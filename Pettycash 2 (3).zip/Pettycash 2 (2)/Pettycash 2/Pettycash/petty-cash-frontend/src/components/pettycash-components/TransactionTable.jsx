import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Stack,
  IconButton,
  Tooltip,
} from "@mui/material";
import { Icons } from "../../theme/icons.js";
import { formatIST } from "../../utils/dateFormatter.js";

// Currency formatter for Indian Rupees
const currency = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);

export default function TransactionsTable({
  rows,
  onEdit,
  onDeleteRequest,
}) {
  return (
    <TableContainer
      component={Paper}
      sx={{ border: `1px solid ${"textPrimary"}14` }}
    >
      <Table size="small" sx={{}}>
        <TableHead>
          <TableRow sx={{ bgcolor: "background.default" }}>
            {["ID", "Date", "Component", "Expense", "Actions"].map((h) => (
              <TableCell
                key={h}
                sx={{ fontWeight: 600, color: "textPrimary", fontSize: 12.5 }}
              >
                {h}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.length === 0 && (
            <TableRow>
              <TableCell
                colSpan={8}
                sx={{ textAlign: "center", py: 4, color: "textPrimary" }}
              >
                No transactions match these filters.
              </TableCell>
            </TableRow>
          )}
          {rows.map((row) => {
            console.log(rows)
            return (
              <TableRow key={row._id} hover>
                <TableCell sx={{ fontWeight: 600 }}>
                  {row.transactionCode}
                </TableCell>
                <TableCell>{formatIST(row.expenseDate)}</TableCell>
                <TableCell>{row.componentId?.componentName}</TableCell>
                <TableCell sx={{ fontVariantNumeric: "tabular-nums" }}>
                  {currency(row.amount)}
                </TableCell>
                <TableCell>
                  <Stack direction="row" spacing={0.5}>
                    <Tooltip title="Edit">
                      <IconButton
                        size="small"
                        onClick={() => onEdit(row)}
                        sx={{ color: "textPrimary" }}
                      >
                        <Icons.EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton
                        size="small"
                        onClick={() => onDeleteRequest(row)}
                        sx={{ color: "primary.error" }}
                      >
                        <Icons.DeleteIcon fontSize="small"/>
                      </IconButton>
                    </Tooltip>
                  </Stack>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
