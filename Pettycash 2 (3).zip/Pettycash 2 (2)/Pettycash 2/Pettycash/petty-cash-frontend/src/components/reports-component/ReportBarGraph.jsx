import { useMemo } from 'react';

import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Divider,
  Skeleton,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';

import BarChartOutlinedIcon from '@mui/icons-material/BarChartOutlined';

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Label,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

/* -------------------------------------------------------------------------- */
/*                                  Colors                                    */
/* -------------------------------------------------------------------------- */

export const CHART_COLORS = [
  '#1D89C8',
  '#3EB8AF',
  '#1565C0',
  '#2C8F89',
  '#42A5F5',
  '#62CEC6',
  '#64B5F6',
  '#80D8D0',
  '#90CAF9',
  '#9CE2DB',
  '#0D47A1',
  '#00796B',
  '#1976D2',
  '#26A69A',
  '#2196F3',
  '#4DB6AC',
  '#5C6BC0',
  '#00ACC1',
  '#3949AB',
  '#0097A7',
];

/* -------------------------------------------------------------------------- */
/*                                  Helpers                                   */
/* -------------------------------------------------------------------------- */

const formatINR = (value) => {
  const numericValue = Number(value) || 0;

  const formattedAmount = numericValue.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return `₹${formattedAmount}`;
};

const formatYAxisValue = (value) => {
  const numericValue = Number(value) || 0;

  if (numericValue >= 10000000) {
    return `₹${(numericValue / 10000000).toFixed(1)}Cr`;
  }

  if (numericValue >= 100000) {
    return `₹${(numericValue / 100000).toFixed(1)}L`;
  }

  if (numericValue >= 1000) {
    return `₹${(numericValue / 1000).toFixed(1)}K`;
  }

  return `₹${numericValue}`;
};

const shortenLabel = (value, maxLength) => {
  const label = String(value || '');

  if (label.length <= maxLength) {
    return label;
  }

  return `${label.slice(0, maxLength - 1)}…`;
};

/* -------------------------------------------------------------------------- */
/*                                Tooltip                                     */
/* -------------------------------------------------------------------------- */

function CustomBarTooltip({ active, payload, label }) {
  if (!active || !payload?.length) {
    return null;
  }

  return (
    <Box
      sx={{
        minWidth: 190,
        maxWidth: 280,
        p: 1.75,
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: 2,
        backgroundColor: 'background.paper',
        boxShadow: '0 12px 32px rgba(15, 23, 42, 0.14)',
        fontFamily: '"DM Sans", sans-serif',
      }}
    >
      <Typography
        variant="body2"
        sx={{
          mb: 0.75,
          fontFamily: 'inherit',
          fontWeight: 700,
          overflowWrap: 'anywhere',
        }}
      >
        {label}
      </Typography>

      <Typography
        variant="body2"
        color="text.secondary"
        sx={{
          fontFamily: 'inherit',
        }}
      >
        Amount:{' '}
        <Box
          component="span"
          sx={{
            fontFamily: 'inherit',
            fontWeight: 700,
            color: 'text.primary',
            whiteSpace: 'nowrap',
            fontVariantNumeric: 'tabular-nums',
          }}
        >
          <span className="amount-value-with-symbol">
            {formatINR(payload[0].value)}
          </span>
        </Box>
      </Typography>
    </Box>
  );
}

/* -------------------------------------------------------------------------- */
/*                              Main Component                                */
/* -------------------------------------------------------------------------- */

export default function ReportBarGraph({
  title = 'Expense By Component',
  subtitle = 'Compare the total expense recorded for each component.',
  data = [],
  loading = false,
  dataKey = 'totalExpense',
  xAxisKey = 'component',
  exportMode = false,
}) {
  const theme = useTheme();

  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  const safeData = useMemo(() => {
    return Array.isArray(data) ? data : [];
  }, [data]);

  const hasData = safeData.length > 0;

  const chartHeight = useMemo(() => {
    if (exportMode) {
      return 520;
    }

    if (isMobile) {
      return 390;
    }

    if (isTablet) {
      return 425;
    }

    return 460;
  }, [exportMode, isMobile, isTablet]);

  const xAxisAngle = isMobile ? -55 : -35;
  const xAxisHeight = isMobile ? 110 : 105;
  const maxLabelLength = isMobile ? 12 : 20;

  return (
    <Card
      sx={{
        width: '100%',
        borderRadius: exportMode ? 0 : 3,
        border: exportMode ? 'none' : '1px solid',
        borderColor: 'divider',
        boxShadow: exportMode ? 'none' : '0 4px 18px rgba(15, 23, 42, 0.06)',
        overflow: 'hidden',
        backgroundColor: '#ffffff',
      }}
    >
      {!exportMode && (
        <>
          <CardHeader
            avatar={
              <Box
                sx={{
                  width: 40,
                  height: 40,
                  display: 'grid',
                  placeItems: 'center',
                  borderRadius: 2,
                  color: 'primary.main',
                  backgroundColor: 'rgba(29, 137, 200, 0.1)',
                }}
              >
                <BarChartOutlinedIcon fontSize="small" />
              </Box>
            }
            title={title}
            subheader={subtitle}
            slotProps={{
              title: {
                sx: {
                  fontFamily: '"DM Sans", sans-serif',
                  fontSize: '1.05rem',
                  fontWeight: 700,
                },
              },
              subheader: {
                sx: {
                  mt: 0.35,
                  fontFamily: '"DM Sans", sans-serif',
                  fontSize: '0.82rem',
                },
              },
            }}
            sx={{
              px: {
                xs: 2,
                sm: 3,
              },
              py: 2,
            }}
          />

          <Divider />
        </>
      )}

      <CardContent
        sx={{
          px: exportMode
            ? 0
            : {
                xs: 1,
                sm: 2,
                md: 2.5,
              },
          pt: exportMode
            ? 1
            : {
                xs: 2,
                sm: 2.5,
              },
          pb: exportMode
            ? 0
            : {
                xs: 1.5,
                sm: 2,
              },
          '&:last-child': {
            pb: exportMode
              ? 0
              : {
                  xs: 1.5,
                  sm: 2,
                },
          },
        }}
      >
        {loading ? (
          <Skeleton
            variant="rounded"
            height={chartHeight}
            sx={{
              borderRadius: 2,
            }}
          />
        ) : !hasData ? (
          <Box
            sx={{
              height: chartHeight,
              display: 'grid',
              placeItems: 'center',
              textAlign: 'center',
              px: 2,
            }}
          >
            <Box>
              <Typography
                fontWeight={700}
                sx={{
                  fontFamily: '"DM Sans", sans-serif',
                }}
              >
                No chart data available
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
                sx={{
                  mt: 0.75,
                  fontFamily: '"DM Sans", sans-serif',
                }}
              >
                Select another reporting period to view expenses.
              </Typography>
            </Box>
          </Box>
        ) : (
          <Box
            sx={{
              width: '100%',
              height: chartHeight,
              minWidth: 0,
            }}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={safeData}
                barCategoryGap={isMobile ? '22%' : '30%'}
                margin={{
                  top: 18,
                  right: isMobile ? 8 : 24,
                  left: isMobile ? 5 : 18,
                  bottom: 8,
                }}
              >
                <CartesianGrid
                  strokeDasharray="4 4"
                  vertical={false}
                  stroke={theme.palette.divider}
                  strokeOpacity={0.9}
                />

                <XAxis
                  dataKey={xAxisKey}
                  interval={0}
                  angle={xAxisAngle}
                  textAnchor="end"
                  height={xAxisHeight}
                  tickLine={false}
                  axisLine={{
                    stroke: theme.palette.divider,
                  }}
                  tick={{
                    fontFamily: 'DM Sans',
                    fontSize: isMobile ? 9 : 11,
                    fill: theme.palette.text.secondary,
                  }}
                  tickFormatter={(value) => shortenLabel(value, maxLabelLength)}
                >
                  <Label
                    value="Component"
                    position="insideBottom"
                    offset={-1}
                    style={{
                      fontFamily: 'DM Sans',
                      fontSize: 12,
                      fill: theme.palette.text.secondary,
                      textAnchor: 'middle',
                    }}
                  />
                </XAxis>

                <YAxis
                  width={isMobile ? 62 : 78}
                  tickCount={6}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={formatYAxisValue}
                  tick={{
                    fontFamily: 'DM Sans',
                    fontSize: isMobile ? 9 : 11,
                    fill: theme.palette.text.secondary,
                  }}
                >
                  <Label
                    value="Amount (₹)"
                    angle={-90}
                    position="insideLeft"
                    offset={isMobile ? 10 : 4}
                    style={{
                      fontFamily: 'DM Sans',
                      fontSize: 12,
                      fill: theme.palette.text.secondary,
                      textAnchor: 'middle',
                    }}
                  />
                </YAxis>

                {!exportMode && (
                  <Tooltip
                    content={<CustomBarTooltip />}
                    cursor={{
                      fill: theme.palette.action.hover,
                      opacity: 0.65,
                    }}
                  />
                )}

                <Bar
                  dataKey={dataKey}
                  maxBarSize={exportMode ? 56 : 64}
                  minPointSize={3}
                  radius={[7, 7, 0, 0]}
                  isAnimationActive={!exportMode}
                >
                  {safeData.map((entry, index) => (
                    <Cell
                      key={entry._id || `${entry[xAxisKey]}-${index}`}
                      fill={CHART_COLORS[index % CHART_COLORS.length]}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Box>
        )}
      </CardContent>
    </Card>
  );
}
