import { Box, Card, CardContent, Grid, Typography } from "@mui/material";

import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

const expenseData = [
  { month: "Jan", amount: 1200 },
  { month: "Feb", amount: 1800 },
  { month: "Mar", amount: 1400 },
  { month: "Apr", amount: 2200 },
  { month: "May", amount: 1900 },
  { month: "Jun", amount: 2600 },
];

const categoryData = [
  {
    name: "Travel",
    value: 35,
  },
  {
    name: "Food",
    value: 30,
  },
  {
    name: "Office",
    value: 20,
  },
  {
    name: "Misc",
    value: 15,
  },
];

const COLORS = ["#1976d2", "#2e7d32", "#ed6c02", "#9c27b0"];

const DashboardCharts = () => {
  return (
    <Box>
      <Grid size={12} container sx={{ alignItems: "stretch" }} spacing={3}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card sx={{ mt: 3 }}>
            <CardContent sx={{ width: "100%", height: "100%" }}>
              <Typography variant="h6" fontWeight={600} gutterBottom>
                Monthly Expense Trend
              </Typography>

              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={expenseData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />

                  <Line
                    type="monotone"
                    dataKey="amount"
                    stroke="#1976d2"
                    strokeWidth={3}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card sx={{ mt: 3 }}>
            <CardContent sx={{ width: "100%", height: "100%" }}>
              <Typography variant="h6" fontWeight={600} gutterBottom>
                Expense By Category
              </Typography>

              <ResponsiveContainer width="100%" height={350}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    outerRadius={120}
                    dataKey="value"
                    label
                  >
                    {categoryData.map((entry, index) => (
                      <Cell
                        key={entry.name}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>

                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DashboardCharts;
