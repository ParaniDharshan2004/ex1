import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Stack,
  IconButton,
  Tooltip,
  TablePagination,
} from "@mui/material";

import { useState } from "react";
import { DeleteOutlined } from "@mui/icons-material";
import { Icons } from "../../theme/icons";

export default function SenderAccountsTable({ rows, onEdit, onDeleteRequest }) {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(Number(event.target.value));
    setPage(0);
  };

  const paginatedRows = rows.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage,
  );

  return (
    <TableContainer
      component={Paper}
      sx={{
        border: (theme) => `1px solid ${theme.palette.divider}`,
      }}
    >
      <Table size="small">
        <TableHead>
          <TableRow sx={{ bgcolor: "background.default" }}>
            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Account Code
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Account Name
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Account Holder
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Bank Name
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Account Number
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Account Type
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Status
            </TableCell>

            <TableCell
              align="center"
              sx={{
                fontWeight: 600,
                fontSize: 12.5,
              }}
            >
              Actions
            </TableCell>
          </TableRow>
        </TableHead>

        <TableBody>
          {paginatedRows.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} align="center">
                No Sender Accounts Found
              </TableCell>
            </TableRow>
          ) : (
            paginatedRows.map((row) => (
              <TableRow key={row._id} hover>
                <TableCell>{row.accountCode}</TableCell>

                <TableCell>{row.accountName}</TableCell>

                <TableCell>{row.accountHolderName}</TableCell>

                <TableCell>{row.bankName}</TableCell>

                <TableCell>{row.maskedAccountNumber}</TableCell>

                <TableCell>
                  <Chip
                    label={row.accountType}
                    size="small"
                    color={
                      row.accountType === "Current" ? "primary" : "secondary"
                    }
                  />
                </TableCell>

                <TableCell>
                  <Chip
                    label={row.isActive ? "Active" : "Inactive"}
                    color={row.isActive ? "success" : "error"}
                    size="small"
                  />
                </TableCell>

                <TableCell align="center">
                  <Stack direction="row" spacing={0.5} justifyContent="center">
                    <Tooltip title="Edit">
                      <IconButton size="small" onClick={() => onEdit(row)}>
                        <Icons.EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>

                    <Tooltip title="Delete">
                      <IconButton
                        size="small"
                        sx={{
                          color: "error.main",
                        }}
                        onClick={() => onDeleteRequest(row)}
                      >
                        <DeleteOutlined />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      <TablePagination
        component="div"
        count={rows.length}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        rowsPerPageOptions={[5, 10, 25, 50]}
        showFirstButton
        showLastButton
      />
    </TableContainer>
  );
}
