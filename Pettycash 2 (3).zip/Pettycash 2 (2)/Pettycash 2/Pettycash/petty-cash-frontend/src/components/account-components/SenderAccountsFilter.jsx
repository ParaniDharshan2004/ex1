import { Box, Button, TextField } from "@mui/material";
import { Icons } from "../../theme/icons";

export default function SenderAccountsFilters({ filters, setFilters, onAdd }) {
  return (
    <Box
      sx={{
        display: "flex",
        gap: 2,
        justifyContent: "space-between",
        mb: 2,
      }}
    >
      <TextField
        size="small"
        label="Search Account"
        value={filters.search}
        onChange={(e) =>
          setFilters((prev) => ({
            ...prev,
            search: e.target.value,
          }))
        }
        sx={{ flexGrow:  1 }}
      />

      <Button variant="contained" startIcon={<Icons.AddIcon />} onClick={onAdd}>
        Add Account
      </Button>
    </Box>
  );
}
