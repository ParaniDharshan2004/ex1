import { Button, Grid, MenuItem, Select, TextField } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";

export default function CashInflowFilters({ filters, setFilters, onAdd }) {

  return (
    <Grid container spacing={1.5} sx={{ mb: 2 }}>
      {/* Search */}
      <Grid size={{ xs: 12, sm: 12, md: 6, lg: 6 }}>
        <TextField
          fullWidth
          size="small"
          label="Search"
          value={filters.search}
          onChange={(e) =>
            setFilters((prev) => ({
              ...prev,
              search: e.target.value,
            }))
          }
        />
      </Grid>

      {/* Date */}
      <Grid size={{ xs: 12, sm: 6, md: 2, lg: 2 }}>
        <TextField
          fullWidth
          size="small"
          type="date"
          InputLabelProps={{ shrink: true }}
          value={filters.date}
          onChange={(e) =>
            setFilters((prev) => ({
              ...prev,
              date: e.target.value,
            }))
          }
        />
      </Grid>

      {/* Month */}
      <Grid size={{ xs: 12, sm: 6, md: 2, lg: 2 }}>
        <Select
          fullWidth
          size="small"
          value={filters.month || ""}
          onChange={(e) =>
            setFilters((prev) => ({
              ...prev,
              month: e.target.value,
            }))
          }
          displayEmpty
        >
          <MenuItem value="">All Months</MenuItem>
          <MenuItem value="0">January</MenuItem>
          <MenuItem value="1">February</MenuItem>
          <MenuItem value="2">March</MenuItem>
          <MenuItem value="3">April</MenuItem>
          <MenuItem value="4">May</MenuItem>
          <MenuItem value="5">June</MenuItem>
          <MenuItem value="6">July</MenuItem>
          <MenuItem value="7">August</MenuItem>
          <MenuItem value="8">September</MenuItem>
          <MenuItem value="9">October</MenuItem>
          <MenuItem value="10">November</MenuItem>
          <MenuItem value="11">December</MenuItem>
          
        </Select>
      </Grid>

      {/* Add Cash */}
      <Grid size={{ xs: 12, sm: 12, md: 2, lg: 2 }}>
        <Button
          fullWidth
          variant="contained"
          startIcon={<AddIcon />}
          onClick={onAdd}
          sx={{
            height: 40,
          }}
        >
          Add Cash
        </Button>
      </Grid>
    </Grid>
  );
}
