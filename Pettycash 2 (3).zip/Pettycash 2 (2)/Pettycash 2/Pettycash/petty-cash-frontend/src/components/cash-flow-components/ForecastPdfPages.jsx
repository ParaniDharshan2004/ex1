import { forwardRef } from "react";
import { Box, Typography } from "@mui/material";

import { A4_HEIGHT_PX, A4_WIDTH_PX } from "../../data/dummy-data.js";

import ForecastStatementTable from "./ForecastStatementTable.jsx";
import CashFlowSummaryTable from "./CashFlowSummaryTable.jsx";

const PAGE_PADDING_X = 20;
const PAGE_PADDING_TOP = 20;
const PAGE_PADDING_BOTTOM = 20;

const PdfPage = ({ pageNumber, totalPages, children }) => (
  <Box
    data-pdf-page="true"
    sx={{
      width: `${A4_WIDTH_PX}px`,
      minHeight: `${A4_HEIGHT_PX}px`,
      boxSizing: "border-box",
      bgcolor: "#fff",
      px: `${PAGE_PADDING_X}px`,
      pt: `${PAGE_PADDING_TOP}px`,
      pb: `${PAGE_PADDING_BOTTOM}px`,
      overflow: "visible",
      fontFamily: "Arial, sans-serif",
    }}
  >
    <Typography
      align="center"
      sx={{
        mb: "12px",
        fontSize: "12px",
        lineHeight: 1.2,
        color: "#111827",
      }}
    >
      Page {pageNumber} of {totalPages}
    </Typography>

    <Box
      sx={{
        width: "100%",
        maxWidth: "100%",
        boxSizing: "border-box",
        overflow: "visible",
      }}
    >
      {children}
    </Box>
  </Box>
);

const ReportHeader = ({ sourcePeriod, title = "Cash Flow Analysis" }) => (
  <Box
    sx={{
      width: "100%",
      maxWidth: "100%",
      boxSizing: "border-box",
    }}
  >
    <Typography
      align="center"
      sx={{
        width: "100%",
        boxSizing: "border-box",
        border: "2px solid #111827",
        bgcolor: "#D1D5DB",
        fontSize: "14px",
        fontWeight: 800,
        lineHeight: 1.2,
        py: "4px",
      }}
    >
      {title} - {sourcePeriod}
    </Typography>
  </Box>
);

const ReportTable = ({ rows, fixedCostRows, forecastMonths, sections }) => (
  <Box
    sx={{
      width: "100%",
      maxWidth: "100%",
      boxSizing: "border-box",
      overflow: "visible",
    }}
  >
    <ForecastStatementTable
      rows={rows}
      fixedCostRows={fixedCostRows}
      forecastMonths={forecastMonths}
      sections={sections}
      readOnly
    />
  </Box>
);

const SummaryTable = ({
  forecastMonths,
  clientInflows,
  discountsAndRefunds,
  openingSurplusDeficit,
  previousMonthSurplusDeficit,
  surplusDeficit,
  cashOutflowTotals,
}) => (
  <Box
    sx={{
      width: "100%",
      maxWidth: "100%",
      boxSizing: "border-box",
      overflow: "visible",
    }}
  >
    <CashFlowSummaryTable
      readOnly
      forecastMonths={forecastMonths}
      clientInflows={clientInflows}
      discountsAndRefunds={discountsAndRefunds}
      openingSurplusDeficit={openingSurplusDeficit}
      previousMonthSurplusDeficit={previousMonthSurplusDeficit}
      surplusDeficit={surplusDeficit}
      cashOutflowTotals={cashOutflowTotals}
    />
  </Box>
);

const ForecastPdfPages = forwardRef(function ForecastPdfPages(
  {
    open,
    sourcePeriod,
    forecastMonths = [],
    rows = [],
    fixedCostRows = [],
    clientInflows = [],
    discountsAndRefunds = [],
    openingSurplusDeficit = 0,
    previousMonthSurplusDeficit = [],
    surplusDeficit = [],
    cashOutflowTotals = [],
  },
  ref,
) {
  if (!open) {
    return null;
  }

  const totalPages = 4;

  return (
    <Box
      ref={ref}
      sx={{
        position: "fixed",
        left: "-10000px",
        top: 0,
        width: `${A4_WIDTH_PX}px`,
        height: "auto",
        overflow: "visible",
        bgcolor: "#fff",
        zIndex: -1,
      }}
    >
      <PdfPage pageNumber={1} totalPages={totalPages}>
        <ReportHeader sourcePeriod={sourcePeriod} />

        <ReportTable
          rows={rows}
          fixedCostRows={fixedCostRows}
          forecastMonths={forecastMonths}
          sections={["direct"]}
        />
      </PdfPage>

      <PdfPage pageNumber={2} totalPages={totalPages}>
        <ReportHeader sourcePeriod={sourcePeriod} />

        <ReportTable
          rows={rows}
          fixedCostRows={fixedCostRows}
          forecastMonths={forecastMonths}
          sections={["indirect"]}
        />
      </PdfPage>

      <PdfPage pageNumber={3} totalPages={totalPages}>
        <ReportHeader sourcePeriod={sourcePeriod} />

        <ReportTable
          rows={rows}
          fixedCostRows={fixedCostRows}
          forecastMonths={forecastMonths}
          sections={["misc", "grandTotal"]}
        />
      </PdfPage>

      <PdfPage pageNumber={4} totalPages={totalPages}>

        <SummaryTable
          forecastMonths={forecastMonths}
          clientInflows={clientInflows}
          discountsAndRefunds={discountsAndRefunds}
          openingSurplusDeficit={openingSurplusDeficit}
          previousMonthSurplusDeficit={previousMonthSurplusDeficit}
          surplusDeficit={surplusDeficit}
          cashOutflowTotals={cashOutflowTotals}
        />
      </PdfPage>
    </Box>
  );
});

ForecastPdfPages.displayName = "ForecastPdfPages";

export default ForecastPdfPages;
