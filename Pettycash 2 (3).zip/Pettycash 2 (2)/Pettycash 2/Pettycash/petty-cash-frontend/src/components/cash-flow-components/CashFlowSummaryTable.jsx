import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  Button,
  IconButton,
  Stack,
  Tooltip,
} from '@mui/material';
import { memo, useState } from 'react';
import { Icons } from '../../theme/icons';
import { formatCompactAmount } from '../../utils/cash-flow-forecast/forecastFormatters';

const formatAmount = (value) => formatCompactAmount(value);

const formatPrintAmount = (value) =>
  Number(value) === 0 ? '-' : formatAmount(value);

const numberInputSx = {
  '& input[type="number"]': {
    MozAppearance: 'textfield',
  },
  '& input[type="number"]::-webkit-outer-spin-button, & input[type="number"]::-webkit-inner-spin-button':
    {
      WebkitAppearance: 'none',
      margin: 0,
    },
};

const getMonthKey = (month) => {
  if (!month) {
    return '';
  }

  if (typeof month === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(month)) {
    return month;
  }

  if (/^\d{4}-(0[1-9]|1[0-2])$/.test(month.key || '')) {
    return month.key;
  }

  const date = month.date instanceof Date ? month.date : new Date(month.date);

  if (!Number.isNaN(date.getTime())) {
    return [
      date.getFullYear(),
      String(date.getMonth() + 1).padStart(2, '0'),
    ].join('-');
  }

  return '';
};
const resetButtonSx = {
  '&:disabled, &.Mui-disabled': {
    color: '#BDBDBD',
    opacity: 1,
  },
};

const deleteButtonSx = {
  '&:disabled, &.Mui-disabled': {
    color: '#BDBDBD',
    opacity: 1,
  },
};

const addButtonSx = {
  '&:disabled, &.Mui-disabled': {
    color: '#BDBDBD',
    borderColor: '#D1D5DB',
  },
};

const getAmountForMonth = (forecastAmounts = [], month, index) => {
  const monthKey = getMonthKey(month);

  const matchingAmount = forecastAmounts.find(
    (item) => item.month === monthKey || item.key === monthKey,
  );

  if (matchingAmount) {
    return matchingAmount.amount;
  }

  return forecastAmounts[index]?.amount ?? 0;
};

const getClientRowId = (clientRow) => {
  return clientRow._id || `${clientRow.clientId}-${clientRow.inflowType}`;
};

const getClientName = (clientRow) => {
  return (
    clientRow.clientName ||
    clientRow.clientId?.clientName ||
    clientRow.clientCode ||
    'Client'
  );
};

const sectionCellSx = {
  fontWeight: 800,
  bgcolor: '#E5E7EB',
  borderTop: '2px solid #111827',
};

const subSectionCellSx = {
  fontWeight: 800,
  bgcolor: '#F8FAFC',
};

const SummaryAmountInput = memo(function SummaryAmountInput({
  value,
  onChange,
  ariaLabel,
  allowNegative,
}) {
  const [draftValue, setDraftValue] = useState(() => value ?? '');
  const [isEditing, setIsEditing] = useState(false);

  const commitValue = () => {
    if (draftValue === '') {
      onChange?.(0);
      return;
    }

    const numericValue = Number(draftValue);

    onChange?.(
      Number.isFinite(numericValue)
        ? allowNegative
          ? numericValue
          : Math.max(0, numericValue)
        : 0,
    );
  };

  return (
    <TextField
      type="number"
      size="small"
      value={!isEditing && draftValue === '' ? 0 : draftValue}
      onFocus={() => setIsEditing(true)}
      onChange={(event) => setDraftValue(event.target.value)}
      onKeyDown={(event) => {
        const blockedKeys = allowNegative
          ? ['+', 'e', 'E']
          : ['-', '+', 'e', 'E'];

        if (blockedKeys.includes(event.key)) {
          event.preventDefault();
          return;
        }

        if (event.key === 'Enter') {
          event.currentTarget.blur();
        }
      }}
      onBlur={() => {
        commitValue();
        setIsEditing(false);
      }}
      onPaste={(event) => {
        if (allowNegative) {
          return;
        }

        const pastedValue = event.clipboardData.getData('text');
        const numericValue = Number(pastedValue);

        if (!Number.isFinite(numericValue) || numericValue < 0) {
          event.preventDefault();
        }
      }}
      inputProps={{
        min: allowNegative ? undefined : 0,
        step: 1,
        inputMode: allowNegative ? 'decimal' : 'numeric',
        'aria-label': ariaLabel,
      }}
      sx={{
        ...numberInputSx,
        width: '100%',
        '& input': {
          py: 0.7,
          textAlign: 'right',
        },
      }}
    />
  );
});

export default function CashFlowSummaryTable({
  forecastMonths = [],
  clientInflows = [],
  discountsAndRefunds = [],
  openingSurplusDeficit = 0,
  previousMonthSurplusDeficit = [],
  surplusDeficit = [],
  cashOutflowTotals = [],
  exporting = false,
  readOnly = false,
  onClientInflowChange,
  onDiscountChange,
  onOpeningBalanceChange,
  onAddCashInflow,
  onRemoveCashInflow,
  onResetClientInflow,
}) {
  const columnCount = 1 + forecastMonths.length + (readOnly ? 0 : 1);

  const displayedClientInflows = clientInflows.filter(
    (clientRow) => clientRow.inflowType !== 'ESTIMATED',
  );

  const totalCashInflowAmounts = forecastMonths.map((month, index) => {
    const clientInflowTotal = displayedClientInflows.reduce(
      (total, clientRow) => {
        const amount = getAmountForMonth(
          clientRow.forecastAmounts,
          month,
          index,
        );

        return total + (Number(amount) || 0);
      },
      0,
    );

    const discountAndRefundAmount = getAmountForMonth(
      discountsAndRefunds,
      month,
      index,
    );

    return clientInflowTotal - (Number(discountAndRefundAmount) || 0);
  });

  const renderEditableAmount = ({
    value,
    onChange,
    ariaLabel,
    allowNegative = false,
  }) => {
    if (readOnly || exporting) {
      return (
        <span className="amount-value">
          {readOnly ? formatPrintAmount(value) : formatAmount(value)}
        </span>
      );
    }

    return (
      <SummaryAmountInput
        value={value}
        onChange={onChange}
        ariaLabel={ariaLabel}
        allowNegative={allowNegative}
      />
    );
  };

  const renderCalculatedAmount = (value, ariaLabel) => {
    if (readOnly || exporting) {
      return (
        <Typography
          component="span"
          className="amount-value"
          variant="h6"
          aria-label={ariaLabel}
          sx={{
            color: Number(value) < 0 ? 'error.main' : 'text.primary',
            whiteSpace: 'nowrap',
            maxWidth: '100%',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          {readOnly ? formatPrintAmount(value) : formatAmount(value)}
        </Typography>
      );
    }

    return (
      <Box
        component="output"
        aria-label={ariaLabel}
        sx={{
          width: '100%',
          minWidth: 0,
          minHeight: 40,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          px: 1.75,
          overflow: 'hidden',
          border: '1px solid',
          borderColor: 'rgba(0, 0, 0, 0.23)',
          borderRadius: 1,
          whiteSpace: 'nowrap',
        }}
      >
        <Typography
          component="span"
          className="amount-value"
          variant="h6"
          sx={{
            color: Number(value) < 0 ? 'error.main' : 'text.primary',
            maxWidth: '100%',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
        >
          {formatAmount(value)}
        </Typography>
      </Box>
    );
  };

  return (
    <TableContainer>
      <Table
        size="small"
        sx={{
          minWidth: readOnly ? 700 : 850,
          tableLayout: 'fixed',

          '& td, & th': {
            border: '1px solid #111827',
            py: readOnly ? 0.35 : 0.8,
            px: readOnly ? 0.7 : 1.2,
          },
        }}
      >
        <colgroup>
          <col style={{ width: readOnly ? '55%' : '42%' }} />
          {forecastMonths.map((month, index) => (
            <col key={`summary-column-${getMonthKey(month) || index}`} />
          ))}
          {!readOnly && <col style={{ width: '120px' }} />}
        </colgroup>

        <TableHead>
          <TableRow>
            <TableCell colSpan={columnCount} align="center" sx={sectionCellSx}>
              Cash Flow Summary
            </TableCell>
          </TableRow>

          <TableRow
            sx={{
              bgcolor: '#D1D5DB',
            }}
          >
            <TableCell
              align="center"
              sx={{
                width: readOnly ? '55%' : '42%',
                fontWeight: 800,
              }}
            >
              Particulars
            </TableCell>

            {forecastMonths.map((month, index) => (
              <TableCell
                key={getMonthKey(month) || index}
                align="center"
                sx={{
                  width: '16%',
                  fontWeight: 800,
                }}
              >
                {month?.fullLabel || `Month ${index + 1}`}

                <Typography component="div" variant="caption" fontWeight={700}>
                  (Estimated in Rs)
                </Typography>
              </TableCell>
            ))}

            {!readOnly && (
              <TableCell
                align="center"
                sx={{
                  fontWeight: 700,
                  width: '120px',
                  minWidth: '120px',
                  maxWidth: '120px',
                }}
              >
                Actions
              </TableCell>
            )}
          </TableRow>
        </TableHead>

        <TableBody>
          <TableRow>
            <TableCell
              colSpan={columnCount}
              sx={{ ...subSectionCellSx, px: 0 }}
            >
              <Stack
                direction="row"
                sx={{
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <Typography variant="body2" sx={{ fontWeight: 800 }}>
                  Cash Inflow (Estimated)
                </Typography>

                {!readOnly && (
                  <Button
                    size="small"
                    variant="outlined"
                    sx={addButtonSx}
                    disabled={exporting}
                    onClick={onAddCashInflow}
                  >
                    + Add Component
                  </Button>
                )}
              </Stack>
            </TableCell>
          </TableRow>

          {displayedClientInflows.map((clientRow) => {
            const rowId = getClientRowId(clientRow);
            const clientName = getClientName(clientRow);
            const rowLabel = clientName;
            return (
              <TableRow key={String(rowId)} hover={!readOnly}>
                <TableCell
                  sx={{
                    pl: 4,
                    textAlign: 'right',
                    fontWeight: 500,
                  }}
                >
                  <Typography variant="body2">{rowLabel}</Typography>
                </TableCell>

                {forecastMonths.map((month, index) => {
                  const value = getAmountForMonth(
                    clientRow.forecastAmounts,
                    month,
                    index,
                  );

                  return (
                    <TableCell
                      key={`${rowId}-${getMonthKey(month)}-${index}`}
                      align="right"
                    >
                      {renderEditableAmount({
                        value,

                        ariaLabel: `${rowLabel} ${
                          month?.fullLabel || `Month ${index + 1}`
                        }`,

                        onChange: (nextValue) =>
                          onClientInflowChange?.(
                            clientRow,
                            month,
                            index,
                            nextValue,
                          ),
                      })}
                    </TableCell>
                  );
                })}

                {!readOnly && (
                  <TableCell
                    align="center"
                    sx={{
                      width: '120px',
                      minWidth: '120px',
                      maxWidth: '120px',
                      px: '4px !important',
                    }}
                  >
                    <Stack
                      direction="row"
                      sx={{ alignItems: 'center', justifyContent: 'center' }}
                      spacing={0.25}
                    >
                      <Tooltip title="Reset amounts" arrow>
                        <IconButton
                          size="small"
                          color="primary"
                          sx={resetButtonSx}
                          disabled={exporting}
                          aria-label={`Reset amounts for ${rowLabel}`}
                          onClick={() => onResetClientInflow?.(clientRow)}
                        >
                          <Icons.RefreshIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="Remove from summary" arrow>
                        <IconButton
                          size="small"
                          color="error"
                          sx={deleteButtonSx}
                          disabled={exporting}
                          aria-label={`Remove ${rowLabel} from Cash Flow Summary`}
                          onClick={() => onRemoveCashInflow?.(clientRow)}
                        >
                          <Icons.DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </TableCell>
                )}
              </TableRow>
            );
          })}

          {!clientInflows.length && (
            <TableRow>
              <TableCell sx={{ height: 48 }} />

              {forecastMonths.map((month, index) => (
                <TableCell
                  key={`empty-client-${getMonthKey(month)}-${index}`}
                />
              ))}

              {!readOnly && (
                <TableCell
                  sx={{
                    width: '120px',
                    minWidth: '120px',
                    maxWidth: '120px',
                  }}
                />
              )}
            </TableRow>
          )}

          <TableRow>
            <TableCell
              align="right"
              sx={{
                pl: 4,
                fontWeight: 500,
              }}
            >
              Discounts & Refunds
            </TableCell>

            {forecastMonths.map((month, index) => {
              const value = getAmountForMonth(
                discountsAndRefunds,
                month,
                index,
              );

              return (
                <TableCell
                  key={`discount-${getMonthKey(month)}-${index}`}
                  align="right"
                >
                  {renderEditableAmount({
                    value,

                    ariaLabel: `Discounts and Refunds ${
                      month?.fullLabel || `Month ${index + 1}`
                    }`,

                    onChange: (nextValue) =>
                      onDiscountChange?.(month, index, nextValue),
                  })}
                </TableCell>
              );
            })}

            {!readOnly && <TableCell />}
          </TableRow>

          <TableRow
            sx={{
              bgcolor: '#F8FAFC',
            }}
          >
            <TableCell
              align="right"
              sx={{
                bgcolor: '#F8FAFC',
              }}
            >
              <Typography variant="h6" fontWeight={800}>
                Total Cash Inflow (Estimated)
              </Typography>
            </TableCell>

            {forecastMonths.map((month, index) => {
              const value = totalCashInflowAmounts[index] || 0;

              return (
                <TableCell
                  key={`total-cash-inflow-${getMonthKey(month)}-${index}`}
                  align="right"
                  sx={{
                    bgcolor: '#F8FAFC',
                    fontWeight: 800,
                    whiteSpace: 'nowrap',
                    color: 'text.primary',
                  }}
                >
                  {renderCalculatedAmount(
                    value,
                    `Total cash inflow ${
                      month?.fullLabel || `Month ${index + 1}`
                    }`,
                  )}
                </TableCell>
              );
            })}

            {!readOnly && (
              <TableCell
                sx={{
                  width: '120px',
                  minWidth: '120px',
                  maxWidth: '120px',
                  bgcolor: '#F8FAFC',
                }}
              />
            )}
          </TableRow>

          <TableRow>
            <TableCell
              colSpan={columnCount}
              sx={{ ...subSectionCellSx, px: 0 }}
            >
              <Stack
                direction="row"
                sx={{
                  width: '100%',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <Typography variant="body2" sx={{ fontWeight: 800 }}>
                  Calculations (Estimated)
                </Typography>
              </Stack>
            </TableCell>
          </TableRow>

          <TableRow
            sx={{
              bgcolor: '#F8FAFC',
            }}
          >
            <TableCell
              align="right"
              sx={{
                bgcolor: '#F8FAFC',
              }}
            >
              <Typography variant="h6" fontWeight={800}>
                Total Cash Inflow (Estimated)
              </Typography>
            </TableCell>

            {forecastMonths.map((month, index) => {
              const value = totalCashInflowAmounts[index] || 0;

              return (
                <TableCell
                  key={`total-cash-inflow-${getMonthKey(month)}-${index}`}
                  align="right"
                  sx={{
                    bgcolor: '#F8FAFC',
                    fontWeight: 800,
                    whiteSpace: 'nowrap',
                    color: 'text.primary',
                  }}
                >
                  {renderCalculatedAmount(
                    value,
                    `Total cash inflow ${
                      month?.fullLabel || `Month ${index + 1}`
                    }`,
                  )}
                </TableCell>
              );
            })}

            {!readOnly && (
              <TableCell
                sx={{
                  width: '120px',
                  minWidth: '120px',
                  maxWidth: '120px',
                  bgcolor: '#F8FAFC',
                }}
              />
            )}
          </TableRow>

          <TableRow>
            <TableCell
              align="right"
              sx={{
                bgcolor: '#FAFAFA',
                color: 'text.primary',
              }}
            >
              <Typography variant="h6">
                {' '}
                Total Cash Outflow (Estimated)
              </Typography>
            </TableCell>

            {forecastMonths.map((month, index) => (
              <TableCell
                key={`outflow-${getMonthKey(month)}-${index}`}
                align="right"
                sx={{
                  fontWeight: 800,
                  bgcolor: '#FAFAFA',
                  whiteSpace: 'nowrap',
                  color:
                    Number(cashOutflowTotals[index]) < 0
                      ? 'error.main'
                      : 'text.primary',
                }}
              >
                {renderCalculatedAmount(
                  cashOutflowTotals[index],
                  `Total cash outflow ${month?.fullLabel || `Month ${index + 1}`}`,
                )}
              </TableCell>
            ))}

            {!readOnly && (
              <TableCell
                sx={{
                  width: '120px',
                  minWidth: '120px',
                  maxWidth: '120px',
                  bgcolor: '#FAFAFA',
                }}
              />
            )}
          </TableRow>

          <TableRow
            sx={{
              bgcolor: '#F8FAFC',
            }}
          >
            <TableCell align="right" sx={{}}>
              <Typography
                variant="h6"
                sx={{ overflowWrap: 'anywhere', whiteSpace: 'normal' }}
              >
                Cash Flow Surplus / Deficit (Estimated) From Previous Month
              </Typography>
            </TableCell>

            {forecastMonths.map((month, index) => {
              const calculatedValue = getAmountForMonth(
                previousMonthSurplusDeficit,
                month,
                index,
              );

              return (
                <TableCell
                  key={`previous-${getMonthKey(month)}-${index}`}
                  align="right"
                  sx={{
                    fontWeight: 700,
                    whiteSpace: 'nowrap',
                    color:
                      Number(calculatedValue) < 0
                        ? 'error.main'
                        : 'text.primary',
                  }}
                >
                  {index === 0 && !readOnly && !exporting
                    ? renderEditableAmount({
                        value: openingSurplusDeficit,

                        allowNegative: true,

                        ariaLabel:
                          'Cash Flow Surplus or Deficit from previous month',

                        onChange: (nextValue) =>
                          onOpeningBalanceChange?.(nextValue),
                      })
                    : renderCalculatedAmount(
                        calculatedValue,
                        `Cash Flow Surplus or Deficit from previous month ${month?.fullLabel || `Month ${index + 1}`}`,
                      )}
                </TableCell>
              );
            })}

            {!readOnly && (
              <TableCell
                sx={{
                  width: '120px',
                  minWidth: '120px',
                  maxWidth: '120px',
                  bgcolor: '#F8FAFC',
                }}
              />
            )}
          </TableRow>

          <TableRow
            sx={{
              bgcolor: '#D1D5DB',
            }}
          >
            <TableCell align="right" sx={{}}>
              <Typography
                variant="h6"
                sx={{ overflowWrap: 'anywhere', whiteSpace: 'normal' }}
              >
                {' '}
                Cash Flow Surplus / Deficit (Estimated)
              </Typography>
            </TableCell>

            {forecastMonths.map((month, index) => {
              const value =
                Number(getAmountForMonth(surplusDeficit, month, index)) || 0;

              return (
                <TableCell
                  key={`surplus-${getMonthKey(month)}-${index}`}
                  align="right"
                  sx={{
                    fontWeight: 800,
                    whiteSpace: 'nowrap',
                    color: value < 0 ? 'error.main' : 'text.primary',
                  }}
                >
                  {renderCalculatedAmount(
                    value,
                    `Cash Flow Surplus or Deficit ${month?.fullLabel || `Month ${index + 1}`}`,
                  )}
                </TableCell>
              );
            })}

            {!readOnly && (
              <TableCell
                sx={{
                  width: '120px',
                  minWidth: '120px',
                  maxWidth: '120px',
                  bgcolor: '#D1D5DB',
                }}
              />
            )}
          </TableRow>

          <TableRow>
            <TableCell
              colSpan={columnCount}
              sx={{
                py: 1.25,
                bgcolor: '#FFFFFF',
              }}
            >
              <Box>
                <Typography variant="caption" color="text.secondary">
                  * Discounts & Refunds - After the payment for items is
                  completed, the discount amount is subsequently reimbursed to
                  our account, which appears as an inflow in the bank statement.
                </Typography>
              </Box>
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
  );
}
