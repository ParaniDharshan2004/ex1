import {
  Box,
  Button,
  IconButton,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import { memo, useMemo, useState } from 'react';
import { Icons } from '../../theme/icons';
import { formatCompactAmount } from '../../utils/cash-flow-forecast/forecastFormatters';

const resetButtonSx = {
  '&:disabled, &.Mui-disabled': {
    color: '#BDBDBD',
    opacity: 1,
  },
};

const deleteButtonSx = {
  '&:disabled, &.Mui-disabled': {
    color: '#BDBDBD',
    opacity: 1,
  },
};

const addButtonSx = {
  '&:disabled, &.Mui-disabled': {
    color: '#BDBDBD',
    borderColor: '#D1D5DB',
  },
};

const formatCurrency = (value) => formatCompactAmount(value);

const formatPrintCurrency = (value) =>
  Number(value) === 0 ? '-' : formatCurrency(value);

const numberInputSx = {
  '& input[type="number"]': {
    MozAppearance: 'textfield',
  },
  '& input[type="number"]::-webkit-outer-spin-button, & input[type="number"]::-webkit-inner-spin-button':
    {
      WebkitAppearance: 'none',
      margin: 0,
    },
};

const getCategoryCode = (row) =>
  row.financialCategoryCode || row.financialCategoryId?.categoryCode || '';

const getSubCategoryCode = (row) =>
  row.financialSubCategoryCode ||
  row.financialSubCategoryId?.subCategoryCode ||
  '';

const getComponentName = (row) =>
  row.componentId?.componentName ||
  row.component?.componentName ||
  row.componentName ||
  row.tallyLedgerName ||
  '-';

const getRowId = (row) =>
  row._id ||
  row.id ||
  row.componentId?._id ||
  row.component?._id ||
  row.componentId ||
  row.componentCode ||
  row.tallyLedgerName;

const getForecastValue = (row, month, index) => {
  const positionalField = `month${index + 1}`;

  if (row[positionalField] !== undefined) {
    return row[positionalField];
  }

  if (month?.key && row[month.key] !== undefined) {
    return row[month.key];
  }

  if (month?.key && row.forecast?.[month.key] !== undefined) {
    return row.forecast[month.key];
  }

  if (month?.key && row.forecastValues?.[month.key] !== undefined) {
    return row.forecastValues[month.key];
  }

  if (Array.isArray(row.forecastAmounts)) {
    const matchingAmount = row.forecastAmounts.find(
      (item) => item.month === month?.key || item.key === month?.key,
    );

    if (matchingAmount) {
      return matchingAmount.amount;
    }

    return row.forecastAmounts[index]?.amount ?? 0;
  }

  return row[`month${index + 1}Amount`] ?? 0;
};

const sectionCellSx = {
  fontWeight: 800,
  bgcolor: '#E5E7EB',
  borderTop: '2px solid #111827',
};

const subSectionCellSx = {
  fontWeight: 800,
  bgcolor: '#F8FAFC',
};

const ForecastAmountInput = memo(function ForecastAmountInput({
  value,
  rowId,
  field,
  onCellChange,
}) {
  const [draftValue, setDraftValue] = useState(value ?? '');
  const [isEditing, setIsEditing] = useState(false);

  const commitValue = () => {
    const numericValue = Number(draftValue);

    onCellChange?.(
      rowId,
      field,
      draftValue === ''
        ? 0
        : Number.isFinite(numericValue)
          ? Math.max(0, numericValue)
          : 0,
    );
  };

  return (
    <TextField
      type="number"
      size="small"
      value={!isEditing && draftValue === '' ? 0 : draftValue}
      onFocus={() => setIsEditing(true)}
      onKeyDown={(event) => {
        if (['-', '+', 'e', 'E'].includes(event.key)) {
          event.preventDefault();
          return;
        }

        if (event.key === 'Enter') {
          event.currentTarget.blur();
        }
      }}
      onChange={(event) => {
        setDraftValue(event.target.value);
      }}
      onBlur={() => {
        commitValue();
        setIsEditing(false);
      }}
      inputProps={{
        min: 0,
        step: 1,
        inputMode: 'numeric',
      }}
      sx={{
        ...numberInputSx,
        width: '100%',
        '& input': {
          py: 0.7,
          textAlign: 'right',
        },
      }}
    />
  );
});

const FixedCostAmountInput = memo(function FixedCostAmountInput({
  value,
  rowId,
  field,
  onCellChange,
}) {
  const [draftValue, setDraftValue] = useState(value ?? '');
  const [isEditing, setIsEditing] = useState(false);

  return (
    <TextField
      type="number"
      size="small"
      value={!isEditing && draftValue === '' ? 0 : draftValue}
      onFocus={() => setIsEditing(true)}
      onChange={(event) => setDraftValue(event.target.value)}
      onBlur={() => {
        const numericValue = Number(draftValue);

        onCellChange?.(
          rowId,
          field,
          draftValue === ''
            ? 0
            : Number.isFinite(numericValue)
              ? Math.max(0, numericValue)
              : 0,
        );
        setIsEditing(false);
      }}
      onKeyDown={(event) => {
        if (event.key === 'Enter') {
          event.currentTarget.blur();
        }
      }}
      onKeyDownCapture={(event) => {
        if (['-', '+', 'e', 'E'].includes(event.key)) {
          event.preventDefault();
        }
      }}
      inputProps={{ min: 0 }}
      sx={{
        ...numberInputSx,
        width: '100%',
        '& input': {
          py: 0.7,
          textAlign: 'right',
        },
      }}
    />
  );
});

function SectionRow({ children, columnCount }) {
  return (
    <TableRow>
      <TableCell colSpan={columnCount} sx={sectionCellSx}>
        {children}
      </TableCell>
    </TableRow>
  );
}

function SubSectionRow({ children, action = null, columnCount, readOnly }) {
  return (
    <TableRow>
      <TableCell
        colSpan={columnCount}
        sx={{
          ...subSectionCellSx,
          px: action ? 0 : 1.2,
        }}
      >
        <Stack
          sx={{
            width: '100%',
            justifyContent: 'space-between',
          }}
        >
          <Typography
            component="span"
            variant="body2"
            fontWeight={800}
            sx={{
              pl: action ? 1.2 : 0,
            }}
          >
            {children}
          </Typography>
          {!readOnly && action}
        </Stack>
      </TableCell>
    </TableRow>
  );
}

function SpacerRow({ columnCount }) {
  return (
    <TableRow>
      <TableCell
        colSpan={columnCount}
        sx={{
          height: 16,
          p: 0,
          borderLeft: 0,
          borderRight: 0,
          bgcolor: '#FFFFFF',
        }}
      />
    </TableRow>
  );
}

function TotalRow({
  label,
  values,
  strong = false,
  readOnly,
  exporting,
  forecastMonths,
}) {
  return (
    <TableRow
      sx={{
        bgcolor: strong ? '#D1D5DB' : '#FAFAFA',
      }}
    >
      <TableCell
        align="right"
        sx={{
          fontWeight: 800,
          color: strong ? 'text.primary' : 'error.main',
        }}
      >
        <Typography variant="h6">{label}</Typography>
      </TableCell>

      {values.map((value, index) => (
        <TableCell
          key={`${label}-${index}`}
          align="right"
          sx={{
            fontWeight: 800,
            whiteSpace: 'nowrap',
          }}
        >
          {readOnly || exporting ? (
            <span className="amount-value-with-symbol">
              {readOnly ? formatPrintCurrency(value) : formatCurrency(value)}
            </span>
          ) : (
            <TextField
              size="small"
              value={formatCurrency(value)}
              inputProps={{
                readOnly: true,
                'aria-label': `${label} ${forecastMonths[index]?.fullLabel || `Month ${index + 1}`}`,
              }}
              sx={{
                width: '100%',
                '& input': {
                  py: 0.7,
                  textAlign: 'right',
                  fontFamily: '"DM Sans", sans-serif',
                  fontWeight: 400,
                },
              }}
            />
          )}
        </TableCell>
      ))}

      {!readOnly && <TableCell />}
    </TableRow>
  );
}

function EmptyRow({ message, columnCount }) {
  return (
    <TableRow>
      <TableCell
        colSpan={columnCount}
        align="center"
        sx={{
          py: 2,
          color: 'text.secondary',
        }}
      >
        {message}
      </TableCell>
    </TableRow>
  );
}

export default function ForecastStatementTable({
  rows = [],
  fixedCostRows = [],
  forecastMonths = [],
  exporting = false,
  readOnly = false,
  sections = ['direct', 'indirect', 'misc', 'grandTotal'],

  onCellChange,
  onFixedCostCellChange,

  onResetRow,
  onRemoveForecastRow,

  onAddFixedCost,
  onAddForecastRow,

  onResetFixedCost,
  onDeleteFixedCost,
}) {
  /*
   * Direct Cost rows are grouped using
   * financialSubCategoryCode.
   */
  const {
    directLabourRows,
    directMaterialRows,
    variableCostRows,
    miscExpenseRows,
  } = useMemo(
    () => ({
      directLabourRows: rows.filter(
        (row) =>
          getCategoryCode(row) === 'DIRECT_COST' &&
          getSubCategoryCode(row) === 'DIRECT_LABOUR',
      ),
      directMaterialRows: rows.filter(
        (row) =>
          getCategoryCode(row) === 'DIRECT_COST' &&
          getSubCategoryCode(row) === 'DIRECT_MATERIAL',
      ),
      variableCostRows: rows.filter(
        (row) =>
          getCategoryCode(row) === 'INDIRECT_COST' &&
          getSubCategoryCode(row) === 'VARIABLE_COST',
      ),
      miscExpenseRows: rows.filter(
        (row) => getCategoryCode(row) === 'MISC_EXPENSES',
      ),
    }),
    [rows],
  );

  const {
    directLabourTotals,
    directMaterialTotals,
    variableCostTotals,
    miscExpenseTotals,
    fixedCostTotals,
    directCostTotals,
    indirectCostTotals,
    cashOutflowTotals,
  } = useMemo(() => {
    const sumRows = (targetRows, month, index) =>
      targetRows.reduce(
        (total, row) =>
          total + (Number(getForecastValue(row, month, index)) || 0),
        0,
      );

    const getCategoryTotals = (targetRows) =>
      forecastMonths.map((month, index) => sumRows(targetRows, month, index));

    const nextDirectLabourTotals = getCategoryTotals(directLabourRows);
    const nextDirectMaterialTotals = getCategoryTotals(directMaterialRows);
    const nextVariableCostTotals = getCategoryTotals(variableCostRows);
    const nextMiscExpenseTotals = getCategoryTotals(miscExpenseRows);
    const nextFixedCostTotals = forecastMonths.map((_, index) =>
      fixedCostRows.reduce(
        (total, row) => total + (Number(row[`month${index + 1}Amount`]) || 0),
        0,
      ),
    );
    const nextDirectCostTotals = forecastMonths.map(
      (_, index) =>
        nextDirectLabourTotals[index] + nextDirectMaterialTotals[index],
    );
    const nextIndirectCostTotals = forecastMonths.map(
      (_, index) => nextVariableCostTotals[index] + nextFixedCostTotals[index],
    );

    return {
      directLabourTotals: nextDirectLabourTotals,
      directMaterialTotals: nextDirectMaterialTotals,
      variableCostTotals: nextVariableCostTotals,
      miscExpenseTotals: nextMiscExpenseTotals,
      fixedCostTotals: nextFixedCostTotals,
      directCostTotals: nextDirectCostTotals,
      indirectCostTotals: nextIndirectCostTotals,
      cashOutflowTotals: forecastMonths.map(
        (_, index) =>
          nextDirectCostTotals[index] +
          nextIndirectCostTotals[index] +
          nextMiscExpenseTotals[index],
      ),
    };
  }, [
    directLabourRows,
    directMaterialRows,
    variableCostRows,
    miscExpenseRows,
    fixedCostRows,
    forecastMonths,
  ]);

  const columnCount = 1 + forecastMonths.length + (readOnly ? 0 : 1);

  const renderForecastRows = (targetRows) => {
    if (!targetRows.length) {
      return (
        <EmptyRow
          message="No components available."
          columnCount={columnCount}
        />
      );
    }

    const parentRows = targetRows.filter((row) => !row.parentComponentId);
    const childRows = targetRows.filter((row) => row.parentComponentId);
    const orderedRows = parentRows.flatMap((parentRow) => {
      const parentComponentId = String(
        parentRow.componentId?._id || parentRow.componentId || '',
      );
      const children = childRows.filter(
        (row) => String(row.parentComponentId) === parentComponentId,
      );

      return [parentRow, ...children];
    });
    const renderedRowIds = new Set(
      orderedRows.map((row) => String(getRowId(row))),
    );
    const rowsToRender = [
      ...orderedRows,
      ...childRows.filter((row) => !renderedRowIds.has(String(getRowId(row)))),
    ];

    return rowsToRender.map((row) => {
      const rowId = getRowId(row);

      return (
        <TableRow key={String(rowId)} hover={!readOnly}>
          <TableCell
            sx={{
              pl: row.parentComponentId ? 6 : 4,
              fontStyle: readOnly ? 'italic' : 'normal',
              textAlign: 'right',
            }}
          >
            <Typography variant="body2">{getComponentName(row)}</Typography>
          </TableCell>

          {forecastMonths.map((month, index) => {
            const value = getForecastValue(row, month, index);

            /*
             * These field names must match the
             * CashFlowForecastPage editing handler.
             */
            const field = `month${index + 1}`;

            return (
              <TableCell key={`${String(rowId)}-${field}`} align="right">
                {readOnly ? (
                  formatPrintCurrency(value)
                ) : (
                  <ForecastAmountInput
                    key={`${String(rowId)}-${field}-${String(value)}`}
                    value={value}
                    rowId={rowId}
                    field={field}
                    onCellChange={onCellChange}
                  />
                )}
              </TableCell>
            );
          })}

          {!readOnly && (
            <TableCell align="center" sx={{ px: '4px !important' }}>
              <Stack
                direction="row"
                sx={{ alignItems: 'center', justifyContent: 'center' }}
                spacing={0.25}
              >
                <Tooltip title="Reset amounts" arrow>
                  <IconButton
                    size="small"
                    color="primary"
                    sx={resetButtonSx}
                    disabled={exporting}
                    aria-label={`Reset amounts for ${getComponentName(row)}`}
                    onClick={() => onResetRow?.(rowId)}
                  >
                    <Icons.RefreshIcon fontSize="small" />
                  </IconButton>
                </Tooltip>

                <Tooltip title="Remove from report" arrow>
                  <IconButton
                    size="small"
                    color="error"
                    sx={deleteButtonSx}
                    disabled={exporting}
                    aria-label={`Remove ${getComponentName(row)} from report`}
                    onClick={() => onRemoveForecastRow?.(row._id, row)}
                  >
                    <Icons.DeleteOutlineIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Stack>
            </TableCell>
          )}
        </TableRow>
      );
    });
  };

  const renderFixedCostRows = () => {
    if (!fixedCostRows.length) {
      return (
        <EmptyRow
          message="No Fixed Costs Items have been added."
          columnCount={columnCount}
        />
      );
    }

    return fixedCostRows.map((row) => (
      <TableRow key={String(row._id)} hover={!readOnly}>
        <TableCell
          sx={{
            pl: 4,
            fontStyle: readOnly ? 'italic' : 'normal',
            textAlign: 'right',
          }}
        >
          <Typography variant="body2" fontWeight={readOnly ? 400 : 500}>
            {row.itemName}
          </Typography>

          {row.description && (
            <Typography
              variant="caption"
              color="text.secondary"
              display="block"
            >
              {row.description}
            </Typography>
          )}
        </TableCell>

        {forecastMonths.map((month, index) => {
          const field = `month${index + 1}Amount`;

          const value = row[field] ?? 0;

          return (
            <TableCell
              key={`${row._id}-${field}`}
              align="right"
              sx={{
                whiteSpace: 'nowrap',
              }}
            >
              {readOnly ? (
                formatPrintCurrency(value)
              ) : (
                <FixedCostAmountInput
                  key={`${String(row._id)}-${field}-${String(value)}`}
                  value={value}
                  rowId={row._id}
                  field={field}
                  onCellChange={onFixedCostCellChange}
                />
              )}
            </TableCell>
          );
        })}

        {!readOnly && (
          <TableCell
            align="center"
            sx={{
              px: '4px !important',
            }}
          >
            <Stack
              direction="row"
              sx={{ alignItems: 'center', justifyContent: 'center' }}
              spacing={0.25}
            >
              <Tooltip title="Reset amounts" arrow>
                <IconButton
                  size="small"
                  color="primary"
                  sx={resetButtonSx}
                  disabled={exporting}
                  aria-label={`Reset amounts for ${row.itemName}`}
                  onClick={() => onResetFixedCost?.(row)}
                >
                  <Icons.RefreshIcon fontSize="small" />
                </IconButton>
              </Tooltip>

              <Tooltip title="Remove from report" arrow>
                <IconButton
                  size="small"
                  color="error"
                  sx={deleteButtonSx}
                  disabled={exporting}
                  aria-label={`Remove ${row.itemName} from report`}
                  onClick={() => onDeleteFixedCost?.(row._id, row)}
                >
                  <Icons.DeleteOutlineIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Stack>
          </TableCell>
        )}
      </TableRow>
    ));
  };

  return (
    <TableContainer
      sx={{
        width: '100%',
        overflowX: readOnly ? 'hidden' : 'auto',
      }}
    >
      <Table
        size="small"
        sx={{
          width: '100%',
          minWidth: readOnly ? 700 : 850,
          tableLayout: 'fixed',
          '& td, & th': {
            border: '1px solid #111827',
            boxSizing: 'border-box',
            py: readOnly ? 0.35 : 0.8,
            px: readOnly ? 0.7 : 1.2,
          },
        }}
      >
        <TableHead>
          <TableRow
            sx={{
              bgcolor: '#D1D5DB',
            }}
          >
            <TableCell
              align="center"
              sx={{
                width: readOnly ? '55%' : '42%',
                fontWeight: 800,
              }}
            >
              Particulars
            </TableCell>

            {forecastMonths.map((month, index) => (
              <TableCell
                key={month?.key || index}
                align="center"
                sx={{
                  width: readOnly ? '15%' : '16%',
                  fontWeight: 800,
                }}
              >
                {month?.fullLabel || `Month ${index + 1}`}

                <Typography component="div" variant="caption" fontWeight={700}>
                  (Estimated in Rs)
                </Typography>
              </TableCell>
            ))}

            {!readOnly && (
              <TableCell
                align="center"
                sx={{
                  width: 90,
                  fontWeight: 800,
                }}
              >
                Actions
              </TableCell>
            )}
          </TableRow>
        </TableHead>

        <TableBody>
          {sections.includes('direct') && (
            <>
              <SectionRow columnCount={columnCount}>
                <Typography variant="h5">Direct Cost</Typography>
              </SectionRow>

              <SubSectionRow columnCount={columnCount} readOnly={readOnly}>
                <Box
                  sx={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <Typography variant="h6">Direct Labour</Typography>

                  {!readOnly && (
                    <Button
                      size="small"
                      variant="outlined"
                      sx={addButtonSx}
                      disabled={exporting}
                      onClick={() =>
                        onAddForecastRow?.({
                          categoryCode: 'DIRECT_COST',
                          subCategoryCode: 'DIRECT_LABOUR',
                          sectionName: 'Direct Labour',
                        })
                      }
                    >
                      + Add Item
                    </Button>
                  )}
                </Box>
              </SubSectionRow>

              {renderForecastRows(directLabourRows)}

              <TotalRow
                readOnly={readOnly}
                exporting={exporting}
                forecastMonths={forecastMonths}
                label="Total Direct Labour"
                values={directLabourTotals}
              />

              <SubSectionRow columnCount={columnCount} readOnly={readOnly}>
                <Box
                  sx={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <Typography variant="h6">Direct Material</Typography>

                  {!readOnly && (
                    <Button
                      size="small"
                      variant="outlined"
                      sx={addButtonSx}
                      disabled={exporting}
                      onClick={() =>
                        onAddForecastRow?.({
                          categoryCode: 'DIRECT_COST',
                          subCategoryCode: 'DIRECT_MATERIAL',
                          sectionName: 'Direct Material',
                        })
                      }
                    >
                      + Add Item
                    </Button>
                  )}
                </Box>
              </SubSectionRow>

              {renderForecastRows(directMaterialRows)}

              <TotalRow
                readOnly={readOnly}
                exporting={exporting}
                forecastMonths={forecastMonths}
                label="Total Direct Material"
                values={directMaterialTotals}
              />

              <TotalRow
                readOnly={readOnly}
                exporting={exporting}
                forecastMonths={forecastMonths}
                label="Total Direct Cost"
                values={directCostTotals}
                strong
              />

              <SpacerRow columnCount={columnCount} />
            </>
          )}

          {sections.includes('indirect') && (
            <>
              <SectionRow columnCount={columnCount}>
                <Typography variant="h5">Indirect Cost</Typography>
              </SectionRow>

              <SubSectionRow columnCount={columnCount} readOnly={readOnly}>
                <Box
                  sx={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <Typography variant="h6">Variable Cost</Typography>

                  {!readOnly && (
                    <Button
                      size="small"
                      variant="outlined"
                      sx={addButtonSx}
                      disabled={exporting}
                      onClick={() =>
                        onAddForecastRow?.({
                          categoryCode: 'INDIRECT_COST',
                          subCategoryCode: 'VARIABLE_COST',
                          sectionName: 'Variable Cost',
                        })
                      }
                    >
                      + Add Item
                    </Button>
                  )}
                </Box>
              </SubSectionRow>

              {renderForecastRows(variableCostRows)}

              <TotalRow
                readOnly={readOnly}
                exporting={exporting}
                forecastMonths={forecastMonths}
                label="Total Variable Cost"
                values={variableCostTotals}
              />

              <SubSectionRow columnCount={columnCount} readOnly={readOnly}>
                <Box
                  sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    width: '100%',
                  }}
                >
                  <Typography variant="h6">Fixed Cost</Typography>

                  {!readOnly && (
                    <Button
                      size="small"
                      variant="outlined"
                      sx={addButtonSx}
                      disabled={exporting}
                      onClick={onAddFixedCost}
                    >
                      + Add Item
                    </Button>
                  )}
                </Box>
              </SubSectionRow>

              {renderFixedCostRows()}

              <TotalRow
                readOnly={readOnly}
                exporting={exporting}
                forecastMonths={forecastMonths}
                label="Total Fixed Cost"
                values={fixedCostTotals}
              />

              <TotalRow
                readOnly={readOnly}
                exporting={exporting}
                forecastMonths={forecastMonths}
                label="Total Indirect Cost"
                values={indirectCostTotals}
                strong
              />

              <SpacerRow columnCount={columnCount} />
            </>
          )}

          {sections.includes('misc') && (
            <>
              <SectionRow columnCount={columnCount}>
                <Box
                  sx={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <Typography variant="h5">Misc Expenses</Typography>

                  {!readOnly && (
                    <Button
                      size="small"
                      variant="outlined"
                      sx={addButtonSx}
                      disabled={exporting}
                      onClick={() =>
                        onAddForecastRow?.({
                          categoryCode: 'MISC_EXPENSES',
                          subCategoryCode: null,
                          sectionName: 'Misc Expenses',
                        })
                      }
                    >
                      + Add Item
                    </Button>
                  )}
                </Box>
              </SectionRow>

              {renderForecastRows(miscExpenseRows)}

              <TotalRow
                readOnly={readOnly}
                exporting={exporting}
                forecastMonths={forecastMonths}
                label="Total Misc Expenses"
                values={miscExpenseTotals}
                strong
              />

              <SpacerRow columnCount={columnCount} />
            </>
          )}

          {sections.includes('grandTotal') && (
            <TotalRow
              readOnly={readOnly}
              exporting={exporting}
              forecastMonths={forecastMonths}
              label="Total Cash Outflow (Estimated)"
              values={cashOutflowTotals}
              strong
            />
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
