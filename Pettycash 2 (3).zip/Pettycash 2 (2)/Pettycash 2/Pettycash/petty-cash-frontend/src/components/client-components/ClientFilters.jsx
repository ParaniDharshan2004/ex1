import {
  InputAdornment,
  MenuItem,
  Select,
  Stack,
  TextField,
  Button,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import { Icons } from "../../theme/icons";

export default function ClientFilters({ filters, setFilters, onAdd }) {
  const theme = useTheme();
  const isMobile = useMediaQuery("(max-width:600px)");

  return (
    <Stack
      direction={isMobile ? "column" : "row"}
      spacing={1.5}
      alignItems={isMobile ? "stretch" : "center"}
      sx={{ mb: 2 }}
    >
      <TextField
        size="small"
        placeholder="Search by client"
        value={filters.search}
        onChange={(event) =>
          setFilters((current) => ({ ...current, search: event.target.value }))
        }
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Icons.SearchIcon fontSize="small" />
            </InputAdornment>
          ),
        }}
        sx={{ flex: 1 }}
      />
      <Select
        size="small"
        value={filters.status}
        onChange={(event) =>
          setFilters((current) => ({ ...current, status: event.target.value }))
        }
        displayEmpty
        sx={{ minWidth: 140 }}
      >
        <MenuItem value="">Both</MenuItem>
        <MenuItem value="Active">Active</MenuItem>
        <MenuItem value="Inactive">Inactive</MenuItem>
      </Select>
      <Button
        variant="contained"
        startIcon={<Icons.AddIcon />}
        onClick={onAdd}
        sx={{
          bgcolor: "primary.main",
          color: "textPrimary",
          "&:hover": { bgcolor: theme.palette.primary.main },
          whiteSpace: "nowrap",
        }}
      >
         Add Client
      </Button>
    </Stack>
  );
}