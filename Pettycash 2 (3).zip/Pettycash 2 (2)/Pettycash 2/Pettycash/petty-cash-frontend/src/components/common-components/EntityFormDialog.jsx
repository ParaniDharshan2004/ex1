import { useMemo, useState } from 'react';
import {
  alpha,
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  IconButton,
  MenuItem,
  Select,
  Stack,
  TextField,
  Typography,
  useTheme,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ConfirmDialog from './ConfirmDialog';

function renderField(field, value, onChange, error) {
  if (field.type === 'select') {
    return (
      <Select
        displayEmpty
        value={value ?? ''}
        onChange={(event) => onChange(field.name, event.target.value)}
        size="small"
        fullWidth
        error={Boolean(error)}
        disabled={field.disabled}
      >
        <MenuItem value="" disabled>
          {field.label}
        </MenuItem>

        {(field.options || []).map((option) => {
          const optionValue =
            typeof option === 'object' ? option.value : option;

          const optionLabel =
            typeof option === 'object' ? option.label : option;

          return (
            <MenuItem key={String(optionValue)} value={optionValue}>
              {optionLabel}
            </MenuItem>
          );
        })}
      </Select>
    );
  }

  if (field.type === 'date') {
    return (
      <TextField
        size="small"
        fullWidth
        type="date"
        value={value ?? ''}
        onChange={(event) => onChange(field.name, event.target.value)}
        InputLabelProps={{ shrink: true }}
        error={Boolean(error)}
        disabled={field.disabled}
      />
    );
  }

  if (field.type === 'number') {
    return (
      <TextField
        label={field.label}
        size="small"
        fullWidth
        type="number"
        value={value ?? ''}
        onChange={(event) => {
          const inputValue = event.target.value;
          const numericValue = Number(inputValue);

          onChange(
            field.name,
            inputValue !== '' &&
              field.min !== undefined &&
              Number.isFinite(numericValue) &&
              numericValue < Number(field.min)
              ? Number(field.min)
              : inputValue,
          );
        }}
        onKeyDown={(event) => {
          if (['e', 'E', '+', '-'].includes(event.key)) {
            event.preventDefault();
          }

          field.onKeyDown?.(event);
        }}
        onPaste={(event) => {
          const pastedText = event.clipboardData.getData('text');

          if (/[eE+-]/.test(pastedText)) {
            event.preventDefault();
            return;
          }

          if (field.min !== undefined) {
            const pastedValue = Number(pastedText);

            if (
              Number.isFinite(pastedValue) &&
              pastedValue < Number(field.min)
            ) {
              event.preventDefault();
            }
          }
        }}
        error={Boolean(error)}
        disabled={field.disabled}
        inputProps={{
          min: field.min ?? 0,
          max: field.max,
          step: field.step ?? 'any',
        }}
        sx={{
          '& input[type="number"]': {
            MozAppearance: 'textfield',
          },
          '& input[type="number"]::-webkit-outer-spin-button, & input[type="number"]::-webkit-inner-spin-button':
            {
              WebkitAppearance: 'none',
              margin: 0,
            },
        }}
      />
    );
  }

  if (field.type === 'checkbox') {
    return (
      <FormControlLabel
        control={
          <Checkbox
            checked={Boolean(value)}
            disabled={field.disabled}
            onChange={(event) => onChange(field.name, event.target.checked)}
          />
        }
        label={field.label}
      />
    );
  }

  if (field.name === 'maskedAccountNumber') {
    return (
      <TextField
        label={field.label}
        size="small"
        fullWidth
        value={value ?? ''}
        error={Boolean(error)}
        disabled={field.disabled}
        inputProps={{ maxLength: 4 }}
        onChange={(event) =>
          onChange(
            field.name,
            event.target.value.replace(/\D/g, '').slice(0, 4),
          )
        }
      />
    );
  }

  return (
    <TextField
      label={field.label}
      size="small"
      fullWidth
      value={value ?? ''}
      error={Boolean(error)}
      disabled={field.disabled}
      multiline={Boolean(field.multiline)}
      rows={field.rows}
      placeholder={field.placeholder}
      onChange={(event) => onChange(field.name, event.target.value)}
    />
  );
}

function resolveConfirmationValue(
  confirmationValue,
  formValues,
  fallbackValue,
) {
  if (typeof confirmationValue === 'function') {
    return confirmationValue(formValues) || fallbackValue;
  }

  return confirmationValue || fallbackValue;
}

function EntityFormDialogContent({
  open,
  mode = 'create',
  title,
  fields = [],
  initialValues = {},
  loading = false,
  onClose,
  onSave,
  onFieldChange,
  saveConfirmTitle,
  saveConfirmMessage,
  saveConfirmLabel,
}) {
  const theme = useTheme();

  const [values, setValues] = useState(() => initialValues || {});
  const [errors, setErrors] = useState({});
  const [confirmSaveOpen, setConfirmSaveOpen] = useState(false);
  const [confirmDiscardOpen, setConfirmDiscardOpen] = useState(false);

  const isDirty = useMemo(
    () => JSON.stringify(values) !== JSON.stringify(initialValues || {}),
    [values, initialValues],
  );

  const resolvedSaveConfirmTitle = resolveConfirmationValue(
    saveConfirmTitle,
    values,
    mode === 'edit' ? 'Update Client Details?' : 'Save Client Details?',
  );

  const resolvedSaveConfirmMessage = resolveConfirmationValue(
    saveConfirmMessage,
    values,
    mode === 'edit'
      ? 'Are you sure you want to update these details?'
      : 'Are you sure you want to save these changes?',
  );

  const resolvedSaveConfirmLabel = resolveConfirmationValue(
    saveConfirmLabel,
    values,
    mode === 'edit' ? 'Yes, update' : 'Yes, save',
  );

  const handleChange = (name, value) => {
    const resetFields =
      fields.find((field) => field.name === name)?.resetFields || [];
    setValues((currentValues) => {
      const nextValues = {
        ...currentValues,
        [name]: value,
      };
      resetFields.forEach((fieldName) => {
        nextValues[fieldName] = '';
      });
      return nextValues;
    });

    setErrors((currentErrors) => {
      if (!currentErrors[name] && !resetFields.some((field) => currentErrors[field])) {
        return currentErrors;
      }

      const nextErrors = { ...currentErrors };
      delete nextErrors[name];
      resetFields.forEach((fieldName) => {
        delete nextErrors[fieldName];
      });
      return nextErrors;
    });

    onFieldChange?.(name, value);
  };

  const validate = () => {
    const nextErrors = {};

    fields.forEach((field) => {
      const value = values[field.name];

      const isEmpty =
        value === undefined ||
        value === null ||
        (typeof value === 'string' && value.trim() === '');

      if (field.required && isEmpty) {
        nextErrors[field.name] = `${field.label} is required`;
        return;
      }

      if (field.type === 'number' && !isEmpty && Number.isNaN(Number(value))) {
        nextErrors[field.name] = `${field.label} must be a valid number`;
        return;
      }

      if (
        field.type === 'number' &&
        !isEmpty &&
        field.min !== undefined &&
        Number(value) < Number(field.min)
      ) {
        nextErrors[field.name] = `${field.label} must be at least ${field.min}`;
      }
    });

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmitClick = () => {
    if (!validate()) return;
    setConfirmSaveOpen(true);
  };

  const handleConfirmSave = async () => {
    if (loading) return;

    try {
      setConfirmSaveOpen(false);
      await onSave(values);
    } catch (error) {
      console.error('Entity form save error:', error);
    }
  };

  const handleCloseAttempt = () => {
    if (loading) return;

    if (isDirty) {
      setConfirmDiscardOpen(true);
      return;
    }

    onClose();
  };

  const handleConfirmDiscard = () => {
    setConfirmDiscardOpen(false);
    setConfirmSaveOpen(false);
    onClose();
  };

  return (
    <>
      <Dialog open={open} onClose={handleCloseAttempt} fullWidth maxWidth="xs">
        <DialogTitle
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            fontWeight: 700,
            color: 'text.primary',
          }}
        >
          {title}

          <IconButton
            size="small"
            onClick={handleCloseAttempt}
            aria-label="Close"
            disabled={loading}
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>

        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            {fields.map((field) => (
              <Box key={field.name}>
                {renderField(
                  field,
                  values[field.name],
                  handleChange,
                  errors[field.name],
                )}

                {errors[field.name] && (
                  <Typography
                    variant="caption"
                    sx={{
                      color: 'error.main',
                      display: 'block',
                      mt: 0.5,
                    }}
                  >
                    {errors[field.name]}
                  </Typography>
                )}
              </Box>
            ))}
          </Stack>
        </DialogContent>

        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={handleCloseAttempt}
            disabled={loading}
            sx={{ color: 'text.primary' }}
          >
            Cancel
          </Button>

          <Button
            variant="contained"
            onClick={handleSubmitClick}
            disabled={loading}
            sx={{
              color: '#fff',
              bgcolor: 'primary.main',
              '&:hover': {
                bgcolor: alpha(theme.palette.primary.main, 0.9),
              },
            }}
          >
            {loading ? 'Saving...' : mode === 'edit' ? 'Update' : 'Submit'}
          </Button>
        </DialogActions>
      </Dialog>

      <ConfirmDialog
        open={confirmSaveOpen}
        title={resolvedSaveConfirmTitle}
        message={resolvedSaveConfirmMessage}
        confirmLabel={resolvedSaveConfirmLabel}
        confirmColor="primary.main"
        onConfirm={handleConfirmSave}
        onCancel={() => {
          if (!loading) {
            setConfirmSaveOpen(false);
          }
        }}
      />

      <ConfirmDialog
        open={confirmDiscardOpen}
        title="Discard changes?"
        message="You have unsaved changes on this form. Closing now will discard them."
        confirmLabel="Yes, discard"
        confirmColor="error.main"
        onConfirm={handleConfirmDiscard}
        onCancel={() => setConfirmDiscardOpen(false)}
      />
    </>
  );
}

export default function EntityFormDialog(props) {
  const entityId =
    props.initialValues?._id ||
    props.initialValues?.id ||
    (props.mode === 'edit' ? 'edit' : 'new');

  const dialogKey = `${props.mode || 'create'}-${String(entityId)}-${
    props.open ? 'open' : 'closed'
  }`;

  return <EntityFormDialogContent key={dialogKey} {...props} />;
}