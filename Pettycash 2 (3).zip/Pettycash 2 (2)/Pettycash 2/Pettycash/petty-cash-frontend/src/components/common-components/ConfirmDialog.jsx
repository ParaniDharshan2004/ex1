import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from "@mui/material";

export default function ConfirmDialog({ open, title, message, confirmLabel, confirmColor, onConfirm, onCancel }) {
  return (
    <Dialog open={open} onClose={onCancel} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ fontWeight: 700, color: "textPrimary" }}>{title}</DialogTitle>
      <DialogContent>
        <Typography variant="body2" sx={{ color: "textPrimary" }}>{message}</Typography>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onCancel} sx={{ color: "textPrimary" }}>Cancel</Button>
        <Button
          variant="contained"
          onClick={onConfirm}
          sx={{ bgcolor: confirmColor || "textPrimary", "&:hover": { filter: "brightness(0.9)" } }}
        >
          {confirmLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
}