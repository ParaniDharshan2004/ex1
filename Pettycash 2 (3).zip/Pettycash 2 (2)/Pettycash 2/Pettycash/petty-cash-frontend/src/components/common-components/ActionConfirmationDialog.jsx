import {
  Alert,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';

export default function ActionConfirmationDialog({
  open,
  title,
  message,
  confirmLabel,
  loadingLabel,
  loading = false,
  errorMessage = '',
  confirmVariant = 'contained',
  onConfirm,
  onCancel,
}) {
  return (
    <Dialog
      open={open}
      onClose={(_, reason) => {
        if (reason === 'backdropClick') return;
        if (!loading) onCancel();
      }}
      maxWidth="xs"
      fullWidth
      sx={{
        '& .MuiDialog-paper': {
          borderRadius: '16px',
          overflow: 'hidden',
        },
      }}
    >
      <DialogTitle
        sx={{
          px: { xs: 2.5, sm: 3 },
          pt: { xs: 2.5, sm: 3 },
          pb: 1,
          color: '#182036',
          fontSize: '18px',
          fontWeight: 700,
          lineHeight: 1.35,
        }}
      >
        {title}
      </DialogTitle>
      <DialogContent
        sx={{
          px: { xs: 2.5, sm: 3 },
          pt: '4px !important',
          pb: 1.5,
        }}
      >
        <DialogContentText
          sx={{
            m: 0,
            color: '#566277',
            fontSize: '16px',
            lineHeight: 1.55,
          }}
        >
          {message}
        </DialogContentText>
        {errorMessage && (
          <Alert severity="error" sx={{ mt: 2, borderRadius: '10px' }}>
            {errorMessage}
          </Alert>
        )}
      </DialogContent>
      <DialogActions
        sx={{
          px: { xs: 2.5, sm: 3 },
          pt: 1.5,
          pb: { xs: 2.5, sm: 3 },
          gap: 1.5,
          justifyContent: 'flex-end',
          flexDirection: { xs: 'column', sm: 'row' },
          alignItems: { xs: 'stretch', sm: 'center' },
        }}
      >
        <Button
          variant="outlined"
          disabled={loading}
          onClick={onCancel}
          sx={{
            minWidth: { xs: '100%', sm: 140 },
            minHeight: 46,
            px: 2,
            borderRadius: '10px',
            textTransform: 'none',
            fontWeight: 700,
          }}
        >
          Cancel
        </Button>
        <Button
          variant={confirmVariant}
          color="error"
          disabled={loading}
          startIcon={loading ? <CircularProgress size={16} color="inherit" /> : undefined}
          onClick={onConfirm}
          sx={{
            minWidth: { xs: '100%', sm: 140 },
            minHeight: 46,
            px: 2,
            borderRadius: '10px',
            textTransform: 'none',
            fontWeight: 700,
          }}
        >
          {loading ? loadingLabel : confirmLabel}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
