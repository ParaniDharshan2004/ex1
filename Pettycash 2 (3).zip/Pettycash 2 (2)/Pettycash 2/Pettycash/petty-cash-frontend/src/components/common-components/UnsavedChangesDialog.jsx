import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
  Stack,
  Typography,
} from '@mui/material';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import SaveRoundedIcon from '@mui/icons-material/SaveRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';

const buttonSx = {
  flex: { xs: '1 1 100%', sm: '0 1 160px' },
  width: { xs: '100%', sm: '160px' },
  minHeight: 48,
  whiteSpace: 'nowrap',
  px: 2.25,
  borderRadius: '10px',
  fontWeight: 700,
  textTransform: 'none',
  boxShadow: '0 3px 8px rgba(26, 42, 82, 0.16)',
};

const TITLE = 'Save your progress?';
const MESSAGE = 'You have unsaved changes. How would you like to proceed?';
const DISCARD_LABEL = 'Discard';
const SAVE_LABEL = 'Save';
const DISCARDING_LABEL = 'Discarding...';
const SAVING_LABEL = 'Saving...';

export default function UnsavedChangesDialog({
  open,
  loading = false,
  loadingAction = '',
  errorMessage = '',
  title = TITLE,
  message = MESSAGE,
  continueLabel = '',
  onContinue,
  onDiscard,
  onSave,
  onClose,
}) {
  return (
    <Dialog
      open={open}
      onClose={(_, reason) => {
        if (!loading && reason !== 'backdropClick') onClose?.();
      }}
      maxWidth="xs"
      fullWidth
      sx={{ '& .MuiDialog-paper': { borderRadius: '16px', overflow: 'hidden' } }}
    >
      <DialogTitle
        sx={{
          px: { xs: 2.5, sm: 3 },
          pt: 3,
          pb: 1.5,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 1.5,
        }}
      >
        <Stack direction="row" sx={{ display: 'flex', alignItems: 'center', gap: 1.5, minWidth: 0 }}>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 42,
              height: 42,
              flexShrink: 0,
              borderRadius: '12px',
              bgcolor: 'primary.light',
              color: 'primary.dark',
            }}
          >
            <SaveRoundedIcon />
          </Box>
          <Typography variant="h6" sx={{ fontWeight: 800, color: '#182036' }}>
            {title}
          </Typography>
        </Stack>
        <IconButton
          aria-label="Close save progress dialog"
          onClick={onClose}
          disabled={loading}
          size="small"
          sx={{ flexShrink: 0, color: '#647087' }}
        >
          <CloseRoundedIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent sx={{ px: { xs: 2.5, sm: 3 }, pb: 1 }}>
        <DialogContentText sx={{ color: '#566277', lineHeight: 1.6 }}>
          {message}
        </DialogContentText>
        {errorMessage && (
          <Alert severity="error" sx={{ mt: 2, borderRadius: '10px' }}>
            {errorMessage}
          </Alert>
        )}
      </DialogContent>
      <DialogActions
        sx={{
          px: { xs: 2.5, sm: 3 },
          pt: 2,
          pb: 2.5,
          gap: 1,
          justifyContent: 'flex-end',
          flexDirection: { xs: 'column', sm: 'row' },
          alignItems: { xs: 'stretch', sm: 'center' },
          '& .MuiButton-root': buttonSx,
          '& > :not(style) ~ :not(style)': { ml: { xs: 0, sm: 1 } },
        }}
      >
        <Button
          variant="contained"
          color="error"
          disabled={loading}
          startIcon={loadingAction === 'discard' ? <CircularProgress size={16} color="inherit" /> : <DeleteOutlineRoundedIcon />}
          onClick={onDiscard}
          sx={buttonSx}
        >
          {loadingAction === 'discard' ? DISCARDING_LABEL : DISCARD_LABEL}
        </Button>
        {continueLabel && (
          <Button
            variant="outlined"
            disabled={loading}
            onClick={onContinue}
            sx={buttonSx}
          >
            {continueLabel}
          </Button>
        )}
        <Button
          variant="contained"
          disabled={loading}
          startIcon={loadingAction === 'save' ? <CircularProgress size={16} color="inherit" /> : <SaveRoundedIcon />}
          onClick={onSave}
          sx={buttonSx}
        >
          {loadingAction === 'save' ? SAVING_LABEL : SAVE_LABEL}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
