import { Fragment } from 'react';
import {
  Box,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress,
} from '@mui/material';
import VerifiedUserRoundedIcon from '@mui/icons-material/VerifiedUserRounded';
import { formatINR } from '../../../utils/operationalExpense/currency';
import { groupFixedAssetsByParent } from '../../../utils/operationalExpense/fixedAssetMapping';

export default function ExpensePreviewTable({
  expenses = [],
  fixedCosts = [],
  directCostTotal = 0,
  indirectCostTotal = 0,
  subtotal = 0,
  markup = 0,
  fixedCostTotal = 0,
  miscellaneousExpenseTotal = 0,
  totalBillable = 0,
  onApprove,
  isApproving = false,
  approveLabel = 'Approve data',
  approveProgressLabel = 'Approving...',
  allowEmptyApprove = false,
  readOnly = false,
  headerActions,
  clientAllocations = [],
  footerActions,
}) {
  const miscellaneousRows = expenses.filter((row) =>
    /\bmisc(?:ellaneous)?\b/i.test(String(row.category || '')),
  );
  const operationalRows = expenses.filter(
    (row) => !miscellaneousRows.includes(row),
  );
  const fixedAssetGroups = groupFixedAssetsByParent(fixedCosts);

  return (
    <Fragment>
      <Box
        sx={{
          bgcolor: '#fff',
          border: '1px solid #dde3ed',
          borderRadius: '15px',
          boxShadow: '0 14px 40px rgba(26, 42, 82, 0.05)',
          p: { xs: 2, sm: 2.5 },
        }}
      >
      <Box
        sx={{
          display: 'flex',
          gap: 2,
          justifyContent: 'space-between',
          alignItems: { xs: 'flex-start', sm: 'center' },
          flexDirection: { xs: 'column', sm: 'row' },
          mb: 2,
        }}
      >
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              gap: 2,
            }}
          >
            <Box>
              <Typography sx={{ fontWeight: 800, fontSize: '15px', color: '#182036' }}>
                {readOnly ? 'Expense report details' : 'Tally report preview'}
              </Typography>
          
            </Box>
            {headerActions}
          </Box>
        </Box>

        {!readOnly && <Box sx={{ display: 'flex', gap: 1 }}>
          <Button
            variant="contained"
            disabled={
              isApproving ||
              (!allowEmptyApprove &&
                expenses.length === 0 &&
                fixedCosts.length === 0 &&
                fixedCostTotal === 0 &&
                miscellaneousExpenseTotal === 0)
            }
            startIcon={
              isApproving ? (
                <CircularProgress size={16} sx={{ color: '#fff' }} />
              ) : (
                <VerifiedUserRoundedIcon sx={{ fontSize: 18 }} />
              )
            }
            onClick={onApprove}
            sx={{
              bgcolor: '#1769ff',
              color: '#fff',
              textTransform: 'none',
              fontWeight: 400,
              fontSize: '12px',
              borderRadius: '8px',
              px: 2.5,
              py: 1,
              boxShadow: '0 7px 18px rgba(23, 105, 255, 0.28)',
              '&:hover': { bgcolor: '#1255d6' },
            }}
          >
            {isApproving ? approveProgressLabel : approveLabel}
          </Button>
        </Box>}
      </Box>

      <TableContainer
        sx={{
          border: '1px solid #dde3ed',
          borderRadius: '11px',
          overflowX: 'auto',
        }}
      >
        <Table sx={{ minWidth: 650 }}>
          <TableHead>
            <TableRow sx={{ bgcolor: '#f5f7fb' }}>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Category
              </TableCell>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Description
              </TableCell>
              <TableCell align="right" sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Monthly amount (<span className="currency-symbol">₹</span>)
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {expenses.length === 0 && fixedCosts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={3} sx={{ textAlign: 'center', py: 5, color: '#647087' }}>
                  {readOnly
                    ? 'No expense data is available for this report.'
                    : 'No report data loaded. Upload a source report to extract expenses.'}
                </TableCell>
              </TableRow>
            ) : (
              <>
                {operationalRows.map((row, index) => {
                  const prevCategory = index > 0 ? operationalRows[index - 1].category : null;
                  const showCategory = index === 0 || prevCategory !== row.category;
                  const nextCategory = operationalRows[index + 1]?.category;
                  const category = String(row.category || '').toLowerCase();
                  const isLastDirectCost =
                    category.includes('direct') &&
                    !category.includes('indirect') &&
                    nextCategory !== row.category;
                  const isLastIndirectCost =
                    category.includes('indirect') && nextCategory !== row.category;

                  return (
                    <Fragment key={`${row.id || index}-group`}>
                      <TableRow key={row.id || index} hover>
                        <TableCell sx={{ fontWeight: 700, color: '#182036', fontSize: '13px', width: '25%' }}>
                          {showCategory ? row.category : ''}
                        </TableCell>
                        <TableCell
                          align="right"
                          sx={{ color: '#2b3953', fontSize: '13px' }}
                        >
                          {row.description}
                        </TableCell>
                        <TableCell
                          align="right"
                          className="opex-currency"
                          sx={{
                            width: '25%',
                            fontWeight: 400,
                            color: '#182036',
                            fontSize: '13px',
                            fontVariantNumeric: 'tabular-nums',
                          }}
                        >
                          {formatINR(row.amount, { showSymbol: false })}
                        </TableCell>
                      </TableRow>
                      {(isLastDirectCost || isLastIndirectCost) && (
                        <TableRow key={`${row.id || index}-total`} sx={{ bgcolor: '#e8edf5' }}>
                          <TableCell colSpan={2} align="right" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                            {isLastDirectCost ? 'Total Direct Cost' : 'Total Indirect Cost'}
                          </TableCell>
                          <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                            {formatINR(
                              isLastDirectCost
                                ? directCostTotal
                                : indirectCostTotal,
                              { showSymbol: false },
                            )}
                          </TableCell>
                        </TableRow>
                      )}
                    </Fragment>
                  );
                })}
              </>
            )}

            {/* Summary Footers */}
            <TableRow sx={{ bgcolor: '#e8edf5', borderTop: '2px solid #dde3ed' }}>
              <TableCell align='right' colSpan={2} sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                Sub Total
              </TableCell>
              <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                {formatINR(subtotal, { showSymbol: false })}
              </TableCell>
            </TableRow>

            <TableRow sx={{ bgcolor: '#e8edf5' }}>
              <TableCell align='right' colSpan={2} sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                20% Markup over Sub Total
              </TableCell>
              <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '13px', color: '#182036' }}>
                {formatINR(markup, { showSymbol: false })}
              </TableCell>
            </TableRow>

            {miscellaneousRows.map((row, index) => (
              <TableRow key={row.id || `misc-expense-${index}`} hover>
                <TableCell sx={{ fontWeight: 700, color: '#182036', fontSize: '13px', width: '25%' }}>
                  {index === 0 ? 'Misc expenses' : ''}
                </TableCell>
                <TableCell
                  align="right"
                  sx={{ color: '#2b3953', fontSize: '13px' }}
                >
                  {row.description}
                </TableCell>
                <TableCell
                  align="right"
                  className="opex-currency"
                  sx={{
                    width: '25%',
                    fontWeight: 400,
                    color: '#182036',
                    fontSize: '13px',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {formatINR(row.amount, { showSymbol: false })}
                </TableCell>
              </TableRow>
            ))}

            {fixedAssetGroups.map((group, groupIndex) => (
              <Fragment key={`fixed-group-${group.parentCategory}`}>
                <TableRow hover>
                  <TableCell
                    sx={{
                      fontWeight: groupIndex === 0 ? 700 : 400,
                      color: '#182036',
                      fontSize: '13px',
                      width: '25%',
                    }}
                  >
                    {groupIndex === 0 ? 'Fixed Assets' : ''}
                  </TableCell>
                  <TableCell
                    align="right"
                    sx={{ color: '#2b3953', fontSize: '13px' }}
                  >
                    {group.parentCategory}
                  </TableCell>
                  <TableCell />
                </TableRow>
                {group.children.map((item, itemIndex) => (
                  <TableRow
                    key={item.id || `${group.parentCategory}-${item.subcomponent}-${itemIndex}`}
                    hover
                  >
                    <TableCell />
                    <TableCell
                      align="right"
                      sx={{ color: '#2b3953', fontSize: '13px' }}
                    >
                      {item.subcomponent || item.itemName || item.assetName || 'Fixed asset'}
                    </TableCell>
                    <TableCell
                      align="right"
                      className="opex-currency"
                      sx={{
                        width: '25%',
                        color: '#182036',
                        fontSize: '13px',
                        fontWeight: 400,
                        fontVariantNumeric: 'tabular-nums',
                      }}
                    >
                      {formatINR(Number(item.amount) || 0, {
                        showSymbol: false,
                      })}
                    </TableCell>
                  </TableRow>
                ))}
              </Fragment>
            ))}

            {fixedAssetGroups.length > 0 && (
              <TableRow sx={{ bgcolor: '#e8edf5' }}>
                <TableCell
                  colSpan={2}
                  align="right"
                  sx={{
                    fontWeight: 800,
                    fontSize: '13px',
                    color: '#182036',
                  }}
                >
                  Fixed Assets Total
                </TableCell>
                <TableCell
                  align="right"
                  className="opex-currency"
                  sx={{
                    fontWeight: 800,
                    fontSize: '13px',
                    color: '#182036',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {formatINR(fixedCostTotal, { showSymbol: false })}
                </TableCell>
              </TableRow>
            )}

            <TableRow sx={{ bgcolor: '#dfe7f2' }}>
              <TableCell align='right' colSpan={2} sx={{ fontWeight: 800, fontSize: '14px', color: '#0b1739' }}>
                Operational Expense Total
              </TableCell>
              <TableCell align="right" className="opex-currency" sx={{ fontWeight: 800, fontSize: '15px', color: '#1769ff' }}>
                {formatINR(totalBillable, { showSymbol: false })}
              </TableCell>
            </TableRow>
            {readOnly && clientAllocations.map((allocation) => (
              <TableRow key={allocation.id || allocation.clientName}>
                <TableCell colSpan={2} align="right" sx={{ fontWeight: 700, fontSize: '13px', color: '#182036', borderBottom: '1px solid #d7dee9' }}>
                  Total Amount Charged to {allocation.clientName}
                </TableCell>
                <TableCell align="right" className="opex-currency" sx={{ fontSize: '13px', color: '#182036', borderBottom: '1px solid #d7dee9' }}>
                  {formatINR(allocation.amount, { showSymbol: false })}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {footerActions && (
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
          {footerActions}
        </Box>
      )}

      </Box>

    </Fragment>
  );
}
