import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@mui/material';
import ReceiptRoundedIcon from '@mui/icons-material/ReceiptRounded';
import PrintRoundedIcon from '@mui/icons-material/PrintRounded';
import ConfirmActionModal from '../common/ConfirmActionModal';
import {
  amountInWords,
  amountInWordsUSD,
  formatINR,
  formatUSD,
  isCrklInvoice,
} from '../../../utils/operationalExpense/currency';
import { formatMonthYear } from '../../../utils/operationalExpense/date';
 
const detailLineSx = {
  fontSize: '13px',
  lineHeight: 1.55,
  color: '#252525',
};
 
const tableCellSx = {
  border: '1px solid #65b8ff',
  color: '#222',
  fontSize: '18px',
  py: 1.5,
};
 
const capitalizeWords = (text) =>
  text.replace(/\b\w/g, (letter) => letter.toUpperCase());

const formatInvoiceAmount = (amount, isCrkl) => {
  if (!Number.isFinite(Number(amount))) return '—';

  return isCrkl
    ? formatUSD(amount)
    : formatINR(amount, { minimumFractionDigits: 0 });
};

export default function InvoiceDocumentTemplate({
  open,
  onClose,
  invoice = null,
  company = null,
  onPrint,
  allowPrint = true,
  embedded = false,
  companyNameSx,
  hideHeaderBorder = false,
}) {
  if (!invoice) return null;
 
  const isCrkl = isCrklInvoice(invoice);
  const invoiceAmount = Number(invoice.grandTotal ?? invoice.amount ?? 0);
  const companyName = company?.companyName || '—';
  const companyAddress = [
    company?.companyAddress,
    [company?.city, company?.state, company?.country].filter(Boolean).join(', '),
    company?.pinCode,
  ]
    .filter(Boolean)
    .join(', ');
  const hasClientTaxDetails =
    /CRKL|MKPL/i.test(invoice.rawInvoice?.clientId?.clientCode || '') ||
    /CRKL|MKPL/i.test(invoice.client || '');
  const isMkplInvoice =
    /MKPL/i.test(invoice.rawInvoice?.clientId?.clientCode || '') ||
    /MKPL/i.test(invoice.client || '');
  const clientAddress = isMkplInvoice
    ? invoice.clientAddress
        ?.replace(/,\s*Karnataka,\s*India\s*$/i, '')
        .replace(/,\s*Tamil Nadu(?=,|$)/i, '')
    : invoice.clientAddress?.replace(/,\s*Tamil Nadu(?=,|$)/i, '');
  const formattedClientAddress = clientAddress
    ?.replace(/\s+District\b/i, '')
    .replace(/,\s*(\d{6}),\s*India\s*$/i, ' - $1');
  const clientCountry = /India\s*$/i.test(clientAddress || '') ? 'India' : '';
  const hasLocationInAddress = invoice.location
    ? formattedClientAddress
        ?.toLowerCase()
        .includes(invoice.location.toLowerCase())
    : false;
  const period = invoice.periodFormatted || formatMonthYear(invoice.period);
  const description = period
    ? `Operational Expense for the month of ${period}`
    : `Accounting Services for the month of ${period}`;
  const billedName = invoice.rawInvoice?.locationId?.billingName || invoice.client;
  const bankRows = [
    ['Beneficiary Name', company?.beneficiaryName || companyName],
    ['Beneficiary Account Number', company?.beneficiaryAccountNo],
    ['Bank Name', company?.bankName],
    ['Branch', company?.branch],
    ['IFSC Code', company?.ifscCode],
  ];
 
  const invoiceContent = (
    <Box
        id="printableInvoiceArea"
        sx={{
          width: '100%',
          maxWidth: 794,
          minHeight: 980,
          mx: 'auto',
          px: { xs: 2, sm: 4 },
          pt: 0,
          pb: 2,
          bgcolor: '#fff',
          color: '#222',
          fontFamily: 'Arial, sans-serif',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <Box
          sx={{
            textAlign: 'center',
            ...(hideHeaderBorder ? {} : { borderTop: '3px solid #222' }),
            pt: 1.5,
            minHeight: 142,
          }}
        >
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 1,
              mb: 1,
            }}
          >
            <Box
              component="img"
              src="/KOPL1.jpg"
              alt="KOPL logo"
              sx={{
                display: 'block',
                width: 72,
                height: 84,
                objectFit: 'contain',
                flexShrink: 0,
              }}
            />
            <Typography
              sx={{
                color: '#50afe8',
                fontSize: { xs: '22px', sm: '31px' },
                fontWeight: 700,
                lineHeight: 1.2,
                textAlign: 'left',
                ...companyNameSx,
              }}
            >
              {companyName}
            </Typography>
          </Box>
          <Typography
            sx={{
              ...detailLineSx,
              width: '100%',
              maxWidth: 620,
              mx: 'auto',
              fontSize: '9px',
              lineHeight: 1.25,
              textAlign: 'center',
              overflowWrap: 'anywhere',
            }}
          >
            {companyAddress || '—'}
          </Typography>
        </Box>
 
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
            gap: { xs: 2, sm: 4 },
            mt: { xs: 2, sm: 1 },
            mb: 5,
            minHeight: 125,
            alignContent: 'center',
          }}
        >
          <Box>
            <Typography sx={{ ...detailLineSx, fontWeight: 700, mb: 1 }}>
              Billed To:
            </Typography>
            <Typography sx={{ ...detailLineSx, fontWeight: 700 }}>
              {billedName}
            </Typography>
            {clientAddress && (
              <Typography sx={detailLineSx}>
                {formattedClientAddress?.replace(/,\s*India\s*$/i, '')}
              </Typography>
            )}
            {!isMkplInvoice &&
              (invoice.clientState || invoice.clientPinCode) && (
              <Typography sx={detailLineSx}>
                {[invoice.clientState, invoice.clientPinCode]
                  .filter(Boolean)
                  .join(' - ')}
              </Typography>
              )}
            {clientCountry && (
              <Typography sx={detailLineSx}>{clientCountry}</Typography>
            )}
            {invoice.location &&
              invoice.location !== 'Corporate' &&
              !hasLocationInAddress && (
              <Typography sx={detailLineSx}>{invoice.location}</Typography>
            )}
          </Box>
 
          <Box sx={{ justifySelf: { sm: 'end' } }}>
            <Typography sx={detailLineSx}>
              <b>Invoice No :</b> {invoice.no || 'DRAFT'}
            </Typography>
            <Typography sx={detailLineSx}>
              <b>Invoice Date :</b> {invoice.date || '—'}
            </Typography>
            {hasClientTaxDetails && (
              <>
                <Typography sx={detailLineSx}>
                  <b>GSTIN/UIN :</b> {invoice.clientTaxDetails?.gstin || '—'}
                </Typography>
                <Typography sx={detailLineSx}>
                  <b>PAN NO :</b> {invoice.clientTaxDetails?.pan || '—'}
                </Typography>
                <Typography sx={detailLineSx}>
                  <b>TAN NO :</b> {invoice.clientTaxDetails?.tan || '—'}
                </Typography>
              </>
            )}
          </Box>
        </Box>
 
        <Table
          aria-label="Invoice line items"
          sx={{
            width: '100%',
            tableLayout: 'fixed',
            borderCollapse: 'collapse',
            mb: 2,
            '& .MuiTableCell-root': tableCellSx,
          }}
        >
          <TableHead>
            <TableRow>
              <TableCell
                align="center"
                sx={{ width: '10%', fontSize: '17px', fontWeight: 700, bgcolor: '#f2f8fc' }}
              >
                #
              </TableCell>
              <TableCell
                align="center"
                sx={{ width: '56%', fontSize: '17px', fontWeight: 700, bgcolor: '#f2f8fc' }}
              >
                Description
              </TableCell>
              <TableCell
                align="center"
                sx={{ width: '14%', fontSize: '17px', fontWeight: 700, bgcolor: '#f2f8fc' }}
              >
                HSN / SAC
              </TableCell>
              <TableCell
                align="center"
                sx={{ width: '20%', fontSize: '17px', fontWeight: 700, bgcolor: '#f2f8fc' }}
              >
                Amount ({isCrkl ? 'USD' : 'INR'})
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow sx={{ height: 84 }}>
              <TableCell align="center" sx={{ color: '#222' }}>001</TableCell>
              <TableCell sx={{ color: '#222' }}>
                {description}
              </TableCell>
              <TableCell align="center" sx={{ color: '#222' }}>
                {invoice.hsnSac || '—'}
              </TableCell>
              <TableCell
                align="right"
                className={
                  isCrkl ? '' : 'opex-currency opex-currency-with-symbol'
                }
                sx={{ color: '#222', fontWeight: 500 }}
              >
                {formatInvoiceAmount(
                  isCrkl ? invoiceAmount : invoice.taxableAmount,
                  isCrkl,
                )}
              </TableCell>
            </TableRow>
            {!isCrkl && (
              <TableRow>
                <TableCell />
                <TableCell colSpan={2} sx={{ color: '#222' }}>
                  {Number.isFinite(invoice.gstRate)
                    ? `GST (${invoice.gstRate}%)`
                    : 'GST'}
                </TableCell>
                <TableCell
                  align="right"
                  className="opex-currency opex-currency-with-symbol"
                  sx={{ color: '#222' }}
                >
                  {Number.isFinite(invoice.gstAmount)
                    ? formatINR(invoice.gstAmount, { minimumFractionDigits: 0 })
                    : '—'}
                </TableCell>
              </TableRow>
            )}
            <TableRow>
              <TableCell colSpan={3} align="right" sx={{ color: '#222', fontWeight: 700 }}>
                Invoice Total
              </TableCell>
              <TableCell
                align="right"
                className={
                  isCrkl ? '' : 'opex-currency opex-currency-with-symbol'
                }
                sx={{ color: '#222', fontWeight: 700 }}
              >
                {formatInvoiceAmount(
                  isCrkl ? invoiceAmount : invoice.grandTotal,
                  isCrkl,
                )}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>

    
 
        <Typography
          sx={{
            color: '#666',
            fontSize: '14px',
            fontWeight: 700,
            letterSpacing: '0.02em',
            mt: 2.5,
            mb: 3,
          }}
        >
          Amount in Words :{' '}
          <Box component="span" sx={{ fontWeight: 500, letterSpacing: 0 }}>
            {capitalizeWords(
              isCrkl
                ? amountInWordsUSD(invoiceAmount)
                : amountInWords(invoice.grandTotal),
            )}
          </Box>
        </Typography>
 
        <Box sx={{ minHeight: 185, fontSize: '13px', lineHeight: 1.65 }}>
          {bankRows.map(([label, value]) => (
            <Typography key={label} sx={detailLineSx}>
              {label}: {value || '—'}
            </Typography>
          ))}
        </Box>
 
        <Box
          sx={{
            mt: 'auto',
            mx: 0.5,
            borderTop: '1px solid #c5c5c5',
            minHeight: 54,
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-around',
            gap: 1,
            pt: 1.5,
            flexWrap: 'wrap',
            color: '#333',
          }}
        >
        </Box>
    </Box>
  );

  if (embedded) return invoiceContent;

  return (
    <ConfirmActionModal
      open={open}
      onClose={onClose}
      icon={<ReceiptRoundedIcon sx={{ fontSize: 24 }} />}
      title="Invoice preview"
      subtitle={invoice.no || 'DRAFT'}
      maxWidth="md"
      actions={[
        {
          label: 'Close',
          onClick: onClose,
        },
        ...(allowPrint ? [{
          label: 'Print / Save PDF',
          primary: true,
          icon: <PrintRoundedIcon sx={{ fontSize: 16 }} />,
          onClick: () => {
            onClose();
            if (onPrint) onPrint(invoice);
          },
        }] : []),
      ]}
    >
      {invoiceContent}
    </ConfirmActionModal>
  );
}
 
 