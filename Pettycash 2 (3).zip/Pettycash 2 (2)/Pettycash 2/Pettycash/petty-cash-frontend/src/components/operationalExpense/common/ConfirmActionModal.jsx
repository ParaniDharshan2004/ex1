import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Box,
  Typography,
  IconButton,
} from '@mui/material';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import ModalActionButton from './ModalActionButton';

export default function ConfirmActionModal({
  open,
  onClose,
  onHeaderClose = onClose,
  icon,
  title,
  subtitle,
  children,
  actions = [],
  maxWidth = 'sm',
  dialogWidth,
  dialogHeight,
  titleSx,
  subtitleSx,
}) {
  return (
    <Dialog
      open={Boolean(open)}
      onClose={onClose}
      maxWidth={dialogWidth ? false : maxWidth}
      fullWidth={!dialogWidth}
      slotProps={{
        paper: {
          sx: {
            borderRadius: '16px',
            boxShadow: '0 30px 90px rgba(0, 0, 0, 0.4)',
            overflow: 'hidden',
            ...(dialogWidth && {
              width: dialogWidth,
              maxWidth: 'calc(100vw - 32px)',
              boxSizing: 'border-box',
            }),
            ...(dialogHeight && {
              height: dialogHeight,
              maxHeight: 'calc(100dvh - 32px)',
              display: 'flex',
              flexDirection: 'column',
            }),
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          p: '20px 24px',
          borderBottom: '1px solid #dde3ed',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 2,
        }}
      >
        <Box sx={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
          {icon && (
            <Box
              sx={{
                width: 42,
                height: 42,
                borderRadius: '12px',
                bgcolor: '#eaf1ff',
                color: '#1769ff',
                display: 'grid',
                placeItems: 'center',
                flexShrink: 0,
              }}
            >
              {icon}
            </Box>
          )}
          <Box>
            <Typography
              variant="h6"
              sx={{
                m: 0,
                fontSize: '17px',
                fontWeight: 700,
                color: '#182036',
                lineHeight: 1.3,
                ...titleSx,
              }}
            >
              {title}
            </Typography>
            {subtitle && (
              <Typography
                variant="body2"
                sx={{
                  m: 0,
                  fontSize: '12px',
                  color: '#647087',
                  mt: 0.25,
                  ...subtitleSx,
                }}
              >
                {subtitle}
              </Typography>
            )}
          </Box>
        </Box>
        <IconButton
          onClick={onHeaderClose}
          size="small"
          aria-label="Close"
          sx={{
            bgcolor: '#f0f3f7',
            color: '#647087',
            borderRadius: '8px',
            '&:hover': { bgcolor: '#e4e9f0' },
          }}
        >
          <CloseRoundedIcon sx={{ fontSize: 18 }} />
        </IconButton>
      </DialogTitle>

      <DialogContent
        sx={{
          p: '24px',
          ...(dialogHeight && {
            flex: '1 1 auto',
            minHeight: 0,
            overflowY: 'auto',
          }),
        }}
      >
        {children}
      </DialogContent>

      {actions && actions.length > 0 && (
        <DialogActions
          sx={{
            p: '16px 24px',
            borderTop: '1px solid #dde3ed',
            display: 'flex',
            gap: 1.5,
            justifyContent: 'flex-end',
            flexWrap: 'wrap',
          }}
        >
          {actions.map((act, index) => (
            <ModalActionButton
              key={index}
              primary={act.primary}
              danger={act.danger}
              dangerLite={act.dangerLite}
              variant={act.variant || (act.primary ? 'contained' : 'outlined')}
              color={act.color || (act.primary ? 'primary' : 'inherit')}
              onClick={act.onClick}
              disabled={act.disabled}
              startIcon={act.icon}
            >
              {act.label}
            </ModalActionButton>
          ))}
        </DialogActions>
      )}
    </Dialog>
  );
}
