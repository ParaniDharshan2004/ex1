import { Box } from '@mui/material';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import AccessTimeRoundedIcon from '@mui/icons-material/AccessTimeRounded';
import HourglassEmptyRoundedIcon from '@mui/icons-material/HourglassEmptyRounded';
import BlockRoundedIcon from '@mui/icons-material/BlockRounded';

export default function StatusBadge({ status }) {
  const s = String(status || '').toLowerCase();

  let bg = '#fff2da';
  let color = '#9a6100';
  let Icon = AccessTimeRoundedIcon;

  if (s.includes('complete') || s.includes('generated') || s.includes('invoiced')) {
    bg = '#e6f8f1';
    color = '#08744f';
    Icon = CheckCircleRoundedIcon;
  } else if (s.includes('allocation')) {
    bg = '#e9f1ff';
    color = '#1d5dcc';
    Icon = HourglassEmptyRoundedIcon;
  } else if (s.includes('cancel')) {
    bg = '#eef0f3';
    color = '#687281';
    Icon = BlockRoundedIcon;
  } else if (s.includes('error')) {
    bg = '#ffeaec';
    color = '#a82834';
    Icon = BlockRoundedIcon;
  }

  return (
    <Box
      component="span"
      sx={{
        display: 'inline-flex',
        gap: '5px',
        alignItems: 'center',
        padding: '5px 10px',
        borderRadius: '99px',
        fontSize: '11px',
        fontWeight: 800,
        whiteSpace: 'nowrap',
        backgroundColor: bg,
        color: color,
        border: '1px solid transparent',
        transition: 'all 0.15s ease',
      }}
    >
      <Icon sx={{ fontSize: 13, color: 'inherit' }} />
      {status}
    </Box>
  );
}
