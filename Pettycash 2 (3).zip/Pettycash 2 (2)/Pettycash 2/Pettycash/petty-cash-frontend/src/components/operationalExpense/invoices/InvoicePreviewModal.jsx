import InvoiceDocumentTemplate from './InvoiceDocumentTemplate';

export default function InvoicePreviewModal(props) {
  return <InvoiceDocumentTemplate {...props} />;
}
