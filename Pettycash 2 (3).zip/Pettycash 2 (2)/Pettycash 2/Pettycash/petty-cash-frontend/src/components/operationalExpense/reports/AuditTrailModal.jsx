import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import HistoryRoundedIcon from '@mui/icons-material/HistoryRounded';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ConfirmActionModal from '../common/ConfirmActionModal';

export default function AuditTrailModal({
  open,
  onClose,
  auditEvents = [],
}) {
  return (
    <ConfirmActionModal
      open={open}
      onClose={onClose}
      icon={<HistoryRoundedIcon sx={{ fontSize: 24 }} />}
      title="Audit trail"
      subtitle="Review financial lifecycle actions and status changes."
      maxWidth="md"
      actions={[
        {
          label: 'Close',
          onClick: onClose,
        },
      ]}
    >
      <Box sx={{ mb: 2 }}>
        <Box
          sx={{
            display: 'flex',
            gap: 1.5,
            p: '12px 16px',
            borderRadius: '9px',
            bgcolor: '#eef5ff',
            color: '#285387',
            border: '1px solid #cfe0ff',
            alignItems: 'center',
            mb: 2,
          }}
        >
          <InfoOutlinedIcon sx={{ fontSize: 20, color: '#1769ff', flexShrink: 0 }} />
          <Typography sx={{ fontSize: '12px' }}>
            Audit events are generated from authoritative backend report and invoice records.
          </Typography>
        </Box>

        <TableContainer
          sx={{
            border: '1px solid #dde3ed',
            borderRadius: '11px',
            maxHeight: 380,
            overflowY: 'auto',
          }}
        >
          <Table stickyHeader>
            <TableHead>
              <TableRow sx={{ bgcolor: '#f5f7fb' }}>
                <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase' }}>
                  Date & time
                </TableCell>
                <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase' }}>
                  Record
                </TableCell>
                <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase' }}>
                  Action
                </TableCell>
                <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase' }}>
                  User
                </TableCell>
                <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase' }}>
                  Details
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {auditEvents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} sx={{ textAlign: 'center', py: 4, color: '#647087' }}>
                    No recorded actions found. Complete a monthly record or generate invoices to view lifecycle events.
                  </TableCell>
                </TableRow>
              ) : (
                auditEvents.map((evt, idx) => (
                  <TableRow key={idx} hover>
                    <TableCell sx={{ fontSize: '12px', color: '#647087', whiteSpace: 'nowrap' }}>
                      {evt.time}
                    </TableCell>
                    <TableCell sx={{ fontSize: '12px', fontWeight: 600, color: '#182036' }}>
                      {evt.record}
                    </TableCell>
                    <TableCell sx={{ fontSize: '12px', fontWeight: 700, color: '#1769ff' }}>
                      {evt.action}
                    </TableCell>
                    <TableCell sx={{ fontSize: '12px', color: '#182036' }}>
                      {evt.user}
                    </TableCell>
                    <TableCell className="opex-currency" sx={{ fontSize: '12px', color: '#647087' }}>
                      {evt.detail}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </ConfirmActionModal>
  );
}
