import { useMemo, useState } from 'react';
import {
  Box,
  Button,
  Divider,
  IconButton,
  Menu,
  MenuItem,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import ArrowBackIosNewRoundedIcon from '@mui/icons-material/ArrowBackIosNewRounded';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import ArrowForwardIosRoundedIcon from '@mui/icons-material/ArrowForwardIosRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import KeyboardArrowDownRoundedIcon from '@mui/icons-material/KeyboardArrowDownRounded';
import CalendarMonthRoundedIcon from '@mui/icons-material/CalendarMonthRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import {
  isInvoiceGeneratedStatus,
  isReportFinalizedStatus,
} from '../../../utils/operationalExpense/statusHelpers';
import WorkflowStepper from '../common/WorkflowStepper';

const COLORS = {
  primary: '#1769ff',
  primaryDark: '#0f54d8',
  primaryLight: '#eaf1ff',
  primaryHover: '#f4f7ff',
  textPrimary: '#182036',
  textSecondary: '#647087',
  textMuted: '#8090a5',
  border: '#dde3ed',
  surface: '#f8faff',
  white: '#ffffff',
  success: '#0c9b6f',
  successText: '#116c50',
  successBackground: '#eaf8f3',
  successBorder: '#bde6d7',
  warning: '#d78508',
  warningText: '#76561b',
  warningBackground: '#fff7e8',
  warningBorder: '#efd7a1',
  danger: '#d8404c',
  dangerBackground: '#fff0f1',
  dangerBorder: '#ffd0d4',
  disabledText: '#a6adb8',
  disabledBackground: '#f3f4f6',
  disabledBorder: '#e2e5e9',
};

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];
const currentYear = String(new Date().getFullYear());
const selectableYears = Array.from(
  { length: 6 },
  (_, index) => String(Number(currentYear) + index),
);
const minimumNavigableYear = currentYear;
const CALENDAR_WIDTH = 500;
const MONTH_CARD_WIDTH = 220;
const MONTH_CARD_HEIGHT = 72;
const CALENDAR_COMPONENT_GAP = 12;
const HEADER_TO_STEPPER_GAP = 35;
const STEPPER_TO_CALENDAR_GAP = 30;

const outlinedButtonStyles = {
  minHeight: 34,
  px: 1.75,
  textTransform: 'none',
  fontWeight: 700,
  borderRadius: '10px',
  borderColor: COLORS.border,
  color: COLORS.textPrimary,
  '&:hover': {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryHover,
  },
};
const primaryButtonStyles = {
  minHeight: 38,
  px: 1.9,
  backgroundColor: COLORS.primary,
  textTransform: 'none',
  fontWeight: 700,
  borderRadius: '10px',
  boxShadow: '0 8px 20px rgba(23, 105, 255, 0.24)',
  '&:hover': {
    backgroundColor: COLORS.primaryDark,
    boxShadow: '0 10px 24px rgba(23, 105, 255, 0.3)',
  },
};
function PeriodPicker({
  value,
  selectedYear,
  years,
  invoicedPeriods,
  error,
  onYearChange,
  onChange,
}) {
  const [yearMenuAnchor, setYearMenuAnchor] = useState(null);
  const yearMenuOpen = Boolean(yearMenuAnchor);
  const lastYear = years[years.length - 1];

  const moveYear = (offset) => {
    const nextYear = String(Number(selectedYear) + offset);
    if (
      Number(nextYear) >= Number(minimumNavigableYear) &&
      Number(nextYear) <= Number(lastYear)
    ) {
      onYearChange(nextYear);
    }
  };

  return (
    <Box
      sx={{
        width: '100%',
        maxWidth: `${CALENDAR_WIDTH}px`,
        mx: 'auto',
      }}
    >
      <Box sx={{ p: { xs: 1.25, sm: 1.5 }, border: `1px solid ${COLORS.border}`, borderRadius: '14px', bgcolor: COLORS.white }}>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: `${CALENDAR_COMPONENT_GAP}px`,
            }}
          >
            <IconButton
              size="small"
              onClick={() => moveYear(-1)}
              disabled={selectedYear === minimumNavigableYear}
              aria-label="Previous year"
              sx={{
                width: 38,
                height: 38,
                border: `1px solid ${COLORS.border}`,
                borderRadius: '10px',
                '&.Mui-disabled': { color: COLORS.disabledText },
              }}
            >
              <ArrowBackIosNewRoundedIcon sx={{ fontSize: 15 }} />
            </IconButton>
            
            <Button
              aria-label={`Selected year ${selectedYear}`}
              aria-haspopup="listbox"
              aria-expanded={yearMenuOpen}
              onClick={(event) => setYearMenuAnchor(event.currentTarget)}
              endIcon={<KeyboardArrowDownRoundedIcon />}
              sx={{
                minWidth: 140,
                minHeight: 44,
                px: 2,
                border: `1px solid ${COLORS.border}`,
                borderRadius: '12px',
                bgcolor: COLORS.surface,
                color: COLORS.textPrimary,
                fontSize: 17,
                fontWeight: 800,
                textTransform: 'none',
                '&:hover': {
                  bgcolor: COLORS.primaryHover,
                  borderColor: COLORS.primary,
                },
              }}
            >
              {selectedYear}
            </Button>
            <Menu
              anchorEl={yearMenuAnchor}
              open={yearMenuOpen}
              onClose={() => setYearMenuAnchor(null)}
              anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
              transformOrigin={{ vertical: 'top', horizontal: 'center' }}
              slotProps={{
                paper: {
                  sx: {
                    mt: 0.75,
                    minWidth: 140,
                    border: `1px solid ${COLORS.border}`,
                    borderRadius: '12px',
                    boxShadow: '0 12px 30px rgba(24, 32, 54, 0.14)',
                  },
                },
              }}
              MenuListProps={{ 'aria-label': 'Choose year' }}
            >
              {years.map((year) => (
                <MenuItem
                  key={year}
                  selected={year === selectedYear}
                  onClick={() => {
                    onYearChange(year);
                    setYearMenuAnchor(null);
                  }}
                  sx={{
                    justifyContent: 'center',
                    py: 1.1,
                    fontWeight: year === selectedYear ? 800 : 600,
                    color: year === selectedYear ? COLORS.primary : COLORS.textPrimary,
                  }}
                >
                  {year}
                </MenuItem>
              ))}
            </Menu>
            <IconButton
              size="small"
              onClick={() => moveYear(1)}
              disabled={selectedYear === lastYear}
              aria-label="Next year"
              sx={{
                width: 38,
                height: 38,
                border: `1px solid ${COLORS.border}`,
                borderRadius: '10px',
                '&.Mui-disabled': { color: COLORS.disabledText },
              }}
            >
              <ArrowForwardIosRoundedIcon sx={{ fontSize: 15 }} />
            </IconButton>
          </Box>

          <Divider sx={{ my: `${CALENDAR_COMPONENT_GAP}px` }} />

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: {
                xs: 'repeat(3, minmax(0, 1fr))',
                sm: `repeat(3, minmax(0, ${MONTH_CARD_WIDTH}px))`,
              },
              justifyContent: 'center',
              gap: `${CALENDAR_COMPONENT_GAP}px`,
            }}
          >
            {MONTHS.map((month, index) => {
              const monthValue = `${selectedYear}-${String(index + 1).padStart(2, '0')}`;
              const isInvoiced = invoicedPeriods.has(monthValue);
              const now = new Date();
              const currentPeriod = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
              const previousDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
              const previousPeriod = `${previousDate.getFullYear()}-${String(previousDate.getMonth() + 1).padStart(2, '0')}`;
              const isCurrentMonth = monthValue === currentPeriod;
              const isPreviousMonth = monthValue === previousPeriod;
              const isActionable = isCurrentMonth || isPreviousMonth;
              const disabled = !isInvoiced && !isActionable;
              const selected = value === monthValue;
              const tooltipTitle = isInvoiced
                ? 'Invoiced'
                : disabled
                  ? 'Only current and previous months are available.'
                  : '';
              return (
                <Tooltip
                  key={monthValue}
                  title={tooltipTitle}
                  placement="top"
                  disableHoverListener={!tooltipTitle}
                >
                  <span>
                    <Button
                      disabled={disabled}
                      onClick={() => {
                        onChange(monthValue);
                      }}
                      aria-pressed={selected}
                      sx={{
                        width: '100%',
                        minWidth: 0,
                        height: `${MONTH_CARD_HEIGHT}px`,
                        minHeight: `${MONTH_CARD_HEIGHT}px`,
                        px: 0.75,
                        py: 0.5,
                        textTransform: 'none',
                        border: '1px solid',
                        borderColor: isInvoiced
                          ? COLORS.success
                          : selected
                            ? COLORS.primary
                            : isPreviousMonth
                              ? '#9bbcff'
                              : COLORS.border,
                        borderRadius: '10px',
                        bgcolor: isInvoiced
                          ? COLORS.success
                          : selected
                            ? COLORS.primary
                            : isPreviousMonth
                              ? COLORS.primaryHover
                              : COLORS.white,
                        color: selected
                          ? COLORS.white
                          : isInvoiced
                            ? COLORS.white
                            : COLORS.textPrimary,
                        opacity: disabled ? 0.48 : 1,
                        fontWeight: 700,
                        '&:hover': {
                          bgcolor: isInvoiced
                            ? COLORS.successText
                            : selected
                              ? COLORS.primaryDark
                              : COLORS.primaryHover,
                          borderColor: isInvoiced ? COLORS.successText : COLORS.primary,
                        },
                        '&.Mui-disabled': {
                          color: COLORS.disabledText,
                          bgcolor: COLORS.disabledBackground,
                          borderColor: COLORS.disabledBorder,
                        },
                      }}
                    >
                      <Typography sx={{ fontSize: 12, fontWeight: 'inherit' }}>
                        {month.slice(0, 3)}
                      </Typography>
                    </Button>
                  </span>
                </Tooltip>
              );
            })}
          </Box>
      </Box>

      {error && (
        <Stack
          role="alert"
          direction="row"
          alignItems="center"
          spacing={0.8}
          sx={{ mt: 1, color: COLORS.danger }}
        >
          <WarningAmberRoundedIcon sx={{ fontSize: 17 }} />
          <Typography sx={{ fontSize: 12, fontWeight: 600 }}>
            {error}
          </Typography>
        </Stack>
      )}
    </Box>
  );
}

export default function PeriodCheckPage({
  initialPeriod = '',
  initialYear = currentYear,
  records = [],
  loading = false,
  onPeriodChange,
  onBack,
  onCreateNew,
  onContinueDraft,
  onViewLocked,
}) {
  const period = initialPeriod;
  const selectedYear =
    initialPeriod.slice(0, 4) || initialYear || currentYear;
  const [validationError, setValidationError] = useState('');

  const invoicedPeriods = useMemo(
    () =>
      new Set(
        records
          .filter((record) =>
            isInvoiceGeneratedStatus(record.rawStatus) ||
            isReportFinalizedStatus(record.rawStatus),
          )
          .map((record) => record.period),
      ),
    [records],
  );
  const years = selectableYears;

  const handleYearChange = (year) => {
    setValidationError('');
    onPeriodChange?.('', year);
  };
  const handlePeriodChange = (value) => {
    setValidationError('');
    onPeriodChange?.(value, value.slice(0, 4));
  };

  const matchedRecord = records
    .filter((record) => record.period === period)
    .sort((a, b) => (b.version || 1) - (a.version || 1))[0];
  const matchedStatus = String(matchedRecord?.rawStatus || '').toUpperCase();
  const actionLabel = !period
    ? 'Next'
    : isInvoiceGeneratedStatus(matchedStatus)
      ? 'View Report'
      : matchedStatus === 'ALLOCATION_PENDING'
        ? 'Next'
        : matchedRecord
          ? 'Next'
          : 'Next';

  const handleCheck = () => {
    if (!period) {
      setValidationError('Please select the expense month and year.');
      return;
    }
    if (!matchedRecord) {
      onCreateNew?.(period);
      return;
    }
    if (isInvoiceGeneratedStatus(matchedStatus)) {
      onViewLocked?.(matchedRecord);
    } else {
      onContinueDraft?.(matchedRecord);
    }
  };

  return (
    <Box sx={{ width: '100%', height: '100%' }}>
      <Stack
        direction="row"
        spacing={1.5}
        sx={{ alignItems: 'center' }}
      >
        
        <Box sx={{ flex: 1 }}>
          <Typography
            variant="h4" 
          >
            Select a Expense Month
          </Typography>
          
        </Box>
        <Stack direction="row" spacing={1} alignItems="center">
          <Button
            variant="contained"
            startIcon={<ArrowBackRoundedIcon sx={{ fontSize: 16 }} />}
            onClick={onBack}
            sx={{
            bgcolor: 'rgb(23, 105, 255)',
            color: '#fff',
            textTransform: 'none',
            fontWeight: 800,
            fontSize: '13px',
            borderRadius: '9px',
            px: 2.5,
            py: 1.1,
            boxShadow: '0 7px 18px rgba(23, 105, 255, 0.28)',
            '&:hover': { bgcolor: '#1255d6' },
          }}
          >
            Back
          </Button>
          <Button
            variant="contained"
            onClick={handleCheck}
            endIcon={<ArrowForwardRoundedIcon />}
            disabled={!period || loading}
            sx={primaryButtonStyles}
          >
            {actionLabel}
          </Button>
          
        </Stack>
      </Stack>
      <Box
        sx={{
          mt: `${HEADER_TO_STEPPER_GAP}px`,
          mb: `${STEPPER_TO_CALENDAR_GAP}px`,
          '& > .MuiBox-root': {
            marginTop: '0 !important',
            marginBottom: '0 !important',
          },
        }}
      >
        <WorkflowStepper />
      </Box>
      <Box>
        <PeriodPicker
          value={period}
          selectedYear={selectedYear}
          years={years}
          invoicedPeriods={invoicedPeriods}
          error={validationError}
          onYearChange={handleYearChange}
          onChange={handlePeriodChange}
        />
      </Box>
    </Box>
  );
}
