import { Box, Typography, Button } from '@mui/material';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';


export default function UploadReviewHeader({
  title = 'Upload & Review Report',
  subtitle = '',
  status = 'Review Pending',
  onBack,
  backDisabled = false,
}) {
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: { xs: 'flex-start', sm: 'center' },
        flexDirection: { xs: 'column', sm: 'row' },
        gap: 2,
        mb: 2.5,
      }}
    >
      <Box>
        <Typography
          variant="h4"
          
        >
          {title}
        </Typography>
        <Typography sx={{ color: '#647087', fontSize: '13px' }}>
          {subtitle}
        </Typography>
      </Box>

      <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center', flexWrap: 'wrap' }}>
        
        
        {onBack && (
          <Button
            variant="contained"
            startIcon={<ArrowBackRoundedIcon sx={{ fontSize: 16 }} />}
            onClick={onBack}
            disabled={backDisabled}
            sx={{
            bgcolor: 'rgb(23, 105, 255)',
            color: '#fff',
            textTransform: 'none',
            fontWeight: 800,
            fontSize: '13px',
            borderRadius: '9px',
            px: 2.5,
            py: 1.1,
            boxShadow: '0 7px 18px rgba(23, 105, 255, 0.28)',
            '&:hover': { bgcolor: '#1255d6' },
            '&.Mui-disabled': {
              bgcolor: '#e0e0e0',
              color: '#9e9e9e',
              boxShadow: 'none',
            },
          }}
          >
            Back
          </Button>
        )}
      </Box>
    </Box>
  );
}
