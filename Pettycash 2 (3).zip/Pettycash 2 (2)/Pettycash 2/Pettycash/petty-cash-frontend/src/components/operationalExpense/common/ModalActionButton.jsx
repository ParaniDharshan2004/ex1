import Button from '@mui/material/Button';

export default function ModalActionButton({
  children,
  primary = false,
  danger = false,
  dangerLite = false,
  sx,
  ...props
}) {
  return (
    <Button
      variant={props.variant || (primary ? 'contained' : 'outlined')}
      color={props.color || (primary ? 'primary' : 'inherit')}
      {...props}
      sx={{
        borderRadius: '9px',
        fontWeight: 700,
        fontSize: '12px',
        minHeight: '39px',
        textTransform: 'none',
        px: 2,
        boxShadow: primary ? '0 7px 18px rgba(23, 105, 255, 0.2)' : 'none',
        ...(danger && {
          bgcolor: '#d8404c',
          color: '#fff',
          '&:hover': { bgcolor: '#c3303c' },
        }),
        ...(dangerLite && {
          bgcolor: '#fff0f1',
          color: '#d8404c',
          borderColor: '#ffd0d4',
          '&:hover': { bgcolor: '#ffe4e6' },
        }),
        ...sx,
      }}
    >
      {children}
    </Button>
  );
}
