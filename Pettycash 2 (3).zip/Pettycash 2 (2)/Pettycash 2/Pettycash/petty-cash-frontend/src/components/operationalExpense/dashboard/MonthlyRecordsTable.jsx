import { useState } from 'react';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Select,
  MenuItem,
  Menu,
  InputAdornment,
  CircularProgress,
  IconButton,
  Tooltip,
} from '@mui/material';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import RestartAltRoundedIcon from '@mui/icons-material/RestartAltRounded';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import StatusBadge from '../common/StatusBadge';
import { formatINR } from '../../../utils/operationalExpense/currency';
import { formatMonthYear } from '../../../utils/operationalExpense/date';
import { isInvoiceGeneratedStatus } from '../../../utils/operationalExpense/statusHelpers';

export default function MonthlyRecordsTable({
  records = [],
  selectedYear,
  onYearChange,
  selectedMonth = 'all',
  onMonthChange,
  searchTerm,
  onSearchChange,
  availableYears = ['2026', '2025'],
  onContinue,
  onView,
  onViewReport,
  onRestart,
  onDelete,
  deletingRecordId = '',
}) {
  const [viewAnchor, setViewAnchor] = useState(null);
  return (
    <Box
      sx={{
        bgcolor: '#fff',
        border: '1px solid #dde3ed',
        borderRadius: 1,
        boxShadow: '0 14px 40px rgba(26, 42, 82, 0.05)',
        p: { xs: 2, sm: 2.5 },
      }}
    >
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0, 1fr)',
          gap: 2,
          mb: 2,
        }}
      >
        <Box sx={{ minWidth: 0 }}>
          <Typography sx={{ fontWeight: 800, fontSize: '15px', color: '#182036' }}>
            Monthly records
          </Typography>
          
        </Box>

        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: {
              xs: 'repeat(2, minmax(0, 1fr))',
              md: 'minmax(110px, 0.7fr) minmax(150px, 1fr) minmax(200px, 2fr)',
            },
            gap: 1.5,
            minWidth: 0,
          }}
        >
          <Box sx={{ minWidth: 0 }}>
            <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
              Year
            </Typography>
            <Select
              size="small"
              value={selectedYear}
              onChange={(e) => onYearChange(e.target.value)}
              sx={{
                width: '100%',
                borderRadius: 1,
                bgcolor: '#fff',
                fontSize: '13px',
                height: 38,
                '& fieldset': { borderColor: '#ccd5e2' },
              }}
            >
              {availableYears.map((yr) => (
                <MenuItem key={yr} value={yr}>
                  {yr}
                </MenuItem>
              ))}
            </Select>
          </Box>

          <Box sx={{ minWidth: 0 }}>
            <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
              Month
            </Typography>
            <Select
              size="small"
              value={selectedMonth}
              onChange={(e) => onMonthChange(e.target.value)}
              sx={{
                width: '100%',
                borderRadius: 1,
                bgcolor: '#fff',
                fontSize: '13px',
                height: 38,
                '& fieldset': { borderColor: '#ccd5e2' },
              }}
            >
              <MenuItem value="all">All months</MenuItem>
              {Array.from({ length: 12 }, (_, index) => {
                const value = String(index + 1).padStart(2, '0');
                return (
                  <MenuItem key={value} value={value}>
                    {new Date(2000, index, 1).toLocaleDateString('en-IN', { month: 'long' })}
                  </MenuItem>
                );
              })}
            </Select>
          </Box>

          <Box sx={{ minWidth: 0, gridColumn: { xs: '1 / -1', md: 'auto' } }}>
            <Typography sx={{ fontSize: '11px', fontWeight: 700, color: '#59667b', mb: 0.5 }}>
              Search
            </Typography>
            <TextField
              size="small"
              placeholder="Search month or draft"
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchRoundedIcon sx={{ fontSize: 18, color: '#8090a5' }} />
                    </InputAdornment>
                  ),
                },
              }}
              sx={{
                width: '100%',
                bgcolor: '#fff',
                '& .MuiOutlinedInput-root': {
                  borderRadius: 1,
                  height: 38,
                  fontSize: '13px',
                  '& fieldset': { borderColor: '#ccd5e2' },
                },
              }}
            />
          </Box>
        </Box>
      </Box>

      <TableContainer
        sx={{
          border: '1px solid #dde3ed',
          borderRadius: 1,
          overflowX: 'auto',
        }}
      >
        <Table sx={{ minWidth: 800 }}>
          <TableHead>
            <TableRow sx={{ bgcolor: '#f5f7fb' }}>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                S.No
              </TableCell>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Expense month
              </TableCell>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Total billable
              </TableCell>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Status
              </TableCell>
              <TableCell sx={{ fontSize: '11px', fontWeight: 800, color: '#566277', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Action
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {records.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} sx={{ textAlign: 'center', py: 5, color: '#647087' }}>
                  No records found. Create the first monthly operational expense.
                </TableCell>
              </TableRow>
            ) : (
              records.map((r, index) => {
                const isGenerated = isInvoiceGeneratedStatus(r.rawStatus);
                const isCancelled = false;
                const isPending = ['REVIEW_PENDING', 'ALLOCATION_PENDING'].includes(r.rawStatus);
                const isDraft = r.rawStatus === 'DRAFT';

                return (
                  <TableRow
                    key={r.id}
                    hover
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell>
                      <Typography sx={{ fontWeight: 700, fontSize: '13px', color: '#182036' }}>
                        {index + 1}
                      </Typography>
                    </TableCell>

                    <TableCell sx={{ fontSize: '13px', color: '#182036', fontWeight: 600 }}>
                      {formatMonthYear(r.period)}
                    </TableCell>

                    <TableCell className="opex-currency opex-currency-with-symbol" sx={{ fontSize: '13px', fontWeight: 700, color: '#182036' }}>
                      {formatINR(r.totalBillable)}
                    </TableCell>

                    <TableCell>
                      <StatusBadge status={r.status} />
                    </TableCell>

                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                        {isGenerated ? (
                          <>
                            <Tooltip title="View">
                              <IconButton
                                size="small"
                                aria-label={`View ${r.periodFormatted}`}
                                onClick={(event) =>
                                  setViewAnchor({ element: event.currentTarget, record: r })
                                }
                                sx={{
                                  bgcolor: '#eaf0f8',
                                  color: '#273653',
                                  border: '1px solid #dde3ed',
                                  borderRadius: 1,
                                  '&:hover': { bgcolor: '#dde5f0', borderColor: '#ccd5e2' },
                                }}
                              >
                                <VisibilityRoundedIcon sx={{ fontSize: 18 }} />
                              </IconButton>
                            </Tooltip>
                            <Menu
                              anchorEl={viewAnchor?.record.id === r.id ? viewAnchor.element : null}
                              open={viewAnchor?.record.id === r.id}
                              onClose={() => setViewAnchor(null)}
                            >
                              <MenuItem onClick={() => { setViewAnchor(null); onView(r); }}>View Invoice</MenuItem>
                              <MenuItem onClick={() => { setViewAnchor(null); onViewReport(r); }}>View Report</MenuItem>
                            </Menu>
                          </>
                        ) : isCancelled ? (
                          <Typography sx={{ fontSize: '11px', color: '#647087' }}>
                            History only
                          </Typography>
                        ) : (
                          <>
                            {isDraft && (
                              <Tooltip title="Reopen draft">
                                <IconButton
                                  size="small"
                                  aria-label={`Reopen ${r.periodFormatted} draft`}
                                  onClick={() => onContinue(r)}
                                  sx={{
                                    color: '#1769ff',
                                    bgcolor: '#eaf1ff',
                                    borderRadius: 1,
                                    '&:hover': { bgcolor: '#dce8ff' },
                                  }}
                                >
                                  <EditRoundedIcon fontSize="small" />
                                </IconButton>
                              </Tooltip>
                            )}
                            {isPending && (
                              <Tooltip title="Continue allocation">
                                <IconButton
                                  size="small"
                                  aria-label={`Continue allocation for ${r.periodFormatted}`}
                                  onClick={() => onContinue(r)}
                                  sx={{
                                    color: '#fff',
                                    bgcolor: '#1769ff',
                                    borderRadius: '8px',
                                    boxShadow: '0 4px 12px rgba(23, 105, 255, 0.25)',
                                    '&:hover': { bgcolor: '#1255d6' },
                                  }}
                                >
                                  <ArrowForwardRoundedIcon fontSize="small" />
                                </IconButton>
                              </Tooltip>
                            )}
                            {isPending && (
                              <>
                                <Tooltip title="Reset">
                                  <IconButton
                                    size="small"
                                    aria-label={`Reset ${r.periodFormatted}`}
                                    onClick={() => onRestart(r)}
                                    sx={{
                                      color: '#d8404c',
                                      bgcolor: '#fff0f1',
                                      border: '1px solid #ffd5d8',
                                      borderRadius: 1,
                                      '&:hover': { bgcolor: '#ffe3e5' },
                                    }}
                                  >
                                    <RestartAltRoundedIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title="Delete record">
                                  <span>
                                    <IconButton
                                      size="small"
                                      aria-label={`Delete ${r.periodFormatted} record`}
                                      disabled={Boolean(deletingRecordId)}
                                      onClick={() => onDelete(r)}
                                      sx={{
                                        color: '#d8404c',
                                        bgcolor: '#fff',
                                        border: '1px solid #ffd5d8',
                                        borderRadius: 1,
                                        '&:hover': { bgcolor: '#fff0f1' },
                                      }}
                                    >
                                      {deletingRecordId === r.id ? (
                                        <CircularProgress size={18} color="inherit" />
                                      ) : (
                                        <DeleteOutlineRoundedIcon fontSize="small" />
                                      )}
                                    </IconButton>
                                  </span>
                                </Tooltip>
                              </>
                            )}
                            {!isPending && isDraft && (
                              <Tooltip title="Delete draft">
                                <IconButton
                                  size="small"
                                  aria-label={`Delete ${r.periodFormatted} draft`}
                                  disabled={Boolean(deletingRecordId)}
                                  onClick={() => onDelete(r)}
                                  sx={{
                                    color: '#d8404c',
                                    border: '1px solid #ffd5d8',
                                    borderRadius: 1,
                                    '&:hover': { bgcolor: '#fff0f1' },
                                  }}
                                >
                                  {deletingRecordId === r.id ? (
                                    <CircularProgress size={18} color="inherit" />
                                  ) : (
                                    <DeleteOutlineRoundedIcon fontSize="small" />
                                  )}
                                </IconButton>
                              </Tooltip>
                            )}
                            {!isPending && !isDraft && (
                              <Tooltip title="Delete record">
                                <span>
                                  <IconButton
                                    size="small"
                                    aria-label={`Delete ${r.periodFormatted} record`}
                                    disabled={Boolean(deletingRecordId)}
                                    onClick={() => onDelete(r)}
                                    sx={{
                                      color: '#d8404c',
                                      bgcolor: '#fff',
                                      border: '1px solid #ffd5d8',
                                      borderRadius: 1,
                                      '&:hover': { bgcolor: '#fff0f1' },
                                    }}
                                  >
                                    {deletingRecordId === r.id ? (
                                      <CircularProgress size={18} color="inherit" />
                                    ) : (
                                      <DeleteOutlineRoundedIcon fontSize="small" />
                                    )}
                                  </IconButton>
                                </span>
                              </Tooltip>
                            )}
                          </>
                        )}
                      </Box>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
