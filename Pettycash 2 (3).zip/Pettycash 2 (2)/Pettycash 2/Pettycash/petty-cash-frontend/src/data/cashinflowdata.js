const cashInflowData = [
  {
    id: 1,
    inflowDate: "01-09-2026",
    amount: 10000,
    description: "Monthly Petty Cash Allocation",
    createdBy: "Admin",
  },
  {
    id: 2,
    inflowDate: "05-09-2026",
    amount: 5000,
    description: "Marketing Expenses Fund",
    createdBy: "Admin",
  },
  {
    id: 3,
    inflowDate: "10-09-2026",
    amount: 8000,
    description: "Project Team Allocation",
    createdBy: "Admin",
  },
  {
    id: 4,
    inflowDate: "15-09-2026",
    amount: 4000,
    description: "Travel Expense Budget",
    createdBy: "Admin",
  },
  {
    id: 5,
    inflowDate: "20-09-2026",
    amount: 12000,
    description: "Additional Monthly Fund",
    createdBy: "Admin",
  },
];

export default cashInflowData;