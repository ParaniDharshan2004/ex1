// import { createContext, useContext, useState } from "react";

// const AuthContext = createContext();

// export const AuthProvider = ({ children }) => {
//   const [user, setUser] = useState(
//     JSON.parse(localStorage.getItem("user")) || null,
//   );

//   const [permissions, setPermissions] = useState(
//     JSON.parse(localStorage.getItem("permissions")) || null,
//   );

//   const login = (user, token, permissions) => {
//     localStorage.setItem("token", token);

//     localStorage.setItem("user", JSON.stringify(user));

//     localStorage.setItem("permissions", JSON.stringify(permissions));

//     setUser(user);
//     setPermissions(permissions);
//   };

//   const logout = () => {
//     localStorage.removeItem("token");
//     localStorage.removeItem("user");
//     localStorage.removeItem("permissions");

//     setUser(null);
//     setPermissions(null);
//   };

//   return (
//     <AuthContext.Provider
//       value={{
//         user,
//         permissions,
//         login,
//         logout,
//       }}
//     >
//       {children}
//     </AuthContext.Provider>
//   );
// };

// export const useAuth = () => useContext(AuthContext);

import { createContext, useContext, useEffect, useMemo, useState } from "react";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("user")) || null,
  );
  const [permissions, setPermissions] = useState(
    JSON.parse(localStorage.getItem("permissions")) || null,
  );
  const [status, setStatus] = useState("loading");
  
  useEffect(() => {
    try {
      const token = localStorage.getItem("token");
      const storedUser = localStorage.getItem("user");

      if (token && storedUser) {
        setUser(JSON.parse(storedUser));
        setStatus("authenticated");
      } else {
        setStatus("anonymous");
      }
    } catch (error) {
      console.error("Auth restore failed:", error);

      localStorage.removeItem("token");
      localStorage.removeItem("user");

      setUser(null);
      setStatus("anonymous");
    }
  }, []);

  const login = (user, token, permissions) => {
    localStorage.setItem("token", token);

    localStorage.setItem("user", JSON.stringify(user));

    localStorage.setItem("permissions", JSON.stringify(permissions));

    setUser(user);
    setPermissions(permissions);
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    setUser(null);
    setStatus("anonymous");

    window.location.href = "/login";
  };

  const role = user?.role || null;

  const value = useMemo(
    () => ({
      user,
      role,
      permissions,
      status,
      isAuthenticated: status === "authenticated",
      isLoading: status === "loading",
      login,
      logout,
    }),
    [user, status],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }

  return context;
}
