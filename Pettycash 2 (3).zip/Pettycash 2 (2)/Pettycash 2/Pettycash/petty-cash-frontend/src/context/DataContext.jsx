import { createContext, useContext, useState } from "react";
import axios from "axios";
import { backendUrl } from "../App";
import api from "../services/auth-service";

const DataContext = createContext();

export const DataProvider = ({ children }) => {
  const [components, setComponents] = useState([]);
  const [subComponents, setSubComponents] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [cashInflow, setCashInflow] = useState([]);
  const [ledger, setLedger] = useState([]);
  const [senderAccounts, setSenderAccounts] = useState([]);
  const [cashAccounts, setCashAccounts] = useState([]);
  const [monthlySummary, setMonthlySummary] = useState(null);
  const [cashFlowEntries, setCashFlowEntries] = useState([]);
  const [financialCategories, setFinancialCategories] = useState([]);
  const [financialSubCategories, setFinancialSubCategories] = useState([]);
  const [clients, setClients] = useState([]);

  // CRUD - Components
  const getComponents = async () => {
    const response = await api.get(
      `${backendUrl}/api/componentRouter/getAllComponents`,
    );

    setComponents(response.data.data);
  };

  const createComponent = async (payload) => {
    return await api.post(
      `${backendUrl}/api/componentRouter/createComponent`,
      payload,
    );
  };

  const updateComponent = async (id, payload) => {
    return await api.patch(
      `${backendUrl}/api/componentRouter/updateComponent/${id}`,
      payload,
    );
  };

  const deleteComponent = async (id) => {
    return await api.delete(
      `${backendUrl}/api/componentRouter/deleteComponent/${id}`,
    );
  };

  // CRUD - Sub Components
  const getSubComponents = async () => {
    const response = await api.get(
      `${backendUrl}/api/subcomponentRouter/getAllSubcomponents`,
    );

    setSubComponents(response.data.data);
  };

  const createSubComponent = async (payload) => {
    return await api.post(
      `${backendUrl}/api/subcomponentRouter/createSubcomponent`,
      payload,
    );
  };

  const updateSubComponent = async (id, payload) => {
    return await api.patch(
      `${backendUrl}/api/subcomponentRouter/updateSubcomponent/${id}`,
      payload,
    );
  };

  const deleteSubComponent = async (id) => {
    return await api.delete(
      `${backendUrl}/api/subcomponentRouter/deleteSubcomponent/${id}`,
    );
  };

  // CRUD - Transactions
  const getTransactions = async () => {
    const response = await api.get(
      `${backendUrl}/api/transactionRouter/getAllTransactions`,
    );

    setTransactions(response.data.data);
  };

  const createTransaction = async (payload) => {
    return await api.post(
      `${backendUrl}/api/transactionRouter/createTransaction`,
      payload,
    );
  };

  const updateTransaction = async (id, payload) => {
    return await api.patch(
      `${backendUrl}/api/transactionRouter/updateTransaction/${id}`,
      payload,
    );
  };

  const deleteTransaction = async (id) => {
    return await api.delete(
      `${backendUrl}/api/transactionRouter/deleteTransaction/${id}`,
    );
  };

  // CRUD - Cash Inflow
  const createCashInflow = async (payload) => {
    return await api.post(
      `${backendUrl}/api/cashInflowRouter/createCashInflow`,
      payload,
    );
  };

  const getCashInflows = async () => {
    const response = await api.get(
      `${backendUrl}/api/cashInflowRouter/getAllCashInflows`,
    );

    setCashInflow(response.data.data);
  };

  const updateCashInflow = async (id, payload) => {
    return await api.patch(
      `${backendUrl}/api/cashInflowRouter/updateCashInflow/${id}`,
      payload,
    );
  };

  const deleteCashInflow = async (id) => {
    return await api.delete(
      `${backendUrl}/api/cashInflowRouter/deleteCashInflow/${id}`,
    );
  };

  // CRUD - Clients
  const getClients = async () => {
    const response = await api.get(
      `${backendUrl}/api/clientRouter/getAllClients`,
    );

    setClients(response.data.data);
    return response.data;
  };

  const getActiveClients = async () => {
    const response = await api.get(
      `${backendUrl}/api/clientRouter/getActiveClients`,
    );

    setClients(response.data.data);
    return response.data;
  };

  const createClient = async (payload) => {
    return await api.post(
      `${backendUrl}/api/clientRouter/create`,
      payload,
    );
  };

  const updateClient = async (id, payload) => {
    return await api.patch(
      `${backendUrl}/api/clientRouter/updateClient/${id}`,
      payload,
    );
  };

  const deleteClient = async (id) => {
    return await api.delete(`${backendUrl}/api/clientRouter/${id}`);
  };

  // Get - Petty Cash Report
  const getComponentExpenseSummary = async (month, year) => {
    const response = await axios.get(
      `${backendUrl}/api/reportRouter/componentExpenseSummary`,
      {
        params: {
          month,
          year,
        },
      },
    );
    return response.data;
  };

  // Get Combined Result Petty cash entry + Cash Inflow API
  const getLedger = async () => {
    const response = await axios.get(
      `${backendUrl}/api/reportRouter/pettyCashLedger`,
    );

    setLedger(response.data.data);
  };

  // Sender Accounts
  const getSenderAccounts = async () => {
    try {
      const response = await api.get(
        "/api/senderAccountRouter/getAllSenderAccount",
      );

      if (response.data.success) {
        setSenderAccounts(response.data.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const createSenderAccount = async (payload) => {
    return await api.post(
      "/api/senderAccountRouter/createSenderAccount",
      payload,
    );
  };

  const updateSenderAccount = async (id, payload) => {
    return await api.patch(
      `/api/senderAccountRouter/updateSenderAccount/${id}`,
      payload,
    );
  };

  const deleteSenderAccount = async (id) => {
    return await api.delete(
      `/api/senderAccountRouter/deleteSenderAccount/${id}`,
    );
  };

  const getSenderAccountById = async (id) => {
    return await api.get(`/api/senderAccountRouter/getSenderAccountById/${id}`);
  };

  // Get Cash Accounts
  const getCashAccounts = async () => {
    try {
      const response = await api.get(
        "/api/pettyCashAccountRouter/getAllPettyCashAccounts",
      );

      if (response.data.success) {
        setCashAccounts(response.data.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Create Cash Account
  const createCashAccount = async (payload) => {
    return await api.post(
      "/api/pettyCashAccountRouter/createPettyCashAccount",
      payload,
    );
  };

  // Update Cash Account
  const updateCashAccount = async (id, payload) => {
    return await api.put(
      `/api/pettyCashAccountRouter/updatePettyCashAccount/${id}`,
      payload,
    );
  };

  // Delete Cash Account
  const deleteCashAccount = async (id) => {
    return await api.delete(
      `/api/pettyCashAccountRouter/deletePettyCashAccount/${id}`,
    );
  };

  // Get Cash Account By Id
  const getCashAccountById = async (id) => {
    return await api.get(
      `/api/pettyCashAccountRouter/getPettyCashAccountById/${id}`,
    );
  };

  // Get Monthly Summary
  const getMonthlySummaryByMonth = async (month) => {
    const response = await api.get(
      `/api/summaryRouter/monthlySummary/${month}`,
    );

    if (response.data.success) {
      setMonthlySummary(response.data.data);
    }

    return response.data;
  };

  // Get Subcomponent based on Head Component
  const getSubComponentsByComponent = async (componentId) => {
    return await api.get(
      `/api/subComponentRouter/getSubComponentByComponent/${componentId}`,
    );
  };

  // CRUD - Cash Flow Entries
  const getCashFlowEntries = async () => {
    const response = await api.get(`${backendUrl}/api/cashFlowRouter/entries`);

    setCashFlowEntries(response.data.data);

    return response;
  };

  const createCashFlowEntry = async (payload) => {
    return await api.post(`${backendUrl}/api/cashFlowRouter/entries`, payload);
  };

  const updateCashFlowEntry = async (id, payload) => {
    return await api.put(
      `${backendUrl}/api/cashFlowRouter/entries/${id}`,
      payload,
    );
  };

  const deleteCashFlowEntry = async (id) => {
    return await api.delete(`${backendUrl}/api/cashFlowRouter/entries/${id}`);
  };

  const getCashFlowEntryById = async (id) => {
    return await api.get(`${backendUrl}/api/cashFlowRouter/entries/${id}`);
  };

  const getFinancialCategories = async () => {
    const response = await api.get("/api/componentRouter/financial-categories");

    if (response.data.success) {
      setFinancialCategories(response.data.data || []);
    }

    return response.data;
  };

  const getFinancialSubCategoriesByCategory = async (financialCategoryId) => {
    if (!financialCategoryId) {
      setFinancialSubCategories([]);
      return {
        success: true,
        data: {
          financialCategory: null,
          financialSubCategories: [],
        },
      };
    }

    const response = await api.get(
      `/api/componentRouter/financial-subcategories/${financialCategoryId}`,
    );

    if (response.data.success) {
      setFinancialSubCategories(
        response.data.data?.financialSubCategories || [],
      );
    }

    return response.data;
  };

  const clearFinancialSubCategories = () => {
    setFinancialSubCategories([]);
  };

  return (
    <DataContext.Provider
      value={{
        components,
        subComponents,
        transactions,
        cashInflow,
        ledger,
        senderAccounts,
        cashAccounts,
        monthlySummary,
        cashFlowEntries,
        clients,

        getComponents,
        createComponent,
        updateComponent,
        deleteComponent,

        getSubComponents,
        createSubComponent,
        updateSubComponent,
        deleteSubComponent,

        getTransactions,
        createTransaction,
        updateTransaction,
        deleteTransaction,

        createCashInflow,
        getCashInflows,
        updateCashInflow,
        deleteCashInflow,

        getClients,
        getActiveClients,
        createClient,
        updateClient,
        deleteClient,

        getCashFlowEntries,
        createCashFlowEntry,
        getCashFlowEntryById,
        updateCashFlowEntry,
        deleteCashFlowEntry,

        getComponentExpenseSummary,
        getLedger,

        getSenderAccounts,
        createSenderAccount,
        updateSenderAccount,
        deleteSenderAccount,
        getSenderAccountById,

        getCashAccounts,
        createCashAccount,
        updateCashAccount,
        deleteCashAccount,
        getCashAccountById,

        getMonthlySummaryByMonth,
        getSubComponentsByComponent,

        financialCategories,
        financialSubCategories,
        getFinancialCategories,
        getFinancialSubCategoriesByCategory,
        clearFinancialSubCategories,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useDataContext = () => useContext(DataContext);
