const palette = (mode) => ({
  mode,

  primary: {
    main: "#1D89C8",
    light: "#1D89C820",
    dark: "#1565C0",
  },

  secondary: {
    main: "#3EB8AF",
    light: "#3EB8AF20",
    dark: "#2C8F89",
  },

  success: {
    main: "#22C55E",
  },

  error: {
    main: "#EF4444",
  },

  warning: {
    main: "#F59E0B",
  },

  background: {
    default: mode === "dark" ? "#000000" : "#F8FAFC",
    paper: mode === "dark" ? "#111827" : "#FFFFFF",
  },

  text: {
    primary: mode === "dark" ? "#FFFFFF" : "#111827",
    secondary: mode === "dark" ? "#B8C5D6" : "#6B7280",
  },

  divider: "#E5E7EB",

  sidebar: {
    main: "#0F172A",
    hover: "#1E293B",
    active: "#1D89C8",
  },
});

export default palette;