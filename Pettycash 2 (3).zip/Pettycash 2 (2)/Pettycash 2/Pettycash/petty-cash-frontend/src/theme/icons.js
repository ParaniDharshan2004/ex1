import DashboardIcon from "@mui/icons-material/Dashboard";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import PaymentsIcon from "@mui/icons-material/Payments";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import SearchIcon from "@mui/icons-material/Search";
import FilterListIcon from "@mui/icons-material/FilterList";
import MenuIcon from "@mui/icons-material/Menu";

import ReceiptLongIcon from "@mui/icons-material/ReceiptLong";
import ApartmentIcon from "@mui/icons-material/Apartment";
import CategoryIcon from "@mui/icons-material/Category";
import PeopleIcon from "@mui/icons-material/People";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import GroupsIcon from "@mui/icons-material/Groups";
import CloseIcon from "@mui/icons-material/Close";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import LogoutIcon from "@mui/icons-material/Logout";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import RemoveCircleOutlineIcon from "@mui/icons-material/RemoveCircleOutlined";
import RefreshIcon from "@mui/icons-material/Refresh";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutlined";

import CurrencyRupeeOutlinedIcon from "@mui/icons-material/CurrencyRupeeOutlined";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";

export const Icons = {
  DashboardIcon,
  AccountBalanceWalletIcon,
  PaymentsIcon,

  AddIcon,
  EditIcon,
  DeleteIcon,

  SearchIcon,
  FilterListIcon,
  MenuIcon,

  ReceiptLongIcon,
  ApartmentIcon,
  CategoryIcon,
  PeopleIcon,

  CheckCircleIcon,
  CancelIcon,
  TrendingUpIcon,
  PendingActionsIcon,
  GroupsIcon,

  CloseIcon,
  ExpandMoreIcon,
  ExpandLessIcon,
  KeyboardArrowDownIcon,
  KeyboardArrowUpIcon,

  LogoutIcon,

  MoreVertIcon,
  RestartAltIcon,
  EditOutlinedIcon,
  RemoveCircleOutlineIcon,
  RefreshIcon,
  DeleteOutlineIcon,

  CurrencyRupeeOutlinedIcon,
  TrendingUpRoundedIcon
};