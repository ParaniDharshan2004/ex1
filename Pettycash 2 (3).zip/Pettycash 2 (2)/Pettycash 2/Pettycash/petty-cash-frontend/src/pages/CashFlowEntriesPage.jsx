import { useEffect, useMemo, useState } from "react";
import { Alert, Box, Snackbar, Typography } from "@mui/material";

import EntityFormDialog from "../components/common-components/EntityFormDialog.jsx";
import ConfirmDialog from "../components/common-components/ConfirmDialog.jsx";
import PageHeader from "../components/common-components/PageHeader.jsx";

import CashFlowEntryFilters from "../components/cash-flow-components/CashFlowFilters.jsx";
import CashFlowEntryTable from "../components/cash-flow-components/CashFlowEntryTable.jsx";

import { Icons } from "../theme/icons.js";
import { useDataContext } from "../context/DataContext.jsx";

export default function CashFlowEntriesPage() {
  const {
    components,
    getComponents,

    getSubComponents,

    cashFlowEntries,
    getCashFlowEntries,
    createCashFlowEntry,
    updateCashFlowEntry,
    deleteCashFlowEntry,

    getSubComponentsByComponent,
  } = useDataContext();

  const [componentSubComponents, setComponentSubComponents] = useState([]);
  const today = new Date();
  const [filters, setFilters] = useState({
    search: "",
    date: "",
    month: today.getMonth().toString(),
    year: today.getFullYear().toString(),
  });
  const [formDialog, setFormDialog] = useState({
    open: false,
    mode: "create",
    initialValues: {},
  });
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [toast, setToast] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  useEffect(() => {
    getComponents();
    getSubComponents();
    getCashFlowEntries();
  }, [getCashFlowEntries, getComponents, getSubComponents]);

  const cashFlowComponents = useMemo(() => {
    return components
      .filter(
        (component) =>
          component.isCashFlowAnalysis === true && component.isActive === true,
      )
      .sort(
        (firstComponent, secondComponent) =>
          (firstComponent.displayOrder || 0) -
          (secondComponent.displayOrder || 0),
      );
  }, [components]);

  const showToast = (message, severity = "success") => {
    setToast({
      open: true,
      message,
      severity,
    });
  };

  const CASH_FLOW_ENTRY_FIELDS = [
    {
      name: "entryDate",
      label: "Entry Date",
      type: "date",
      required: true,
    },
    {
      name: "componentId",
      label: "Component",
      type: "select",
      required: true,

      options: cashFlowComponents.map((component) => ({
        label: component.componentName,
        value: component._id,
      })),
    },
    ...(componentSubComponents.length > 0
      ? [
          {
            name: "subComponentId",

            label: "Sub Component",

            type: "select",

            required: true,

            options: componentSubComponents.map((subComponent) => ({
              label: subComponent.subComponentName,

              value: subComponent._id,
            })),
          },
        ]
      : []),
    {
      name: "description",
      label: "Description",
      type: "text",
      required: false,
    },
    {
      name: "amount",
      label: "Amount",
      type: "number",
      prefix: "₹",
      required: true,
    },
  ];

  const handleFieldChange = async (fieldName, value) => {
    if (fieldName !== "componentId") {
      return;
    }

    setComponentSubComponents([]);

    if (!value) {
      return;
    }

    try {
      const response = await getSubComponentsByComponent(value);

      if (response.data.success) {
        const filteredSubComponents = response.data.data
          .filter(
            (subComponent) =>
              subComponent.isCashFlowAnalysis === true &&
              subComponent.isActive === true,
          )
          .sort(
            (firstSubComponent, secondSubComponent) =>
              (firstSubComponent.displayOrder || 0) -
              (secondSubComponent.displayOrder || 0),
          );

        setComponentSubComponents(filteredSubComponents);
      }
    } catch (error) {
      console.error("Get Sub Components Error:", error);
      showToast(
        error.response?.data?.message || "Unable to load Sub Components",
        "error",
      );
    }
  };

  const filteredEntries = useMemo(() => {
    return cashFlowEntries.filter((entry) => {
      const componentName = entry.componentId?.componentName || "";

      const description = entry.description || "";

      const entryDate = new Date(entry.entryDate);

      const matchesSearch =
        !filters.search ||
        componentName.toLowerCase().includes(filters.search.toLowerCase()) ||
        description.toLowerCase().includes(filters.search.toLowerCase());

      const matchesDate =
        !filters.date || entry.entryDate?.slice(0, 10) === filters.date;

      const matchesMonth =
        filters.month === "" ||
        entryDate.getMonth().toString() === filters.month;

      const matchesYear =
        !filters.year || entryDate.getFullYear().toString() === filters.year;

      return matchesSearch && matchesDate && matchesMonth && matchesYear;
    });
  }, [cashFlowEntries, filters]);

  const openCreateDialog = () => {
    setComponentSubComponents([]);

    const localDate = new Date();
    const year = localDate.getFullYear();
    const month = String(localDate.getMonth() + 1).padStart(2, "0");
    const day = String(localDate.getDate()).padStart(2, "0");

    setFormDialog({
      open: true,
      mode: "create",
      initialValues: {
        entryDate: `${year}-${month}-${day}`,
        componentId: "",
        subComponentId: "",
        description: "",
        amount: "",
      },
    });
  };

  const openEditDialog = async (row) => {
    try {
      const componentId = row.componentId?._id || row.componentId || "";

      const subComponentId =
        row.subComponentId?._id || row.subComponentId || "";

      setComponentSubComponents([]);

      if (componentId) {
        const response = await getSubComponentsByComponent(componentId);

        if (response.data.success) {
          const filteredSubComponents = response.data.data
            .filter(
              (subComponent) =>
                subComponent.isCashFlowAnalysis === true &&
                subComponent.isActive === true,
            )
            .sort(
              (firstSubComponent, secondSubComponent) =>
                (firstSubComponent.displayOrder || 0) -
                (secondSubComponent.displayOrder || 0),
            );

          setComponentSubComponents(filteredSubComponents);
        }
      }

      setFormDialog({
        open: true,
        mode: "edit",
        initialValues: {
          _id: row._id,
          entryDate: row.entryDate?.split("T")[0] || "",
          componentId,
          subComponentId,
          description: row.description || "",
          amount: row.amount ?? "",
        },
      });
    } catch (error) {
      console.error("Open Cash Flow Edit Error:", error);

      showToast("Unable to open Cash Flow Entry.", "error");
    }
  };

  const closeFormDialog = () => {
    setComponentSubComponents([]);

    setFormDialog((previousDialog) => ({
      ...previousDialog,
      open: false,
    }));
  };

  const handleSaveEntry = async (values) => {
    try {
      const payload = {
        entryDate: values.entryDate,
        componentId: values.componentId,
        subComponentId: values.subComponentId || null,
        description: values.description || null,
        amount: Number(values.amount),
      };

      if (values._id) {
        const response = await updateCashFlowEntry(values._id, payload);

        if (response.data.success) {
          await getCashFlowEntries();
          showToast(
            response.data.message || "Cash Flow Entry updated successfully",
          );
        }
      } else {
        const response = await createCashFlowEntry(payload);

        if (response.data.success) {
          await getCashFlowEntries();
          showToast(
            response.data.message || "Cash Flow Entry created successfully",
          );
        }
      }

      closeFormDialog();
    } catch (error) {
      console.error("Save Cash Flow Entry Error:", error);

      showToast(
        error.response?.data?.message || "Something went wrong",
        "error",
      );
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) {
      return;
    }

    try {
      const response = await deleteCashFlowEntry(deleteTarget._id);

      if (response.data.success) {
        /*
         * Reload database data.
         */

        await getCashFlowEntries();

        showToast(
          response.data.message || "Cash Flow Entry deleted successfully",
        );
      }

      setDeleteTarget(null);
    } catch (error) {
      console.error("Delete Cash Flow Entry Error:", error);

      showToast(
        error.response?.data?.message || "Unable to delete Cash Flow Entry",
        "error",
      );
    }
  };

  const getDeleteComponentName = () => {
    if (!deleteTarget) {
      return "";
    }
    if (deleteTarget.componentId?.componentName) {
      return deleteTarget.componentId.componentName;
    }

    const componentId =
      deleteTarget.componentId?._id || deleteTarget.componentId;

    const component = cashFlowComponents.find(
      (item) => String(item._id) === String(componentId),
    );

    return component?.componentName || "this entry";
  };

  return (
    <Box>
      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box
          sx={{
            p: {
              xs: 2,
              sm: 3,
            },

            flex: 1,
          }}
        >
          <PageHeader
            title="Cash Flow Entries"
            buttonText="Add Entry"
            onButtonClick={openCreateDialog}
          />

          <Box
            sx={{
              mt: 3,
              mb: 1,
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <Icons.FilterListIcon
              fontSize="small"
              sx={{
                color: "textPrimary",
              }}
            />

            <Typography
              variant="subtitle2"
              sx={{
                color: "textPrimary",
              }}
            >
              Filter cash flow entries
            </Typography>
          </Box>

          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 2,
              overflowX: "auto",
            }}
          >
            <CashFlowEntryFilters
              filters={filters}
              setFilters={setFilters}
              onAdd={openCreateDialog}
            />

            <CashFlowEntryTable
              rows={filteredEntries}
              components={cashFlowComponents}
              onEdit={openEditDialog}
              onDeleteRequest={setDeleteTarget}
            />
          </Box>
        </Box>
      </Box>

      {/* CREATE / EDIT */}

      <EntityFormDialog
        open={formDialog.open}
        mode={formDialog.mode}
        title={
          formDialog.mode === "edit"
            ? "Edit Cash Flow Entry"
            : "Add Cash Flow Entry"
        }
        saveConfirmTitle={
          formDialog.mode === "edit"
            ? "Update this cash flow entry?"
            : "Save this cash flow entry?"
        }
        saveConfirmMessage={
          formDialog.mode === "edit"
            ? "You're about to update this cash flow entry. Continue?"
            : "You're about to add this cash flow entry. Continue?"
        }
        fields={CASH_FLOW_ENTRY_FIELDS}
        initialValues={formDialog.initialValues}
        onFieldChange={handleFieldChange}
        onClose={closeFormDialog}
        onSave={handleSaveEntry}
      />

      <ConfirmDialog
        open={deleteTarget !== null}
        title="Delete this entry?"
        message={
          deleteTarget
            ? `This permanently removes the ${getDeleteComponentName()} cash flow entry. This can't be undone.`
            : ""
        }
        confirmLabel="Yes, delete"
        confirmColor="primary.error"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* TOAST */}

      <Snackbar
        open={toast.open}
        autoHideDuration={3000}
        onClose={() =>
          setToast((previousToast) => ({
            ...previousToast,
            open: false,
          }))
        }
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
      >
        <Alert
          severity={toast.severity}
          variant="filled"
          onClose={() =>
            setToast((previousToast) => ({
              ...previousToast,
              open: false,
            }))
          }
          sx={{
            width: "100%",

            "& .MuiAlert-icon": {
              alignItems: "center",
              display: "flex",
            },

            "& .MuiAlert-message": {
              display: "flex",
              alignItems: "center",
            },
          }}
        >
          {toast.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
