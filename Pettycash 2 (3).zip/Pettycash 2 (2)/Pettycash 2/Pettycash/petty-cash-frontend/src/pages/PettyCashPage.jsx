import { useEffect, useMemo, useState } from 'react';
import { Box, Snackbar, Alert, Typography } from '@mui/material';
import EntityFormDialog from '../components/common-components/EntityFormDialog';
import ConfirmDialog from '../components/common-components/ConfirmDialog';
import FilterToolbar from '../components/pettycash-components/PettyCashFilters';
import { Icons } from '../theme/icons';
import { useDataContext } from '../context/DataContext';
import LedgerTable from '../components/pettycash-components/LedgerTable';
import PageHeader from '../components/common-components/PageHeader';

export default function PettyCashPage() {
  const {
    getTransactions,
    ledger,
    getLedger,
    createTransaction,
    updateTransaction,
    deleteTransaction,
    components,
    getComponents,
    getSubComponents,
    getMonthlySummaryByMonth,
    getSubComponentsByComponent,
  } = useDataContext();
  const [componentSubComponents, setComponentSubComponents] = useState([]);
  const today = new Date();
  const [filters, setFilters] = useState({
    search: '',
    date: '',
    month: today.getMonth().toString(),
    year: today.getFullYear().toString(),
    componentId: '',
    startDate: '',
    endDate: '',
  });
  const [toast, setToast] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  // One piece of state drives the form dialog for create AND edit.
  // mode + initialValues (with or without _id) is all EntityFormDialog needs.
  const [formDialog, setFormDialog] = useState({
    open: false,
    mode: 'create',
    initialValues: {},
  });
  const [deleteTarget, setDeleteTarget] = useState(null);

  const refreshMonthlySummary = async () => {
    const month =
      filters.year && filters.month !== ''
        ? `${filters.year}-${String(Number(filters.month) + 1).padStart(2, '0')}`
        : new Date().toISOString().slice(0, 7);

    console.log(month);
    await getMonthlySummaryByMonth(month);
  };

  // Get Transaction
  useEffect(() => {
    getTransactions();
    getComponents();
    getSubComponents();
    getLedger();
  }, [getTransactions, getComponents, getSubComponents, getLedger]);

  useEffect(() => {
    const month =
      filters.year && filters.month !== ''
        ? `${filters.year}-${String(Number(filters.month) + 1).padStart(2, '0')}`
        : new Date().toISOString().slice(0, 7);

    getMonthlySummaryByMonth(month);
  }, [filters.month, filters.year, getMonthlySummaryByMonth]);

  // Form Fields
  const TRANSACTION_FIELDS = [
    {
      name: 'transactionDate',
      label: 'Transaction Date',
      type: 'date',
      required: true,
    },

    {
      name: 'transactionType',
      label: 'Transaction Type',
      type: 'select',
      required: true,
      options: [
        {
          label: 'Expense',
          value: 'EXPENSE',
        },
        {
          label: 'Reimbursement',
          value: 'REIMBURSEMENT',
        },
      ],
    },

    {
      name: 'componentId',
      label: 'Component',
      type: 'select',
      required: true,
      options: components
        .filter((item) => item.isPettyCash === true && item.isActive === true)
        .map((item) => ({
          label: item.componentName,
          value: item._id,
        })),
    },

    ...(componentSubComponents.length > 0
      ? [
          {
            name: 'subComponentId',
            label: 'Sub Component',
            type: 'select',
            required: true,
            options: componentSubComponents.map((item) => ({
              label: item.subComponentName,
              value: item._id,
            })),
          },
        ]
      : []),

    {
      name: 'description',
      label: 'Description',
      type: 'text',
      required: false,
    },

    {
      name: 'amount',
      label: 'Amount',
      type: 'number',
      prefix: '₹',
      required: true,
    },

    {
      name: 'billAvailable',
      label: 'Bill Available',
      type: 'select',
      options: [
        {
          label: 'Yes',
          value: true,
        },
        {
          label: 'No',
          value: false,
        },
      ],
    },
  ];

  const filteredLedger = useMemo(() => {
    return ledger.filter((t) => {
      if (t.source !== 'PETTY_CASH') return false;

      const rowDate = new Date(t.date);

      const matchesSearch =
        !filters.search ||
        t.component?.toLowerCase().includes(filters.search.toLowerCase()) ||
        t.description?.toLowerCase().includes(filters.search.toLowerCase());

      const matchesDate =
        !filters.date || t.date?.slice(0, 10) === filters.date;

      const matchesMonth =
        !filters.month || rowDate.getMonth().toString() === filters.month;

      const matchesYear =
        !filters.year || rowDate.getFullYear().toString() === filters.year;

      const matchesComponent =
        !filters.componentId || t.componentId === filters.componentId;

      return (
        matchesSearch &&
        matchesDate &&
        matchesMonth &&
        matchesYear &&
        matchesComponent
      );
    });
  }, [ledger, filters]);

  const showToast = (message, severity = 'success') =>
    setToast({ open: true, message, severity });

  const openCreateDialog = () =>
    setFormDialog({ open: true, mode: 'create', initialValues: {} });

  const openEditDialog = (row) => {
    if (row.source !== 'PETTY_CASH') {
      showToast('Cash Inflow edit dialog not implemented yet', 'warning');
      return;
    }

    const data = row.pettyCashData;

    setFormDialog({
      open: true,
      mode: 'edit',
      initialValues: {
        _id: data._id,
        transactionDate: data.transactionDate?.split('T')[0],
        transactionType: data.transactionType,
        componentId: data.componentId?._id,
        subComponentId: data.subComponentId?._id,
        description: data.description,
        amount: data.amount,
        billAvailable: data.billAvailable,
      },
    });
  };

  const closeFormDialog = () => setFormDialog((s) => ({ ...s, open: false }));

  // Create & update Petty cash entry
  const handleSaveTransaction = async (values) => {
    try {
      const payload = {
        ...values,

        cashAccountId: '6aa25521f06a66a35dd15391',

        spentByUserId: '6aa0ddf6f070abe2bf992b12',

        balanceBefore: 0,
        balanceAfter: 0,
      };

      if (values._id) {
        const response = await updateTransaction(values._id, payload);

        if (response.data.success) {
          await Promise.all([
            getTransactions(),
            getLedger(),
            refreshMonthlySummary(),
          ]);

          showToast(response.data.message);
        }
      } else {
        const response = await createTransaction(payload);

        if (response.data.success) {
          await Promise.all([
            getTransactions(),
            getLedger(),
            refreshMonthlySummary(),
          ]);

          showToast(response.data.message);
        }
      }

      closeFormDialog();
    } catch (error) {
      showToast(
        error.response?.data?.message || 'Something went wrong',
        'error',
      );
    }
  };

  // Delete Ledger Entry Table
  const confirmDelete = async () => {
    try {
      let response;

      response = await deleteTransaction(deleteTarget._id);

      if (response.data.success) {
        await Promise.all([
          getTransactions(),
          getLedger(),
          refreshMonthlySummary(),
        ]);

        showToast(response.data.message);
      }

      setDeleteTarget(null);
    } catch (error) {
      showToast(error.response?.data?.message, 'error');
    }
  };

  const handleFieldChange = async (fieldName, value) => {
    if (fieldName === 'componentId') {
      try {
        const response = await getSubComponentsByComponent(value);

        if (response.data.success) {
          setComponentSubComponents(response.data.data);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };

  return (
    <Box>
      <Box
        sx={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <Box sx={{ p: { xs: 2, sm: 3 }, flex: 1 }}>
          <PageHeader
            title="Petty Cash Transactions"
            buttonText="Add Cash"
            onButtonClick={openCreateDialog}
          />
          <Box
            sx={{
              mt: 3,
              mb: 1,
              display: 'flex',
              alignItems: 'center',
              gap: 1,
            }}
          >
            <Icons.FilterListIcon
              fontSize="small"
              sx={{ color: 'textPrimary' }}
            />
            <Typography variant="subtitle2" sx={{ color: 'textPrimary' }}>
              Filter transactions
            </Typography>
          </Box>

          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 2,
              overflowX: 'auto',
            }}
          >
            <FilterToolbar
              filters={filters}
              setFilters={setFilters}
              onAdd={openCreateDialog}
              components={components.filter((c) => c.isPettyCash)}
            />
            <LedgerTable
              rows={filteredLedger}
              onEdit={openEditDialog}
              onDeleteRequest={setDeleteTarget}
            />
            {/* <TransactionsTable
              rows={filteredRows}
              onEdit={openEditDialog}
              onDeleteRequest={setDeleteTarget}
            /> */}
          </Box>
        </Box>
      </Box>

      <EntityFormDialog
        open={formDialog.open}
        mode={formDialog.mode}
        onFieldChange={handleFieldChange}
        title={
          formDialog.mode === 'edit' ? 'Edit transaction' : 'Add transaction'
        }
        saveConfirmTitle={
          formDialog.mode === 'edit'
            ? 'Update this transaction?'
            : 'Save this transaction'
        }
        saveConfirmMessage={
          formDialog.mode === 'edit'
            ? "You're about to update this transaction. Continue?"
            : "You're about to save this transaction. Continue?"
        }
        fields={TRANSACTION_FIELDS}
        initialValues={formDialog.initialValues}
        onClose={closeFormDialog}
        onSave={handleSaveTransaction}
      />

      <ConfirmDialog
        open={deleteTarget !== null}
        title="Delete this record?"
        message={
          deleteTarget
            ? `This permanently removes ${deleteTarget.component}. This can't be undone.`
            : ''
        }
        confirmLabel="Yes, delete"
        confirmColor={'primary.error'}
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <Snackbar
        open={toast.open}
        autoHideDuration={3000}
        onClose={() => setToast((t) => ({ ...t, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          severity={toast.severity}
          variant="filled"
          onClose={() => setToast((t) => ({ ...t, open: false }))}
          sx={{
            alignItems: 'center',
            '& .MuiAlert-icon': {
              alignItems: 'center',
              display: 'flex',
            },
            '& .MuiAlert-message': {
              display: 'flex',
              alignItems: 'center',
            },
          }}
        >
          {toast.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
