import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Container,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutlined";
import { useNavigate } from "react-router-dom";
import api from "../services/auth-service";
import ForecastStatementTable from "../components/cash-flow-components/ForecastStatementTable";
import CashFlowSummaryTable from "../components/cash-flow-components/CashFlowSummaryTable";
import ConfirmDialog from "../components/common-components/ConfirmDialog";
import { buildForecastMonths } from "../utils/cash-flow-forecast/tallyExcelParser";

const formatMonth = (forecast) => {
  const sourceDate = forecast.sourceDate
    ? new Date(forecast.sourceDate)
    : new Date(`${forecast.sourceMonth}-01T00:00:00`);

  if (Number.isNaN(sourceDate.getTime())) {
    return forecast.sourceMonth || "Unknown month";
  }

  return sourceDate.toLocaleDateString("en-IN", {
    month: "long",
    year: "numeric",
  });
};

const getForecastId = (forecast) => forecast._id || forecast.id;

const getSourceDate = (forecast) => {
  const sourceDate = forecast.sourceDate
    ? new Date(forecast.sourceDate)
    : new Date(`${forecast.sourceMonth}-01T00:00:00`);

  return Number.isNaN(sourceDate.getTime()) ? null : sourceDate;
};

const mapForecastRows = (rows = []) =>
  rows.map((row) => ({
    ...row,
    financialCategoryCode:
      row.financialCategoryCode || row.financialCategoryId?.categoryCode || "",
    financialSubCategoryCode:
      row.financialSubCategoryCode ||
      row.financialSubCategoryId?.subCategoryCode ||
      "",
    month1: Number(row.month1 ?? row.forecastAmounts?.[0]?.amount) || 0,
    month2: Number(row.month2 ?? row.forecastAmounts?.[1]?.amount) || 0,
    month3: Number(row.month3 ?? row.forecastAmounts?.[2]?.amount) || 0,
  }));

const mapFixedCostRows = (rows = []) =>
  rows.map((row) => ({
    ...row,
    month1Amount:
      Number(row.month1Amount ?? row.forecastAmounts?.[0]?.amount) || 0,
    month2Amount:
      Number(row.month2Amount ?? row.forecastAmounts?.[1]?.amount) || 0,
    month3Amount:
      Number(row.month3Amount ?? row.forecastAmounts?.[2]?.amount) || 0,
  }));

export default function CashFlowReportPage() {
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [reportSearch, setReportSearch] = useState("");
  const [selectedReport, setSelectedReport] = useState(null);
  const [selectedSummary, setSelectedSummary] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [loading, setLoading] = useState(true);
  const [reportToDelete, setReportToDelete] = useState(null);
  const [deletingReport, setDeletingReport] = useState(false);
  const [editingReportId, setEditingReportId] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const loadReports = async () => {
      try {
        setLoading(true);
        setErrorMessage("");

        const response = await api.get("/api/cashFlowRouter/forecast/all");
        setReports(response.data?.data || []);
      } catch (error) {
        setErrorMessage(
          error.response?.data?.message || "Unable to load cash flow reports.",
        );
      } finally {
        setLoading(false);
      }
    };

    loadReports();
  }, []);

  const filteredReports = useMemo(() => {
    const searchTerm = reportSearch.trim().toLowerCase();

    if (!searchTerm) {
      return reports;
    }

    return reports.filter((report) =>
      formatMonth(report).toLowerCase().includes(searchTerm),
    );
  }, [reports, reportSearch]);

  const openReport = async (report) => {
    try {
      setLoadingDetails(true);
      setErrorMessage("");
      setSelectedReport(report);

      const response = await api.get(
        `/api/cashFlowRouter/forecast/${getForecastId(report)}/cash-flow-summary`,
      );

      setSelectedSummary(response.data?.data || {});
    } catch (error) {
      setSelectedSummary(null);
      setErrorMessage(
        error.response?.data?.message || "Unable to load the selected report.",
      );
    } finally {
      setLoadingDetails(false);
    }
  };

  const editReport = async (report) => {
    const forecastId = getForecastId(report);

    try {
      setEditingReportId(String(forecastId));
      setErrorMessage("");
      await api.patch(`/api/cashFlowRouter/forecast/${forecastId}/status`, {
        status: "DRAFT",
      });
      setReports((currentReports) =>
        currentReports.map((item) =>
          String(getForecastId(item)) === String(forecastId)
            ? { ...item, status: "DRAFT" }
            : item,
        ),
      );
      localStorage.setItem("cashFlowForecastId", String(forecastId));
      navigate("/cash-flow-analysis");
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message || "Unable to edit the cash flow report.",
      );
    } finally {
      setEditingReportId(null);
    }
  };

  const confirmDeleteReport = async () => {
    if (!reportToDelete || deletingReport) {
      return;
    }

    const forecastId = getForecastId(reportToDelete);

    try {
      setDeletingReport(true);
      setErrorMessage("");
      await api.delete(`/api/cashFlowRouter/forecast/${forecastId}`);
      setReports((currentReports) =>
        currentReports.filter(
          (report) => String(getForecastId(report)) !== String(forecastId),
        ),
      );

      if (String(getForecastId(selectedReport || {})) === String(forecastId)) {
        setSelectedReport(null);
        setSelectedSummary(null);
      }

      if (localStorage.getItem("cashFlowForecastId") === String(forecastId)) {
        localStorage.removeItem("cashFlowForecastId");
      }

      setReportToDelete(null);
    } catch (error) {
      setReportToDelete(null);
      setErrorMessage(
        error.response?.data?.message || "Unable to delete the cash flow report.",
      );
    } finally {
      setDeletingReport(false);
    }
  };

  const reportDate = selectedReport ? getSourceDate(selectedReport) : null;
  const reportMonths = useMemo(
    () => buildForecastMonths(reportDate),
    [reportDate],
  );
  const reportRows = useMemo(
    () => mapForecastRows(selectedReport?.rows || []),
    [selectedReport],
  );
  const fixedCostRows = useMemo(
    () => mapFixedCostRows(selectedReport?.fixedCosts || []),
    [selectedReport],
  );
  const reportOutflowTotals = useMemo(
    () =>
      reportMonths.map(
        (_, index) =>
          reportRows.reduce(
            (total, row) => total + (Number(row[`month${index + 1}`]) || 0),
            0,
          ) +
          fixedCostRows.reduce(
            (total, row) =>
              total + (Number(row[`month${index + 1}Amount`]) || 0),
            0,
          ),
      ),
    [fixedCostRows, reportMonths, reportRows],
  );

  return (
    <Container maxWidth="xl" sx={{ py: { xs: 2, sm: 2.5, md: 3 } }}>
      <Stack alignItems="stretch" spacing={2} sx={{ mb: 2 }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>
            Cash Flow Reports
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Select a saved month to open its cash flow report.
          </Typography>

          <Stack
            direction={{ xs: "column", sm: "row" }}
            alignItems={{ xs: "stretch", sm: "center" }}
            spacing={1.5}
            sx={{ mt: 2 }}
          >
            <TextField
              label="Search reports"
              placeholder="Type a month name or year"
              size="small"
              value={reportSearch}
              onChange={(event) => setReportSearch(event.target.value)}
              sx={{
                flex: { xs: "1 1 auto", sm: "0 1 780px" },
                width: "100%",
                maxWidth: 780,
                minWidth: 0,
              }}
            />
            {selectedReport && (
              <Button
                variant="outlined"
                onClick={() => {
                  setSelectedReport(null);
                  setSelectedSummary(null);
                }}
                sx={{
                  alignSelf: { xs: "flex-start", sm: "center" },
                  flexShrink: 0,
                  whiteSpace: "nowrap",
                }}
              >
                Back reports
              </Button>
            )}
          </Stack>
        </Box>
      </Stack>

      {errorMessage && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {errorMessage}
        </Alert>
      )}

      {!selectedReport && (
        <Stack spacing={2}>
          {loading ? (
            <Paper variant="outlined" sx={{ p: 5, textAlign: "center" }}>
              <Typography fontWeight={700}>Loading saved reports...</Typography>
            </Paper>
          ) : filteredReports.length === 0 ? (
            <Paper variant="outlined" sx={{ p: 5, textAlign: "center" }}>
              <Typography fontWeight={700}>No saved reports found</Typography>
              <Typography variant="body2" color="text.secondary">
                Save a cash flow report to see it here.
              </Typography>
            </Paper>
          ) : (
            filteredReports.map((report) => (
              <Card
                key={getForecastId(report)}
                variant="outlined"
                sx={{
                  borderRadius: 2,
                  transition: "border-color 160ms ease, box-shadow 160ms ease",
                  "&:hover": {
                    borderColor: "primary.main",
                    boxShadow: 2,
                  },
                }}
              >
                <CardContent sx={{ p: { xs: 2, sm: 2.5 } }}>
                  <Stack
                    direction={{ xs: "column", md: "row" }}
                    alignItems={{ xs: "stretch", md: "center" }}
                    justifyContent="space-between"
                    spacing={{ xs: 2, md: 3 }}
                  >
                    <Box
                      onClick={() => openReport(report)}
                      sx={{
                        flex: 1,
                        minWidth: 0,
                        cursor: "pointer",
                      }}
                    >
                      <Stack
                        direction="row"
                        alignItems="center"
                        flexWrap="wrap"
                        sx={{ columnGap: 1.5, rowGap: 0.75 }}
                      >
                        <Typography
                          variant="h6"
                          fontWeight={800}
                          sx={{ color: "text.primary" }}
                        >
                          {formatMonth(report)}
                        </Typography>
                        <Chip
                          size="small"
                          label={
                            report.status === "FINALIZED"
                              ? "Finalized"
                              : "Draft"
                          }
                          color={
                            report.status === "DRAFT" ? "default" : "success"
                          }
                        />
                      </Stack>
                      <Typography
                        component="div"
                        variant="caption"
                        color="text.secondary"
                        sx={{ mt: 0.5 }}
                      >
                        Saved on{" "}
                        {report.updatedAt || report.createdAt
                          ? new Date(
                              report.updatedAt || report.createdAt,
                            ).toLocaleDateString("en-IN")
                          : "-"}
                      </Typography>
                    </Box>

                    <Stack
                      direction={{ xs: "column", sm: "row" }}
                      spacing={1}
                      sx={{ flexShrink: 0 }}
                    >
                      <Button
                        variant="contained"
                        startIcon={<EditOutlinedIcon />}
                        onClick={() => editReport(report)}
                        disabled={editingReportId !== null}
                        sx={{
                          alignSelf: { xs: "stretch", md: "center" },
                        }}
                      >
                        {editingReportId === String(getForecastId(report))
                          ? "Opening..."
                          : "Edit"}
                      </Button>
                      <Button
                        variant="outlined"
                        color="error"
                        startIcon={<DeleteOutlineIcon />}
                        onClick={() => setReportToDelete(report)}
                        sx={{
                          alignSelf: { xs: "stretch", md: "center" },
                        }}
                      >
                        Delete
                      </Button>
                    </Stack>
                  </Stack>
                </CardContent>
              </Card>
            ))
          )}
        </Stack>
      )}

      {selectedReport && (
        <Stack spacing={{ xs: 2, md: 3 }}>
          {loadingDetails ? (
            <Paper variant="outlined" sx={{ p: 5, textAlign: "center" }}>
              <Typography fontWeight={700}>Loading report...</Typography>
            </Paper>
          ) : (
            <>
              <Paper
                variant="outlined"
                sx={{ overflow: "hidden", borderRadius: 0 }}
              >
                <Box sx={{ px: 2, py: 1.5, bgcolor: "background.default" }}>
                  <Typography variant="h6" fontWeight={800}>
                    Cash Flow Analysis - {formatMonth(selectedReport)}
                  </Typography>
                </Box>
                <ForecastStatementTable
                  rows={reportRows}
                  fixedCostRows={fixedCostRows}
                  forecastMonths={reportMonths}
                  readOnly
                />
              </Paper>

              <Paper
                variant="outlined"
                sx={{ overflow: "hidden", borderRadius: 0 }}
              >
                <CashFlowSummaryTable
                  forecastMonths={reportMonths}
                  clientInflows={selectedSummary?.clientInflows || []}
                  discountsAndRefunds={
                    selectedSummary?.discountsAndRefunds || []
                  }
                  openingSurplusDeficit={
                    selectedSummary?.openingSurplusDeficit || 0
                  }
                  previousMonthSurplusDeficit={
                    selectedSummary?.previousMonthSurplusDeficit || []
                  }
                  surplusDeficit={selectedSummary?.surplusDeficit || []}
                  cashOutflowTotals={reportOutflowTotals}
                  readOnly
                />
              </Paper>
            </>
          )}
        </Stack>
      )}

      <ConfirmDialog
        open={Boolean(reportToDelete)}
        title="Delete this cash flow report?"
        message={
          reportToDelete
            ? `This permanently deletes the ${formatMonth(reportToDelete)} report. This action cannot be undone.`
            : ""
        }
        confirmLabel={deletingReport ? "Deleting..." : "Yes, delete"}
        confirmColor="error.main"
        onConfirm={confirmDeleteReport}
        onCancel={() => {
          if (!deletingReport) {
            setReportToDelete(null);
          }
        }}
      />
    </Container>
  );
}
