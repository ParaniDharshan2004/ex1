import { useEffect, useMemo, useState } from "react";
import { Box, Snackbar, Alert, Typography } from "@mui/material";
import ConfirmDialog from "../components/common-components/ConfirmDialog";
import ComponentsTable from "../components/pettycash-components/ComponentsTable";
import ComponentFilter from "../components/pettycash-components/ComponentFilters";
import { useDataContext } from "../context/DataContext";
import { Icons } from "../theme/icons";
import EntityFormDialog from "../components/common-components/EntityFormDialog";

export default function AddComponentsPage() {
  const {
    components,
    subComponents,

    getComponents,
    createComponent,
    updateComponent,
    deleteComponent,

    getSubComponents,
    createSubComponent,
    updateSubComponent,
    deleteSubComponent,

    financialCategories,
    financialSubCategories,
    getFinancialCategories,
    getFinancialSubCategoriesByCategory,
    clearFinancialSubCategories,
  } = useDataContext();
  const [filters, setFilters] = useState({
    search: "",
    department: "",
    status: "",
  });
  const [toast, setToast] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  // Load Data functions
  useEffect(() => {
    const loadData = async () => {
      try {
        await Promise.all([
          getComponents(),
          getSubComponents(),
          getFinancialCategories(),
        ]);
      } catch (error) {
        console.error("Load Component Master Data Error:", error);
      }
    };

    loadData();
  }, [getComponents, getSubComponents, getFinancialCategories]);

  const [formDialog, setFormDialog] = useState({
    open: false,
    mode: "create",
    initialValues: {},
  });
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleteType, setDeleteType] = useState(null);
  const [dialogType, setDialogType] = useState(null);

  // Form Fields
  const COMPONENT_FIELDS = useMemo(() => {
    const fields = [
      {
        name: "financialCategoryId",
        label: "Financial Category",
        type: "select",
        required: true,
        resetFields: ["financialSubCategoryId"],
        options: financialCategories.map((category) => ({
          label: category.categoryName,
          value: category._id,
        })),
      },
    ];

    if (financialSubCategories.length > 0) {
      fields.push({
        name: "financialSubCategoryId",
        label: "Financial Subcategory",
        type: "select",
        required: true,
        options: financialSubCategories.map((subCategory) => ({
          label: subCategory.subCategoryName,
          value: subCategory._id,
        })),
      });
    }

    fields.push(
      {
        name: "componentName",
        label: "Component Name",
        type: "text",
        required: true,
      },
      {
        name: "description",
        label: "Description",
        type: "text",
        required: false,
        multiline: true,
        rows: 2,
      },
      {
        name: "displayOrder",
        label: "Display Order",
        type: "number",
        required: true,
        min: 0,
        step: 1,
      },
      {
        name: "isPettyCash",
        label: "Petty Cash",
        type: "checkbox",
      },
      {
        name: "isCashFlowAnalysis",
        label: "Cash Flow Analysis",
        type: "checkbox",
      },
      {
        name: "isOperationalExpense",
        label: "Operational Expense",
        type: "checkbox",
      },
      {
        name: "isFullyLoadedCost",
        label: "Fully Loaded Cost",
        type: "checkbox",
      },
      {
        name: "isActive",
        label: "Status",
        type: "select",
        required: true,
        options: [
          {
            label: "Active",
            value: true,
          },
          {
            label: "Inactive",
            value: false,
          },
        ],
      },
    );

    return fields;
  }, [financialCategories, financialSubCategories]);

  const SUB_COMPONENT_FIELDS = [
    {
      name: "componentId",
      label: "Head Component",
      type: "select",
      required: true,
      options: components.map((item) => ({
        label: item.componentName,
        value: item._id,
      })),
    },
    {
      name: "subComponentName",
      label: "Sub Component Name",
      type: "text",
      required: true,
    },
    {
      name: "description",
      label: "Description",
      type: "text",
    },
    {
      name: "requiresBill",
      label: "Requires Bill",
      type: "checkbox",
    },
    {
      name: "displayOrder",
      label: "Display Order",
      type: "number",
    },
    {
      name: "isActive",
      label: "Status",
      type: "select",
      options: [
        {
          label: "Active",
          value: true,
        },
        {
          label: "Inactive",
          value: false,
        },
      ],
    },
  ];

  // Filter Logic
  const filteredRows = useMemo(() => {
    return components.filter((item) => {
      const matchesSearch =
        !filters.search ||
        item.componentCode
          .toLowerCase()
          .includes(filters.search.toLowerCase()) ||
        item.componentName.toLowerCase().includes(filters.search.toLowerCase());

      const matchesStatus =
        !filters.status ||
        (filters.status === "Active" && item.isActive) ||
        (filters.status === "Inactive" && !item.isActive);

      return matchesSearch && matchesStatus;
    });
  }, [components, filters]);

  const showToast = (message, severity = "success") =>
    setToast({ open: true, message, severity });

  const openCreateComponentDialog = () => {
    clearFinancialSubCategories();

    setDialogType("component");

    setFormDialog({
      open: true,
      mode: "create",
      initialValues: {
        financialCategoryId: "",
        financialSubCategoryId: "",
        componentName: "",
        description: "",
        isPettyCash: false,
        isCashFlowAnalysis: false,
        isOperationalExpense: false,
        isFullyLoadedCost: false,
        displayOrder: 0,
        isActive: true,
      },
    });
  };

  const openCreateSubComponentDialog = () => {
    setDialogType("subcomponent");
    setFormDialog({
      open: true,
      mode: "create",
      initialValues: {},
    });
  };

  const openEditDialog = async (row) => {
    const financialCategoryId =
      row.financialCategoryId?._id || row.financialCategoryId || "";

    const financialSubCategoryId =
      row.financialSubCategoryId?._id || row.financialSubCategoryId || "";

    clearFinancialSubCategories();

    try {
      if (financialCategoryId) {
        await getFinancialSubCategoriesByCategory(financialCategoryId);
      }

      setDialogType("component");

      setFormDialog({
        open: true,
        mode: "edit",
        initialValues: {
          _id: row._id,
          financialCategoryId,
          financialSubCategoryId,
          componentName: row.componentName || "",
          description: row.description || "",
          isPettyCash: Boolean(row.isPettyCash),
          isCashFlowAnalysis: Boolean(row.isCashFlowAnalysis),
          isOperationalExpense: Boolean(row.isOperationalExpense),
          isFullyLoadedCost: Boolean(row.isFullyLoadedCost),
          displayOrder: Number.isFinite(Number(row.displayOrder))
            ? Number(row.displayOrder)
            : 0,
          isActive: row.isActive !== false,
        },
      });
    } catch (error) {
      console.error("Open Edit Component Error:", error);

      showToast(
        error.response?.data?.message || "Unable to load Component details.",
        "error",
      );
    }
  };

  const handleComponentDeleteRequest = (row) => {
    setDeleteType("component");
    setDeleteTarget(row);
  };

  const closeFormDialog = () => {
    setDialogType(null);

    setFormDialog({
      open: false,
      mode: "create",
      initialValues: {},
    });
  };

  const openEditSubComponentDialog = (row) => {
    setDialogType("subcomponent");
    setFormDialog({
      open: true,
      mode: "edit",
      initialValues: {
        ...row,
        componentId: row.componentId?._id || row.componentId,
      },
    });
  };

  const handleSubComponentDeleteRequest = (row) => {
    setDeleteType("subcomponent");
    setDeleteTarget(row);
  };

  // Create & Update Component function
  const handleSaveComponent = async (values) => {
    try {
      const hasSubCategories = financialSubCategories.length > 0;

      if (hasSubCategories && !values.financialSubCategoryId) {
        showToast("Please select a Financial Subcategory.", "warning");
        return;
      }

      const payload = {
        financialCategoryId: values.financialCategoryId || null,

        financialSubCategoryId: hasSubCategories
          ? values.financialSubCategoryId || null
          : null,

        componentName: values.componentName?.trim(),

        description: values.description?.trim() || null,

        isPettyCash: Boolean(values.isPettyCash),

        isCashFlowAnalysis: Boolean(values.isCashFlowAnalysis),

        isOperationalExpense: Boolean(values.isOperationalExpense),

        isFullyLoadedCost: Boolean(values.isFullyLoadedCost),

        displayOrder: Number(values.displayOrder),

        isActive: values.isActive !== false,
      };

      if (values._id) {
        await updateComponent(values._id, payload);

        showToast("Component updated successfully");
      } else {
        await createComponent(payload);

        showToast("Component created successfully");
      }

      await getComponents();
      closeFormDialog();
    } catch (error) {
      console.error("Save Component Error:", error);

      showToast(
        error.response?.data?.message || "Failed to save Component",
        "error",
      );
    }
  };

  // Create & Update Sub Components function
  const handleSaveSubComponent = async (values) => {
    try {
      if (values._id) {
        await updateSubComponent(values._id, values);

        showToast("Sub Component updated successfully");
      } else {
        await createSubComponent(values);

        showToast("Sub Component created successfully");
      }

      await getSubComponents();
      closeFormDialog();
    } catch (error) {
      showToast(
        error.response?.data?.message || "Failed to save sub component",
        "error",
      );
    }
  };

  // Delete both component & subcomponents based on delete type
  const handleDelete = async () => {
    try {
      if (deleteType === "component") {
        await deleteComponent(deleteTarget._id);

        await getComponents();

        showToast("Component deleted successfully");
      }

      if (deleteType === "subcomponent") {
        await deleteSubComponent(deleteTarget._id);

        await getSubComponents();

        showToast("Sub Component deleted successfully");
      }
    } catch (error) {
      showToast(error.response?.data?.message || "Delete failed", "error");
    } finally {
      setDeleteTarget(null);
      setDeleteType(null);
    }
  };

  const handleComponentFieldChange = async (fieldName, value) => {
    if (fieldName !== "financialCategoryId") {
      return;
    }

    clearFinancialSubCategories();

    if (!value) {
      return;
    }

    try {
      await getFinancialSubCategoriesByCategory(value);
    } catch (error) {
      console.error("Load Financial Subcategories Error:", error);

      showToast(
        error.response?.data?.message ||
          "Unable to load Financial Subcategories.",
        "error",
      );
    }
  };

  return (
    <Box>
      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box sx={{ p: { xs: 2, sm: 3 }, flex: 1 }}>
          <Box
            sx={{
              mt: 3,
              mb: 1,
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <Icons.FilterListIcon
              fontSize="small"
              sx={{ color: "textPrimary" }}
            />
            <Typography variant="subtitle2" sx={{ color: "textPrimary" }}>
              Filter Components
            </Typography>
          </Box>
          <ComponentFilter
            filters={filters}
            setFilters={setFilters}
            onAddComponent={openCreateComponentDialog}
            onAddSubComponent={openCreateSubComponentDialog}
          />
          <Box sx={{ display: "flex", overflowX: "auto" }}>
            <ComponentsTable
              rows={filteredRows}
              subComponents={subComponents}
              onEdit={openEditDialog}
              onDeleteRequest={handleComponentDeleteRequest}
              onEditSubComponent={openEditSubComponentDialog}
              onDeleteSubComponent={handleSubComponentDeleteRequest}
            />
          </Box>
        </Box>
      </Box>

      <EntityFormDialog
        open={dialogType === "component"}
        mode={formDialog.mode}
        title={formDialog.mode === "edit" ? "Edit Component" : "Add Component"}
        saveConfirmTitle={
          formDialog.mode === "edit"
            ? "Update this component?"
            : "Save this component?"
        }
        saveConfirmMessage={
          formDialog.mode === "edit"
            ? "You're about to update this component. Continue?"
            : "You're about to save this component. Continue?"
        }
        fields={COMPONENT_FIELDS}
        initialValues={formDialog.initialValues}
        onFieldChange={handleComponentFieldChange}
        onClose={closeFormDialog}
        onSave={handleSaveComponent}
      />

      <EntityFormDialog
        open={dialogType === "subcomponent"}
        mode={formDialog.mode}
        title={
          formDialog.mode === "edit" ? "Edit Subcomponent" : "Add Subcomponent"
        }
        saveConfirmTitle={
          formDialog.mode === "edit"
            ? "Update this subcomponent?"
            : "Save this subcomponent?"
        }
        saveConfirmMessage={
          formDialog.mode === "edit"
            ? "You're about to update this subcomponent. Continue?"
            : "You're about to save this subcomponent. Continue?"
        }
        fields={SUB_COMPONENT_FIELDS}
        initialValues={formDialog.initialValues}
        onClose={closeFormDialog}
        onSave={handleSaveSubComponent}
      />

      <ConfirmDialog
        open={deleteTarget !== null}
        title={
          deleteType === "component"
            ? "Delete this component?"
            : "Delete this sub component?"
        }
        message={
          deleteTarget
            ? deleteType === "component"
              ? `This permanently removes "${deleteTarget.componentName}". This can't be undone.`
              : `This permanently removes "${
                  deleteTarget.subComponentName || deleteTarget.subcomponentName
                }". This can't be undone.`
            : ""
        }
        confirmLabel="Yes, delete"
        confirmColor="primary.error"
        onConfirm={handleDelete}
        onCancel={() => {
          setDeleteTarget(null);
          setDeleteType(null);
        }}
      />

      <Snackbar
        open={toast.open}
        autoHideDuration={3000}
        onClose={() => setToast((t) => ({ ...t, open: false }))}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          severity={toast.severity}
          variant="filled"
          onClose={() => setToast((t) => ({ ...t, open: false }))}
          sx={{
            alignItems: "center",
            "& .MuiAlert-icon": {
              alignItems: "center",
              display: "flex",
            },
            "& .MuiAlert-message": {
              display: "flex",
              alignItems: "center",
            },
          }}
        >
          {toast.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
