import { useEffect, useMemo, useState } from "react";
import { Box } from "@mui/material";
import { useDataContext } from "../context/DataContext";
import CashAccountsFilters from "../components/account-components/CashAccountFilter";
import CashAccountsTable from "../components/account-components/CashAccountTable";
import EntityFormDialog from "../components/common-components/EntityFormDialog";
import ConfirmDialog from "../components/common-components/ConfirmDialog";

export default function CashAccountsPage() {
  const {
    cashAccounts,
    getCashAccounts,
    createCashAccount,
    updateCashAccount,
    deleteCashAccount,
  } = useDataContext();
  const [filters, setFilters] = useState({
    search: "",
  });
  const [formDialog, setFormDialog] = useState({
    open: false,
    mode: "create",
    initialValues: {},
  });

  const [deleteTarget, setDeleteTarget] = useState(null);

  const CASH_ACCOUNT_FIELDS = [
    {
      name: "accountName",
      label: "Account Name",
      type: "text",
      required: true,
    },
    {
      name: "accountHolderName",
      label: "Account Holder Name",
      type: "text",
      required: true,
    },
    {
      name: "bankName",
      label: "Bank Name",
      type: "text",
      required: true,
    },
    {
      name: "maskedAccountNumber",
      label: "Last 4 Digits",
      type: "text",
      required: true,
    },
    {
      name: "accountType",
      label: "Account Type",
      type: "select",
      required: true,
      options: [
        {
          label: "Current",
          value: "Current",
        },
        {
          label: "Savings",
          value: "Savings",
        },
      ],
    },
    {
      name: "isActive",
      label: "Status",
      type: "select",
      options: [
        {
          label: "Active",
          value: true,
        },
        {
          label: "Inactive",
          value: false,
        },
      ],
    },
  ];

  const openCreateDialog = () => {
    setFormDialog({
      open: true,
      mode: "create",
      initialValues: {},
    });
  };

  const openEditDialog = (row) => {
    setFormDialog({
      open: true,
      mode: "edit",
      initialValues: {
        _id: row._id,
        accountName: row.accountName,
        accountHolderName: row.accountHolderName,
        bankName: row.bankName,
        maskedAccountNumber: row.maskedAccountNumber?.replace("XXXXXX", ""),
        accountType: row.accountType,
        isActive: row.isActive,
      },
    });
  };

  const closeDialog = () => {
    setFormDialog((prev) => ({
      ...prev,
      open: false,
    }));
  };

  const handleSaveCashAccount = async (values) => {
    try {
      const payload = {
        accountName: values.accountName,
        accountHolderName: values.accountHolderName,
        bankName: values.bankName,
        maskedAccountNumber: values.maskedAccountNumber,
        accountType: values.accountType,
        isActive: values.isActive,
      };

      if (values._id) {
        await updateCashAccount(values._id, payload);
      } else {
        await createCashAccount(payload);
      }

      await getCashAccounts();

      closeDialog();
    } catch (error) {
      console.error(error);
    }
  };

  const confirmDelete = async () => {
    try {
      await deleteCashAccount(deleteTarget._id);

      await getCashAccounts();

      setDeleteTarget(null);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getCashAccounts();
  }, [getCashAccounts]);

  const filteredAccounts = useMemo(() => {
    return cashAccounts.filter(
      (account) =>
        account.accountName
          ?.toLowerCase()
          .includes(filters.search.toLowerCase()) ||
        account.accountCode
          ?.toLowerCase()
          .includes(filters.search.toLowerCase()) ||
        account.bankName?.toLowerCase().includes(filters.search.toLowerCase()),
    );
  }, [cashAccounts, filters]);

  return (
    <Box sx={{ p: 3 }}>
      <CashAccountsFilters
        filters={filters}
        setFilters={setFilters}
        onAdd={openCreateDialog}
      />

      <CashAccountsTable
        rows={filteredAccounts}
        onEdit={openEditDialog}
        onDeleteRequest={setDeleteTarget}
      />

      <EntityFormDialog
        open={formDialog.open}
        mode={formDialog.mode}
        title={
          formDialog.mode === "edit" ? "Edit Cash Account" : "Add Cash Account"
        }
        fields={CASH_ACCOUNT_FIELDS}
        initialValues={formDialog.initialValues}
        onClose={closeDialog}
        onSave={handleSaveCashAccount}
      />

      <ConfirmDialog
        open={deleteTarget !== null}
        title="Delete Cash Account?"
        message={deleteTarget ? `Delete ${deleteTarget.accountName}?` : ""}
        confirmLabel="Delete"
        confirmColor="primary.error"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </Box>
  );
}
