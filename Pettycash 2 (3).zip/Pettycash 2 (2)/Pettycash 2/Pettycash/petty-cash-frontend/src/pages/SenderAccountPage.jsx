import { useEffect, useMemo, useState } from "react";
import { Box } from "@mui/material";

import SenderAccountsTable from "../components/account-components/SenderAccountsTable";
import SenderAccountsFilters from "../components/account-components/SenderAccountsFilter";
import { useDataContext } from "../context/DataContext";
import EntityFormDialog from "../components/common-components/EntityFormDialog";
import ConfirmDialog from "../components/common-components/ConfirmDialog";

export default function SenderAccountsPage() {
  const {
    senderAccounts,
    getSenderAccounts,
    createSenderAccount,
    updateSenderAccount,
    deleteSenderAccount,
  } = useDataContext();
  const [filters, setFilters] = useState({
    search: "",
  });
  const [formDialog, setFormDialog] = useState({
    open: false,
    mode: "create",
    initialValues: {},
  });

  const [deleteTarget, setDeleteTarget] = useState(null);

  const SENDER_ACCOUNT_FIELDS = [
    {
      name: "accountName",
      label: "Account Name",
      type: "text",
      required: true,
    },
    {
      name: "accountHolderName",
      label: "Account Holder Name",
      type: "text",
      required: true,
    },
    {
      name: "bankName",
      label: "Bank Name",
      type: "text",
      required: true,
    },
    {
      name: "maskedAccountNumber",
      label: "Last 4 Digits",
      type: "text",
      required: true,
    },
    {
      name: "accountType",
      label: "Account Type",
      type: "select",
      required: true,
      options: [
        {
          label: "Current",
          value: "Current",
        },
        {
          label: "Savings",
          value: "Savings",
        },
      ],
    },
    {
      name: "isActive",
      label: "Status",
      type: "select",
      options: [
        {
          label: "Active",
          value: true,
        },
        {
          label: "Inactive",
          value: false,
        },
      ],
    },
  ];

  const openCreateDialog = () => {
    setFormDialog({
      open: true,
      mode: "create",
      initialValues: {},
    });
  };

  const openEditDialog = (row) => {
    setFormDialog({
      open: true,
      mode: "edit",
      initialValues: {
        _id: row._id,
        accountName: row.accountName,
        accountHolderName: row.accountHolderName,
        bankName: row.bankName,
        maskedAccountNumber: row.maskedAccountNumber,
        accountType: row.accountType,
        isActive: row.isActive,
      },
    });
  };

  const closeDialog = () => {
    setFormDialog((prev) => ({
      ...prev,
      open: false,
    }));
  };

  const handleSaveSenderAccount = async (values) => {
    try {
      const payload = {
        accountName: values.accountName,
        accountHolderName: values.accountHolderName,
        bankName: values.bankName,
        maskedAccountNumber: values.maskedAccountNumber,
        accountType: values.accountType,
        isActive: values.isActive,
      };

      if (values._id) {
        await updateSenderAccount(values._id, payload);
      } else {
        await createSenderAccount(payload);
      }

      await getSenderAccounts();

      closeDialog();
    } catch (error) {
      console.error(error);
    }
  };

  const confirmDelete = async () => {
    try {
      await deleteSenderAccount(deleteTarget._id);

      await getSenderAccounts();

      setDeleteTarget(null);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getSenderAccounts();
  }, [getSenderAccounts]);

  const filteredAccounts = useMemo(() => {
    return senderAccounts.filter(
      (account) =>
        account.accountName
          ?.toLowerCase()
          .includes(filters.search.toLowerCase()) ||
        account.accountCode
          ?.toLowerCase()
          .includes(filters.search.toLowerCase()) ||
        account.bankName?.toLowerCase().includes(filters.search.toLowerCase()),
    );
  }, [senderAccounts, filters]);

  return (
    <Box sx={{ p: 3 }}>
      <SenderAccountsFilters
        filters={filters}
        setFilters={setFilters}
        onAdd={openCreateDialog}
      />
      <SenderAccountsTable
        rows={filteredAccounts}
        onEdit={openEditDialog}
        onDeleteRequest={setDeleteTarget}
      />
      <EntityFormDialog
        open={formDialog.open}
        mode={formDialog.mode}
        title={
          formDialog.mode === "edit"
            ? "Edit Sender Account"
            : "Add Sender Account"
        }
        fields={SENDER_ACCOUNT_FIELDS}
        initialValues={formDialog.initialValues}
        onClose={closeDialog}
        onSave={handleSaveSenderAccount}
      />
      <ConfirmDialog
        open={deleteTarget !== null}
        title="Delete Sender Account?"
        message={deleteTarget ? `Delete ${deleteTarget.accountName}?` : ""}
        confirmLabel="Delete"
        confirmColor="primary.error"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </Box>
  );
}
