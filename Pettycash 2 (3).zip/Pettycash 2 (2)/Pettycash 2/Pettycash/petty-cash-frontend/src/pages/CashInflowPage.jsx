import { useEffect, useMemo, useState } from "react";
import { Alert, Box, Snackbar } from "@mui/material";

import PageHeader from "../components/common-components/PageHeader";
import CashInflowFilters from "../components/cashinflow-components/CashInflowFilters";
import CashInflowTable from "../components/cashinflow-components/CashInflowTable";
import EntityFormDialog from "../components/common-components/EntityFormDialog";

import { useDataContext } from "../context/DataContext";
import ConfirmDialog from "../components/common-components/ConfirmDialog";

const CashInflowPage = () => {
  const {
    cashInflow,
    getCashInflows,
    createCashInflow,
    updateCashInflow,
    deleteCashInflow,
  } = useDataContext();
  const today = new Date();
  const [filters, setFilters] = useState({
    search: "",
    date: "",
    month: today.getMonth().toString(),
    year: today.getFullYear().toString(),
    componentId: "",
    startDate: "",
    endDate: "",
  });

  const [formDialog, setFormDialog] = useState({
    open: false,
    mode: "create",
    initialValues: {},
  });
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [toast, setToast] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  useEffect(() => {
    getCashInflows();
  }, [getCashInflows]);

  const CASH_INFLOW_FIELDS = [
    {
      name: "inflowDate",
      label: "Inflow Date",
      type: "date",
      required: true,
    },
    {
      name: "amount",
      label: "Amount",
      type: "number",
      prefix: "₹",
      required: true,
    },
    {
      name: "remarks",
      label: "Remarks",
      type: "text",
      required: true,
    },
  ];

  const showToast = (message, severity = "success") =>
    setToast({ open: true, message, severity });

  const openCreateDialog = () => {
    setFormDialog({
      open: true,
      mode: "create",
      initialValues: {},
    });
  };

  const openEditDialog = (row) => {
    setFormDialog({
      open: true,
      mode: "edit",
      initialValues: {
        _id: row._id,
        inflowDate: row.inflowDate?.split("T")[0],
        amount: row.amount,
        remarks: row.remarks,
      },
    });
  };

  const closeFormDialog = () => {
    console.log("Closing Dialog");

    setFormDialog((prev) => ({
      ...prev,
      open: false,
    }));
  };

  const handleSaveCashInflow = async (values) => {
    try {
      let response;

      if (values._id) {
        response = await updateCashInflow(values._id, values);
      } else {
        response = await createCashInflow(values);
      }

      await getCashInflows();

      showToast(
        response?.data?.message || "Cash inflow saved successfully",
        "success",
      );

      closeFormDialog();
    } catch (error) {
      showToast(
        error.response?.data?.message || "Something went wrong",
        "error",
      );

      console.error(error);
    }
  };

  const confirmDelete = async () => {
    try {
      const response = await deleteCashInflow(deleteTarget._id);

      await getCashInflows();

      showToast(
        response?.data?.message || "Cash inflow deleted successfully",
        "success",
      );

      setDeleteTarget(null);
    } catch (error) {
      showToast(
        error.response?.data?.message || "Failed to delete cash inflow",
        "error",
      );

      console.error(error);
    }
  };

  const filteredCashInflows = useMemo(() => {
    return cashInflow.filter((row) => {
      const rowDate = new Date(row.inflowDate);

      const matchesSearch =
        !filters.search ||
        row.remarks?.toLowerCase().includes(filters.search.toLowerCase());

      const matchesDate =
        !filters.date || row.inflowDate?.slice(0, 10) === filters.date;

      const matchesMonth =
        !filters.month || rowDate.getMonth() === Number(filters.month);

      const matchesYear =
        !filters.year || rowDate.getFullYear().toString() === filters.year;

      return matchesSearch && matchesDate && matchesMonth && matchesYear;
    });
  }, [cashInflow, filters]);

  return (
    <Box>
      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box sx={{ p: { xs: 2, sm: 3 }, flex: 1 }}>
          <PageHeader
            title="Cash Inflow"
            buttonText="Add Cash"
            onButtonClick={openCreateDialog}
          />

          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 2,
              overflowX: "auto",
            }}
          >
            <CashInflowFilters
              filters={filters}
              setFilters={setFilters}
              onAdd={openCreateDialog}
            />

            <CashInflowTable
              rows={filteredCashInflows}
              onEdit={openEditDialog}
              onDeleteRequest={setDeleteTarget}
            />
          </Box>

          <EntityFormDialog
            open={formDialog.open}
            mode={formDialog.mode}
            title={
              formDialog.mode === "edit"
                ? "Edit Cash Inflow"
                : "Add Cash Inflow"
            }
            saveConfirmTitle={
              formDialog.mode === "edit"
                ? "Update this cashInflow entry?"
                : "Save this cashInflow entry?"
            }
            saveConfirmMessage={
              formDialog.mode === "edit"
                ? "You're about to update this cashinflow entry. Continue?"
                : "You're about to save this cashinflow entry. Continue?"
            }
            fields={CASH_INFLOW_FIELDS}
            initialValues={formDialog.initialValues}
            onClose={closeFormDialog}
            onSave={handleSaveCashInflow}
          />

          <ConfirmDialog
            open={deleteTarget !== null}
            title="Delete this cashinflow entry?"
            message={
              deleteTarget
                ? `This permanently removes the cash inflow entry. This can't be undone.`
                : ""
            }
            confirmLabel="Yes, delete"
            confirmColor="primary.error"
            onConfirm={confirmDelete}
            onCancel={() => setDeleteTarget(null)}
          />

          <Snackbar
            open={toast.open}
            autoHideDuration={3000}
            onClose={() => setToast((t) => ({ ...t, open: false }))}
            anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
          >
            <Alert
              severity={toast.severity}
              variant="filled"
              onClose={() => setToast((t) => ({ ...t, open: false }))}
              sx={{
                alignItems: "center",
                "& .MuiAlert-icon": {
                  alignItems: "center",
                  display: "flex",
                },
                "& .MuiAlert-message": {
                  display: "flex",
                  alignItems: "center",
                },
              }}
            >
              {toast.message}
            </Alert>
          </Snackbar>
        </Box>
      </Box>
    </Box>
  );
};

export default CashInflowPage;
