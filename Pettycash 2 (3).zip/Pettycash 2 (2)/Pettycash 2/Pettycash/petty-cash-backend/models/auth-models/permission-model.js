import mongoose from "mongoose";

const permissionSchema = new mongoose.Schema(
  {
    permissionName: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    read: {
      type: Boolean,
      default: false,
    },

    write: {
      type: Boolean,
      default: false,
    },

    delete: {
      type: Boolean,
      default: false,
    },

    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  },
);

export default mongoose.model(
  "Permission",
  permissionSchema,
);