import mongoose from "mongoose";

const auditLogSchema = new mongoose.Schema(
  {
    eventAt: {
      type: Date,
      required: true,
      default: Date.now,
      immutable: true,
      index: true,
    },

    actorUserId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
      immutable: true,
      index: true,
    },

    actorRoleId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Role",
      default: null,
      immutable: true,
      index: true,
    },

    actorRole: {
      type: String,
      trim: true,
      maxlength: 100,
      default: null,
      immutable: true,
      index: true,
    },

    actorType: {
      type: String,
      required: true,
      enum: ["USER", "SYSTEM"],
      default: "USER",
      immutable: true,
    },

    action: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      enum: [
        "CREATE",
        "UPDATE",
        "ENABLE",
        "DISABLE",
        "POST",
        "VOID",
        "ASSIGN",
        "REMOVE",
        "LOGIN",
        "LOGOUT",
        "PASSWORD_CHANGE",
        "RECONCILE",
        "EXPORT",
      ],
      immutable: true,
      index: true,
    },

    entityType: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      immutable: true,
      index: true,
    },

    entityId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      immutable: true,
      index: true,
    },

    changedFields: {
      type: [String],
      default: [],
      immutable: true,
    },

    beforeData: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
      immutable: true,
    },

    afterData: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
      immutable: true,
    },

    reason: {
      type: String,
      trim: true,
      maxlength: 500,
      default: null,
      immutable: true,
    },

    correlationId: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
      immutable: true,
      index: true,
    },

    idempotencyKey: {
      type: String,
      trim: true,
      maxlength: 150,
      default: null,
      immutable: true,
      index: true,
    },

    result: {
      type: String,
      required: true,
      enum: ["SUCCESS", "FAILURE"],
      default: "SUCCESS",
      immutable: true,
      index: true,
    },

    errorCode: {
      type: String,
      trim: true,
      maxlength: 100,
      default: null,
      immutable: true,
    },

    ipAddress: {
      type: String,
      trim: true,
      maxlength: 64,
      default: null,
      immutable: true,
    },

    userAgent: {
      type: String,
      trim: true,
      maxlength: 500,
      default: null,
      immutable: true,
    },

    retentionUntil: {
      type: Date,
      default: null,
      immutable: true,
      index: true,
    },
  },
  {
    collection: "audit_logs",
    timestamps: false,
    versionKey: false,
    strict: true,
  },
);

// Retrieves the complete history of one business record efficiently.
auditLogSchema.index({ entityType: 1, entityId: 1, eventAt: -1 });

// Retrieves activities performed by one User efficiently.
auditLogSchema.index({ actorUserId: 1, eventAt: -1 });

// Supports module/action/date filtering on the Audit Log screen.
auditLogSchema.index({ entityType: 1, action: 1, eventAt: -1 });

// Supports filtering successful and failed activities by date.
auditLogSchema.index({ result: 1, eventAt: -1 });

/**
 * Block normal document updates and deletes.
 * Audit logs are append-only application records.
 */
const blockMutation = function blockMutation(next) {
  next(
    new Error(
      "Audit Log records are append-only and cannot be modified or deleted.",
    ),
  );
};

auditLogSchema.pre("updateOne", blockMutation);
auditLogSchema.pre("updateMany", blockMutation);
auditLogSchema.pre("findOneAndUpdate", blockMutation);
auditLogSchema.pre("deleteOne", blockMutation);
auditLogSchema.pre("deleteMany", blockMutation);
auditLogSchema.pre("findOneAndDelete", blockMutation);

const AuditLog =
  mongoose.models.AuditLog || mongoose.model("AuditLog", auditLogSchema);

export default AuditLog;
