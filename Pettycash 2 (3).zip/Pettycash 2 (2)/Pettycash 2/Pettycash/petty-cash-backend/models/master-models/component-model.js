import mongoose from "mongoose";

const componentSchema = new mongoose.Schema(
  {
    componentCode: {
      type: String,
      required: [true, "Component code is required"],
      trim: true,
      uppercase: true,
      maxlength: [20, "Component code cannot exceed 20 characters"],
      match: [
        /^CMP-\d{3}$/,
        "Component code must follow the format CMP-001",
      ],
      immutable: true,
    },

    componentName: {
      type: String,
      required: [true, "Component name is required"],
      trim: true,
      minlength: [
        2,
        "Component name must contain at least 2 characters",
      ],
      maxlength: [
        120,
        "Component name cannot exceed 120 characters",
      ],
    },

    description: {
      type: String,
      trim: true,
      maxlength: [
        500,
        "Description cannot exceed 500 characters",
      ],
      default: null,
    },

    isPettyCash: {
      type: Boolean,
      required: true,
      default: false,
    },

    isCashFlowAnalysis: {
      type: Boolean,
      required: true,
      default: false,
    },

    isOperationalExpense: {
      type: Boolean,
      required: true,
      default: false,
    },

    isFullyLoadedCost: {
      type: Boolean,
      required: true,
      default: false,
    },

    financialCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FinancialCategory",
      default: null,
    },

    financialSubCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FinancialSubCategory",
      default: null,
    },

    requiresBill: {
      type: Boolean,
      required: true,
      default: false,
    },

    displayOrder: {
      type: Number,
      required: true,
      default: 1,
      min: [1, "Display order must be at least 1"],
      validate: {
        validator: Number.isInteger,
        message: "Display order must be an integer",
      },
    },

    isActive: {
      type: Boolean,
      required: true,
      default: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
      immutable: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: "version",
    optimisticConcurrency: true,
    collection: "components",
  },
);

/*
 * Unique business code.
 */
componentSchema.index(
  { componentCode: 1 },
  {
    unique: true,
    name: "uq_components_componentCode",
  },
);

/*
 * Prevents case-insensitive duplicate Component names.
 */
componentSchema.index(
  { componentName: 1 },
  {
    unique: true,
    name: "uq_components_componentName",
    collation: {
      locale: "en",
      strength: 2,
    },
  },
);

/*
 * Report-specific retrieval indexes.
 */
componentSchema.index(
  {
    isPettyCash: 1,
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: "idx_components_pettyCash_active_order",
  },
);

componentSchema.index(
  {
    isCashFlowAnalysis: 1,
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: "idx_components_cashFlowAnalysis_active_order",
  },
);

componentSchema.index(
  {
    isOperationalExpense: 1,
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: "idx_components_operationalExpense_active_order",
  },
);

/*
 * Financial Category lookup index.
 */
componentSchema.index(
  {
    financialCategoryId: 1,
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: "idx_components_financialCategory_active_order",
  },
);

/*
 * Financial Subcategory lookup index.
 */
componentSchema.index(
  {
    financialSubCategoryId: 1,
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: "idx_components_financialSubCategory_active_order",
  },
);

/*
 * Combined Category and Subcategory lookup index.
 */
componentSchema.index(
  {
    financialCategoryId: 1,
    financialSubCategoryId: 1,
    isCashFlowAnalysis: 1,
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: "idx_components_category_subCategory_cashFlow_order",
  },
);

componentSchema.index(
  { createdBy: 1 },
  {
    name: "idx_components_createdBy",
  },
);

componentSchema.index(
  { updatedBy: 1 },
  {
    name: "idx_components_updatedBy",
  },
);

const Component = mongoose.model(
  "Component",
  componentSchema,
);

export default Component;