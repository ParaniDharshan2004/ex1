import mongoose from 'mongoose';

const companyMasterSchema = new mongoose.Schema(
  {
    companyName: {
      type: String,
      required: true,
      trim: true,
    },

    gstNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    panNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    tanNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    companyAddress: {
      type: String,
      required: true,
      trim: true,
    },

    city: {
      type: String,
      required: true,
      trim: true,
    },

    state: {
      type: String,
      required: true,
      trim: true,
    },

    pinCode: {
      type: String,
      required: true,
      trim: true,
    },

    country: {
      type: String,
      required: true,
      trim: true,
      default: 'India',
    },

    beneficiaryName: {
      type: String,
      trim: true,
      default: '',
    },

    beneficiaryAccountNo: {
      type: String,
      trim: true,
      default: '',
    },

    bankName: {
      type: String,
      trim: true,
      default: '',
    },

    branch: {
      type: String,
      trim: true,
      default: '',
    },

    ifscCode: {
      type: String,
      trim: true,
      uppercase: true,
      default: '',
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  {
    timestamps: true,
    collection: 'company_master',
  },
);

companyMasterSchema.pre('validate', function normalize() {
  this.companyName = String(this.companyName || '').trim();
  this.gstNumber = String(this.gstNumber || '')
    .trim()
    .toUpperCase();
  this.panNumber = String(this.panNumber || '')
    .trim()
    .toUpperCase();
  this.tanNumber = String(this.tanNumber || '')
    .trim()
    .toUpperCase();
  this.city = String(this.city || '').trim();
  this.state = String(this.state || '').trim();
  this.country = String(this.country || '').trim();
  this.beneficiaryName = String(this.beneficiaryName || '').trim();
  this.beneficiaryAccountNo = String(
    this.beneficiaryAccountNo || '',
  ).trim();
  this.bankName = String(this.bankName || '').trim();
  this.branch = String(this.branch || '').trim();
  this.ifscCode = String(this.ifscCode || '')
    .trim()
    .toUpperCase();
});

export default mongoose.model('CompanyMaster', companyMasterSchema);
