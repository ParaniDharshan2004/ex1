import mongoose from 'mongoose';

const fixedAssetMasterSchema = new mongoose.Schema(
  {
    assetName: {
      type: String,
      required: true,
      trim: true,
    },

    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'FixedAssetCategoryMaster',
      required: true,
    },

    description: {
      type: String,
      default: '',
      trim: true,
    },

    aliases: [
      {
        type: String,
        trim: true,
      },
    ],

    isActive: {
      type: Boolean,
      default: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
  },
);

fixedAssetMasterSchema.index({ assetName: 1, categoryId: 1 }, { unique: true });

export default mongoose.model('FixedAssetMaster', fixedAssetMasterSchema);
