import mongoose from 'mongoose';

const currencyMasterSchema = new mongoose.Schema(
  {
    currencyCode: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      unique: true,
    },

    currencyName: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },

    currencySymbol: {
      type: String,
      required: true,
      trim: true,
    },

    exchangeRate: {
      type: Number,
      required: true,
      default: 1,
      min: 0,
    },

    displayOrder: {
      type: Number,
      default: 1,
      min: 1,
    },

    isActive: {
      type: Boolean,
      default: true,
      required: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
      immutable: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: 'version',
    optimisticConcurrency: true,
    collection: 'currency_masters',
  },
);

currencyMasterSchema.index(
  { currencyCode: 1 },
  {
    unique: true,
    name: 'uq_currency_currencyCode',
  },
);

currencyMasterSchema.index(
  { currencyName: 1 },
  {
    unique: true,
    name: 'uq_currency_currencyName',
    collation: {
      locale: 'en',
      strength: 2,
    },
  },
);

currencyMasterSchema.index(
  {
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: 'idx_currency_active_order',
  },
);

const CurrencyMaster = mongoose.model('CurrencyMaster', currencyMasterSchema);

export default CurrencyMaster;
