import mongoose from "mongoose";

const subComponentSchema = new mongoose.Schema(
  {
    componentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Component",
      required: [true, "Component reference is required"],
      immutable: true,
    },

    subComponentCode: {
      type: String,
      required: [true, "Subcomponent code is required"],
      trim: true,
      uppercase: true,
      immutable: true,
    },

    subComponentName: {
      type: String,
      required: [true, "Subcomponent name is required"],
      trim: true,
    },

    isPettyCash: {
      type: Boolean,
      required: true,
      default: false,
    },

    isCashFlowAnalysis: {
      type: Boolean,
      required: true,
      default: false,
    },

    isOperationalExpense: {
      type: Boolean,
      required: true,
      default: false,
    },

    isFullyLoadedCost: {
      type: Boolean,
      required: true,
      default: false,
    },

    requiresBill: {
      type: Boolean,
      default: false,
    },

    displayOrder: {
      type: Number,
      required: true,
      default: 1,
      min: [1, "Display order must be at least 1"],
      validate: {
        validator: Number.isInteger,
        message: "Display order must be an integer",
      },
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
      immutable: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: "version",
    collection: "subcomponents",
  },
);

export default mongoose.model("SubComponent", subComponentSchema);
