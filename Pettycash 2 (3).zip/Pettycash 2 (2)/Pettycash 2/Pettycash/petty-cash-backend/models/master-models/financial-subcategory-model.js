import mongoose from "mongoose";

const financialSubCategorySchema = new mongoose.Schema(
  {
    financialCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FinancialCategory",
      required: true,
    },
    subCategoryCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
    },
    subCategoryName: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    collection: "financial_sub_categories",
  },
);

financialSubCategorySchema.index(
  { subCategoryCode: 1 },
  {
    unique: true,
    name: "idx_financialSubCategory_subCategoryCode",
  },
);

financialSubCategorySchema.index(
  {
    financialCategoryId: 1,
    displayOrder: 1,
  },
  {
    name: "idx_financialSubCategory_parent_displayOrder",
  },
);

const FinancialSubCategory = mongoose.model(
  "FinancialSubCategory",
  financialSubCategorySchema,
);

export default FinancialSubCategory;