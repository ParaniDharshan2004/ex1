import mongoose from "mongoose";

const financialCategorySchema = new mongoose.Schema(
  {
    categoryCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
    },
    categoryName: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    collection: "financial_categories",
  },
);

financialCategorySchema.index(
  { categoryCode: 1 },
  {
    unique: true,
    name: "idx_financialCategory_categoryCode",
  },
);

const FinancialCategory = mongoose.model(
  "FinancialCategory",
  financialCategorySchema,
);

export default FinancialCategory;