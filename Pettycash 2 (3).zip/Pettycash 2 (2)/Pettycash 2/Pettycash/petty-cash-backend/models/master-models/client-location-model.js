import mongoose from 'mongoose';

const schema = new mongoose.Schema(
  {
    clientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Client',
      required: true,
      index: true,
    },

    locationCode: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    locationName: {
      type: String,
      required: true,
      trim: true,
    },

    gstNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    panNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    tanNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },

    billingAddress: {
      type: String,
      required: true,
      trim: true,
    },

    pinCode: {
      type: String,
      required: true,
      trim: true,
    },

    stateName: {
      type: String,
      required: true,
      trim: true,
    },

    taxIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'TaxMaster',
      },
    ],

    currencyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CurrencyMaster',
      required: true
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  {
    timestamps: true,
    collection: 'client_locations',
  },
);

schema.pre('validate', function normalize() {
  this.locationCode = String(this.locationCode || '')
    .trim()
    .toUpperCase();

  this.locationName = String(this.locationName || '').trim();

  this.gstNumber = String(this.gstNumber || '')
    .trim()
    .toUpperCase();

  this.panNumber = String(this.panNumber || '')
    .trim()
    .toUpperCase();

  this.tanNumber = String(this.tanNumber || '')
    .trim()
    .toUpperCase();
});

schema.index(
  { clientId: 1, locationCode: 1 },
  { unique: true, name: 'idx_client_location_client_code' },
);

export default mongoose.model('ClientLocation', schema);
