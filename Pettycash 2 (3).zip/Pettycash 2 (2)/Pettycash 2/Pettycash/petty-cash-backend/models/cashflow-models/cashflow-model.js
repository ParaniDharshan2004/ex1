import mongoose from "mongoose";

const cashFlowEntrySchema = new mongoose.Schema(
  {
    entryDate: {
      type: Date,
      required: [true, "Entry date is required"],
    },

    componentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Component",
      required: [true, "Component is required"],
    },

    subComponentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SubComponent",
      default: null,
    },

    description: {
      type: String,
      trim: true,
      maxlength: [
        500,
        "Description cannot exceed 500 characters",
      ],
      default: null,
    },

    amount: {
      type: Number,
      required: [true, "Amount is required"],
      min: [0, "Amount cannot be negative"],
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
      immutable: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: "version",
    optimisticConcurrency: true,
    collection: "cash_flow_entries",
  },
);

cashFlowEntrySchema.index(
  {
    entryDate: 1,
  },
  {
    name: "idx_cashFlowEntries_entryDate",
  },
);

cashFlowEntrySchema.index(
  {
    componentId: 1,
    entryDate: 1,
  },
  {
    name: "idx_cashFlowEntries_component_date",
  },
);

cashFlowEntrySchema.index(
  {
    subComponentId: 1,
    entryDate: 1,
  },
  {
    name: "idx_cashFlowEntries_subComponent_date",
  },
);

const CashFlowEntry = mongoose.model(
  "CashFlowEntry",
  cashFlowEntrySchema,
);

export default CashFlowEntry;