import mongoose from "mongoose";

const forecastAmountSchema = new mongoose.Schema(
  {
    month: {
      type: String,
      required: true,
      trim: true,
      match: [/^\d{4}-(0[1-9]|1[0-2])$/, "Month must use YYYY-MM format"],
    },
    amount: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  {
    _id: false,
  },
);

const signedForecastAmountSchema = new mongoose.Schema(
  {
    month: {
      type: String,
      required: true,
      match: [
        /^\d{4}-(0[1-9]|1[0-2])$/,
        "Month must follow the format YYYY-MM",
      ],
    },

    amount: {
      type: Number,
      required: true,
      default: 0,
    },
  },
  {
    _id: false,
  },
);

const matchedTallyLedgerSchema = new mongoose.Schema(
  {
    tallyLedgerName: {
      type: String,
      required: true,
      trim: true,
    },
    amount: {
      type: Number,
      default: 0,
    },
    excelRowNumber: {
      type: Number,
      default: null,
    },
    matchType: {
      type: String,
      enum: ["HEAD_COMPONENT", "SUBCOMPONENT"],
      required: true,
    },
    subComponentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SubComponent",
      default: null,
    },
    subComponentName: {
      type: String,
      default: "",
      trim: true,
    },
  },
  {
    _id: false,
  },
);

const subComponentBreakdownSchema = new mongoose.Schema(
  {
    subComponentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SubComponent",
      default: null,
    },
    subComponentName: {
      type: String,
      default: "",
      trim: true,
    },
    tallyLedgerName: {
      type: String,
      default: "",
      trim: true,
    },
    amount: {
      type: Number,
      default: 0,
    },
  },
  {
    _id: false,
  },
);

// To store each row data in Cash flow Forecast Table
const forecastRowSchema = new mongoose.Schema(
  {
    componentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Component",
      default: null,
    },
    parentComponentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Component",
      default: null,
    },
    componentCode: {
      type: String,
      default: "",
      trim: true,
    },
    componentName: {
      type: String,
      required: true,
      trim: true,
    },

    rowSource: {
      type: String,
      enum: ["TALLY_IMPORT", "MASTER_COMPONENT", "REPORT_ONLY"],
      default: "TALLY_IMPORT",
    },

    isManuallyAdded: {
      type: Boolean,
      default: false,
    },

    // Parent Financial Category
    financialCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FinancialCategory",
      default: null,
    },
    financialCategoryCode: {
      type: String,
      default: "",
      trim: true,
    },
    financialCategoryName: {
      type: String,
      default: "",
      trim: true,
    },

    // Financial Subcategory
    financialSubCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FinancialSubCategory",
      default: null,
    },
    financialSubCategoryCode: {
      type: String,
      default: "",
      trim: true,
    },
    financialSubCategoryName: {
      type: String,
      default: "",
      trim: true,
    },

    description: {
      type: String,
      default: "",
      trim: true,
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    sourceAmount: {
      type: Number,
      default: 0,
    },
    forecastAmounts: {
      type: [forecastAmountSchema],
      default: [],
    },
    matchStatus: {
      type: String,
      enum: [
        "HEAD_COMPONENT_MATCHED",
        "CALCULATED_FROM_SUBCOMPONENTS",
        "NOT_PRESENT_IN_TALLY",
        "MANUALLY_ADDED",
      ],
      default: "NOT_PRESENT_IN_TALLY",
    },
    hasTallyExpense: {
      type: Boolean,
      default: false,
    },
    matchedTallyLedgers: {
      type: [matchedTallyLedgerSchema],
      default: [],
    },
    subComponentBreakdown: {
      type: [subComponentBreakdownSchema],
      default: [],
    },
    isEdited: {
      type: Boolean,
      default: false,
    },
  },
  {
    _id: true,
  },
);

// To store Fixed cost Component and their forecast amount
const fixedCostSchema = new mongoose.Schema(
  {
    itemName: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      trim: true,
      default: "",
    },
    forecastAmounts: {
      type: [forecastAmountSchema],
      default: [],
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
  },
);

// Client Cash Infow Schema in Cash flow Report
const clientInflowSchema = new mongoose.Schema(
  {
    clientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Client",
      default: null,
    },

    clientCode: {
      type: String,
      trim: true,
      default: "",
    },

    clientName: {
      type: String,
      required: true,
      trim: true,
    },

    inflowType: {
      type: String,
      enum: ["ACTUAL", "ESTIMATED"],
      required: true,
    },

    rowSource: {
      type: String,
      enum: ["MASTER_CLIENT", "REPORT_ONLY"],
      default: "MASTER_CLIENT",
    },

    isManuallyAdded: {
      type: Boolean,
      default: false,
    },

    forecastAmounts: {
      type: [forecastAmountSchema],
      default: [],
    },
  },
  {
    _id: true,
  },
);

// Cash Flow report Summary Data
const cashFlowSummarySchema = new mongoose.Schema(
  {
    clientInflows: {
      type: [clientInflowSchema],
      default: [],
    },

    clientInflowsInitialized: {
      type: Boolean,
      default: false,
    },

    discountsAndRefunds: {
      type: [forecastAmountSchema],
      default: [],
    },

    openingSurplusDeficit: {
      type: Number,
      default: 0,
    },

    previousMonthSurplusDeficit: {
      type: [signedForecastAmountSchema],
      default: [],
    },

    surplusDeficit: {
      type: [signedForecastAmountSchema],
      default: [],
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    _id: false,
  },
);

// Main Cash Flow Forecast Data Schema
const cashFlowForecastSchema = new mongoose.Schema(
  {
    sourceMonth: {
      type: String,
      required: true,
      trim: true,
      match: [
        /^\d{4}-(0[1-9]|1[0-2])$/,
        "Source month must use YYYY-MM format",
      ],
    },
    sourceDate: {
      type: Date,
      required: true,
    },
    forecastMonths: {
      type: [String],
      default: [],
      validate: {
        validator: (months) =>
          months.length === 3 &&
          months.every((month) => /^\d{4}-(0[1-9]|1[0-2])$/.test(month)),
        message: "Three valid forecast months are required",
      },
    },
    sourceFile: {
      fileName: {
        type: String,
        default: "",
        trim: true,
      },
      worksheetName: {
        type: String,
        default: "",
        trim: true,
      },
    },
    rows: {
      type: [forecastRowSchema],
      default: [],
    },
    fixedCosts: {
      type: [fixedCostSchema],
      default: [],
    },
    unmatchedTallyRows: {
      type: [mongoose.Schema.Types.Mixed],
      default: [],
    },
    totals: {
      sourceTotal: {
        type: Number,
        default: 0,
      },
      month1Total: {
        type: Number,
        default: 0,
      },
      month2Total: {
        type: Number,
        default: 0,
      },
      month3Total: {
        type: Number,
        default: 0,
      },
      forecastTotal: {
        type: Number,
        default: 0,
      },
    },
    summary: {
      totalComponents: {
        type: Number,
        default: 0,
      },
      matchedHeadComponents: {
        type: Number,
        default: 0,
      },
      calculatedFromSubComponents: {
        type: Number,
        default: 0,
      },
      componentsWithoutExpense: {
        type: Number,
        default: 0,
      },
      unmatchedTallyRows: {
        type: Number,
        default: 0,
      },
    },
    cashFlowSummary: {
      type: cashFlowSummarySchema,
      default: () => ({
        clientInflows: [],
        discountsAndRefunds: [],
        openingSurplusDeficit: 0,
        previousMonthSurplusDeficit: [],
        surplusDeficit: [],
        updatedBy: null,
      }),
    },
    status: {
      type: String,
      enum: ["DRAFT", "FINALIZED"],
      default: "DRAFT",
    },
    importedAt: {
      type: Date,
      default: Date.now,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: "version",
    collection: "cash_flow_forecasts",
  },
);

cashFlowForecastSchema.index(
  {
    sourceMonth: 1,
  },
  {
    unique: true,
    name: "idx_cashFlowForecast_sourceMonth",
  },
);

cashFlowForecastSchema.index(
  {
    "rows.financialCategoryId": 1,
  },
  {
    name: "idx_cashFlowForecast_category",
  },
);

cashFlowForecastSchema.index(
  {
    "rows.financialSubCategoryId": 1,
  },
  {
    name: "idx_cashFlowForecast_subCategory",
  },
);

const CashFlowForecast = mongoose.model(
  "CashFlowForecast",
  cashFlowForecastSchema,
);

export default CashFlowForecast;
