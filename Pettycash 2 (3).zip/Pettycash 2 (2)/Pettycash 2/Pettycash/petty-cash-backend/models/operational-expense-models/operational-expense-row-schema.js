import mongoose from "mongoose";
import matchedTallyLedgerSchema from "./matched-tally-ledger-schema.js";

const operationalExpenseRowSchema = new mongoose.Schema(
  {
    componentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Component",
      default: null,
    },
    componentCode: {
      type: String,
      default: "",
      trim: true,
    },
    componentName: {
      type: String,
      required: true,
      trim: true,
    },
    rowSource: {
      type: String,
      enum: ["TALLY_IMPORT", "MASTER_COMPONENT", "REPORT_ONLY"],
      default: "TALLY_IMPORT",
    },
    financialCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FinancialCategory",
      default: null,
    },
    financialCategoryCode: {
      type: String,
      default: "",
      trim: true,
    },
    financialCategoryName: {
      type: String,
      default: "",
      trim: true,
    },
    sourceAmount: {
      type: Number,
      default: 0,
      min: 0,
    },
    amount: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    matchStatus: {
      type: String,
      enum: [
        "HEAD_COMPONENT_MATCHED",
        "CALCULATED_FROM_SUBCOMPONENTS",
        "NOT_PRESENT_IN_TALLY",
        "MANUALLY_ADDED",
      ],
      default: "NOT_PRESENT_IN_TALLY",
    },
    hasTallyExpense: {
      type: Boolean,
      default: false,
    },
    matchedTallyLedgers: {
      type: [matchedTallyLedgerSchema],
      default: [],
    },
    isManuallyAdded: {
      type: Boolean,
      default: false,
    },
    isEdited: {
      type: Boolean,
      default: false,
    },
    displayOrder: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
  },
  { _id: true },
);

export default operationalExpenseRowSchema;