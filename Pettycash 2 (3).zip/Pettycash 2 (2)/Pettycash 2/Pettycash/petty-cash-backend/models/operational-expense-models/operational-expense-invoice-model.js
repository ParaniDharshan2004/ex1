import mongoose from 'mongoose';

const schema = new mongoose.Schema(
  {
    operationalExpenseReportId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'OperationalExpenseReport',
      required: true,
    },

    clientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Client',
      required: true,
    },

    locationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ClientLocation',
      default: null,
    },

    locationCode: {
      type: String,
      trim: true,
      uppercase: true,
      default: '',
    },

    locationName: {
      type: String,
      trim: true,
      default: '',
    },

    invoiceNo: {
      type: String,
      trim: true,
      uppercase: true,
      match: [
        /^INV-[A-Z0-9]+-\d{8}-\d{3,}$/,
        'Invoice number must use INV-CLIENT-YYYYMMDD-NNN format',
      ],
    },

    invoiceDate: {
      type: Date,
      required: true,
    },

    expensePeriod: {
      type: String,
      trim: true,
      match: [
        /^\d{4}-(0[1-9]|1[0-2])$/,
        'Expense period must use YYYY-MM format',
      ],
    },

    status: {
      type: String,
      enum: ['DRAFT', 'GENERATED'],
      default: 'DRAFT',
      required: true,
    },

    baseCurrency: {
      type: String,
      default: 'INR',
      required: true,
    },

    invoiceCurrency: {
      type: String,
      required: true,
    },

    exchangeRate: {
      type: Number,
      required: true,
      min: 0.0000001,
    },

    baseAmount: {
      type: Number,
      required: true,
      min: 0,
    },

    invoiceAmount: {
      type: Number,
      required: true,
      min: 0,
    },

    gstRate: {
      type: Number,
      required: true,
      min: 0,
    },

    taxableAmount: {
      type: Number,
      required: true,
      min: 0,
    },

    gstAmount: {
      type: Number,
      required: true,
      min: 0,
    },

    grandTotal: {
      type: Number,
      required: true,
      min: 0,
    },

    currencyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CurrencyMaster',
      required: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  {
    timestamps: true,
    collection: 'operational_expense_invoices',
  },
);

schema.index(
  { invoiceNo: 1 },
  {
    unique: true,
    sparse: true,
    name: 'idx_operational_expense_invoice_no',
  },
);

schema.index(
  {
    operationalExpenseReportId: 1,
    clientId: 1,
    locationCode: 1,
  },
  {
    unique: true,
    name: 'idx_operational_expense_invoice_target',
  },
);

export default mongoose.model('OperationalExpenseInvoice', schema);
