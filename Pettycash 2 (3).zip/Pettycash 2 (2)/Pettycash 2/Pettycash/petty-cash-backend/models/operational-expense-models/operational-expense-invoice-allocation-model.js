import mongoose from 'mongoose';
const schema = new mongoose.Schema(
  {
    operationalExpenseReportId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'OperationalExpenseReport',
      required: true,
    },
    clientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Client',
      required: true,
    },
    clientTotalAmount: { type: Number, required: true, min: 0 },
    locationAllocations: [
      {
        locationId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'ClientLocation',
          default: null,
        },
        amount: { type: Number, required: true, min: 0 },
      },
    ],
    allocationStatus: {
      type: String,
      enum: ['DRAFT', 'CONFIRMED'],
      default: 'DRAFT',
    },
    isAutomatic: { type: Boolean, default: false },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  { timestamps: true, collection: 'operational_expense_invoice_allocations' },
);
schema.index(
  { operationalExpenseReportId: 1, clientId: 1 },
  { unique: true, name: 'idx_operational_expense_allocation_report_client' },
);
schema.pre('validate', function normalize() {
  this.clientTotalAmount =
    Math.round(Number(this.clientTotalAmount) * 100) / 100;
  for (const item of this.locationAllocations || [])
    item.amount = Math.round(Number(item.amount) * 100) / 100;
});
export default mongoose.model('OperationalExpenseInvoiceAllocation', schema);
