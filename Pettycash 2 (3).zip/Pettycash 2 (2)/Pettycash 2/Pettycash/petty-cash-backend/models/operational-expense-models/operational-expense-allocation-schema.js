import mongoose from "mongoose";

const operationalExpenseAllocationSchema = new mongoose.Schema(
  {
    clientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Client",
      required: true,
    },
    clientCode: {
      type: String,
      default: "",
      trim: true,
    },
    clientName: {
      type: String,
      required: true,
      trim: true,
    },
    allocationPercentage: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
      max: 100,
    },
    amount: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
  },
  { _id: true },
);

export default operationalExpenseAllocationSchema;