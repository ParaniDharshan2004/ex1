import mongoose from "mongoose";

const operationalExpenseMarkupSchema = new mongoose.Schema(
  {
    enabled: {
      type: Boolean,
      default: true,
    },
    percentage: {
      type: Number,
      required: true,
      default: 20,
      min: 0,
    },
    baseType: {
      type: String,
      enum: ["SUBTOTAL", "DIRECT_COST", "INDIRECT_COST", "CUSTOM"],
      default: "SUBTOTAL",
    },
    baseAmount: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    amount: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    notes: {
      type: String,
      default: "",
      trim: true,
    },
  },
  { _id: false },
);

export default operationalExpenseMarkupSchema;