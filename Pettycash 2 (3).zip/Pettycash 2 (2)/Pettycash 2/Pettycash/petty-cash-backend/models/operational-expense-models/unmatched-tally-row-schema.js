import mongoose from 'mongoose';

const unmatchedTallyRowSchema = new mongoose.Schema(
  {
    tallyLedgerName: {
      type: String,
      required: true,
      trim: true,
    },

    amount: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },

    excelRowNumber: {
      type: Number,
      default: null,
      min: 1,
    },

    reason: {
      type: String,
      default: '',
      trim: true,
    },

    resolutionStatus: {
      type: String,
      enum: ['UNRESOLVED', 'MAPPED', 'EXCLUDED', 'ADDED_TO_REPORT'],
      default: 'UNRESOLVED',
    },

    mappedComponentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Component',
      default: null,
    },

    resolutionReason: {
      type: String,
      default: '',
      trim: true,
    },

    resolvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },

    resolvedAt: {
      type: Date,
      default: null,
    },
  },
  {
    _id: true,
  },
);

unmatchedTallyRowSchema.pre("validate", function validateResolution() {
  const resolved = ["MAPPED", "EXCLUDED", "ADDED_TO_REPORT"].includes(
    this.resolutionStatus,
  );

  if (resolved && !this.resolutionReason?.trim()) {
    this.invalidate(
      "resolutionReason",
      "Resolution reason is required when an unmatched Tally row is mapped or excluded.",
    );
    return;
  }

  if (this.resolutionStatus === "MAPPED" && !this.mappedComponentId) {
    this.invalidate(
      "mappedComponentId",
      "Mapped Component is required when resolution status is MAPPED.",
    );
  }
});

export default unmatchedTallyRowSchema;
