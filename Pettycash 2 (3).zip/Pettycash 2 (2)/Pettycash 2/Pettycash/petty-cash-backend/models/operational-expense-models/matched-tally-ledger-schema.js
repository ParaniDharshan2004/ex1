import mongoose from "mongoose";


const matchedTallyLedgerSchema = new mongoose.Schema(
  {
    tallyLedgerName: {
      type: String,
      required: true,
      trim: true,
    },

    amount: {
      type: Number,
      default: 0,
      min: 0,
    },

    excelRowNumber: {
      type: Number,
      default: null,
      min: 1,
    },

    matchType: {
      type: String,
      enum: [
        "HEAD_COMPONENT",
        "SUBCOMPONENT",
      ],
      required: true,
    },

    subComponentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SubComponent",
      default: null,
    },

    subComponentName: {
      type: String,
      default: "",
      trim: true,
    },
  },
  {
    _id: false,
  },
);

export default matchedTallyLedgerSchema;