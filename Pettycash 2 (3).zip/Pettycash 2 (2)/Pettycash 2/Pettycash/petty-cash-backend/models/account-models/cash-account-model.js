import mongoose from "mongoose";

const pettyCashAccountSchema = new mongoose.Schema(
  {
    accountCode: {
      type: String,
      required: true,
      unique: true,
      immutable: true,
      trim: true,
      uppercase: true,
    },

    accountName: {
      type: String,
      required: true,
      trim: true,
    },

    receiverUserId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    receiverBankAccountMasked: {
      type: String,
      default: null,
    },

    currentBalance: {
      type: mongoose.Schema.Types.Decimal128,
      default: 0,
    },

    lastCashInflowId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CashInflow",
      default: null,
    },

    lastTransactionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "PettyCash",
      default: null,
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
    versionKey: "version",
    optimisticConcurrency: true,
    collection: "petty_cash_accounts",
  }
);

export default mongoose.model(
  "PettyCashAccount",
  pettyCashAccountSchema
);