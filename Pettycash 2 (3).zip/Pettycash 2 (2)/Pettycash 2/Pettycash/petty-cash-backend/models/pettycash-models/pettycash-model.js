import mongoose from "mongoose";

const pettyCashSchema = new mongoose.Schema(
  {
    entryNo: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    cashAccountId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "PettyCashAccount",
      required: true,
    },

    transactionType: {
      type: String,
      enum: ["EXPENSE", "REIMBURSEMENT"],
      required: true,
      default: "EXPENSE",
    },

    transactionDate: {
      type: Date,
      required: true,
    },

    componentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Component",
      required: true,
    },

    subComponentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SubComponent",
      default: null,
    },

    description: {
      type: String,
      required: false,
      trim: true,
    },

    amount: {
      type: Number,
      required: true,
      min: 1,
    },

    spentByUserId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    reimbursedToUserId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    billAvailable: {
      type: Boolean,
      default: false,
    },

    status: {
      type: String,
      enum: ["POSTED", "DRAFT", "CANCELLED"],
      default: "POSTED",
    },

    idempotencyKey: {
      type: String,
      unique: true,
      sparse: true,
    },

    enteredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    postedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    postedAt: {
      type: Date,
      default: null,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
    versionKey: "version",
  }
);

export default mongoose.model(
  "PettyCash",
  pettyCashSchema
);