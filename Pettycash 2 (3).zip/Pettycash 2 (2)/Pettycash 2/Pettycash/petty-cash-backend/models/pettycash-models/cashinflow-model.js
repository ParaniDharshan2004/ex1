import mongoose from "mongoose";

const cashInflowSchema = new mongoose.Schema(
  {
    inflowDate: {
      type: Date,
      required: true,
    },

    amount: {
      type: Number,
      required: true,
      min: 1,
    },

    remarks: {
      type: String,
      default: "",
    },

    createdBy: {
      type: String,
      default: "Admin",
    },
    
  },
  {
    timestamps: true,
  },
);

export default mongoose.model(
  "CashInflow",
  cashInflowSchema,
);