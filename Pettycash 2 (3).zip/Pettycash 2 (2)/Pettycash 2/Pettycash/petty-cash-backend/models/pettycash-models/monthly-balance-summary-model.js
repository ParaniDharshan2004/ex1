import mongoose from "mongoose";

const monthlyBalanceSummarySchema =
  new mongoose.Schema(
    {
      month: {
        type: String,
        required: true,
        unique: true,
      },

      openingBalance: {
        type: Number,
        default: 0,
      },

      totalCashInflow: {
        type: Number,
        default: 0,
      },

      totalExpenseAndReimbursement: {
        type: Number,
        default: 0,
      },

      closingBalance: {
        type: Number,
        default: 0,
      },

      transactionCount: {
        type: Number,
        default: 0,
      },
    },
    {
      timestamps: true,
    },
  );

export default mongoose.model(
  "MonthlyBalanceSummary",
  monthlyBalanceSummarySchema,
);