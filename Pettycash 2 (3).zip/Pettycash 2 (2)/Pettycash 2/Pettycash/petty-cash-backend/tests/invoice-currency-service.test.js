import { calculateInvoiceCurrencyAmounts } from '../services/operational-expense-services/operational-expense-invoice-currency-service.js';

describe('calculateInvoiceCurrencyAmounts', () => {
  test('converts INR to foreign currency and stores the currency snapshot', () => {
    const amount = calculateInvoiceCurrencyAmounts(8450, {
      _id: 'currency-id',
      currencyCode: 'USD',
      exchangeRate: 84.5,
    });

    expect(amount).toEqual({
      baseCurrency: 'INR',
      invoiceCurrency: 'USD',
      currencyId: 'currency-id',
      exchangeRate: 84.5,
      baseAmount: 8450,
      invoiceAmount: 100,
    });
  });

  test('uses the same amount when invoice currency is INR', () => {
    const amount = calculateInvoiceCurrencyAmounts(118, {
      _id: 'inr-id',
      currencyCode: 'INR',
      exchangeRate: 1,
    });

    expect(amount.invoiceAmount).toBe(118);
    expect(amount.baseAmount).toBe(118);
  });

  test('rejects invalid exchange rates', () => {
    expect(() =>
      calculateInvoiceCurrencyAmounts(100, {
        _id: 'currency-id',
        currencyCode: 'USD',
        exchangeRate: 0,
      }),
    ).toThrow('Exchange rate must be a positive number');
  });
});
