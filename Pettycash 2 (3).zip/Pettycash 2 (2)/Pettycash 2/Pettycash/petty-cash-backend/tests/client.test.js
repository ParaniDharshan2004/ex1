import request from "supertest";
import app from "../app.js";

describe("Sample Test", () => {
  test("should pass", async () => {
    const response = await request(app).get("/");

    expect(response.statusCode).toBeDefined();
  });
});