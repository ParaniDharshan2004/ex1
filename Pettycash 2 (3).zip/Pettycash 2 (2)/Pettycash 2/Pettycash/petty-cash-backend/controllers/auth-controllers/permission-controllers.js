import Permission from "../../models/auth-models/permission-model.js";

// Create Permission
export const createPermission = async (req, res) => {
  try {
    const permission = await Permission.create(req.body);

    return res.status(201).json({
      success: true,
      data: permission,
      message: "Permission created successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Unable to create permission",
    });
  }
};

// Get All Permissions
export const getAllPermissions = async (req, res) => {
  try {
    const permissions = await Permission.find();

    return res.status(200).json({
      success: true,
      data: permissions,
      message: "Permissions retrieved successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Unable to fetch permissions",
    });
  }
};

// Update Permission
export const updatePermission = async (req, res) => {
  try {
    const permission = await Permission.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    );

    if (!permission) {
      return res.status(404).json({
        success: false,
        message: "Permission not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: permission,
      message: "Permission updated successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Unable to update permission",
    });
  }
};

// Delete Permission
export const deletePermission = async (req, res) => {
  try {
    const permission = await Permission.findByIdAndDelete(
      req.params.id
    );

    if (!permission) {
      return res.status(404).json({
        success: false,
        message: "Permission not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Permission deleted successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Unable to delete permission",
    });
  }
};