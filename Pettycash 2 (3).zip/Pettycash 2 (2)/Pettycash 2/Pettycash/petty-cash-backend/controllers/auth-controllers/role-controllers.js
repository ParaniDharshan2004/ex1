import Role from "../../models/auth-models/role-model.js";
import Permission from "../../models/auth-models/permission-model.js";

// Create Role
export const createRole = async (req, res) => {
  try {
    const { roleName, permissionId } = req.body;

    // Check Permission exists
    const permission = await Permission.findById(permissionId);

    if (!permission) {
      return res.status(404).json({
        success: false,
        message: "Permission not found",
      });
    }

    // Check Role already exists
    const existingRole = await Role.findOne({
      roleName,
    });

    if (existingRole) {
      return res.status(400).json({
        success: false,
        message: "Role already exists",
      });
    }

    const role = await Role.create({
      roleName,
      permissionId,
    });

    const populatedRole = await Role.findById(role._id).populate(
      "permissionId",
      "permissionName read write delete",
    );

    return res.status(201).json({
      success: true,
      data: populatedRole,
      message: "Role created successfully",
    });
  } catch (error) {
    console.error("Create Role Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to create role",
    });
  }
};

// Get All Roles
export const getAllRoles = async (req, res) => {
  try {
    const roles = await Role.find()
      .populate("permissionId", "permissionName read write delete")
      .sort({ roleName: 1 });

    return res.status(200).json({
      success: true,
      data: roles,
      message: "Roles retrieved successfully",
    });
  } catch (error) {
    console.error("Get Roles Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve roles",
    });
  }
};

// Get Role By Id
export const getRoleById = async (req, res) => {
  try {
    const role = await Role.findById(req.params.id).populate(
      "permissionId",
      "permissionName read write delete",
    );

    if (!role) {
      return res.status(404).json({
        success: false,
        message: "Role not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: role,
      message: "Role retrieved successfully",
    });
  } catch (error) {
    console.error("Get Role Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve role",
    });
  }
};

// Update Role
export const updateRole = async (req, res) => {
  try {
    const { permissionId } = req.body;

    if (permissionId) {
      const permission = await Permission.findById(permissionId);

      if (!permission) {
        return res.status(404).json({
          success: false,
          message: "Permission not found",
        });
      }
    }

    const role = await Role.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).populate("permissionId", "permissionName read write delete");

    if (!role) {
      return res.status(404).json({
        success: false,
        message: "Role not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: role,
      message: "Role updated successfully",
    });
  } catch (error) {
    console.error("Update Role Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to update role",
    });
  }
};

// Delete Role
export const deleteRole = async (req, res) => {
  try {
    const role = await Role.findByIdAndDelete(req.params.id);

    if (!role) {
      return res.status(404).json({
        success: false,
        message: "Role not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Role deleted successfully",
    });
  } catch (error) {
    console.error("Delete Role Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to delete role",
    });
  }
};
