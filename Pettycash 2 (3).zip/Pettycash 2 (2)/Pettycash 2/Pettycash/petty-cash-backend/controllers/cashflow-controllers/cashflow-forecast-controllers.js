import Component from "../../models/master-models/component-model.js";
import SubComponent from "../../models/master-models/subcomponent.js";
import CashFlowForecast from "../../models/cashflow-models/cashflow-forecast-model.js";

import {
  normalizeName,
  createNameSet,
  findMatchingRecord,
  getNextThreeMonths,
} from "../../utils/cashflow-utils/cashflow-forcast-utils.js";

export const generateCashFlowForecast = async (req, res) => {
  try {
    const {
      sourceMonth,
      tallyRows = [],
      sourceFileName = "",
      worksheetName = "",
    } = req.body;

    if (!sourceMonth) {
      return res.status(400).json({
        success: false,
        message: "Source month is required",
      });
    }

    if (!Array.isArray(tallyRows)) {
      return res.status(400).json({
        success: false,
        message: "Tally rows must be an array",
      });
    }
     const existingForecast = await CashFlowForecast.exists({ sourceMonth });
    if (existingForecast) {
      return res.status(409).json({
        success: false,
        message: `A Tally report has already been imported for ${sourceMonth}.`,
      });
    }

    const forecastMonths = getNextThreeMonths(sourceMonth);

    const components = await Component.find({
      isCashFlowAnalysis: true,
      isActive: true,
    })
      .populate({
        path: "financialCategoryId",
        select: "categoryCode categoryName description displayOrder isActive",
      })
      .populate({
        path: "financialSubCategoryId",
        select:
          "subCategoryCode subCategoryName financialCategoryId description displayOrder isActive",
      })
      .sort({
        displayOrder: 1,
        componentName: 1,
      })
      .lean();

    if (!components.length) {
      return res.status(404).json({
        success: false,
        message: "No active cash-flow components found",
      });
    }

    const componentIds = components.map((component) => component._id);

    const subComponents = await SubComponent.find({
      componentId: {
        $in: componentIds,
      },
      isCashFlowAnalysis: true,
      isActive: true,
    })
      .sort({
        displayOrder: 1,
        subComponentName: 1,
      })
      .lean();

    const componentRecords = components.map((component) => ({
      component,

      matchingNames: createNameSet(
        component.componentName,
        component.componentCode,
        component.description,
        component.tallyLedgerNames,
      ),
    }));

    const subComponentRecords = subComponents.map((subComponent) => ({
      subComponent,

      matchingNames: createNameSet(
        subComponent.subComponentName,
        subComponent.subComponentCode,
        subComponent.description,
        subComponent.tallyLedgerNames,
      ),
    }));

    const componentAmountMap = new Map();

    components.forEach((component) => {
      const componentId = String(component._id);

      componentAmountMap.set(componentId, {
        component,
        directParentAmounts: [],
        subComponentAmounts: [],
        matchedTallyLedgers: [],
        matchedSubComponents: [],
      });
    });

    const unmatchedTallyRows = [];

    tallyRows.forEach((tallyRow, tallyRowIndex) => {
      const tallyLedgerName = String(
        tallyRow.tallyLedgerName ||
          tallyRow.component ||
          tallyRow.particulars ||
          "",
      ).trim();

      const normalizedTallyName = normalizeName(tallyLedgerName);

      const amount =
        Number(
          tallyRow.sourceAmount ?? tallyRow.amount ?? tallyRow.debitAmount ?? 0,
        ) || 0;

      if (!normalizedTallyName) {
        return;
      }

      const matchedComponentRecord = findMatchingRecord(
        normalizedTallyName,
        componentRecords,
      );

      if (matchedComponentRecord) {
        const componentId = String(matchedComponentRecord.component._id);

        const accumulator = componentAmountMap.get(componentId);

        accumulator.directParentAmounts.push(amount);

        accumulator.matchedTallyLedgers.push({
          tallyLedgerName,
          amount,
          excelRowNumber: tallyRow.excelRowNumber || tallyRowIndex + 1,
          matchType: "HEAD_COMPONENT",
        });

        return;
      }

      const matchedSubComponentRecord = findMatchingRecord(
        normalizedTallyName,
        subComponentRecords,
      );

      if (matchedSubComponentRecord) {
        const matchedSubComponent = matchedSubComponentRecord.subComponent;

        const parentComponentId = String(matchedSubComponent.componentId);

        const parentAccumulator = componentAmountMap.get(parentComponentId);

        if (!parentAccumulator) {
          unmatchedTallyRows.push({
            tallyLedgerName,
            amount,
            excelRowNumber: tallyRow.excelRowNumber || tallyRowIndex + 1,
            reason:
              "Matched subcomponent does not have an eligible cash-flow parent",
          });

          return;
        }

        parentAccumulator.subComponentAmounts.push(amount);

        parentAccumulator.matchedTallyLedgers.push({
          tallyLedgerName,
          amount,
          excelRowNumber: tallyRow.excelRowNumber || tallyRowIndex + 1,
          matchType: "SUBCOMPONENT",
          subComponentId: matchedSubComponent._id,
          subComponentName:
            matchedSubComponent.subComponentName ||
            matchedSubComponent.componentName,
        });

        parentAccumulator.matchedSubComponents.push({
          subComponentId: matchedSubComponent._id,

          subComponentName:
            matchedSubComponent.subComponentName ||
            matchedSubComponent.componentName,

          tallyLedgerName,

          amount,
        });

        return;
      }

      unmatchedTallyRows.push({
        tallyLedgerName,
        amount,
        excelRowNumber: tallyRow.excelRowNumber || tallyRowIndex + 1,
        reason: "No database component or subcomponent matched",
      });
    });

    const forecastRows = components.map((component, index) => {
      const componentId = String(component._id);
      const accumulator = componentAmountMap.get(componentId);

      const directParentTotal = accumulator.directParentAmounts.reduce(
        (total, amount) => total + (Number(amount) || 0),
        0,
      );

      const subComponentTotal = accumulator.subComponentAmounts.reduce(
        (total, amount) => total + (Number(amount) || 0),
        0,
      );

      const hasDirectParentMatch = accumulator.directParentAmounts.length > 0;

      const sourceAmount = hasDirectParentMatch
        ? directParentTotal
        : subComponentTotal;

      let matchStatus = "NOT_PRESENT_IN_TALLY";

      if (hasDirectParentMatch) {
        matchStatus = "HEAD_COMPONENT_MATCHED";
      } else if (accumulator.subComponentAmounts.length > 0) {
        matchStatus = "CALCULATED_FROM_SUBCOMPONENTS";
      }

      return {
        id: componentId,
        componentId: component._id,
        componentCode: component.componentCode,
        componentName: component.componentName,

        rowSource: "TALLY_IMPORT",
        isManuallyAdded: false,

        financialCategoryId: component.financialCategoryId?._id || null,

        financialCategoryCode:
          component.financialCategoryId?.categoryCode || "",

        financialCategoryName:
          component.financialCategoryId?.categoryName || "",

        financialSubCategoryId: component.financialSubCategoryId?._id || null,

        financialSubCategoryCode:
          component.financialSubCategoryId?.subCategoryCode || "",

        financialSubCategoryName:
          component.financialSubCategoryId?.subCategoryName || "",

        description: component.description || "",
        displayOrder: component.displayOrder ?? index + 1,
        sourceAmount,

        forecastAmounts: forecastMonths.map((month) => ({
          month,
          amount: sourceAmount,
        })),

        matchStatus,
        hasTallyExpense: sourceAmount > 0,
        matchedTallyLedgers: accumulator.matchedTallyLedgers,
        subComponentBreakdown: accumulator.matchedSubComponents,
        isEdited: false,
      };
    });

    const sourceTotal = forecastRows.reduce(
      (total, row) => total + (Number(row.sourceAmount) || 0),
      0,
    );

    const monthTotals = forecastMonths.map((month) =>
      forecastRows.reduce((total, row) => {
        const forecastAmount = row.forecastAmounts.find(
          (item) => item.month === month,
        );

        return total + (Number(forecastAmount?.amount) || 0);
      }, 0),
    );

    const [month1Total, month2Total, month3Total] = monthTotals;
    const forecastTotal = monthTotals.reduce(
      (total, amount) => total + amount,
      0,
    );

    const rowsForDatabase = forecastRows.map((row) => ({
      componentId: row.componentId,
      componentCode: row.componentCode,
      componentName: row.componentName,

      financialCategoryId: row.financialCategoryId,
      financialCategoryCode: row.financialCategoryCode,
      financialCategoryName: row.financialCategoryName,

      financialSubCategoryId: row.financialSubCategoryId,
      financialSubCategoryCode: row.financialSubCategoryCode,
      financialSubCategoryName: row.financialSubCategoryName,

      description: row.description,
      displayOrder: row.displayOrder,
      sourceAmount: row.sourceAmount,
      forecastAmounts: row.forecastAmounts,

      matchStatus: row.matchStatus,
      hasTallyExpense: row.hasTallyExpense,
      matchedTallyLedgers: row.matchedTallyLedgers,
      subComponentBreakdown: row.subComponentBreakdown,
      isEdited: row.isEdited,
    }));

    const sourceDate = new Date(`${sourceMonth}-01T00:00:00.000Z`);

    const updateData = {
      $set: {
        sourceDate,
        forecastMonths,
        sourceFile: {
          fileName: sourceFileName,
          worksheetName,
        },
        rows: rowsForDatabase,
        unmatchedTallyRows,
        totals: {
          sourceTotal,
          month1Total,
          month2Total,
          month3Total,
          forecastTotal,
        },
        summary: {
          totalComponents: forecastRows.length,
          matchedHeadComponents: forecastRows.filter(
            (row) => row.matchStatus === "HEAD_COMPONENT_MATCHED",
          ).length,
          calculatedFromSubComponents: forecastRows.filter(
            (row) => row.matchStatus === "CALCULATED_FROM_SUBCOMPONENTS",
          ).length,
          componentsWithoutExpense: forecastRows.filter(
            (row) => row.matchStatus === "NOT_PRESENT_IN_TALLY",
          ).length,
          unmatchedTallyRows: unmatchedTallyRows.length,
        },
        importedAt: new Date(),
        updatedBy: req.user?.userId || null,
      },
      $setOnInsert: {
        sourceMonth,
        fixedCosts: [],
        status: "DRAFT",
        createdBy: req.user?.userId || null,
      },
    };

    const savedForecast = await CashFlowForecast.findOneAndUpdate(
      { sourceMonth },
      updateData,
      {
        upsert: true,
        returnDocument: "after",
        setDefaultsOnInsert: true,
        runValidators: true,
      },
    );

    return res.status(200).json({
      success: true,
      message: "Cash-flow forecast generated and saved successfully",
      data: {
        forecastId: savedForecast._id,
        sourceMonth,
        forecastMonths,
        sourceFile: savedForecast.sourceFile,
        rows: savedForecast.rows,
        fixedCosts: savedForecast.fixedCosts || [],
        unmatchedTallyRows: savedForecast.unmatchedTallyRows,
        totals: savedForecast.totals,
        summary: savedForecast.summary,
        status: savedForecast.status,
      },
    });
  } catch (error) {
    console.error("Generate cash-flow forecast error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Failed to generate cash-flow forecast",
    });
  }
};

export const getCashFlowForecastById = async (req, res) => {
  try {
    const forecast = await CashFlowForecast.findById(req.params.id).lean();

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash-flow forecast not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: forecast,
      message: "Cash-flow forecast retrieved successfully",
    });
  } catch (error) {
    console.error("Get Cash Flow Forecast Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to retrieve forecast",
    });
  }
};

export const updateCashFlowForecastStatus = async (req, res) => {
  try {
    const { status } = req.body;

    if (!["DRAFT", "FINALIZED"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Status must be DRAFT or FINALIZED",
      });
    }

    const forecast = await CashFlowForecast.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          status,
          updatedBy: req.user?.userId || null,
        },
      },
      { new: true, runValidators: true },
    );

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash-flow forecast not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Cash-flow forecast status updated successfully",
      data: { forecastId: forecast._id, status: forecast.status },
    });
  } catch (error) {
    console.error("Update Cash Flow Forecast Status Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to update cash-flow forecast status",
    });
  }
};

export const getAllCashFlowForecasts = async (req, res) => {
  try {
    const forecasts = await CashFlowForecast.find({})
      .sort({ sourceDate: -1, sourceMonth: -1 })
      .lean();

    return res.status(200).json({
      success: true,
      data: forecasts,
      message: "Cash-flow forecasts retrieved successfully",
    });
  } catch (error) {
    console.error("Get All Cash Flow Forecasts Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to retrieve cash-flow forecasts",
    });
  }
};

export const deleteCashFlowForecast = async (req, res) => {
  try {
    const forecast = await CashFlowForecast.findByIdAndDelete(req.params.id);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash-flow forecast not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Cash-flow forecast deleted successfully",
      data: { forecastId: forecast._id },
    });
  } catch (error) {
    console.error("Delete Cash Flow Forecast Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to delete cash-flow forecast",
    });
  }
};

export const updateCashFlowForecastRows = async (req, res) => {
  try {
    const { rows = [] } = req.body;

    if (!Array.isArray(rows)) {
      return res.status(400).json({
        success: false,
        message: "Forecast rows must be an array",
      });
    }

    const forecast = await CashFlowForecast.findById(req.params.id);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash-flow forecast not found",
      });
    }

    forecast.rows = rows;
    forecast.updatedBy = req.user?.userId || null;

    forecast.totals.month1Total = rows.reduce(
      (total, row) => total + (Number(row.month1) || 0),
      0,
    );

    forecast.totals.month2Total = rows.reduce(
      (total, row) => total + (Number(row.month2) || 0),
      0,
    );

    forecast.totals.month3Total = rows.reduce(
      (total, row) => total + (Number(row.month3) || 0),
      0,
    );

    forecast.totals.forecastTotal =
      forecast.totals.month1Total +
      forecast.totals.month2Total +
      forecast.totals.month3Total;

    await forecast.save();

    return res.status(200).json({
      success: true,
      data: forecast,
      message: "Cash-flow forecast saved successfully",
    });
  } catch (error) {
    console.error("Save Cash Flow Forecast Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to save forecast",
    });
  }
};
