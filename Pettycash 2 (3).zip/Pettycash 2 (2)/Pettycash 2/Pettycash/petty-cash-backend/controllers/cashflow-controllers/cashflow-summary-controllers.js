import mongoose from "mongoose";

import Client from "../../models/master-models/client-model.js";
import CashFlowForecast from "../../models/cashflow-models/cashflow-forecast-model.js";

import { calculateCashFlowSummary } from "../../utils/cashflow-utils/cashflow-summary-utils.js";

const getAmountForMonth = (forecastAmounts = [], month) => {
  const matchingAmount = forecastAmounts.find((item) => item.month === month);

  return Number(matchingAmount?.amount) || 0;
};

const normalizeForecastAmounts = (
  forecastAmounts = [],
  forecastMonths = [],
) => {
  return forecastMonths.map((month) => ({
    month,
    amount: getAmountForMonth(forecastAmounts, month),
  }));
};

// Calculation of Total Cash Outflows
const calculateCashOutflowTotals = (forecast) => {
  return forecast.forecastMonths.map((month) => {
    const forecastRowsTotal = forecast.rows.reduce((total, row) => {
      const amount = getAmountForMonth(row.forecastAmounts, month);

      return total + amount;
    }, 0);

    const fixedCostsTotal = forecast.fixedCosts.reduce((total, fixedCost) => {
      const amount = getAmountForMonth(fixedCost.forecastAmounts, month);

      return total + amount;
    }, 0);

    return forecastRowsTotal + fixedCostsTotal;
  });
};

// Get Cash Flow Summary
export const getCashFlowSummary = async (req, res) => {
  try {
    const { forecastId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Cash Flow Forecast ID",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const activeClients = await Client.find({
      isActive: true,
    })
      .select("_id clientCode clientName displayOrder")
      .sort({
        displayOrder: 1,
        clientName: 1,
      })
      .lean();

    const forecastMonths = forecast.forecastMonths || [];

    if (forecastMonths.length !== 3) {
      return res.status(400).json({
        success: false,
        message: "Three valid forecast months are required",
      });
    }

    const existingSummary = forecast.cashFlowSummary || {};

    const existingClientInflows = existingSummary.clientInflows || [];

    let synchronizedClientInflows = [];

    if (
      existingClientInflows.length === 0 &&
      existingSummary.clientInflowsInitialized !== true
    ) {
      activeClients.forEach((client) => {
        synchronizedClientInflows.push({
          clientId: client._id,
          clientCode: client.clientCode || "",
          clientName: client.clientName || "",
          inflowType: "ACTUAL",
          rowSource: "MASTER_CLIENT",
          isManuallyAdded: false,
          forecastAmounts: normalizeForecastAmounts([], forecastMonths),
        });

      });
    } else {
      synchronizedClientInflows = existingClientInflows
        .filter((row) => row.inflowType !== "ESTIMATED")
        .map((row) => ({
        clientId: row.clientId || null,
        clientCode: row.clientCode || "",
        clientName: row.clientName || "",
        inflowType: row.inflowType,

        rowSource:
          row.rowSource || (row.clientId ? "MASTER_CLIENT" : "REPORT_ONLY"),

        isManuallyAdded: Boolean(row.isManuallyAdded),

        forecastAmounts: normalizeForecastAmounts(
          row.forecastAmounts,
          forecastMonths,
        ),
        }));
    }

    const discountsAndRefunds = normalizeForecastAmounts(
      existingSummary.discountsAndRefunds,
      forecastMonths,
    );

    const openingSurplusDeficit =
      Number(existingSummary.openingSurplusDeficit) || 0;

    const cashOutflowTotals = calculateCashOutflowTotals(forecast);

    const calculatedSummary = calculateCashFlowSummary({
      forecastMonths,
      clientInflows: synchronizedClientInflows,
      discountsAndRefunds,
      openingSurplusDeficit,
      cashOutflowTotals,
    });

    forecast.cashFlowSummary = {
      clientInflows: synchronizedClientInflows,
      clientInflowsInitialized: true,
      discountsAndRefunds,
      openingSurplusDeficit,
      previousMonthSurplusDeficit:
        calculatedSummary.previousMonthSurplusDeficit,
      surplusDeficit: calculatedSummary.surplusDeficit,
      updatedBy: req.user?.userId || null,
    };

    await forecast.save();

    return res.status(200).json({
      success: true,
      data: {
        forecastId: forecast._id,
        forecastMonths,
        clientInflows: forecast.cashFlowSummary.clientInflows,
        discountsAndRefunds: forecast.cashFlowSummary.discountsAndRefunds,
        openingSurplusDeficit: forecast.cashFlowSummary.openingSurplusDeficit,
        previousMonthSurplusDeficit:
          forecast.cashFlowSummary.previousMonthSurplusDeficit,
        surplusDeficit: forecast.cashFlowSummary.surplusDeficit,
        cashOutflowTotals,
      },
      message: "Cash Flow Summary retrieved successfully",
    });
  } catch (error) {
    console.error("Get Cash Flow Summary Error:", error.stack || error);

    if (error.name === "ValidationError") {
      const message = Object.values(error.errors)
        .map((item) => item.message)
        .join(", ");

      return res.status(400).json({
        success: false,
        message,
      });
    }

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to retrieve Cash Flow Summary",
    });
  }
};

// Update Cash Flow Summary
export const updateCashFlowSummary = async (req, res) => {
  try {
    const { forecastId } = req.params;

    const {
      clientInflows = [],
      discountsAndRefunds = [],
      openingSurplusDeficit = 0,
    } = req.body;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Cash Flow Forecast ID",
      });
    }

    if (!Array.isArray(clientInflows)) {
      return res.status(400).json({
        success: false,
        message: "Client inflows must be an array",
      });
    }

    if (!Array.isArray(discountsAndRefunds)) {
      return res.status(400).json({
        success: false,
        message: "Discounts and Refunds must be an array",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const forecastMonths = forecast.forecastMonths || [];

    if (forecastMonths.length !== 3) {
      return res.status(400).json({
        success: false,
        message: "Three valid forecast months are required",
      });
    }

    const submittedRowsById = new Map();

    clientInflows.forEach((row) => {
      if (row._id) {
        submittedRowsById.set(String(row._id), row);
      }
    });

    const existingClientInflows = (
      forecast.cashFlowSummary?.clientInflows || []
    ).filter((row) => row.inflowType !== "ESTIMATED");
    const retainedClientInflows = existingClientInflows.filter((row) =>
      submittedRowsById.has(String(row._id)),
    );

    const normalizedClientInflows = retainedClientInflows.map((row) => {
      const submittedRow = submittedRowsById.get(String(row._id));

      return {
        _id: row._id,
        clientId: row.clientId?._id || row.clientId || null,
        clientCode: row.clientCode || "",
        clientName: row.clientName || "",
        inflowType: row.inflowType,
        rowSource:
          row.rowSource || (row.clientId ? "MASTER_CLIENT" : "REPORT_ONLY"),
        isManuallyAdded: Boolean(row.isManuallyAdded),
        forecastAmounts: normalizeForecastAmounts(
          submittedRow?.forecastAmounts || row.forecastAmounts,
          forecastMonths,
        ),
      };
    });

    const normalizedDiscounts = normalizeForecastAmounts(
      discountsAndRefunds,
      forecastMonths,
      false,
    );

    const normalizedOpeningBalance = Number(openingSurplusDeficit) || 0;

    const cashOutflowTotals = calculateCashOutflowTotals(forecast);

    const calculatedSummary = calculateCashFlowSummary({
      forecastMonths,

      clientInflows: normalizedClientInflows,

      discountsAndRefunds: normalizedDiscounts,

      openingSurplusDeficit: normalizedOpeningBalance,

      cashOutflowTotals,
    });

    forecast.cashFlowSummary = {
      clientInflows: normalizedClientInflows,

      clientInflowsInitialized: true,

      discountsAndRefunds: normalizedDiscounts,

      openingSurplusDeficit: normalizedOpeningBalance,

      previousMonthSurplusDeficit:
        calculatedSummary.previousMonthSurplusDeficit,

      surplusDeficit: calculatedSummary.surplusDeficit,

      updatedBy: req.user?.userId || null,
    };

    await forecast.save();

    return res.status(200).json({
      success: true,

      data: {
        forecastId: forecast._id,

        forecastMonths,

        clientInflows: forecast.cashFlowSummary.clientInflows,

        discountsAndRefunds: forecast.cashFlowSummary.discountsAndRefunds,

        openingSurplusDeficit: forecast.cashFlowSummary.openingSurplusDeficit,

        previousMonthSurplusDeficit:
          forecast.cashFlowSummary.previousMonthSurplusDeficit,

        surplusDeficit: forecast.cashFlowSummary.surplusDeficit,

        cashOutflowTotals,
      },

      message: "Cash Flow Summary updated successfully",
    });
  } catch (error) {
    console.error("Update Cash Flow Summary Error:", error.stack || error);

    if (error.name === "ValidationError") {
      const message = Object.values(error.errors)
        .map((item) => item.message)
        .join(", ");

      return res.status(400).json({
        success: false,
        message,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "One or more submitted values are invalid",
      });
    }

    return res.status(500).json({
      success: false,

      message: error.message || "Unable to update Cash Flow Summary",
    });
  }
};

// Add New Cash Flow Item in Summary Table
export const addCashFlowSummaryItem = async (req, res) => {
  try {
    const { forecastId } = req.params;

    const {
      addType,
      clientId,
      itemName,
      inflowType = "ACTUAL",
      forecastAmounts = [],
    } = req.body;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Cash Flow Forecast ID",
      });
    }

    if (!["MASTER_CLIENT", "REPORT_ONLY"].includes(addType)) {
      return res.status(400).json({
        success: false,
        message: "Add Type must be MASTER_CLIENT or REPORT_ONLY",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const forecastMonths = forecast.forecastMonths || [];

    const normalizedAmounts = normalizeForecastAmounts(
      forecastAmounts,
      forecastMonths,
    );

    if (!forecast.cashFlowSummary) {
      forecast.cashFlowSummary = {
        clientInflows: [],
        discountsAndRefunds: normalizeForecastAmounts([], forecastMonths),
        openingSurplusDeficit: 0,
        previousMonthSurplusDeficit: [],
        surplusDeficit: [],
        updatedBy: null,
      };
    }

    const addedRows = [];

    if (addType === "MASTER_CLIENT") {
      if (!clientId || !mongoose.Types.ObjectId.isValid(clientId)) {
        return res.status(400).json({
          success: false,
          message: "Select a valid Client",
        });
      }

      const client = await Client.findOne({
        _id: clientId,
        isActive: true,
      }).lean();

      if (!client) {
        return res.status(404).json({
          success: false,
          message: "Selected Client was not found or is inactive",
        });
      }

      const existingRows = forecast.cashFlowSummary.clientInflows;
      const clientAlreadyExists = existingRows.some(
        (row) => row.clientId && String(row.clientId) === String(clientId),
      );
      let clientName = client.clientName;

      if (clientAlreadyExists) {
        const existingNames = new Set(
          existingRows.map((row) => row.clientName.trim().toLowerCase()),
        );
        let suffix = 1;

        while (existingNames.has(`${client.clientName}-${suffix}`.toLowerCase())) {
          suffix += 1;
        }

        clientName = `${client.clientName}-${suffix}`;
      }

      const actualRow = {
        clientId: client._id,
        clientCode: client.clientCode || "",
        clientName,
        inflowType: "ACTUAL",
        rowSource: "MASTER_CLIENT",
        isManuallyAdded: true,
        forecastAmounts: normalizedAmounts,
      };

      forecast.cashFlowSummary.clientInflows.push(actualRow);

      addedRows.push(actualRow);
    }

    if (addType === "REPORT_ONLY") {
      const normalizedItemName = itemName?.trim();

      if (!normalizedItemName) {
        return res.status(400).json({
          success: false,
          message: "Cash inflow Item Name is required",
        });
      }

      const normalizedInflowType = "ACTUAL";

      if (String(inflowType).toUpperCase() !== "ACTUAL") {
        return res.status(400).json({
          success: false,
          message: "Only Actual inflows are supported",
        });
      }

      const itemAlreadyExists = forecast.cashFlowSummary.clientInflows.some(
        (row) =>
          row.clientName?.trim().toLowerCase() ===
            normalizedItemName.toLowerCase() &&
          row.inflowType === normalizedInflowType,
      );

      if (itemAlreadyExists) {
        return res.status(409).json({
          success: false,
          message: "An inflow item with this name and type already exists",
        });
      }

      const reportOnlyRow = {
        clientId: null,
        clientCode: "",
        clientName: normalizedItemName,
        inflowType: normalizedInflowType,
        rowSource: "REPORT_ONLY",
        isManuallyAdded: true,
        forecastAmounts: normalizedAmounts,
      };

      forecast.cashFlowSummary.clientInflows.push(reportOnlyRow);

      addedRows.push(reportOnlyRow);
    }

    const discountsAndRefunds = normalizeForecastAmounts(
      forecast.cashFlowSummary.discountsAndRefunds,
      forecastMonths,
    );

    const cashOutflowTotals = calculateCashOutflowTotals(forecast);

    const calculatedSummary = calculateCashFlowSummary({
      forecastMonths,
      clientInflows: forecast.cashFlowSummary.clientInflows,
      discountsAndRefunds,
      openingSurplusDeficit:
        Number(forecast.cashFlowSummary.openingSurplusDeficit) || 0,
      cashOutflowTotals,
    });

    forecast.cashFlowSummary.discountsAndRefunds = discountsAndRefunds;

    forecast.cashFlowSummary.previousMonthSurplusDeficit =
      calculatedSummary.previousMonthSurplusDeficit;

    forecast.cashFlowSummary.surplusDeficit = calculatedSummary.surplusDeficit;

    forecast.cashFlowSummary.updatedBy = req.user?.userId || null;

    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    const savedRows = forecast.cashFlowSummary.clientInflows.slice(
      -addedRows.length,
    );

    return res.status(201).json({
      success: true,
      data: {
        addedRows: savedRows,
        clientInflows: forecast.cashFlowSummary.clientInflows,
        previousMonthSurplusDeficit:
          forecast.cashFlowSummary.previousMonthSurplusDeficit,
        surplusDeficit: forecast.cashFlowSummary.surplusDeficit,
        cashOutflowTotals,
      },
      message:
        addType === "MASTER_CLIENT"
          ? "Client added to Cash Flow Summary successfully"
          : "Report-only Cash Inflow item added successfully",
    });
  } catch (error) {
    console.error("Add Cash Flow Summary Item Error:", error.stack || error);

    if (error.name === "ValidationError") {
      const message = Object.values(error.errors)
        .map((item) => item.message)
        .join(", ");

      return res.status(400).json({
        success: false,
        message,
      });
    }

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to add Cash Flow Summary item",
    });
  }
};

export const deleteCashFlowSummaryItem = async (req, res) => {
  try {
    const { forecastId, itemId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Cash Flow Forecast ID",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(itemId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Cash Flow Summary Item ID",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    if (!forecast.cashFlowSummary) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Summary not found",
      });
    }

    const summaryItem = forecast.cashFlowSummary.clientInflows.id(itemId);

    if (!summaryItem) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Summary item not found",
      });
    }

    const deletedItemName = summaryItem.clientName;

    const deletedItemIds = [String(summaryItem._id)];

    forecast.cashFlowSummary.clientInflows =
      forecast.cashFlowSummary.clientInflows.filter(
        (row) => String(row._id) !== String(itemId),
      );
    forecast.cashFlowSummary.clientInflowsInitialized = true;

    const forecastMonths = forecast.forecastMonths || [];

    const discountsAndRefunds = normalizeForecastAmounts(
      forecast.cashFlowSummary.discountsAndRefunds,
      forecastMonths,
    );

    const openingSurplusDeficit =
      Number(forecast.cashFlowSummary.openingSurplusDeficit) || 0;

    const cashOutflowTotals = calculateCashOutflowTotals(forecast);

    const calculatedSummary = calculateCashFlowSummary({
      forecastMonths,

      clientInflows: forecast.cashFlowSummary.clientInflows,

      discountsAndRefunds,

      openingSurplusDeficit,

      cashOutflowTotals,
    });

    forecast.cashFlowSummary.discountsAndRefunds = discountsAndRefunds;

    forecast.cashFlowSummary.previousMonthSurplusDeficit =
      calculatedSummary.previousMonthSurplusDeficit;

    forecast.cashFlowSummary.surplusDeficit = calculatedSummary.surplusDeficit;

    forecast.cashFlowSummary.updatedBy = req.user?.userId || null;

    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    return res.status(200).json({
      success: true,

      data: {
        deletedItemIds,

        clientInflows: forecast.cashFlowSummary.clientInflows,

        discountsAndRefunds: forecast.cashFlowSummary.discountsAndRefunds,

        openingSurplusDeficit: forecast.cashFlowSummary.openingSurplusDeficit,

        previousMonthSurplusDeficit:
          forecast.cashFlowSummary.previousMonthSurplusDeficit,

        surplusDeficit: forecast.cashFlowSummary.surplusDeficit,

        cashOutflowTotals,
      },

      message: `${deletedItemName} removed from the Cash Flow Summary`,
    });
  } catch (error) {
    console.error("Delete Cash Flow Summary Item Error:", error.stack || error);

    if (error.name === "ValidationError") {
      const message = Object.values(error.errors)
        .map((item) => item.message)
        .join(", ");

      return res.status(400).json({
        success: false,
        message,
      });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "One or more submitted IDs are invalid",
      });
    }

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to remove the Cash Flow Summary item",
    });
  }
};

export const getAvailableSummaryClients = async (req, res) => {
  try {
    const { forecastId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(forecastId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Cash Flow Forecast ID",
      });
    }

    const forecast = await CashFlowForecast.findById(forecastId)
      .select("cashFlowSummary.clientInflows")
      .lean();

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash Flow Forecast not found",
      });
    }

    const clients = await Client.find({
      isActive: true,
    })
      .select("_id clientCode clientName description displayOrder isActive")
      .sort({
        displayOrder: 1,
        clientName: 1,
      })
      .lean();

    return res.status(200).json({
      success: true,
      data: clients,
      message:
        clients.length > 0
          ? "Available Summary Clients retrieved successfully"
          : "No additional Clients are available",
    });
  } catch (error) {
    console.error("Get Available Summary Clients Error:", error.stack || error);

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: "Invalid Cash Flow Forecast ID",
      });
    }

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to retrieve available Summary Clients",
    });
  }
};
