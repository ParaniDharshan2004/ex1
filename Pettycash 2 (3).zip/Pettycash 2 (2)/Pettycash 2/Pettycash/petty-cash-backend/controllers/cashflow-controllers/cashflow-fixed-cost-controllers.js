import CashFlowForecast from "../../models/cashflow-models/cashflow-forecast-model.js";

export const addForecastFixedCost = async (req, res) => {
  try {
    const { id } = req.params;
    const { itemName, description = "", forecastAmounts = [] } = req.body;

    if (!itemName?.trim()) {
      return res.status(400).json({
        success: false,
        message: "Fixed Cost item name is required",
      });
    }

    const forecast = await CashFlowForecast.findById(id);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash-flow forecast not found",
      });
    }

    forecast.fixedCosts.push({
      itemName: itemName.trim(),
      description: description.trim(),
      forecastAmounts,
      createdBy: req.user?.userId || null,
      updatedBy: req.user?.userId || null,
    });

    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    const fixedCost = forecast.fixedCosts[forecast.fixedCosts.length - 1];

    return res.status(201).json({
      success: true,
      data: fixedCost,
      message: "Fixed Cost added successfully",
    });
  } catch (error) {
    console.error("Add Fixed Cost Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to add Fixed Cost",
    });
  }
};

export const updateForecastFixedCost = async (req, res) => {
  try {
    const { id, fixedCostId } = req.params;
    const { itemName, description, forecastAmounts } = req.body;

    if (itemName !== undefined && !itemName.trim()) {
      return res.status(400).json({
        success: false,
        message: "Fixed Cost item name is required",
      });
    }

    if (forecastAmounts !== undefined && !Array.isArray(forecastAmounts)) {
      return res.status(400).json({
        success: false,
        message: "Forecast amounts must be an array",
      });
    }

    const forecast = await CashFlowForecast.findById(id);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash-flow forecast not found",
      });
    }

    const fixedCost = forecast.fixedCosts.id(fixedCostId);

    if (!fixedCost) {
      return res.status(404).json({
        success: false,
        message: "Fixed Cost not found",
      });
    }

    if (itemName !== undefined) fixedCost.itemName = itemName.trim();
    if (description !== undefined) fixedCost.description = description.trim();
    if (forecastAmounts !== undefined) {
      fixedCost.forecastAmounts = forecastAmounts;
    }

    fixedCost.updatedBy = req.user?.userId || null;
    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    return res.status(200).json({
      success: true,
      data: fixedCost,
      message: "Fixed Cost updated successfully",
    });
  } catch (error) {
    console.error("Update Fixed Cost Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to update Fixed Cost",
    });
  }
};

export const deleteForecastFixedCost = async (req, res) => {
  try {
    const { id, fixedCostId } = req.params;

    const forecast = await CashFlowForecast.findById(id);

    if (!forecast) {
      return res.status(404).json({
        success: false,
        message: "Cash-flow forecast not found",
      });
    }

    const fixedCost = forecast.fixedCosts.id(fixedCostId);

    if (!fixedCost) {
      return res.status(404).json({
        success: false,
        message: "Fixed Cost not found",
      });
    }

    fixedCost.deleteOne();
    forecast.updatedBy = req.user?.userId || null;

    await forecast.save();

    return res.status(200).json({
      success: true,
      message: "Fixed Cost removed successfully",
    });
  } catch (error) {
    console.error("Delete Fixed Cost Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Unable to remove Fixed Cost",
    });
  }
};
