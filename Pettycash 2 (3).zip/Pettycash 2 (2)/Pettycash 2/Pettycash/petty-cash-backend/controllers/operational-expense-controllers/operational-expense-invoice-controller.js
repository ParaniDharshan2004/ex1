import mongoose from 'mongoose';
import Client from '../../models/master-models/client-model.js';
import ClientLocation from '../../models/master-models/client-location-model.js';
import CurrencyMaster from '../../models/master-models/currency-master-model.js';
import OperationalExpenseReport from '../../models/operational-expense-models/operational-expense-report-model.js';
import Allocation from '../../models/operational-expense-models/operational-expense-invoice-allocation-model.js';
import Invoice from '../../models/operational-expense-models/operational-expense-invoice-model.js';
import { GST_RATE } from '../../config/invoice-config.js';
import { calculateInvoiceCurrencyAmounts } from '../../services/operational-expense-services/operational-expense-invoice-currency-service.js';
import {
  calculateInvoiceAmounts,
  roundCurrency,
} from '../../services/operational-expense-services/operational-expense-allocation-calculation-service.js';
import { buildInvoiceExpenseBreakdown } from '../../services/operational-expense-services/operational-expense-invoice-preview-service.js';
import { createAuditLog } from '../../services/audit-services.js';

// To get the User
const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

const BASE_CURRENCY = 'INR';

const resolveInvoiceCurrency = async (client, location = null) => {
  const currencyId = location?.currencyId || client.defaultCurrencyId;
  const currency = currencyId
    ? await CurrencyMaster.findOne({ _id: currencyId, isActive: true })
        .select('_id currencyCode exchangeRate')
        .lean()
    : await CurrencyMaster.findOne({
        currencyCode: BASE_CURRENCY,
        isActive: true,
      })
        .select('_id currencyCode exchangeRate')
        .lean();

  if (
    !currency ||
    !Number.isFinite(Number(currency.exchangeRate)) ||
    Number(currency.exchangeRate) <= 0
  ) {
    return null;
  }
  return currency;
};

// To get Short Client Name
const getShortClientName = (clientName) => {
  const words = String(clientName || '')
    .toUpperCase()
    .match(/[A-Z0-9]+/g);
  if (!words?.length)
    throw new Error('Client name cannot form an invoice number');
  const initials = words
    .map((word) => word[0])
    .join('')
    .slice(0, 6);
  return initials.length > 1 ? initials : words[0].slice(0, 6);
};

// To Generate Invoice Number
const allocateInvoiceNumber = async (clientName, invoiceDate) => {
  const clientShortName = getShortClientName(clientName);
  const date = invoiceDate.toISOString().slice(0, 10).replace(/-/g, '');
  const counterId = `${clientShortName}-${date}`;
  const counter = await mongoose.connection
    .collection('operational_expense_invoice_counters')
    .findOneAndUpdate(
      { _id: counterId },
      { $inc: { sequence: 1 } },
      { upsert: true, returnDocument: 'after' },
    );
  const sequence = counter.value?.sequence ?? counter.sequence;
  if (!Number.isInteger(sequence) || sequence < 1) {
    throw new Error('Unable to allocate a unique invoice number');
  }
  return `INV-${clientShortName}-${date}-${String(sequence).padStart(3, '0')}`;
};

// To Record audits
const recordReportStatusAudit = async (req, report, beforeData) => {
  try {
    await createAuditLog({
      req,
      action: 'UPDATE',
      entityType: 'operational_expense_report',
      entityId: report._id,
      changedFields: ['status'],
      beforeData,
      afterData: report.toObject(),
    });
  } catch (error) {
    console.error('Operational Expense Report Status Audit Log Error:', error);
  }
};

// To create a single invoice for selected clients based on location
export const createInvoice = async (req, res) => {
  try {
    const { reportId } = req.params;
    const { clientId, locationId = null, invoiceDate } = req.body || {};
    const parsedInvoiceDate =
      invoiceDate == null ? new Date() : new Date(invoiceDate);
    if (Number.isNaN(parsedInvoiceDate.getTime()))
      return fail(res, 400, 'Invoice date is invalid');
    if (
      !actor(req) ||
      !mongoose.Types.ObjectId.isValid(reportId) ||
      !mongoose.Types.ObjectId.isValid(clientId)
    )
      return fail(res, 400, 'Valid report and client IDs are required');
    if (locationId != null && !mongoose.Types.ObjectId.isValid(locationId))
      return fail(res, 400, 'Location ID is invalid');
    const [report, client, allocation] = await Promise.all([
      OperationalExpenseReport.findById(reportId)
        .select('_id status reportMonth')
        .lean(),
      Client.findOne({ _id: clientId, isActive: true })
        .select('_id clientName defaultCurrencyId')
        .lean(),
      Allocation.findOne({
        operationalExpenseReportId: reportId,
        clientId,
      }).lean(),
    ]);
    if (!report) return fail(res, 404, 'Operational Expense report not found');
    if (report.status !== 'ALLOCATION_PENDING')
      return fail(
        res,
        409,
        'Invoices can only be created while the report is ALLOCATION_PENDING',
      );
    if (!client) return fail(res, 400, 'Client is invalid or inactive');
    if (
      locationId == null &&
      (await ClientLocation.exists({ clientId, isActive: true }))
    )
      return fail(
        res,
        400,
        'Location ID is required for a client with active locations',
      );
    if (!allocation || allocation.allocationStatus !== 'CONFIRMED')
      return fail(
        res,
        409,
        'Confirm the client allocation before generating an invoice',
      );
    const selectedLocation =
      locationId == null
        ? null
        : allocation.locationAllocations.find(
            (item) => String(item.locationId) === String(locationId),
          );
    if (locationId != null && !selectedLocation)
      return fail(
        res,
        400,
        'The selected location is not saved for this client',
      );
    const location =
      locationId == null
        ? null
        : await ClientLocation.findOne({
            _id: locationId,
            clientId,
            isActive: true,
          })
            .select('_id locationCode locationName currencyId')
            .lean();
    if (locationId != null && !location)
      return fail(res, 400, 'Location is invalid or inactive');
    const currency = await resolveInvoiceCurrency(client, location);
    if (!currency)
      return fail(
        res,
        400,
        'The assigned currency is missing, inactive, or has an invalid exchange rate',
      );
    const currencyAmountFields = calculateInvoiceCurrencyAmounts(
      selectedLocation?.amount ?? allocation.clientTotalAmount,
      currency,
      BASE_CURRENCY,
    );
    const amountFields = {
      ...currencyAmountFields,
      ...calculateInvoiceAmounts(currencyAmountFields.invoiceAmount),
    };
    const invoiceNo = await allocateInvoiceNumber(
      client.clientName,
      parsedInvoiceDate,
    );
    const invoiceUpdate = {
      $set: {
        gstRate: GST_RATE,
        status: 'DRAFT',
        ...amountFields,
        locationId: location?._id || null,
        locationCode: location?.locationCode || '',
        locationName: location?.locationName || '',
        expensePeriod: report.reportMonth,
        updatedBy: actor(req),
      },
      $setOnInsert: {
        invoiceNo,
        createdBy: actor(req),
      },
    };
    if (invoiceDate != null) {
      invoiceUpdate.$set.invoiceDate = parsedInvoiceDate;
    } else {
      invoiceUpdate.$setOnInsert.invoiceDate = parsedInvoiceDate;
    }
    const invoice = await Invoice.findOneAndUpdate(
      {
        operationalExpenseReportId: reportId,
        clientId,
        locationCode: location?.locationCode || '',
      },
      invoiceUpdate,
      {
        upsert: true,
        returnDocument: 'after',
        runValidators: true,
        setDefaultsOnInsert: true,
      },
    ).populate('clientId locationId currencyId');
    if (!invoice.invoiceNo || !invoice.invoiceDate || !invoice.expensePeriod) {
      if (!invoice.invoiceNo)
        invoice.invoiceNo = await allocateInvoiceNumber(
          client.clientName,
          invoice.invoiceDate || parsedInvoiceDate,
        );
      if (!invoice.invoiceDate) invoice.invoiceDate = parsedInvoiceDate;
      if (!invoice.expensePeriod) invoice.expensePeriod = report.reportMonth;
      await invoice.save();
    }
    return res.json({
      success: true,
      data: invoice,
      message: 'Invoice generated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError')
      return fail(res, 400, error.message);
    return fail(res, 500, error.message || 'Unable to generate invoice');
  }
};

export const getAllInvoices = async (req, res) => {
  try {
    const invoices = await Invoice.find({})
      .populate('clientId', 'clientName clientCode')
      .populate('clientId', 'clientName clientCode displayOrder')
      .populate(
        'locationId',
        'locationCode locationName gstNumber panNumber tanNumber billingAddress pinCode stateName',
      )
      .populate('currencyId')
      .populate('operationalExpenseReportId', 'reportMonth')
      .sort({ createdAt: -1 });

    const invoicesWithoutLocation = invoices.filter(
      (invoice) => !invoice.locationId,
    );
    const reportIdsWithoutLocation = invoicesWithoutLocation
      .map(
        (invoice) =>
          invoice.operationalExpenseReportId?._id ||
          invoice.operationalExpenseReportId,
      )
      .filter(Boolean);
    const clientIdsWithoutLocation = invoicesWithoutLocation
      .map((invoice) => invoice.clientId?._id || invoice.clientId)
      .filter(Boolean);
    const allocationsWithoutInvoiceLocation =
      reportIdsWithoutLocation.length && clientIdsWithoutLocation.length
        ? await Allocation.find({
            operationalExpenseReportId: { $in: reportIdsWithoutLocation },
            clientId: { $in: clientIdsWithoutLocation },
          })
            .populate(
              'locationAllocations.locationId',
              'locationCode locationName gstNumber panNumber tanNumber billingAddress pinCode stateName',
            )
            .lean()
        : [];
    const allocationByReportAndClient = new Map(
      allocationsWithoutInvoiceLocation.map((allocation) => [
        `${String(allocation.operationalExpenseReportId)}:${String(allocation.clientId)}`,
        allocation,
      ]),
    );
    const clientTaxRecords = clientIdsWithoutLocation.length
      ? await ClientLocation.find({
          clientId: { $in: clientIdsWithoutLocation },
        })
          .select(
            'clientId locationCode locationName gstNumber panNumber tanNumber billingAddress pinCode stateName',
          )
          .lean()
      : [];
    const taxRecordsByClientId = new Map(
      clientTaxRecords.map((record) => [String(record.clientId), record]),
    );
    const invoicesWithClientTaxDetails = invoices.map((invoice) => {
      const invoiceData = invoice.toObject();
      const clientId = invoiceData.clientId?._id || invoiceData.clientId;
      const reportId =
        invoiceData.operationalExpenseReportId?._id ||
        invoiceData.operationalExpenseReportId;
      const allocation = allocationByReportAndClient.get(
        `${String(reportId)}:${String(clientId)}`,
      );
      const allocatedLocations = (allocation?.locationAllocations || []).filter(
        (item) => item.locationId && typeof item.locationId === 'object',
      );
      const matchingLocations = allocatedLocations.filter(
        (item) =>
          Math.round(Number(item.amount) * 100) ===
          Math.round(Number(invoiceData.grandTotal) * 100),
      );
      const inferredLocation =
        matchingLocations.length === 1
          ? matchingLocations[0].locationId
          : allocatedLocations.length === 1
            ? allocatedLocations[0].locationId
            : null;
      const clientDetails = taxRecordsByClientId.get(String(clientId));
      const location =
        invoiceData.locationId || inferredLocation || clientDetails || null;
      const taxRecord = location || clientDetails;

      return {
        ...invoiceData,
        locationId: location,
        clientTaxDetails: {
          gstin: taxRecord?.gstNumber || '',
          pan: taxRecord?.panNumber || '',
          tan: taxRecord?.tanNumber || '',
        },
        clientAddress:
          taxRecord?.billingAddress ||
          invoiceData.locationId?.billingAddress ||
          '',
        clientPinCode:
          taxRecord?.pinCode || invoiceData.locationId?.pinCode || '',
        clientState:
          taxRecord?.stateName || invoiceData.locationId?.stateName || '',
      };
    });

    return res.status(200).json({
      success: true,
      count: invoices.length,
      data: invoicesWithClientTaxDetails,
      message: invoices.length
        ? 'Invoices fetched successfully'
        : 'No invoices found',
    });
  } catch (error) {
    console.error('Get All Invoices Error:', error);

    return res.status(500).json({
      success: false,
      message: 'Unable to fetch invoices',
      error: error.message,
    });
  }
};

// Update the status of invoice DRAFT -> GENERATED
export const updateInvoiceStatus = async (req, res) => {
  try {
    const { reportId, invoiceId } = req.params;
    const { status } = req.body || {};

    if (!actor(req)) {
      return res.status(400).json({
        success: false,
        message: 'User Required',
      });
    }

    if (
      !mongoose.Types.ObjectId.isValid(reportId) ||
      !mongoose.Types.ObjectId.isValid(invoiceId)
    ) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Report ID or Invoice ID',
      });
    }

    const report = await OperationalExpenseReport.findById(reportId);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense Report not found',
      });
    }
    if (report.status === 'INVOICE_GENERATED') {
      return fail(
        res,
        409,
        'Invoices cannot be changed after report generation',
      );
    }
    if (!['DRAFT', 'GENERATED'].includes(status)) {
      return fail(res, 400, 'Invoice status must be DRAFT or GENERATED');
    }
    if (status === 'GENERATED' && report.status !== 'ALLOCATION_PENDING') {
      return fail(
        res,
        409,
        'Invoices can only be generated while the report is ALLOCATION_PENDING',
      );
    }

    const updatedInvoice = await Invoice.findOneAndUpdate(
      {
        _id: invoiceId,
        operationalExpenseReportId: reportId,
      },
      {
        $set: {
          status,
          updatedBy: actor(req),
        },
      },
      {
        new: true,
      },
    );

    if (!updatedInvoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found',
      });
    }
    if (status === 'GENERATED') {
      const [invoiceCount, remainingDraftCount] = await Promise.all([
        Invoice.countDocuments({ operationalExpenseReportId: reportId }),
        Invoice.countDocuments({
          operationalExpenseReportId: reportId,
          status: { $ne: 'GENERATED' },
        }),
      ]);
      if (invoiceCount > 0 && remainingDraftCount === 0) {
        const beforeData = report.toObject();
        report.status = 'INVOICE_GENERATED';
        report.updatedBy = actor(req);
        await report.save();
        await recordReportStatusAudit(req, report, beforeData);
      }
    }

    return res.status(200).json({
      success: true,
      data: updatedInvoice,
      message: 'Invoice status updated successfully',
    });
  } catch (error) {
    console.error('Update Invoice Error:', error);

    return res.status(500).json({
      success: false,
      message: 'Unable to update invoice',
    });
  }
};

export const deleteInvoice = async (req, res) => {
  try {
    const { invoiceId } = req.params;

    const invoice = await Invoice.findById(invoiceId);

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found',
      });
    }

    await Invoice.findByIdAndDelete(invoiceId);

    return res.status(200).json({
      success: true,
      message: 'Invoice deleted successfully',
    });
  } catch (error) {
    console.error('Delete Invoice Error:', error);

    return res.status(500).json({
      success: false,
      message: 'Unable to delete invoice',
      error: error.message,
    });
  }
};

export const previewOperationalExpenseInvoices = async (req, res) => {
  try {
    const { reportId } = req.params;
    const { clientId, locationAllocations = [] } = req.body || {};
    if (
      !actor(req) ||
      !mongoose.Types.ObjectId.isValid(reportId) ||
      !mongoose.Types.ObjectId.isValid(clientId)
    ) {
      return fail(res, 400, 'Valid report and MKPL client IDs are required');
    }
    if (!Array.isArray(locationAllocations)) {
      return fail(res, 400, 'Location allocations must be an array');
    }

    const cleanLocations = locationAllocations.map((item) => ({
      locationId: item?.locationId,
      amount: Number(item?.amount),
    }));
    if (
      cleanLocations.some(
        (item) =>
          !mongoose.Types.ObjectId.isValid(item.locationId) ||
          !Number.isFinite(item.amount) ||
          item.amount < 0,
      )
    ) {
      return fail(res, 400, 'Location allocation data is invalid');
    }

    const [report, mkplClient, activeClients] = await Promise.all([
      OperationalExpenseReport.findById(reportId)
        .select('_id reportMonth status rows fixedAssets totals markup')
        .lean(),
      Client.findOne({ _id: clientId, isActive: true })
        .select('_id clientName clientCode defaultCurrencyId')
        .lean(),
      Client.find({ isActive: true })
        .select('_id clientName clientCode defaultCurrencyId')
        .lean(),
    ]);
    if (!report) return fail(res, 404, 'Operational Expense report not found');
    if (report.status !== 'ALLOCATION_PENDING') {
      return fail(
        res,
        409,
        'Invoices can only be previewed while the report is ALLOCATION_PENDING',
      );
    }
    if (
      !mkplClient ||
      !/MKPL/i.test(`${mkplClient.clientCode || ''} ${mkplClient.clientName || ''}`)
    ) {
      return fail(res, 400, 'The selected client is not an active MKPL client');
    }

    const totalBillable = roundCurrency(
      report.totals?.operationalExpenseTotal || 0,
    );
    const mkplAmount = roundCurrency(
      cleanLocations.reduce((sum, item) => sum + item.amount, 0),
    );
    if (mkplAmount > totalBillable + 0.01) {
      return fail(res, 400, 'MKPL allocation cannot exceed the total billable amount');
    }
    if (cleanLocations.length === 0 && mkplAmount > 0) {
      return fail(res, 400, 'At least one MKPL location is required');
    }
    if (
      new Set(cleanLocations.map((item) => String(item.locationId))).size !==
      cleanLocations.length
    ) {
      return fail(res, 400, 'Duplicate MKPL locations are not allowed');
    }

    const locationIds = cleanLocations.map((item) => item.locationId);
    const locations = locationIds.length
      ? await ClientLocation.find({
          _id: { $in: locationIds },
          clientId: mkplClient._id,
          isActive: true,
        })
          .select('_id clientId locationCode locationName billingName billingAddress pinCode stateName stateCode gstNumber currencyId')
          .lean()
      : [];
    if (locations.length !== cleanLocations.length) {
      return fail(res, 400, 'One or more MKPL locations are invalid or inactive');
    }

    const crklMatches = activeClients.filter(
      (client) =>
        String(client._id) !== String(mkplClient._id) &&
        /CRKL/i.test(`${client.clientCode || ''} ${client.clientName || ''}`),
    );
    const otherActiveClients = activeClients.filter(
      (client) => String(client._id) !== String(mkplClient._id),
    );
    const crklClient =
      crklMatches.length === 1
        ? crklMatches[0]
        : crklMatches.length === 0 && otherActiveClients.length === 1
          ? otherActiveClients[0]
          : null;
    if (!crklClient) {
      return fail(res, 400, 'Unable to identify a unique active CRKL client');
    }

    const previewItems = [];
    const addPreviewItem = async ({
      client,
      location = null,
      type,
      baseAmount,
    }) => {
      if (baseAmount <= 0) return;
      const currency = await resolveInvoiceCurrency(client, location);
      if (!currency) {
        throw new Error(
          `Currency for ${location?.locationName || client.clientName} is missing, inactive, or has an invalid exchange rate`,
        );
      }
      const currencyAmounts = calculateInvoiceCurrencyAmounts(
        baseAmount,
        currency,
        BASE_CURRENCY,
      );
      const taxableAmount = roundCurrency(
        currencyAmounts.invoiceAmount / (1 + GST_RATE / 100),
      );
      const invoiceTotals = {
        taxableAmount,
        gstAmount: roundCurrency(
          currencyAmounts.invoiceAmount - taxableAmount,
        ),
        grandTotal: currencyAmounts.invoiceAmount,
      };
      const breakdown = buildInvoiceExpenseBreakdown(report, baseAmount);
      previewItems.push({
        type,
        invoiceName: location?.billingName || client.clientName,
        entityName: client.clientName,
        baseAmount: currencyAmounts.baseAmount,
        invoiceAmount: currencyAmounts.invoiceAmount,
        invoiceCurrency: currency.currencyCode,
        exchangeRate: currency.exchangeRate,
        markupAmount: breakdown.markupAmount,
        totalBillableAmount: breakdown.totalBillableAmount,
        allocatedExpenseBreakdown: breakdown.expenses,
        taxableAmount: invoiceTotals.taxableAmount,
        gstAmount: invoiceTotals.gstAmount,
        grandTotal: invoiceTotals.grandTotal,
        locationDetails: location
          ? {
              locationName: location.locationName,
              locationCode: location.locationCode,
              billingName: location.billingName,
              billingAddress: location.billingAddress,
              pinCode: location.pinCode,
              stateName: location.stateName,
              stateCode: location.stateCode,
              gstNumber: location.gstNumber,
            }
          : null,
      });
    };

    const mkplBaseAmount = Math.min(mkplAmount, totalBillable);
    const crklBaseAmount = roundCurrency(totalBillable - mkplBaseAmount);
    await addPreviewItem({
      client: crklClient,
      type: 'CRKL Invoice',
      baseAmount: crklBaseAmount,
    });
    await addPreviewItem({
      client: mkplClient,
      type: 'MKPL Invoice',
      baseAmount: mkplBaseAmount,
    });

    const locationsById = new Map(
      locations.map((location) => [String(location._id), location]),
    );
    for (const allocation of cleanLocations) {
      const location = locationsById.get(String(allocation.locationId));
      await addPreviewItem({
        client: mkplClient,
        location,
        type: `${location.locationName} Invoice`,
        baseAmount: allocation.amount,
      });
    }

    return res.status(200).json({
      success: true,
      data: {
        reportMonth: report.reportMonth,
        totalBillable,
        invoices: previewItems,
      },
    });
  } catch (error) {
    console.error('Preview Operational Expense Invoices Error:', error);
    return fail(res, 500, error.message || 'Unable to preview invoices');
  }
};

// To create a bulk invoice based on clients list and their locations
export const generateOperationalExpenseInvoices = async (req, res) => {
  try {
    const { reportId } = req.params;

    const [report, allocations] = await Promise.all([
      OperationalExpenseReport.findById(reportId).select(
        '_id reportMonth status',
      ),
      Allocation.find({ operationalExpenseReportId: reportId }),
    ]);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }
    const { invoiceDate } = req.body || {};
    const parsedInvoiceDate =
      invoiceDate == null ? new Date() : new Date(invoiceDate);
    if (Number.isNaN(parsedInvoiceDate.getTime())) {
      return res.status(400).json({
        success: false,
        message: 'Invoice date is invalid',
      });
    }

    if (!allocations.length) {
      return res.status(404).json({
        success: false,
        message: 'No allocations found',
      });
    }

    const existingInvoices = await Invoice.find({
      operationalExpenseReportId: reportId,
    }).lean();
    const expectedInvoiceCount = allocations.reduce(
      (count, allocation) =>
        count + Math.max(allocation.locationAllocations?.length || 0, 1),
      0,
    );

    if (existingInvoices.length > 0) {
      if (
        existingInvoices.length === expectedInvoiceCount &&
        existingInvoices.every((invoice) => invoice.status === 'GENERATED')
      ) {
        const beforeData = report.toObject();
        const updatedReport = await OperationalExpenseReport.findOneAndUpdate(
          { _id: reportId, status: 'ALLOCATION_PENDING' },
          {
            $set: {
              status: 'INVOICE_GENERATED',
              updatedBy: actor(req),
            },
          },
          { new: true, runValidators: true },
        );
        if (!updatedReport) {
          return res.status(409).json({
            success: false,
            message:
              'Report status changed while reconciling existing invoices',
          });
        }
        await recordReportStatusAudit(req, updatedReport, beforeData);
        return res.status(200).json({
          success: true,
          count: existingInvoices.length,
          data: existingInvoices,
          message:
            'Existing invoices confirmed and report status updated successfully',
        });
      }
      return res.status(400).json({
        success: false,
        message:
          'Invoices already exist for this report but do not match the complete generated allocation set',
      });
    }

    const clients = await Client.find({
      _id: { $in: allocations.map((allocation) => allocation.clientId) },
    })
      .select('_id clientName defaultCurrencyId')
      .lean();
    const clientsById = new Map(
      clients.map((client) => [String(client._id), client]),
    );
    const locationIds = allocations.flatMap((allocation) =>
      (allocation.locationAllocations || [])
        .map((item) => item.locationId)
        .filter(Boolean),
    );
    const locations = locationIds.length
      ? await ClientLocation.find({ _id: { $in: locationIds } })
          .select('_id clientId locationCode locationName currencyId isActive')
          .lean()
      : [];
    const locationsById = new Map(
      locations.map((location) => [String(location._id), location]),
    );
    const invoices = [];

    for (const allocation of allocations) {
      const client = clientsById.get(String(allocation.clientId));
      if (!client) {
        return res.status(400).json({
          success: false,
          message: `Client ${allocation.clientId} was not found`,
        });
      }
      // Client has locations
      if (allocation.locationAllocations?.length > 0) {
        for (const location of allocation.locationAllocations) {
          const clientLocation = locationsById.get(String(location.locationId));
          if (
            !clientLocation ||
            String(clientLocation.clientId) !== String(allocation.clientId) ||
            !clientLocation.isActive
          ) {
            return res.status(400).json({
              success: false,
              message: `Location ${location.locationId} is missing, inactive, or does not belong to the client`,
            });
          }
          const currency = await resolveInvoiceCurrency(client, clientLocation);
          if (!currency) {
            return res.status(400).json({
              success: false,
              message: `Currency for location ${location.locationId} is missing, inactive, or has an invalid exchange rate`,
            });
          }
          const currencyAmountFields = calculateInvoiceCurrencyAmounts(
            location.amount,
            currency,
            BASE_CURRENCY,
          );
          const taxableAmount = roundCurrency(
            currencyAmountFields.invoiceAmount / (1 + GST_RATE / 100),
          );
          const amountFields = {
            ...currencyAmountFields,
            taxableAmount,
            gstAmount: roundCurrency(
              currencyAmountFields.invoiceAmount - taxableAmount,
            ),
            grandTotal: currencyAmountFields.invoiceAmount,
          };
          const invoiceNo = await allocateInvoiceNumber(
            client.clientName,
            parsedInvoiceDate,
          );

          invoices.push({
            invoiceNo,
            invoiceDate: parsedInvoiceDate,
            expensePeriod: report.reportMonth,
            operationalExpenseReportId: reportId,
            clientId: allocation.clientId,
            locationId: location.locationId,
            locationCode: clientLocation.locationCode,
            locationName: clientLocation.locationName,
            ...amountFields,
            gstRate: GST_RATE,

            status: 'GENERATED',

            createdBy: actor(req),
            updatedBy: actor(req),
          });
        }
      }
      // Client has no locations
      else {
        const clientHasLocations = await ClientLocation.exists({
          clientId: allocation.clientId,
          isActive: true,
        });
        if (clientHasLocations) {
          return res.status(400).json({
            success: false,
            message: `Add location IDs and amounts to the allocation for client ${allocation.clientId} before generating invoices`,
          });
        }
        const currency = await resolveInvoiceCurrency(client);
        if (!currency) {
          return res.status(400).json({
            success: false,
            message: `Currency for client ${allocation.clientId} is missing, inactive, or has an invalid exchange rate`,
          });
        }
        const currencyAmountFields = calculateInvoiceCurrencyAmounts(
          allocation.clientTotalAmount,
          currency,
          BASE_CURRENCY,
        );
        const taxableAmount = roundCurrency(
          currencyAmountFields.invoiceAmount / (1 + GST_RATE / 100),
        );
        const amountFields = {
          ...currencyAmountFields,
          taxableAmount,
          gstAmount: roundCurrency(
            currencyAmountFields.invoiceAmount - taxableAmount,
          ),
          grandTotal: currencyAmountFields.invoiceAmount,
        };
        const invoiceNo = await allocateInvoiceNumber(
          client.clientName,
          parsedInvoiceDate,
        );

        invoices.push({
          invoiceNo,
          invoiceDate: parsedInvoiceDate,
          expensePeriod: report.reportMonth,
          operationalExpenseReportId: reportId,

          clientId: allocation.clientId,
          locationId: null,
          locationCode: '',
          locationName: '',
          ...amountFields,
          gstRate: GST_RATE,

          status: 'GENERATED',

          createdBy: actor(req),
          updatedBy: actor(req),
        });
      }
    }

    const session = await mongoose.startSession();
    let createdInvoices;
    let updatedReport;
    const beforeData = report.toObject();
    try {
      await session.withTransaction(async () => {
        createdInvoices = await Invoice.insertMany(invoices, { session });
        updatedReport = await OperationalExpenseReport.findOneAndUpdate(
          { _id: reportId, status: 'ALLOCATION_PENDING' },
          {
            $set: {
              status: 'INVOICE_GENERATED',
              updatedBy: actor(req),
            },
          },
          {
            new: true,
            runValidators: true,
            session,
          },
        );
        if (!updatedReport) {
          throw new Error(
            'Report status changed before invoices could be finalized',
          );
        }
      });
    } finally {
      await session.endSession();
    }
    await recordReportStatusAudit(req, updatedReport, beforeData);

    return res.status(201).json({
      success: true,
      count: createdInvoices.length,
      data: createdInvoices,
      message: 'Invoices generated successfully',
    });
  } catch (error) {
    console.error('Generate Invoice Error:', error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
