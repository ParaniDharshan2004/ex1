import PettyCash from "../../models/pettycash-models/pettycash-model.js";
import CashInflow from "../../models/pettycash-models/cashinflow-model.js";

// Get Component Wise Summary
export const getComponentExpenseSummary = async (req, res) => {
  try {
    const { month, year } = req.query;

    const monthString = `${year}-${String(month).padStart(2, "0")}`;

    const startDate = new Date(`${monthString}-01`);

    const endDate = new Date(startDate);

    endDate.setMonth(endDate.getMonth() + 1);

    endDate.setDate(0);

    const report = await PettyCash.aggregate([
      {
        $match: {
          transactionDate: {
            $gte: startDate,
            $lte: endDate,
          },
          status: "POSTED",
        },
      },
      {
        $group: {
          _id: "$componentId",

          totalTransactions: {
            $sum: 1,
          },

          totalExpense: {
            $sum: "$amount",
          },

          totalReimbursement: {
            $sum: {
              $cond: [
                {
                  $eq: ["$transactionType", "REIMBURSEMENT"],
                },
                "$amount",
                0,
              ],
            },
          },
        },
      },
      {
        $lookup: {
          from: "components",
          localField: "_id",
          foreignField: "_id",
          as: "component",
        },
      },
      {
        $unwind: "$component",
      },
      {
        $project: {
          _id: 0,
          componentId: "$component._id",
          componentCode: "$component.componentCode",
          component: "$component.componentName",
          totalTransactions: 1,
          totalExpense: 1,
          totalReimbursement: 1,
        },
      },
      {
        $sort: {
          totalExpense: -1,
        },
      },
    ]);

    return res.status(200).json({
      success: true,
      data: report,
      message: "Component expense summary retrieved successfully",
    });
  } catch (error) {
    console.error("Component Expense Summary Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve expense summary",
    });
  }
};

// Get Combined Ledger
export const getLedger = async (req, res) => {
  try {
    const cashInflows = await CashInflow.find().sort({
      inflowDate: 1,
    });
    const expenses = await PettyCash.find()
      .populate("componentId", "componentCode componentName")
      .populate("subComponentId", "subComponentCode subComponentName")
      .populate("spentByUserId", "username")
      .populate("reimbursedToUserId", "username")
      .sort({
        transactionDate: 1,
      });

    const inflowRows = cashInflows.map((item) => ({
      _id: item._id,
      source: "CASH_INFLOW",

      date: item.inflowDate,

      transactionType: "Cash Added",

      component: "-",

      cashAdded: item.amount,

      expense: 0,

      remarks: item.remarks,

      cashInflowData: item,
    }));

    const expenseRows = expenses.map((item) => ({
      _id: item._id,
      source: "PETTY_CASH",

      date: item.transactionDate,

      transactionType: "Expense",

      component: item.componentId?.componentName || "-",

      cashAdded: 0,

      expense: item.amount,

      pettyCashData: item,
    }));

    const ledger = [...inflowRows, ...expenseRows];

    ledger.sort((a, b) => new Date(a.date) - new Date(b.date));

    let runningBalance = 0;

    const result = ledger.map((item) => {
      runningBalance = runningBalance + item.cashAdded - item.expense;

      return {
        ...item,
        balance: runningBalance,
      };
    });

    return res.status(200).json({
      success: true,
      count: result.length,
      data: result,
    });
  } catch (error) {
    console.error("Get Ledger Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve ledger",
    });
  }
};
