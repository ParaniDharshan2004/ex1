import SenderAccount from "../../models/account-models/sender-account-model.js";

export const createSenderAccount = async (req, res) => {
  try {
    const {
      accountName,
      accountHolderName,
      bankName,
      maskedAccountNumber,
      accountType,
      isActive = true,
    } = req.body;

    // Validation
    if (
      !accountName ||
      !accountHolderName ||
      !bankName ||
      !maskedAccountNumber ||
      !accountType
    ) {
      return res.status(400).json({
        success: false,
        message: "All required fields must be provided.",
      });
    }

    // Validate last 4 digits
    if (!/^\d{4}$/.test(maskedAccountNumber)) {
      return res.status(400).json({
        success: false,
        message: "Account number must contain exactly 4 numeric digits.",
      });
    }

    // Get latest account code
    const lastAccount = await SenderAccount.findOne()
      .sort({ createdAt: -1 })
      .select("accountCode")
      .lean();

    let nextNumber = 1;

    if (lastAccount?.accountCode) {
      const currentNumber = parseInt(
        lastAccount.accountCode.replace("ACC-", ""),
        10,
      );

      nextNumber = currentNumber + 1;
    }

    const accountCode = `ACC-${String(nextNumber).padStart(3, "0")}`;

    // Generate masked account number
    const finalMaskedAccountNumber = `XXXXXX${maskedAccountNumber}`;

    const senderAccount = await SenderAccount.create({
      accountCode,
      accountName,
      accountHolderName,
      bankName,
      maskedAccountNumber: finalMaskedAccountNumber,
      accountType,
      isActive,
      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    });

    return res.status(201).json({
      success: true,
      data: senderAccount,
      message: "Sender account created successfully",
    });
  } catch (error) {
    console.error("Create Sender Account Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getAllSenderAccounts = async (req, res) => {
  try {
    const senderAccounts = await SenderAccount.find().sort({ accountCode: 1 });

    return res.status(200).json({
      success: true,
      count: senderAccounts.length,
      data: senderAccounts,
      message: "Sender accounts retrieved successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getSenderAccountById = async (req, res) => {
  try {
    const senderAccount = await SenderAccount.findById(req.params.id);

    if (!senderAccount) {
      return res.status(404).json({
        success: false,
        message: "Sender account not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: senderAccount,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateSenderAccount = async (req, res) => {
  try {
    const senderAccount = await SenderAccount.findByIdAndUpdate(
      req.params.id,
      {
        ...req.body,
        updatedBy: req.user.userId,
      },
      {
        new: true,
        runValidators: true,
      },
    );

    if (!senderAccount) {
      return res.status(404).json({
        success: false,
        message: "Sender account not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: senderAccount,
      message: "Sender account updated successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const deleteSenderAccount = async (req, res) => {
  try {
    const senderAccount = await SenderAccount.findByIdAndUpdate(
      req.params.id,
      {
        isActive: false,
        updatedBy: req.user.userId,
      },
      {
        new: true,
      },
    );

    if (!senderAccount) {
      return res.status(404).json({
        success: false,
        message: "Sender account not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Sender account deactivated successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
