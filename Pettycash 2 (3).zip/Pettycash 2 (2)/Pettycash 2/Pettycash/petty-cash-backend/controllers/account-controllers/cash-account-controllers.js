import PettyCashAccount from "../../models/account-models/cash-account-model.js";

export const createPettyCashAccount = async (req, res) => {
  try {
    const pettyCashAccount = await PettyCashAccount.create({
      ...req.body,
      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    });

    return res.status(201).json({
      success: true,
      data: pettyCashAccount,
      message: "Petty cash account created successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getAllPettyCashAccounts = async (req, res) => {
  try {
    const pettyCashAccounts = await PettyCashAccount.find()
      .populate("receiverUserId", "username email employeeCode")
      .populate("lastCashInflowId", "cashInflowCode amount")
      .populate("lastTransactionId", "transactionCode amount")
      .sort({
        accountCode: 1,
      });

    return res.status(200).json({
      success: true,
      count: pettyCashAccounts.length,
      data: pettyCashAccounts,
      message: "Petty cash accounts retrieved successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getPettyCashAccountById = async (req, res) => {
  try {
    const pettyCashAccount = await PettyCashAccount.findById(req.params.id)
      .populate("receiverUserId", "username email employeeCode")
      .populate("lastCashInflowId", "cashInflowCode amount")
      .populate("lastTransactionId", "transactionCode amount");

    if (!pettyCashAccount) {
      return res.status(404).json({
        success: false,
        message: "Petty cash account not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: pettyCashAccount,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updatePettyCashAccount = async (req, res) => {
  try {
    const pettyCashAccount = await PettyCashAccount.findByIdAndUpdate(
      req.params.id,
      {
        ...req.body,
        updatedBy: req.user.userId,
      },
      {
        new: true,
        runValidators: true,
      },
    );

    if (!pettyCashAccount) {
      return res.status(404).json({
        success: false,
        message: "Petty cash account not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: pettyCashAccount,
      message: "Petty cash account updated successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const deletePettyCashAccount = async (req, res) => {
  try {
    const pettyCashAccount = await PettyCashAccount.findByIdAndUpdate(
      req.params.id,
      {
        isActive: false,
        updatedBy: req.user.userId,
      },
      {
        new: true,
      },
    );

    if (!pettyCashAccount) {
      return res.status(404).json({
        success: false,
        message: "Petty cash account not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Petty cash account deactivated successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
