import Component from "../models/master-models/component-model.js";
import SubComponent from "../models/master-models/subcomponent.js";
import PettyCash from "../models/pettycash-models/pettycash-model.js";
import FinancialCategory from "../models/master-models/financial-category-model.js";
import mongoose from "mongoose";
import { rebuildMonthlySummary } from "../services/monthly-summary-service.js";

export const migrateComponents = async (req, res) => {
  try {
    const userId = req.user.userId;

    const result = await Component.updateMany(
      {},
      {
        $set: {
          isOperationalBudget: false,
          createdBy: userId,
          updatedBy: userId,
        },
        $unset: {
          approvalThreshold: "",
        },
      },
    );

    return res.status(200).json({
      success: true,
      modifiedCount: result.modifiedCount,
      migratedBy: userId,
      message: "Component migration completed successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const bulkCreateComponents = async (req, res) => {
  try {
    const components = req.body;

    // Validate request body
    if (!Array.isArray(components) || components.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Request body must be a non-empty array",
      });
    }

    /*
     * Collect unique Financial Category IDs
     * supplied in the request.
     */
    const financialCategoryIds = [
      ...new Set(
        components
          .filter((component) => component.financialCategoryId)
          .map((component) => String(component.financialCategoryId)),
      ),
    ];

    /*
     * Validate Financial Category ObjectIds.
     */
    const invalidObjectId = financialCategoryIds.find(
      (id) => !mongoose.Types.ObjectId.isValid(id),
    );

    if (invalidObjectId) {
      return res.status(400).json({
        success: false,
        message: `Invalid financial category ID: ${invalidObjectId}`,
      });
    }

    /*
     * Verify that all supplied Financial Categories
     * exist and are active.
     */
    const financialCategories = await FinancialCategory.find({
      _id: {
        $in: financialCategoryIds,
      },
      isActive: true,
    })
      .select("_id")
      .lean();

    const validCategoryIds = new Set(
      financialCategories.map((category) => category._id.toString()),
    );

    /*
     * Check whether any supplied category ID
     * does not exist or is inactive.
     */
    const missingCategoryId = financialCategoryIds.find(
      (id) => !validCategoryIds.has(id),
    );

    if (missingCategoryId) {
      return res.status(400).json({
        success: false,
        message:
          "One or more financial categories do not exist or are inactive",
      });
    }

    /*
     * Every Cash Flow Analysis component
     * must have a Financial Category.
     */
    const unclassifiedCashFlowComponent = components.find(
      (component) =>
        component.isCashFlowAnalysis === true && !component.financialCategoryId,
    );

    if (unclassifiedCashFlowComponent) {
      return res.status(400).json({
        success: false,
        message: `Financial category is required for cash flow component: ${unclassifiedCashFlowComponent.componentName}`,
      });
    }

    /*
     * Prepare Components for insertion.
     */
    const componentsToInsert = components.map((component, index) => ({
      componentCode: component.componentCode,

      componentName: component.componentName,

      description: component.description ?? null,

      isPettyCash: component.isPettyCash ?? false,

      isCashFlowAnalysis: component.isCashFlowAnalysis ?? false,

      /*
       * Keep Financial Category only when the
       * component participates in Cash Flow Analysis.
       */
      financialCategoryId: component.isCashFlowAnalysis
        ? component.financialCategoryId
        : null,

      isOperationalBudget: component.isOperationalBudget ?? false,

      isFullyLoadedCost: component.isFullyLoadedCost ?? false,

      requiresBill: component.requiresBill ?? false,

      displayOrder: component.displayOrder ?? index + 1,

      isActive: component.isActive ?? true,

      createdBy: req.user?.userId ?? null,

      updatedBy: req.user?.userId ?? null,
    }));

    /*
     * Insert all Components.
     */
    const insertedComponents = await Component.insertMany(componentsToInsert, {
      ordered: true,
    });

    return res.status(201).json({
      success: true,
      count: insertedComponents.length,
      data: insertedComponents,
      message: "Components created successfully",
    });
  } catch (error) {
    /*
     * Duplicate Component Code / Component Name.
     */
    if (error?.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Component code or component name already exists",
        duplicate: error.keyValue ?? null,
      });
    }

    /*
     * Mongoose validation error.
     */
    if (error?.name === "ValidationError") {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    /*
     * Unexpected server error.
     */
    return res.status(500).json({
      success: false,
      message: "Failed to create components",
      error: error.message,
    });
  }
};

export const bulkCreateSubComponents = async (req, res) => {
  try {
    const subComponents = req.body;
    if (!Array.isArray(subComponents) || subComponents.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Request body must be a non-empty array",
      });
    }
    const subComponentsToInsert = subComponents.map((subComponent) => ({
      componentId: subComponent.componentId,
      subComponentCode: subComponent.subComponentCode,
      subComponentName: subComponent.subComponentName,
      description: subComponent.description,
      requiresBill: subComponent.requiresBill,
      displayOrder: subComponent.displayOrder,
      isActive: subComponent.isActive ?? true,
      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    }));
    const insertedSubComponents = await SubComponent.insertMany(
      subComponentsToInsert,
      {
        ordered: true,
      },
    );
    return res.status(201).json({
      success: true,
      count: insertedSubComponents.length,
      data: insertedSubComponents,
      message: "SubComponents created successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const migrateComponentFields = async (req, res) => {
  try {
    const components = await Component.find();

    for (const item of components) {
      await Component.replaceOne(
        { _id: item._id },
        {
          _id: item._id,

          componentCode: item.componentCode,
          componentName: item.componentName,
          description: item.description,

          isPettyCash: item.isPettyCash,

          isCashFlowAnalysis: item.isCashFlowAnalysis ?? item.isCashFlow,

          isOperationalExpense:
            item.isOperationalExpense ?? item.isOperationalBudget,

          isFullyLoadedCost: item.isFullyLoadedCost,

          requiresBill: item.requiresBill ?? false,

          displayOrder: item.displayOrder,

          isActive: item.isActive,

          createdBy: item.createdBy,

          updatedBy: req.user.userId,

          createdAt: item.createdAt,
          updatedAt: new Date(),

          version: item.version ?? 0,
        },
      );
    }

    return res.status(200).json({
      success: true,
      count: components.length,
      message: "Components migrated successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const migrateSubComponentFields = async (req, res) => {
  try {
    const subComponents = await SubComponent.find();

    for (const item of subComponents) {
      await SubComponent.replaceOne(
        { _id: item._id },
        {
          _id: item._id,

          componentId: item.componentId,

          subComponentCode: item.subComponentCode,

          subComponentName: item.subComponentName,

          isPettyCash: false,

          isCashFlowAnalysis: false,

          isOperationalExpense: false,

          isFullyLoadedCost: false,

          requiresBill: item.requiresBill ?? false,

          displayOrder: item.displayOrder,

          isActive: item.isActive,

          createdBy: item.createdBy,

          updatedBy: req.user.userId,

          createdAt: item.createdAt,

          updatedAt: new Date(),

          version: item.version ?? 0,
        },
      );
    }

    return res.status(200).json({
      success: true,
      count: subComponents.length,
      message: "SubComponents migrated successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const bulkCreateTransactions = async (req, res) => {
  try {
    const transactions = req.body;

    if (!Array.isArray(transactions) || transactions.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Request body must be a non-empty array",
      });
    }

    const currentYear = new Date().getFullYear();

    const lastTransaction = await PettyCash.findOne({
      entryNo: new RegExp(`^PE-${currentYear}-`),
    })
      .sort({ entryNo: -1 })
      .select("entryNo");

    let nextNumber = 1;

    if (lastTransaction?.entryNo) {
      nextNumber = Number(lastTransaction.entryNo.split("-")[2]) + 1;
    }

    const records = transactions.map((transaction, index) => ({
      ...transaction,

      entryNo: `PE-${currentYear}-${String(nextNumber + index).padStart(
        6,
        "0",
      )}`,

      enteredBy: transaction.enteredBy || req.user.userId,
      postedBy: transaction.postedBy || req.user.userId,

      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    }));

    const insertedRecords = await PettyCash.insertMany(records, {
      ordered: true,
    });

    // Rebuild monthly summaries
    const affectedMonths = [
      ...new Set(
        insertedRecords.map((item) =>
          new Date(item.transactionDate).toISOString().slice(0, 7),
        ),
      ),
    ];

    await Promise.all(
      affectedMonths.map((month) => rebuildMonthlySummary(month)),
    );

    return res.status(201).json({
      success: true,
      count: insertedRecords.length,
      data: insertedRecords,
      message: "Transactions created successfully",
    });
  } catch (error) {
    console.log(error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
