import CurrencyMaster from '../../models/master-models/currency-master-model.js';

const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;

export const createCurrency = async (req, res) => {
  try {
    const { currencyCode, currencyName, currencySymbol } = req.body;

    if (
      !actor(req) ||
      !currencyCode?.trim() ||
      !currencyName?.trim() ||
      !currencySymbol?.trim()
    ) {
      return res.status(400).json({
        success: false,
        message: 'Currency code, name and symbol are required',
      });
    }

    const existingCurrency = await CurrencyMaster.findOne({
      $or: [
        { currencyCode: currencyCode.trim().toUpperCase() },
        { currencyName: currencyName.trim() },
      ],
    });

    if (existingCurrency) {
      return res.status(409).json({
        success: false,
        message: 'Currency already exists',
      });
    }

    const currency = await CurrencyMaster.create({
      currencyCode: currencyCode.trim().toUpperCase(),
      currencyName: currencyName.trim(),
      currencySymbol: currencySymbol.trim(),
      createdBy: actor(req),
      updatedBy: actor(req),
    });

    return res.status(201).json({
      success: true,
      data: currency,
      message: 'Currency created successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getAllCurrencies = async (req, res) => {
  try {
    const currencies = await CurrencyMaster.find({})
      .sort({ currencyCode: 1 })
      .lean();

    return res.status(200).json({
      success: true,
      data: currencies,
      message: 'Currencies fetched successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getCurrencyById = async (req, res) => {
  try {
    const { currencyId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(currencyId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Currency ID',
      });
    }

    const currency = await CurrencyMaster.findById(currencyId);

    if (!currency) {
      return res.status(404).json({
        success: false,
        message: 'Currency not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: currency,
      message: 'Currency fetched successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateCurrency = async (req, res) => {
  try {
    const { currencyId } = req.params;
    const { currencyName, currencySymbol, isActive } = req.body;

    if (!mongoose.Types.ObjectId.isValid(currencyId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Currency ID',
      });
    }

    const currency = await CurrencyMaster.findByIdAndUpdate(
      currencyId,
      {
        ...(currencyName !== undefined && { currencyName }),
        ...(currencySymbol !== undefined && { currencySymbol }),
        ...(isActive !== undefined && { isActive }),
        updatedBy: actor(req),
      },
      {
        new: true,
        runValidators: true,
      },
    );

    if (!currency) {
      return res.status(404).json({
        success: false,
        message: 'Currency not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: currency,
      message: 'Currency updated successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const toggleCurrencyStatus = async (req, res) => {
  try {
    const { currencyId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(currencyId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Currency ID',
      });
    }

    const currency = await CurrencyMaster.findById(currencyId);

    if (!currency) {
      return res.status(404).json({
        success: false,
        message: 'Currency not found',
      });
    }

    currency.isActive = !currency.isActive;
    currency.updatedBy = actor(req);

    await currency.save();

    return res.status(200).json({
      success: true,
      data: currency,
      message: `Currency ${
        currency.isActive ? 'activated' : 'deactivated'
      } successfully`,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
