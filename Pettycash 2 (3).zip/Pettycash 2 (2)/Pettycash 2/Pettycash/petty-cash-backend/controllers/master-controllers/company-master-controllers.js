import mongoose from 'mongoose';
import CompanyMaster from '../../models/master-models/company-master-model.js';
import { createAuditLog } from '../../services/audit-services.js';

const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;
const editableFields = [
  'companyName',
  'gstNumber',
  'panNumber',
  'tanNumber',
  'companyAddress',
  'city',
  'state',
  'pinCode',
  'country',
  'beneficiaryName',
  'beneficiaryAccountNo',
  'bankName',
  'branch',
  'ifscCode',
];
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

const writeAudit = async (req, action, company, beforeData, afterData) => {
  try {
    await createAuditLog({
      req,
      action,
      entityType: 'company_master',
      entityId: company._id,
      changedFields: editableFields,
      beforeData,
      afterData,
    });
  } catch (error) {
    console.error('Company Master audit error:', error);
  }
};

export const createCompany = async (req, res) => {
  try {
    const userId = actor(req);
    if (!userId) return fail(res, 400, 'User is required');

    const body = req.body || {};
    const companyData = Object.fromEntries(
      editableFields
        .filter((field) => body[field] !== undefined)
        .map((field) => [field, body[field]]),
    );
    const company = await CompanyMaster.create({
      ...companyData,
      createdBy: userId,
      updatedBy: userId,
    });
    await writeAudit(req, 'CREATE', company, null, company.toObject());

    return res.status(201).json({
      success: true,
      data: company,
      message: 'Company created successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError') {
      return fail(res, 400, error.message);
    }
    console.error('Create Company Error:', error);
    return fail(res, 500, 'Unable to create company');
  }
};

export const getAllCompanies = async (req, res) => {
  try {
    const companies = await CompanyMaster.find({})
      .sort({ companyName: 1 })
      .lean();
    return res.json({
      success: true,
      data: companies,
      message: 'Companies retrieved successfully',
    });
  } catch (error) {
    console.error('Get All Companies Error:', error);
    return fail(res, 500, 'Unable to fetch companies');
  }
};

export const getCompanyById = async (req, res) => {
  try {
    const { companyId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(companyId)) {
      return fail(res, 400, 'Invalid company ID');
    }
    const company = await CompanyMaster.findById(companyId).lean();
    if (!company) return fail(res, 404, 'Company not found');

    return res.json({
      success: true,
      data: company,
      message: 'Company retrieved successfully',
    });
  } catch (error) {
    console.error('Get Company Error:', error);
    return fail(res, 500, 'Unable to fetch company');
  }
};

export const updateCompany = async (req, res) => {
  try {
    const userId = actor(req);
    const { companyId } = req.params;
    if (!userId || !mongoose.Types.ObjectId.isValid(companyId)) {
      return fail(res, 400, 'Valid user and company ID are required');
    }

    const company = await CompanyMaster.findById(companyId);
    if (!company) return fail(res, 404, 'Company not found');

    const body = req.body || {};
    const beforeData = company.toObject();
    for (const field of editableFields) {
      if (body[field] !== undefined) company[field] = body[field];
    }
    company.updatedBy = userId;
    await company.save();
    await writeAudit(req, 'UPDATE', company, beforeData, company.toObject());

    return res.json({
      success: true,
      data: company,
      message: 'Company updated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError') {
      return fail(res, 400, error.message);
    }
    console.error('Update Company Error:', error);
    return fail(res, 500, 'Unable to update company');
  }
};

export const deleteCompany = async (req, res) => {
  try {
    const { companyId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(companyId)) {
      return fail(res, 400, 'Invalid company ID');
    }
    const company = await CompanyMaster.findById(companyId);
    if (!company) return fail(res, 404, 'Company not found');

    await writeAudit(req, 'REMOVE', company, company.toObject(), null);
    await company.deleteOne();
    return res.json({
      success: true,
      message: 'Company deleted successfully',
    });
  } catch (error) {
    console.error('Delete Company Error:', error);
    return fail(res, 500, 'Unable to delete company');
  }
};
