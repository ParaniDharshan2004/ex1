import mongoose from "mongoose";
import Component from "../../models/master-models/component-model.js";
import FinancialCategory from "../../models/master-models/financial-category-model.js";
import FinancialSubCategory from "../../models/master-models/financial-subcategory-model.js";
import { createAuditLog } from "../../services/audit-services.js";

export const createComponent = async (req, res) => {
  try {
    const componentName = String(req.body.componentName || "").trim();

    const existingComponent = await Component.findOne({ componentName })
      .collation({ locale: "en", strength: 2 })
      .select("_id componentName isActive isCashFlowAnalysis")
      .lean();

    if (existingComponent) {
      return res.status(409).json({
        success: false,
        message: `A Component named "${existingComponent.componentName}" already exists in Master Data. Choose Report Only or use the existing Component.`,
      });
    }

    const lastComponent = await Component.findOne().sort({ componentCode: -1 });

    let nextNumber = 1;

    if (lastComponent?.componentCode) {
      nextNumber = Number(lastComponent.componentCode.replace("CMP-", "")) + 1;
    }

    const componentCode = `CMP-${String(nextNumber).padStart(3, "0")}`;

    const component = await Component.create({
      componentCode,

      componentName,

      description: req.body.description || null,

      financialCategoryId: req.body.financialCategoryId || null,

      financialSubCategoryId: req.body.financialSubCategoryId || null,

      displayOrder: req.body.displayOrder,

      isPettyCash: Boolean(req.body.isPettyCash),

      isCashFlowAnalysis: Boolean(req.body.isCashFlowAnalysis),

      isOperationalExpense: Boolean(req.body.isOperationalExpense),

      isFullyLoadedCost: Boolean(req.body.isFullyLoadedCost),

      isActive: req.body.isActive !== false,

      createdBy: req.user.userId,

      updatedBy: req.user.userId,
    });

    try {
      await createAuditLog({
        req,
        action: "CREATE",
        entityType: "component",
        entityId: component._id,
        changedFields: Object.keys(component.toObject()),
        beforeData: null,
        afterData: component.toObject(),
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    return res.status(201).json({
      success: true,
      data: component,
      message: "Component created successfully",
    });
  } catch (error) {
    if (error.code === 11000 && error.keyPattern?.componentName) {
      return res.status(409).json({
        success: false,
        message:
          "A Component with this name already exists in Master Data. Choose Report Only or use the existing Component.",
      });
    }

    console.error("Create Component Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to create Component. Please try again.",
    });
  }
};

// Get All Components
export const getAllComponents = async (req, res) => {
  try {
    const components = await Component.find().sort({ displayOrder: 1 });
    res.status(200).json({
      success: true,
      data: components,
      message: "Components retrieved successfully",
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to Fetch the Component details",
    });
  }
};

export const updateComponent = async (req, res) => {
  try {
    const oldComponent = await Component.findById(req.params.id);

    if (!oldComponent) {
      return res.status(404).json({
        success: false,
        message: "Component not found",
      });
    }

    const component = await Component.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      },
    );

    try {
      await createAuditLog({
        req,
        action: "UPDATE",
        entityType: "component",
        entityId: component._id,
        changedFields: Object.keys(req.body),
        beforeData: oldComponent.toObject(),
        afterData: component.toObject(),
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    return res.status(200).json({
      success: true,
      data: component,
      message: "Component updated successfully",
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      message: "Unable to update component. Please try again.",
    });
  }
};

export const deleteComponent = async (req, res) => {
  try {
    const component = await Component.findByIdAndDelete(req.params.id);
    if (!component) {
      return res
        .status(404)
        .json({ success: false, message: "Component not found" });
    }

    try {
      await createAuditLog({
        req,
        action: "REMOVE",
        entityType: "component",
        entityId: component._id,
        changedFields: ["deleted"],
        beforeData: component.toObject(),
        afterData: null,
      });
    } catch (auditError) {
      console.error("Audit Log Error:", auditError);
    }

    res
      .status(200)
      .json({ success: true, message: "Component deleted successfully" });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to delete component. Please try again.",
    });
  }
};

// Financial Categories
export const getFinancialCategories = async (req, res) => {
  try {
    const financialCategories = await FinancialCategory.find({
      isActive: true,
    })
      .select("_id categoryCode categoryName description displayOrder isActive")
      .sort({
        displayOrder: 1,
        categoryName: 1,
      })
      .lean();

    return res.status(200).json({
      success: true,
      data: financialCategories,
      message: "Financial Categories retrieved successfully",
    });
  } catch (error) {
    console.error("Get Financial Categories Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve Financial Categories",
    });
  }
};

// Get Financial Sub Categories
export const getFinancialSubCategoriesByCategory = async (req, res) => {
  try {
    const { financialCategoryId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(financialCategoryId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid Financial Category ID",
      });
    }

    const financialCategory = await FinancialCategory.findOne({
      _id: financialCategoryId,
      isActive: true,
    })
      .select("_id categoryCode categoryName")
      .lean();

    if (!financialCategory) {
      return res.status(404).json({
        success: false,
        message: "Financial Category not found or inactive",
      });
    }

    const financialSubCategories = await FinancialSubCategory.find({
      financialCategoryId,
      isActive: true,
    })
      .select(
        "_id financialCategoryId subCategoryCode subCategoryName description displayOrder isActive",
      )
      .sort({
        displayOrder: 1,
        subCategoryName: 1,
      })
      .lean();

    return res.status(200).json({
      success: true,
      data: {
        financialCategory,
        financialSubCategories,
      },
      message: financialSubCategories.length
        ? "Financial Subcategories retrieved successfully"
        : "The selected Financial Category has no subcategories",
    });
  } catch (error) {
    console.error("Get Financial Subcategories Error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve Financial Subcategories",
    });
  }
};
