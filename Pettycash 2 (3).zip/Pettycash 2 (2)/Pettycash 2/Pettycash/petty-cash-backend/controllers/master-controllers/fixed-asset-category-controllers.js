import FixedAssetCategoryMaster from '../../models/master-models/fixed-assets-category-model.js';

const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

export const createFixedAssetCategory = async (req, res) => {
  try {
    const { categoryName, description } = req.body;

    if (!categoryName?.trim())
      return fail(res, 400, 'Category name is required');

    const exists = await FixedAssetCategoryMaster.findOne({
      categoryName: categoryName.trim(),
    });

    if (exists) return fail(res, 409, 'Fixed asset category already exists');

    const category = await FixedAssetCategoryMaster.create({
      categoryName: categoryName.trim(),
      description,
      createdBy: actor(req),
      updatedBy: actor(req),
    });

    return res.status(201).json({
      success: true,
      data: category,
      message: 'Fixed asset category created successfully',
    });
  } catch (error) {
    return fail(
      res,
      500,
      error.message || 'Unable to create fixed asset category',
    );
  }
};

export const getAllFixedAssetCategories = async (req, res) => {
  try {
    const categories = await FixedAssetCategoryMaster.find({}).sort({
      displayOrder: 1,
      categoryName: 1,
    });

    return res.json({
      success: true,
      data: categories,
      message: 'Fixed asset categories retrieved successfully',
    });
  } catch (error) {
    return fail(
      res,
      500,
      error.message || 'Unable to fetch fixed asset categories',
    );
  }
};

export const getFixedAssetCategoryById = async (req, res) => {
  try {
    const { categoryId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(categoryId))
      return fail(res, 400, 'Invalid category ID');

    const category = await FixedAssetCategoryMaster.findById(categoryId);

    if (!category) return fail(res, 404, 'Fixed asset category not found');

    return res.json({
      success: true,
      data: category,
      message: 'Fixed asset category retrieved successfully',
    });
  } catch (error) {
    return fail(
      res,
      500,
      error.message || 'Unable to fetch fixed asset category',
    );
  }
};

export const updateFixedAssetCategory = async (req, res) => {
  try {
    const { categoryId } = req.params;
    const { categoryName, description, displayOrder, isActive } = req.body;

    if (!mongoose.Types.ObjectId.isValid(categoryId))
      return fail(res, 400, 'Invalid category ID');

    const category = await FixedAssetCategoryMaster.findById(categoryId);

    if (!category) return fail(res, 404, 'Fixed asset category not found');

    if (categoryName !== undefined) category.categoryName = categoryName.trim();

    if (description !== undefined) category.description = description;

    if (displayOrder !== undefined) category.displayOrder = displayOrder;

    if (typeof isActive === 'boolean') category.isActive = isActive;

    category.updatedBy = actor(req);

    await category.save();

    return res.json({
      success: true,
      data: category,
      message: 'Fixed asset category updated successfully',
    });
  } catch (error) {
    return fail(
      res,
      500,
      error.message || 'Unable to update fixed asset category',
    );
  }
};

export const deleteFixedAssetCategory = async (req, res) => {
  try {
    const { categoryId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(categoryId))
      return fail(res, 400, 'Invalid category ID');

    const category = await FixedAssetCategoryMaster.findByIdAndUpdate(
      categoryId,
      {
        isActive: false,
        updatedBy: actor(req),
      },
      { new: true },
    );

    if (!category) return fail(res, 404, 'Fixed asset category not found');

    return res.json({
      success: true,
      data: category,
      message: 'Fixed asset category deleted successfully',
    });
  } catch (error) {
    return fail(
      res,
      500,
      error.message || 'Unable to delete fixed asset category',
    );
  }
};
