import express from "express";
import {
  createClient,
  deactivateClient,
  deleteClient,
  getActiveClients,
  getAllClients,
  getClientById,
  updateClient,
} from "../../controllers/master-controllers/client-controllers.js";
import { authenticateUser } from "../../middlewares/auth-middleware.js";

const clientRouter = express.Router();

clientRouter.post("/create", authenticateUser, createClient);
clientRouter.get("/getAllClients", authenticateUser, getAllClients);
clientRouter.get("/getActiveClients", authenticateUser, getActiveClients);
clientRouter.get("/getClientById/:id", authenticateUser, getClientById);
clientRouter.patch("/updateClient/:id", authenticateUser, updateClient);
clientRouter.patch("/deactivateClient/:id/deactivate", authenticateUser, deactivateClient);
clientRouter.delete("/:id", authenticateUser, deleteClient);


export default clientRouter;
