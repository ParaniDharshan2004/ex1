import express from "express";
import {
  createComponent,
  deleteComponent,
  getAllComponents,
  getFinancialCategories,
  getFinancialSubCategoriesByCategory,
  updateComponent,
} from "../../controllers/master-controllers/component-controllers.js";
import { authenticateUser } from "../../middlewares/auth-middleware.js";
import { getActivePettyCashComponents } from "../../controllers/pettycash-controllers/pettycash-controllers.js";

const componentRouter = express.Router();

// Components
componentRouter.post("/createComponent", authenticateUser, createComponent);
componentRouter.get("/getAllComponents", authenticateUser, getAllComponents);
componentRouter.get(
  "/getActivePettyCashComponents",
  authenticateUser,
  getActivePettyCashComponents,
);
componentRouter.patch(
  "/updateComponent/:id",
  authenticateUser,
  updateComponent,
);
componentRouter.delete(
  "/deleteComponent/:id",
  authenticateUser,
  deleteComponent,
);
componentRouter.get("/financial-categories", getFinancialCategories);

componentRouter.get(
  "/financial-subcategories/:financialCategoryId",
  getFinancialSubCategoriesByCategory,
);

export default componentRouter;
