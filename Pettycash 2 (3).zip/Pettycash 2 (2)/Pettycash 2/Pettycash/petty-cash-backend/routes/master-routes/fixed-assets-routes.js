import express from 'express';
import { authenticateUser } from '../../middlewares/auth-middleware.js';
import {
  createFixedAsset,
  getAllFixedAssets,
  getFixedAssetById,
  updateFixedAsset,
  deleteFixedAsset,
} from '../../controllers/master-controllers/fixed-assets-controllers.js';

const fixedAssetRouter = express.Router();

fixedAssetRouter.post('/createFixedAsset', authenticateUser, createFixedAsset);
fixedAssetRouter.get('/getAllFixedAssets', authenticateUser, getAllFixedAssets);

fixedAssetRouter.get(
  '/getFixedAssetById/:assetId',
  authenticateUser,
  getFixedAssetById,
);

fixedAssetRouter.patch(
  '/updateFixedAsset/:assetId',
  authenticateUser,
  updateFixedAsset,
);

fixedAssetRouter.delete(
  '/deleteFixedAsset/:assetId',
  authenticateUser,
  deleteFixedAsset,
);

export default fixedAssetRouter;
