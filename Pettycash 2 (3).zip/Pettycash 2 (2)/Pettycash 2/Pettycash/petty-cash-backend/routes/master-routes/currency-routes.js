import express from 'express';
import { authenticateUser } from '../../middlewares/auth-middleware.js';
import {
  createCurrency,
  getAllCurrencies,
  getCurrencyById,
  toggleCurrencyStatus,
  updateCurrency,
} from '../../controllers/master-controllers/currency-master-controllers.js';

const currencyRouter = express.Router();

currencyRouter.post('/createCurrency', authenticateUser, createCurrency);
currencyRouter.get('/getAllCurrencies', authenticateUser, getAllCurrencies);
currencyRouter.get(
  '/getCurrencyById/:currencyId',
  authenticateUser,
  getCurrencyById,
);
currencyRouter.patch(
  '/updateCurrency/:currencyId',
  authenticateUser,
  updateCurrency,
);
currencyRouter.patch(
  '/toggleCurrencyStatus/:currencyId',
  authenticateUser,
  toggleCurrencyStatus,
);

export default currencyRouter;
