import express from 'express';
import { authenticateUser } from '../../middlewares/auth-middleware.js';
import {
  createFixedAssetCategory,
  getAllFixedAssetCategories,
  getFixedAssetCategoryById,
  updateFixedAssetCategory,
  deleteFixedAssetCategory,
} from '../../controllers/master-controllers/fixed-asset-category-controllers.js';

const fixedAssetCategoryRouter = express.Router();

fixedAssetCategoryRouter.post(
  '/createFixedAssetCategory',
  authenticateUser,
  createFixedAssetCategory,
);

fixedAssetCategoryRouter.get(
  '/getAllFixedAssetCategories',
  authenticateUser,
  getAllFixedAssetCategories,
);

fixedAssetCategoryRouter.get(
  '/getFixedAssetCategoryById/:categoryId',
  authenticateUser,
  getFixedAssetCategoryById,
);

fixedAssetCategoryRouter.patch(
  '/updateFixedAssetCategory/:categoryId',
  authenticateUser,
  updateFixedAssetCategory,
);

fixedAssetCategoryRouter.delete(
  '/deleteFixedAssetCategory/:categoryId',
  authenticateUser,
  deleteFixedAssetCategory,
);

export default fixedAssetCategoryRouter;
