import express from "express";
import { authenticateUser } from "../../middlewares/auth-middleware.js";

import {
  createSenderAccount,
  getAllSenderAccounts,
  getSenderAccountById,
  updateSenderAccount,
  deleteSenderAccount,
} from "../../controllers/account-controllers/sender-account-controllers.js";

const senderAccountRouter = express.Router();

senderAccountRouter.post("/createSenderAccount", authenticateUser, createSenderAccount);

senderAccountRouter.get("/getAllSenderAccount", authenticateUser, getAllSenderAccounts);

senderAccountRouter.get("/getSenderAccountById/:id", authenticateUser, getSenderAccountById);

senderAccountRouter.patch("/updateSenderAccount/:id", authenticateUser, updateSenderAccount);

senderAccountRouter.delete("/deleteSenderAccount/:id", authenticateUser, deleteSenderAccount);

export default senderAccountRouter;
