import express from "express";
import {
  bulkCreateComponents,
  bulkCreateSubComponents,
  bulkCreateTransactions,
  migrateComponentFields,
  migrateComponents,
  migrateSubComponentFields,
} from "../controllers/migration-controller.js";
import { authenticateUser } from "../middlewares/auth-middleware.js";

const router = express.Router();

router.post("/components", authenticateUser, migrateComponents);
router.post("/bulk-create", authenticateUser, bulkCreateComponents);
router.post("/bulk-subcreate", authenticateUser, bulkCreateSubComponents);
router.post("/component-fields", authenticateUser, migrateComponentFields);
router.post(
  "/subcomponent-fields",
  authenticateUser,
  migrateSubComponentFields,
);

router.post(
  "/bulkCreateTransactions",
  authenticateUser,
  bulkCreateTransactions,
);

export default router;
