import express from "express";

import {
  getComponentExpenseSummary,
  getLedger,
} from "../../controllers/pettycash-controllers/pettycash-report-controllers.js";

const reportRouter = express.Router();

reportRouter.get("/componentExpenseSummary", getComponentExpenseSummary);
reportRouter.get("/pettyCashLedger", getLedger);

export default reportRouter;
