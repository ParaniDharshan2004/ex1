import express from "express";
import {
  createTransaction,
  deleteTransaction,
  getAllTransactions,
  updateTransaction,
} from "../../controllers/pettycash-controllers/pettycash-controllers.js";
import { authenticateUser } from "../../middlewares/auth-middleware.js";

const transactionRouter = express.Router();

// Transactions
transactionRouter.post(
  "/createTransaction",
  authenticateUser,
  createTransaction,
);
transactionRouter.get("/getAllTransactions", getAllTransactions);
transactionRouter.patch(
  "/updateTransaction/:id",
  authenticateUser,
  updateTransaction,
);
transactionRouter.delete(
  "/deleteTransaction/:id",
  authenticateUser,
  deleteTransaction,
);

export default transactionRouter;
