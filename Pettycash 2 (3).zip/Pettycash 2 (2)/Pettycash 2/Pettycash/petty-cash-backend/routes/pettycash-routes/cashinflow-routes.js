import express from "express";
import {
  createCashInflow,
  deleteCashInflow,
  getAllCashInflows,
  getCashInflowById,
  updateCashInflow,
} from "../../controllers/pettycash-controllers/cashinflow-controllers.js";
import { authenticateUser } from "../../middlewares/auth-middleware.js";

const cashInflowRouter = express.Router();

// Cash Inflow
cashInflowRouter.post("/createCashInflow", authenticateUser, createCashInflow);
cashInflowRouter.get("/getAllCashInflows", authenticateUser, getAllCashInflows);
cashInflowRouter.get("/getCashInflow/:id", authenticateUser, getCashInflowById);
cashInflowRouter.patch(
  "/updateCashInflow/:id",
  authenticateUser,
  updateCashInflow,
);
cashInflowRouter.delete(
  "/deleteCashInflow/:id",
  authenticateUser,
  deleteCashInflow,
);

export default cashInflowRouter;
