import express from "express";
import {
  createRole,
  getAllRoles,
  updateRole,
  deleteRole,
} from "../../controllers/auth-controllers/role-controllers.js";

const roleRouter = express.Router();

roleRouter.post("/createRole", createRole);
roleRouter.get("/getAllRoles", getAllRoles);
roleRouter.put("/updateRole/:id", updateRole);
roleRouter.delete("/deleteRole/:id", deleteRole);

export default roleRouter;