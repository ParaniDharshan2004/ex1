import express from "express";

import {
  createCashFlowEntry,
  deleteCashFlowEntry,
  getAllCashFlowEntries,
  getCashFlowEntryById,
  getCashFlowEntryOptions,
  updateCashFlowEntry,
} from "../../controllers/cashflow-controllers/cashflow-controllers.js";
import { authenticateUser } from "../../middlewares/auth-middleware.js";
import {
  generateCashFlowForecast,
  getAllCashFlowForecasts,
  getCashFlowForecastById,
  deleteCashFlowForecast,
  updateCashFlowForecastStatus,
  updateCashFlowForecastRows,
} from "../../controllers/cashflow-controllers/cashflow-forecast-controllers.js";
import {
  addForecastFixedCost,
  updateForecastFixedCost,
  deleteForecastFixedCost,
} from "../../controllers/cashflow-controllers/cashflow-fixed-cost-controllers.js";
import {
  addForecastRow,
  discardUnmatchedTallyRow,
  deleteForecastRow,
  getAvailableForecastComponents,
} from "../../controllers/cashflow-controllers/cashflow-forecast-row-controllers.js";
import {
  getCashFlowSummary,
  updateCashFlowSummary,
  addCashFlowSummaryItem,
  deleteCashFlowSummaryItem,
  getAvailableSummaryClients,
} from "../../controllers/cashflow-controllers/cashflow-summary-controllers.js";

const cashFlowRouter = express.Router();

cashFlowRouter.get("/options", authenticateUser, getCashFlowEntryOptions);
cashFlowRouter.post("/generate", authenticateUser, generateCashFlowForecast);

// CRUD Cash Flow Controllers
cashFlowRouter.post("/entries", authenticateUser, createCashFlowEntry);
cashFlowRouter.get("/entries", authenticateUser, getAllCashFlowEntries);
cashFlowRouter.get("/entries/:id", authenticateUser, getCashFlowEntryById);
cashFlowRouter.put("/entries/:id", authenticateUser, updateCashFlowEntry);
cashFlowRouter.delete("/entries/:id", authenticateUser, deleteCashFlowEntry);

// Generate the Forcast controllers
cashFlowRouter.get(
  "/forecast/all",
  authenticateUser,
  getAllCashFlowForecasts,
);
cashFlowRouter.delete(
  "/forecast/:id",
  authenticateUser,
  deleteCashFlowForecast,
);
cashFlowRouter.patch(
  "/forecast/:id/status",
  authenticateUser,
  updateCashFlowForecastStatus,
);
cashFlowRouter.get("/forecast/:id", getCashFlowForecastById);
cashFlowRouter.get(
  "/forecast/:forecastId/cash-flow-summary",
  authenticateUser,
  getCashFlowSummary,
);
cashFlowRouter.patch(
  "/forecast/:forecastId/cash-flow-summary",
  authenticateUser,
  updateCashFlowSummary,
);
cashFlowRouter.post(
  "/forecast/:forecastId/cash-summary/item",
  authenticateUser,
  addCashFlowSummaryItem,
);
cashFlowRouter.delete(
  "/forecast/:forecastId/cash-summary/item/:itemId",
  authenticateUser,
  deleteCashFlowSummaryItem,
);

cashFlowRouter.patch("/forecast/:id/rows", updateCashFlowForecastRows);
cashFlowRouter.get(
  "/forecast/:forecastId/available-components",
  getAvailableForecastComponents,
);
cashFlowRouter.get(
  "/forecast/:forecastId/cash-summary/available-clients",
  authenticateUser,
  getAvailableSummaryClients,
);
cashFlowRouter.post("/forecast/:forecastId/row", addForecastRow);
cashFlowRouter.delete(
  "/forecast/:forecastId/unmatched-tally-row",
  authenticateUser,
  discardUnmatchedTallyRow,
);
cashFlowRouter.delete("/forecast/:forecastId/row/:rowId", deleteForecastRow);

// Add Fixed Cost Controllers
cashFlowRouter.post("/forecast/:id/fixed-cost", addForecastFixedCost);
cashFlowRouter.patch(
  "/forecast/:id/fixed-cost/:fixedCostId",
  authenticateUser,
  updateForecastFixedCost,
);
cashFlowRouter.delete(
  "/forecast/:id/fixed-cost/:fixedCostId",
  deleteForecastFixedCost,
);

export default cashFlowRouter;
