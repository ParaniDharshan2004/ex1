export const calculateCashFlowSummary = ({
  forecastMonths = [],
  clientInflows = [],
  discountsAndRefunds = [],
  openingSurplusDeficit = 0,
  cashOutflowTotals = [],
}) => {
  const getAmountForMonth = (amounts = [], month) => {
    const matchingAmount = amounts.find((item) => item.month === month);

    return Number(matchingAmount?.amount) || 0;
  };

  const previousMonthSurplusDeficit = [];
  const surplusDeficit = [];

  forecastMonths.forEach((month, index) => {
    const totalClientInflow = clientInflows.reduce((total, clientRow) => {
      return total + getAmountForMonth(clientRow.forecastAmounts, month);
    }, 0);

    const discountAmount = getAmountForMonth(discountsAndRefunds, month);

    const previousMonthAmount =
      index === 0
        ? Number(openingSurplusDeficit) || 0
        : Number(surplusDeficit[index - 1]?.amount) || 0;

    const cashOutflow = Number(cashOutflowTotals[index]) || 0;

    const calculatedAmount =
      totalClientInflow + discountAmount + previousMonthAmount - cashOutflow;

    previousMonthSurplusDeficit.push({
      month,
      amount: previousMonthAmount,
    });

    surplusDeficit.push({
      month,
      amount: calculatedAmount,
    });
  });

  return {
    previousMonthSurplusDeficit,
    surplusDeficit,
  };
};
