export const normalizeName = (value) =>
  String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "")
    .trim();

export const createNameSet = (...values) => {
  const names = values.flat(Infinity).filter(Boolean);

  return [...new Set(names.map(normalizeName).filter(Boolean))];
};

export const findMatchingRecord = (tallyName, records) => {
  return records.find((record) =>
    record.matchingNames.some(
      (name) => name === tallyName,
    ),
  );
};

export const getNextThreeMonths = (sourceMonth) => {
  const [year, month] = sourceMonth.split("-").map(Number);

  return [1, 2, 3].map((offset) => {
    const date = new Date(
      Date.UTC(year, month - 1 + offset, 1),
    );

    return [
      date.getUTCFullYear(),
      String(date.getUTCMonth() + 1).padStart(2, "0"),
    ].join("-");
  });
};