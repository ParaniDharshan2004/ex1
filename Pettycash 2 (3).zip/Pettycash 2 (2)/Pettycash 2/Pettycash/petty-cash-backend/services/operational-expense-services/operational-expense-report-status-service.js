export const OPERATIONAL_EXPENSE_REPORT_STATUSES = Object.freeze({
  REVIEW_PENDING: 'REVIEW_PENDING',
  ALLOCATION_PENDING: 'ALLOCATION_PENDING',
  INVOICE_GENERATED: 'INVOICE_GENERATED',
});

const allowedTransitions = new Map([
  [
    OPERATIONAL_EXPENSE_REPORT_STATUSES.REVIEW_PENDING,
    OPERATIONAL_EXPENSE_REPORT_STATUSES.ALLOCATION_PENDING,
  ],
  [
    OPERATIONAL_EXPENSE_REPORT_STATUSES.ALLOCATION_PENDING,
    OPERATIONAL_EXPENSE_REPORT_STATUSES.INVOICE_GENERATED,
  ],
]);

export const isValidOperationalExpenseReportTransition = (
  currentStatus,
  nextStatus,
) => allowedTransitions.get(currentStatus) === nextStatus;
