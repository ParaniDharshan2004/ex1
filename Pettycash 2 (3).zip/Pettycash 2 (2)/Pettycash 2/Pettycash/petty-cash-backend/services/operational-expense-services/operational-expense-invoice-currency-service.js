import { roundCurrency } from './operational-expense-allocation-calculation-service.js';

export const calculateInvoiceCurrencyAmounts = (
  baseAmount,
  currency,
  baseCurrency = 'INR',
) => {
  const parsedBaseAmount = Number(baseAmount);
  const exchangeRate = Number(currency?.exchangeRate);

  if (!Number.isFinite(parsedBaseAmount) || parsedBaseAmount < 0) {
    throw new RangeError('Base amount must be a non-negative number');
  }
  if (!Number.isFinite(exchangeRate) || exchangeRate <= 0) {
    throw new RangeError('Exchange rate must be a positive number');
  }
  if (!currency?.currencyCode) {
    throw new TypeError('Currency code is required');
  }

  const roundedBaseAmount = roundCurrency(parsedBaseAmount);
  const invoiceAmount = roundCurrency(roundedBaseAmount / exchangeRate);

  return {
    baseCurrency,
    invoiceCurrency: currency.currencyCode,
    currencyId: currency._id,
    exchangeRate,
    baseAmount: roundedBaseAmount,
    invoiceAmount,
  };
};
