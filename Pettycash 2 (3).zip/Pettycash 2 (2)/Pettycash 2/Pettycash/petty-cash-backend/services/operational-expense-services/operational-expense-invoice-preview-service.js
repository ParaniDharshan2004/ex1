import { roundCurrency } from './operational-expense-allocation-calculation-service.js';

const getRowCategory = (row) =>
  String(
    row.financialCategoryName ||
      row.financialCategory?.name ||
      row.category ||
      'Other Expenses',
  ).trim() || 'Other Expenses';

const getRowDescription = (row) =>
  row.componentName ||
  row.description ||
  row.name ||
  row.ledgerName ||
  'Expense';

export const buildInvoiceExpenseBreakdown = (report, invoiceBaseAmount) => {
  const totalBillable = Math.max(
    0,
    Number(report.totals?.operationalExpenseTotal) || 0,
  );
  const allocationRatio =
    totalBillable > 0
      ? Math.min(1, Math.max(0, Number(invoiceBaseAmount) / totalBillable))
      : 0;
  const scaleAmount = (amount) =>
    roundCurrency((Number(amount) || 0) * allocationRatio);
  const expenses = (report.rows || [])
    .map((row) => ({
      category: getRowCategory(row),
      description: getRowDescription(row),
      amount: scaleAmount(row.amount),
    }))
    .filter((row) => row.amount !== 0);
  const fixedAssets = (report.fixedAssets || [])
    .map((asset) => ({
      category: 'Fixed Assets',
      description: asset.itemName || asset.description || 'Fixed asset',
      amount: scaleAmount(asset.amount),
    }))
    .filter((row) => row.amount !== 0);
  const markupAmount = scaleAmount(
    report.totals?.markupAmount ?? report.markup?.amount,
  );
  const expectedExpenseAmount = roundCurrency(
    Number(invoiceBaseAmount) - markupAmount,
  );
  const currentExpenseAmount = roundCurrency(
    [...expenses, ...fixedAssets].reduce(
      (total, expense) => total + expense.amount,
      0,
    ),
  );
  const expenseAdjustment = roundCurrency(
    expectedExpenseAmount - currentExpenseAmount,
  );
  if (expenseAdjustment !== 0) {
    const expenseLine = [...expenses, ...fixedAssets].find(
      (expense) => expense.category === 'Indirect Cost',
    ) || [...expenses, ...fixedAssets][0];
    if (expenseLine) {
      expenseLine.amount = roundCurrency(expenseLine.amount + expenseAdjustment);
      if (expenseLine.amount === 0) {
        const index = [...expenses, ...fixedAssets].indexOf(expenseLine);
        if (index < expenses.length) expenses.splice(index, 1);
        else fixedAssets.splice(index - expenses.length, 1);
      }
    } else if (expenseAdjustment > 0) {
      expenses.push({
        category: 'Other Expenses',
        description: 'Other expenses',
        amount: expenseAdjustment,
      });
    }
  }

  return {
    expenses: [...expenses, ...fixedAssets],
    markupAmount,
    totalBillableAmount: roundCurrency(Number(invoiceBaseAmount) || 0),
  };
};
