export class OperationalExpenseInputError extends Error {}

const normalizeName = (value) =>
  String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

const createNameSet = (...values) =>
  [...new Set(values.flat(Infinity).map(normalizeName).filter(Boolean))];

const findMatchingRecord = (normalizedName, records) =>
  records.find((record) => record.matchingNames.includes(normalizedName));

export const matchOperationalExpenseTallyRows = ({
  tallyRows,
  components,
  subComponents,
}) => {
  const componentRecords = components.map((component) => ({
    component,
    matchingNames: createNameSet(
      component.componentName,
      component.componentCode,
      component.description,
    ),
  }));

  const subComponentRecords = subComponents.map((subComponent) => ({
    subComponent,
    matchingNames: createNameSet(
      subComponent.subComponentName,
      subComponent.subComponentCode,
    ),
  }));

  const componentAmounts = new Map(
    components.map((component) => [
      String(component._id),
      {
        directAmounts: [],
        subComponentAmounts: [],
        matchedTallyLedgers: [],
      },
    ]),
  );
  const unmatchedTallyRows = [];

  tallyRows.forEach((row, index) => {
    const tallyLedgerName = String(
      row.tallyLedgerName ||
        row.ledgerName ||
        row.component ||
        row.particulars ||
        row.name ||
        "",
    ).trim();
    const amount = Number(
      row.sourceAmount ?? row.amount ?? row.debitAmount ?? 0,
    );
    const excelRowNumber = Number(row.excelRowNumber) || index + 1;
    const normalizedName = normalizeName(tallyLedgerName);

    if (!tallyLedgerName || !Number.isFinite(amount) || amount < 0) {
      throw new OperationalExpenseInputError(
        `Tally row ${index + 1} must include a ledger name and a non-negative finite amount`,
      );
    }

    const componentMatch = findMatchingRecord(
      normalizedName,
      componentRecords,
    );
    if (componentMatch) {
      componentAmounts
        .get(String(componentMatch.component._id))
        .directAmounts.push({
          tallyLedgerName,
          amount,
          excelRowNumber,
          matchType: "HEAD_COMPONENT",
        });
      return;
    }

    const subComponentMatch = findMatchingRecord(
      normalizedName,
      subComponentRecords,
    );
    if (subComponentMatch) {
      const subComponent = subComponentMatch.subComponent;
      const accumulator = componentAmounts.get(String(subComponent.componentId));

      if (accumulator) {
        accumulator.subComponentAmounts.push({
          tallyLedgerName,
          amount,
          excelRowNumber,
          matchType: "SUBCOMPONENT",
          subComponentId: subComponent._id,
          subComponentName: subComponent.subComponentName,
        });
        return;
      }
    }

    unmatchedTallyRows.push({
      tallyLedgerName,
      amount,
      excelRowNumber,
      reason: "No active operational-expense component or subcomponent matched",
    });
  });

  return { componentAmounts, unmatchedTallyRows };
};