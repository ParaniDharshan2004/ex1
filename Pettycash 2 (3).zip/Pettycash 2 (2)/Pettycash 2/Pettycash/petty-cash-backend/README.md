# petty-cash-backend

This repository contains the Express/Mongoose API for the petty-cash project.

## Operational Expense Reports

Operational Expense routes are mounted at `/api/operational-expense` and require
an authenticated bearer token.

| Method | Path                                  | Description                                                                         |
| ------ | ------------------------------------- | ----------------------------------------------------------------------------------- |
| POST   | `/generateOperationalExpenseReport`   | Generate a monthly report from active Operational Expense components and Tally rows |
| GET    | `/`                                   | List reports; optionally filter with `reportMonth` and `status` query parameters    |
| GET    | `/:id`                                | Retrieve one report, including its fixed assets                                     |
| PUT    | `/updateOperationalExpenseReport/:id` | Update report fields until invoices are generated                                   |
| PATCH  | `/:reportId/status`                   | Advance report status through the workflow                                          |
| DELETE | `/deleteOperationalExpenseReport/:id` | Delete a report until invoices are generated                                        |
| GET    | `/:reportId/fixed-costs`              | List a report's fixed assets                                                        |
| GET    | `/:reportId/fixed-costs/:fixedCostId` | Retrieve one fixed asset entry                                                      |
| POST   | `/:reportId/fixed-costs`              | Add a fixed asset entry to a report                                                 |
| PATCH  | `/:reportId/fixed-costs/:fixedCostId` | Update a fixed asset entry                                                          |
| DELETE | `/:reportId/fixed-costs/:fixedCostId` | Delete a fixed asset entry                                                          |

Example report-generation request:

```json
{
  "reportMonth": "2026-10",
  "tallyRows": [
    { "tallyLedgerName": "Office Rent", "amount": 25000, "excelRowNumber": 2 }
  ]
}
```

Tally ledger names are matched case-insensitively after removing punctuation
against active Operational Expense component/subcomponent names, codes, and
component descriptions. Unmatched ledgers are retained on the report for
resolution. The generator initializes `totals.totalDirectCost` from matched
report rows unless that total is supplied in the request. Fixed-cost changes
recalculate fixed-cost, markup, total, allocated, and unallocated figures.
Director remuneration is included in `totals.totalIndirectCost`; it is not added
as a separate amount to the operational expense total.
When generating a report, matched rows assigned to a Financial Category whose
name contains "indirect" or "misc" contribute to `totals.totalIndirectCost`;
other matched rows contribute to `totals.totalDirectCost`. Unmatched Tally
rows are recorded for resolution and do not contribute to the total until
matched to a report row.

The Operational Expense report embeds the extracted row, allocation, markup,
totals, unmatched-ledger, and fixed-asset schemas from
`models/operational-expense-models`.

Fixed asset expense entries are stored in the report's `fixedAssets` field.
Before deploying this field rename to a database with existing reports, run
the one-time migration from the `backend` directory:

```sh
npm run migrate:operational-expense-fixed-assets
```

Reports are created with status `REVIEW_PENDING`. Approving a report advances
it to `ALLOCATION_PENDING`; successfully generating all invoices advances it to
`INVOICE_GENERATED`. The status API accepts only the transitions
`REVIEW_PENDING` → `ALLOCATION_PENDING` and
`ALLOCATION_PENDING` → `INVOICE_GENERATED`; invalid transitions return HTTP 400. The older named report-status route remains available as a compatibility
alias.

Before deploying this workflow to a database containing reports with the old
statuses, run this migration once from the `backend` directory:

```sh
npm run migrate:operational-expense-report-statuses
```

## Seeding master data

Set `MONGO_URI` in `backend/.env` to the MongoDB Atlas database to seed, then run
the following from the `backend` directory:

```sh
npm run seed
```

The script idempotently inserts sample records into all nine master-model
collections and does not overwrite or delete existing records. It uses the
first active user for required audit references, or `SEED_USER_ID` if set to an
existing user ID. Create a user before running the script if the database does
not already contain one. The seeded client and billing location are demo data.

## Company Master APIs

Company Master routes are mounted at `/api/companyMasterRouter` and require an
authenticated bearer token.

| Method | Path                         | Description          |
| ------ | ---------------------------- | -------------------- |
| POST   | `/createCompany`             | Create a company     |
| GET    | `/getAllCompanies`           | List companies       |
| GET    | `/getCompanyById/:companyId` | Retrieve one company |
| PATCH  | `/updateCompany/:companyId`  | Update a company     |
| DELETE | `/deleteCompany/:companyId`  | Delete a company     |

Company records require `companyName`, `gstNumber`, `panNumber`, `tanNumber`,
`companyAddress`, `city`, `state`, and `pinCode`. `country` defaults to `India`.
Optional bank details include `beneficiaryName`, `beneficiaryAccountNo`,
`bankName`, `branch`, and `ifscCode`.

## Client Location APIs

Client Location routes are mounted at `/api/clientLocationRouter` and require
an authenticated bearer token.

| Method | Path | Description |
| --- | --- | --- |
| POST | `/client-locations` | Create a location for a client |
| GET | `/client-locations/client/:clientId` | List a client's active locations |
| GET | `/client-locations/:locationId` | Retrieve one location |
| PATCH | `/client-locations/:locationId` | Update a location |
| PATCH | `/client-locations/:locationId/status` | Activate or deactivate a location |
| DELETE | `/client-locations/:locationId` | Delete a location not used by invoices or allocations |

A client can have multiple locations. `locationCode` must be unique within
that client.
