import mongoose from "mongoose";

const uri =
  "mongodb+srv://Ajay:za8IhkpQTjCKNAbA@cluster0.w523omf.mongodb.net/petty-cash-data";

async function exportDatabase() {
  await mongoose.connect(uri);

  const db = mongoose.connection.db;

  const collections = await db.listCollections().toArray();

  const result = {};

  for (const collection of collections) {
    result[collection.name] = await db
      .collection(collection.name)
      .find({})
      .toArray();
  }

  const fs = await import("fs");

  fs.writeFileSync(
    "database-backup.json",
    JSON.stringify(result, null, 2)
  );

  console.log("Database exported successfully");
  process.exit();
}

exportDatabase();