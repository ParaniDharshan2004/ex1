const names = {
        dashboard: "Dashboard",
        upload: "Excel Upload",
        excel: "Uploaded Excel Data",
        results: "FLC Results",
        reports: "Reports",
        master: "Master",
        assets: "Asset Tracking",
        insurance: "Insurance",
        history: "Calculation History",
        users: "User Management",
      };
      function go(page) {
        document
          .querySelectorAll(".page")
          .forEach((p) => p.classList.toggle("active", p.id === page));
        document
          .querySelectorAll(".nav-item")
          .forEach((n) =>
            n.classList.toggle("active", n.dataset.page === page),
          );
        document.getElementById("crumb").textContent =
          names[page] || "Dashboard";
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
      document
        .querySelectorAll("[data-page]")
        .forEach((n) => n.addEventListener("click", () => go(n.dataset.page)));
      document
        .querySelectorAll("[data-go]")
        .forEach((n) => n.addEventListener("click", () => go(n.dataset.go)));
      document.querySelectorAll("[data-master-tab]").forEach((tab) => {
        tab.addEventListener("click", () => {
          const target = tab.dataset.masterTab;
          document
            .querySelectorAll("[data-master-tab]")
            .forEach((item) =>
              item.classList.toggle("active", item.dataset.masterTab === target),
            );
          document
            .querySelectorAll(".master-subpage")
            .forEach((page) =>
              page.classList.toggle("active", page.id === target),
            );
          document
            .querySelectorAll("[data-master-tab]")
            .forEach((item) =>
              item.setAttribute(
                "aria-selected",
                String(item.dataset.masterTab === target),
              ),
            );
        });
      });
      const assetModal = document.getElementById("assetModal");
      const assetForm = document.getElementById("assetForm");
      const assetTableBody = document.getElementById("assetTableBody");
      const assetModalTitle = document.getElementById("assetModalTitle");
      const assetSubmitButton = assetForm.querySelector('button[type="submit"]');
      let editingAssetRow = null;

      const formatCurrency = (value) =>
        value
          ? `₹${Number(value).toLocaleString("en-IN")}`
          : "—";
      const formatDate = (value) =>
        value
          ? new Date(`${value}T00:00:00`).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "—";

      function updateAssetCounts() {
        const rows = Array.from(assetTableBody.querySelectorAll("tr"));
        const assigned = rows.filter(
          (row) => row.dataset.status === "Assigned",
        ).length;
        const purchaseValue = rows.reduce((total, row) => {
          const value = row.cells[5].textContent.replace(/[₹,]/g, "");
          return total + (value === "—" ? 0 : Number(value) || 0);
        }, 0);
        document.getElementById("totalAssetCount").textContent =
          rows.length;
        document.getElementById("availableAssetCount").textContent =
          rows.filter((row) => row.dataset.status !== "Assigned").length;
        document.getElementById("assignedAssetCount").textContent =
          assigned;
        document.getElementById("assetPurchaseValue").textContent =
          purchaseValue >= 100000
            ? `₹${(purchaseValue / 100000).toFixed(1)}L`
            : `₹${purchaseValue.toLocaleString("en-IN")}`;
      }
      function deleteAsset(button) {
        const row = button.closest("tr");
        const code = row.cells[0].textContent.trim();
        if (window.confirm(`Delete asset ${code}?`)) {
          row.remove();
          updateAssetCounts();
          refreshAvailableAssetLists();
        }
      }
      function openAssetEditor(button) {
        const row = button.closest("tr");
        const cells = row.querySelectorAll("td");
        assetForm.reset();
        assetForm.elements.resourceCategoryId.value = "1";
        assetForm.elements.assetCode.value = cells[0].textContent.trim();
        assetForm.elements.assetName.value = cells[2].textContent.trim();
        assetForm.elements.asset.value =
          cells[2].textContent.trim();
        assetForm.elements.brand.value = cells[3].textContent.trim();
        assetForm.elements.serialNumber.value =
          cells[4].textContent.trim();
        assetForm.elements.purchaseCost.value =
          cells[5].textContent.replace(/[₹,]/g, "") === "—"
            ? ""
            : cells[5].textContent.replace(/[₹,]/g, "");
        assetForm.elements.assignedDate.value = "";
        assetForm.elements.warrantyDate.value = "";
        assetForm.elements.status.value =
          row.dataset.status || "In Stock";
        assetForm.elements.createdBy.value = "Administrator";
        editingAssetRow = row;
        assetModalTitle.textContent = "Edit asset";
        assetSubmitButton.textContent = "Update asset";
        assetModal.hidden = false;
        assetForm.elements.assetCode.focus();
      }
      document
        .getElementById("addAssetBtn")
        .addEventListener("click", () => {
          assetForm.reset();
          editingAssetRow = null;
          assetModalTitle.textContent = "Add asset";
          assetSubmitButton.textContent = "Save asset";
          assetModal.hidden = false;
          assetForm.elements.assetCode.focus();
        });
      document
        .querySelectorAll("[data-close-asset-modal]")
        .forEach((button) =>
          button.addEventListener("click", () => {
            assetModal.hidden = true;
            editingAssetRow = null;
          }),
        );
      assetModal.addEventListener("click", (event) => {
        if (event.target === assetModal) {
          assetModal.hidden = true;
          editingAssetRow = null;
        }
      });
      assetTableBody
        .querySelectorAll("[data-edit-asset]")
        .forEach((button) =>
          button.addEventListener("click", () => openAssetEditor(button)),
        );
      assetTableBody
        .querySelectorAll("[data-delete-asset]")
        .forEach((button) =>
          button.addEventListener("click", () => deleteAsset(button)),
        );
      assetForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const data = Object.fromEntries(new FormData(assetForm).entries());
        const statusClass =
          data.status === "Assigned"
            ? "neutral"
            : data.status === "Returned"
              ? "warning"
              : "success";
        const row = editingAssetRow || document.createElement("tr");
        row.dataset.assetType = data.assetName;
        row.dataset.status = data.status;
        row.innerHTML = `
          <td><b>${escapeHtml(data.assetCode)}</b></td>
          <td>Hardware</td>
          <td>${escapeHtml(data.assetName)}</td>
          <td>${escapeHtml(data.brand)}</td>
          <td>${escapeHtml(data.serialNumber)}</td>
          <td>${formatCurrency(data.purchaseCost)}</td>
          <td>${formatDate(data.assignedDate)}</td>
          <td>${formatDate(data.warrantyDate)}</td>
          <td><span class="status ${statusClass}">${escapeHtml(data.status)}</span></td>
          <td><button class="btn small" type="button" data-edit-asset>Edit</button> <button class="btn small danger" type="button" data-delete-asset>Delete</button></td>
        `;
        if (!editingAssetRow) assetTableBody.appendChild(row);
        row
          .querySelector("[data-edit-asset]")
          .addEventListener("click", () => openAssetEditor(row.querySelector("[data-edit-asset]")));
        row
          .querySelector("[data-delete-asset]")
          .addEventListener("click", () => deleteAsset(row.querySelector("[data-delete-asset]")));
        assetModal.hidden = true;
        editingAssetRow = null;
        updateAssetCounts();
        refreshAvailableAssetLists();
      });
      function filterAssets() {
        const search =
          document.getElementById("assetSearch").value.toLowerCase();
        const type = document.getElementById("assetTypeFilter").value;
        const status = document.getElementById("assetStatusFilter").value;
        assetTableBody.querySelectorAll("tr").forEach((row) => {
          const matchesSearch = row.textContent.toLowerCase().includes(search);
          const matchesType = !type || row.dataset.assetType === type;
          const matchesStatus = !status || row.dataset.status === status;
          row.hidden = !(matchesSearch && matchesType && matchesStatus);
        });
      }
      ["assetSearch", "assetTypeFilter", "assetStatusFilter"].forEach((id) => {
        document
          .getElementById(id)
          .addEventListener(id === "assetSearch" ? "input" : "change", filterAssets);
      });
      function refreshAvailableAssetLists() {
        document
          .querySelectorAll(".available-asset-select")
          .forEach((select) => {
            const assetType = select.dataset.assetType;
            const currentValue = select.value;
            select.innerHTML =
              `<option value="">Select an available ${assetType.toLowerCase()}</option>`;
            assetTableBody.querySelectorAll("tr").forEach((row) => {
              if (
                row.dataset.assetType === assetType &&
                row.dataset.status !== "Assigned"
              ) {
                const code = row.cells[0].textContent.trim();
                const brand = row.cells[3].textContent.trim();
                const serial = row.cells[4].textContent.trim();
                const option = document.createElement("option");
                option.value = code;
                option.textContent = `${code} · ${brand} · ${serial}`;
                select.appendChild(option);
              }
            });
            if (
              Array.from(select.options).some(
                (option) => option.value === currentValue,
              )
            ) {
              select.value = currentValue;
            }
          });
      }
      refreshAvailableAssetLists();
      updateAssetCounts();
      const departmentModal = document.getElementById("departmentModal");
      const departmentForm = document.getElementById("departmentForm");
      const departmentTableBody =
        document.getElementById("departmentTableBody");
      const departmentCardGrid =
        document.getElementById("departmentCardGrid");
      const addDepartmentButton =
        document.getElementById("addDepartmentBtn");
      const departmentModalTitle =
        document.getElementById("departmentModalTitle");
      const departmentSubmitButton =
        departmentForm.querySelector('button[type="submit"]');
      let editingDepartmentRow = null;

      const closeDepartmentModal = () => {
        departmentModal.hidden = true;
        editingDepartmentRow = null;
      };
      addDepartmentButton.addEventListener("click", () => {
        departmentForm.reset();
        editingDepartmentRow = null;
        departmentModalTitle.textContent = "Add department";
        departmentSubmitButton.textContent = "Save department";
        departmentModal.hidden = false;
        departmentForm.elements.deptId.focus();
      });
      document
        .querySelectorAll("[data-close-department-modal]")
        .forEach((button) =>
          button.addEventListener("click", closeDepartmentModal),
        );
      departmentModal.addEventListener("click", (event) => {
        if (event.target === departmentModal) closeDepartmentModal();
      });

      function deleteDepartment(button) {
        const row = button.closest("tr");
        const departmentName =
          row.querySelector("td:nth-child(3)")?.textContent.trim() ||
          "this department";
        if (window.confirm(`Delete ${departmentName}?`)) {
          row.remove();
          refreshDepartmentCards();
        }
      }
      function openDepartmentEditor(button) {
        const row = button.closest("tr");
        const cells = row.querySelectorAll("td");
        departmentForm.reset();
        departmentForm.elements.deptId.value = cells[0].textContent.trim();
        departmentForm.elements.compId.value = "1";
        departmentForm.elements.deptCode.value =
          cells[1].textContent.trim();
        departmentForm.elements.deptName.value =
          cells[2].textContent.trim();
        departmentForm.elements.isActive.value =
          cells[3].textContent.includes("Active") ? "true" : "false";
        editingDepartmentRow = row;
        departmentModalTitle.textContent = "Edit department";
        departmentSubmitButton.textContent = "Update department";
        departmentModal.hidden = false;
        departmentForm.elements.deptCode.focus();
      }
      function refreshDepartmentCards() {
        const cards = Array.from(departmentCardGrid.querySelectorAll(".master-card"));
        ["1", "2", "3"].forEach((departmentId, index) => {
          const row = Array.from(departmentTableBody.querySelectorAll("tr")).find(
            (departmentRow) =>
              departmentRow.cells[0]?.textContent.trim() === departmentId,
          );
          if (!row || !cards[index]) return;
          const code = row.cells[1].textContent.trim();
          const name = row.cells[2].textContent.trim();
          const status = row.cells[3].textContent.trim().replace("●", "").trim();
          cards[index].querySelector("h3").textContent = name;
          cards[index].querySelector(".code").textContent = `${code} · ${status}`;
        });
      }
      departmentTableBody
        .querySelectorAll("[data-edit-department]")
        .forEach((button) =>
          button.addEventListener("click", () =>
            openDepartmentEditor(button),
          ),
        );
      departmentTableBody
        .querySelectorAll("[data-delete-department]")
        .forEach((button) =>
          button.addEventListener("click", () => deleteDepartment(button)),
        );
      departmentForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const formData = new FormData(departmentForm);
        const department = Object.fromEntries(formData.entries());
        const isActive = department.isActive === "true";
        const statusClass = isActive ? "success" : "neutral";
        const statusText = isActive ? "Active" : "Inactive";
        const created = editingDepartmentRow
          ? editingDepartmentRow.cells[4].textContent.trim()
          : new Date().toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            });
        const row = editingDepartmentRow || document.createElement("tr");
        row.innerHTML = `
          <td>${escapeHtml(department.deptId)}</td>
          <td><span class="tag">${escapeHtml(department.deptCode)}</span></td>
          <td>${escapeHtml(department.deptName)}</td>
          <td><span class="status ${statusClass}">${statusText}</span></td>
          <td>${created}</td>
          <td>
            <button class="btn small" type="button" data-edit-department>Edit</button>
            <button class="btn small danger" type="button" data-delete-department>Delete</button>
          </td>
        `;
        if (!editingDepartmentRow) departmentTableBody.appendChild(row);
        row
          .querySelector("[data-edit-department]")
          .addEventListener("click", () =>
            openDepartmentEditor(row.querySelector("[data-edit-department]")),
          );
        row
          .querySelector("[data-delete-department]")
          .addEventListener("click", () =>
            deleteDepartment(row.querySelector("[data-delete-department]")),
          );
        refreshDepartmentCards();
        closeDepartmentModal();
      });
      const employeeModal = document.getElementById("employeeModal");
      const employeeForm = document.getElementById("employeeForm");
      const employeeTableBody = document.getElementById("employeeTableBody");
      const addEmployeeButton = document.getElementById("addEmployeeBtn");
      const employeeModalTitle =
        document.getElementById("employeeModalTitle");
      const employeeSubmitButton =
        employeeForm.querySelector('button[type="submit"]');
      let editingEmployeeRow = null;
      const employeeRowData = new WeakMap();
      const departmentNames = {
        1: "Revenue Generating Department",
        2: "Reservation Department",
        3: "Administrative Department",
      };
      employeeForm
        .querySelectorAll('input[type="checkbox"][data-detail]')
        .forEach((checkbox) => {
          checkbox.addEventListener("change", () => {
            const detail = document.getElementById(checkbox.dataset.detail);
            if (detail) detail.hidden = !checkbox.checked;
          });
        });
      const escapeHtml = (value) =>
        value.replace(
          /[&<>"']/g,
          (character) =>
            ({
              "&": "&amp;",
              "<": "&lt;",
              ">": "&gt;",
              '"': "&quot;",
              "'": "&#039;",
            })[character],
        );
      const insuranceSection = document.getElementById("employeeInsuranceSection");
      const clearEmployeeInsurance = () => {
        if (!insuranceSection) return;
        insuranceSection.querySelectorAll('input[name="insurance"]').forEach((checkbox) => {
          checkbox.checked = false;
        });
        insuranceSection.querySelectorAll(".item-detail").forEach((detail) => {
          detail.hidden = true;
          detail.querySelectorAll("input, select").forEach((field) => {
            if (field instanceof HTMLInputElement) field.value = "";
            if (field instanceof HTMLSelectElement) {
              field.selectedIndex = 0;
            }
          });
        });
      };
      const syncEmployeeInsuranceDepartment = (clearOnReservation = false) => {
        if (!insuranceSection) return;
        const departmentId = String(employeeForm.elements.deptId.value);
        const eligible = departmentId === "1" || departmentId === "3";
        insuranceSection.hidden = !eligible;
        if (!eligible && clearOnReservation) clearEmployeeInsurance();
      };
      employeeForm.elements.deptId.addEventListener("change", () => {
        syncEmployeeInsuranceDepartment(true);
      });
      const closeEmployeeModal = () => {
        employeeModal.hidden = true;
        editingEmployeeRow = null;
      };
      addEmployeeButton.addEventListener("click", () => {
        employeeForm.reset();
        employeeForm
          .querySelectorAll(".item-detail")
          .forEach((detail) => (detail.hidden = true));
        const today = new Date().toISOString().slice(0, 10);
        ["laptopAssignedDate", "desktopAssignedDate", "monitorAssignedDate", "mobileAssignedDate"]
          .forEach((fieldName) => {
            employeeForm.elements[fieldName].value = today;
          });
        employeeModalTitle.textContent = "Add employee";
        employeeSubmitButton.textContent = "Save employee";
        editingEmployeeRow = null;
        employeeModal.hidden = false;
        syncEmployeeInsuranceDepartment(false);
        employeeForm.elements.empCode.focus();
      });
      employeeTableBody
        .querySelectorAll("[data-edit-employee]")
        .forEach((button) => {
          button.addEventListener("click", () => openEmployeeEditor(button));
        });
      employeeTableBody
        .querySelectorAll("[data-delete-employee]")
        .forEach((button) => {
          button.addEventListener("click", () => deleteEmployee(button));
        });
      function deleteEmployee(button) {
        const row = button.closest("tr");
        const employeeName =
          row.querySelector("td:nth-child(2)")?.textContent.trim() ||
          "this employee";
        if (window.confirm(`Delete ${employeeName}?`)) {
          row.remove();
        }
      }
      function openEmployeeEditor(button) {
        const row = button.closest("tr");
        const cells = row.querySelectorAll("td");
        employeeForm.reset();
        employeeForm
          .querySelectorAll(".item-detail")
          .forEach((detail) => (detail.hidden = true));
        const departmentCode =
          cells[4].querySelector(".tag")?.textContent.trim() || "";
        const departmentId =
          departmentCode === "Revenue Generating Department" ? "1" :
          departmentCode === "Reservation Department" ? "2" :
          departmentCode === "Administrative Department" ? "3" :
          departmentCode === "RG" ? "1" :
          departmentCode === "RE" ? "2" : "3";
        const savedData = employeeRowData.get(row) || {};
        employeeForm.elements.compId.value = savedData.compId || "1";
        employeeForm.elements.empCode.value =
          savedData.empCode || cells[0].textContent.trim();
        employeeForm.elements.empName.value =
          savedData.empName || cells[1].textContent.trim();
        employeeForm.elements.email.value =
          savedData.email || cells[2].textContent.trim();
        employeeForm.elements.designation.value =
          savedData.designation || cells[3].textContent.trim();
        employeeForm.elements.deptId.value =
          savedData.deptId || departmentId;
        employeeForm.elements.teamId.value =
          savedData.teamId || cells[5].textContent.trim();
        employeeForm.elements.status.value =
          savedData.status ||
          cells[6].textContent.trim().replace("●", "").trim();
        syncEmployeeInsuranceDepartment(false);
        if (savedData.assignmentDetails) {
          Object.entries(savedData.assignmentDetails).forEach(([name, value]) => {
            const field = employeeForm.elements[name];
            if (!field) return;
            if (field instanceof RadioNodeList) {
              Array.from(field).forEach((checkbox) => {
                checkbox.checked = Array.isArray(value)
                  ? value.includes(checkbox.value)
                  : value === checkbox.value;
                if (checkbox.checked) {
                  const detail = document.getElementById(checkbox.dataset.detail);
                  if (detail) detail.hidden = false;
                }
              });
              return;
            }
            if (field instanceof HTMLInputElement &&
                field.type === "checkbox") {
              field.checked = Array.isArray(value)
                ? value.includes(field.value)
                : value === field.value;
              if (field.checked) {
                const detail = document.getElementById(field.dataset.detail);
                if (detail) detail.hidden = false;
              }
              return;
            }
            if (field instanceof HTMLInputElement ||
                field instanceof HTMLSelectElement ||
                field instanceof HTMLTextAreaElement) {
              field.value = value;
            }
          });
        }
        editingEmployeeRow = row;
        employeeModalTitle.textContent = "Edit employee";
        employeeSubmitButton.textContent = "Update employee";
        employeeModal.hidden = false;
        employeeForm.elements.empCode.focus();
      }
      document
        .querySelectorAll("[data-close-employee-modal]")
        .forEach((button) => button.addEventListener("click", closeEmployeeModal));
      employeeModal.addEventListener("click", (event) => {
        if (event.target === employeeModal) closeEmployeeModal();
      });
      employeeForm.addEventListener("submit", (event) => {
        event.preventDefault();
        const formData = new FormData(employeeForm);
        const employee = Object.fromEntries(formData.entries());
        employee.resources = formData.getAll("resources");
        employee.software = formData.getAll("software");
        const isInsuranceEligible =
          employee.deptId === "1" || employee.deptId === "3";
        employee.insurance = isInsuranceEligible
          ? formData.getAll("insurance")
          : [];
        employee.assignmentDetails = {
          ...Object.fromEntries(formData.entries()),
          resources: employee.resources,
          software: employee.software,
          insurance: employee.insurance,
        };
        const today = new Date().toISOString().slice(0, 10);
        [
          ["laptopAsset", "laptopAssignedDate"],
          ["desktopAsset", "desktopAssignedDate"],
          ["monitorAsset", "monitorAssignedDate"],
          ["mobileAsset", "mobileAssignedDate"],
        ].forEach(
          ([fieldName, dateFieldName]) => {
            const assetCode = formData.get(fieldName);
            if (!assetCode) return;
            const assignedDate = formData.get(dateFieldName) || today;
            const assetRow = Array.from(assetTableBody.querySelectorAll("tr")).find(
              (row) =>
                row.cells[0].textContent.trim() === String(assetCode),
            );
            if (!assetRow) return;
            assetRow.dataset.status = "Assigned";
            assetRow.cells[6].textContent =
              formatDate(assignedDate);
            assetRow.cells[8].innerHTML =
              '<span class="status neutral">Assigned</span>';
            assetRow.dataset.assignedEmployee =
              employee.empName;
          },
        );
        const initials = employee.empName
          .split(/\s+/)
          .map((part) => part[0])
          .join("")
          .slice(0, 2)
          .toUpperCase();
        const statusClass =
          employee.status === "Active" ? "success" : "neutral";
        const row = editingEmployeeRow || document.createElement("tr");
        row.innerHTML = `
          <td><b>${escapeHtml(employee.empCode)}</b></td>
          <td><div class="employee"><span class="emp-avatar">${escapeHtml(initials)}</span>${escapeHtml(employee.empName)}</div></td>
          <td>${escapeHtml(employee.email)}</td>
          <td>${escapeHtml(employee.designation)}</td>
          <td><span class="tag">${departmentNames[employee.deptId]}</span></td>
          <td>${escapeHtml(employee.teamId)}</td>
          <td><span class="status ${statusClass}">${escapeHtml(employee.status)}</span></td>
          <td>
            <button class="btn small" type="button" data-edit-employee>Edit</button>
            <button class="btn small danger" type="button" data-delete-employee>Delete</button>
          </td>
        `;
        employeeRowData.set(row, employee);
        if (!editingEmployeeRow) employeeTableBody.appendChild(row);
        row
          .querySelector("[data-edit-employee]")
          .addEventListener("click", () => openEmployeeEditor(row.querySelector("[data-edit-employee]")));
        row
          .querySelector("[data-delete-employee]")
          .addEventListener("click", () => deleteEmployee(row.querySelector("[data-delete-employee]")));
        updateAssetCounts();
        refreshAvailableAssetLists();
        refreshInsuranceTable();
        closeEmployeeModal();
      });
      function refreshInsuranceTable() {
        const insuranceBody = document.getElementById("insuranceTableBody");
        insuranceBody.querySelectorAll(".insurance-dynamic").forEach((row) => row.remove());

        const dynamicTypes = [
          ["Health Insurance", "health", "health_riderOpted"],
          ["Life Insurance", "life", null],
          ["Accidental Insurance", "accidental", null],
        ];

        employeeTableBody.querySelectorAll("tr").forEach((employeeRow) => {
          const employee = employeeRowData.get(employeeRow);
          if (!employee || !Array.isArray(employee.insurance)) return;
          if (!["1", "3"].includes(String(employee.deptId))) return;

          employee.insurance.forEach((insuranceName) => {
            const config = dynamicTypes.find(([name]) => name === insuranceName);
            if (!config) return;
            const [, prefix, riderName] = config;
            const details = employee.assignmentDetails || {};
            const premium = details[`${prefix}_premiumAmount`];
            const status = details[`${prefix}_status`] || "Active";
            const statusClass =
              status === "Active" ? "success" :
              status === "Renewal Due" ? "warning" : "neutral";
            const formatValue = (value) => {
              if (!value) return "—";
              if (String(value).includes("-")) return value;
              return value;
            };
            const formatPremium = (value) =>
              value ? `₹${Number(value).toLocaleString("en-IN")}` : "—";
            const effectiveFrom = formatValue(
              details[`${prefix}_effectiveFrom`]
                ? formatDate(details[`${prefix}_effectiveFrom`])
                : "",
            );
            const renewalDate = formatValue(
              details[`${prefix}_renewalDate`]
                ? formatDate(details[`${prefix}_renewalDate`])
                : "",
            );
            const row = document.createElement("tr");
            row.className = "insurance-dynamic";
            row.dataset.insuranceType = insuranceName;
            row.dataset.status = status;
            row.innerHTML = `
              <td><b>${escapeHtml(employee.empName)}</b></td>
              <td>${escapeHtml(insuranceName)}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_policyNo`]))}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_policyName`]))}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_provider`]))}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_frequency`]))}</td>
              <td>${escapeHtml(effectiveFrom)}</td>
              <td>${escapeHtml(renewalDate)}</td>
              <td>${escapeHtml(formatPremium(premium))}</td>
              <td>${escapeHtml(riderName ? (details[riderName] || "No") : "—")}</td>
              <td><span class="status ${statusClass}">${escapeHtml(status)}</span></td>
            `;
            insuranceBody.appendChild(row);
          });
        });
        updateInsuranceMetrics();
      }
      function updateInsuranceMetrics() {
        const rows = Array.from(
          document.querySelectorAll("#insuranceTableBody tr"),
        ).filter((row) => !row.hidden);
        const visibleRows = rows.length ? rows : [];
        document.getElementById("totalPolicyCount").textContent =
          String(visibleRows.length);
        document.getElementById("activePolicyCount").textContent =
          String(visibleRows.filter((row) => row.dataset.status === "Active").length);
        document.getElementById("renewalDueCount").textContent =
          String(visibleRows.filter((row) => row.dataset.status === "Renewal Due").length);
        let annualPremium = 0;
        visibleRows.forEach((row) => {
          const premiumCell = row.cells[8]?.textContent || "";
          const premium = Number(premiumCell.replace(/[₹,—,\s]/g, ""));
          if (!Number.isNaN(premium)) annualPremium += premium;
        });
        document.getElementById("annualPremiumValue").textContent =
          `₹${annualPremium.toLocaleString("en-IN")}`;
      }
      function filterInsuranceTable() {
        const search = document
          .getElementById("insuranceSearch")
          .value.trim()
          .toLowerCase();
        const type = document.getElementById("insuranceTypeFilter").value;
        const status = document.getElementById("insuranceStatusFilter").value;
        document.querySelectorAll("#insuranceTableBody tr").forEach((row) => {
          const matchesSearch = !search ||
            row.textContent.toLowerCase().includes(search);
          const matchesType =
            !type || row.dataset.insuranceType === type;
          const matchesStatus =
            !status || row.dataset.status === status;
          row.hidden = !(matchesSearch && matchesType && matchesStatus);
        });
        updateInsuranceMetrics();
      }
      document
        .getElementById("insuranceSearch")
        .addEventListener("input", filterInsuranceTable);
      document
        .getElementById("insuranceTypeFilter")
        .addEventListener("change", filterInsuranceTable);
      document
        .getElementById("insuranceStatusFilter")
        .addEventListener("change", filterInsuranceTable);
      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && !assetModal.hidden) {
          assetModal.hidden = true;
          editingAssetRow = null;
        }
        if (event.key === "Escape" && !departmentModal.hidden) {
          closeDepartmentModal();
        }
        if (event.key === "Escape" && !employeeModal.hidden) {
          closeEmployeeModal();
        }
      });
      const templateColumns = [
        "Cost item",
        "Total cost",
        "Ratio",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Total Cost - RG Department",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Total Cost - RE Department",
        "Ratio",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Cost Per Annum (RS)",
        "Cost Per Month (RS)",
        "Total Cost - AD Department",
        "Total Cost (RG+RE+AD)",
        "Total Cost Per Component",
      ];
      const employeeGroups = [
        ["RG Emp 1", "rg"],
        ["RG Emp 2", "rg"],
        ["RG Emp 3", "rg"],
        ["RG Emp 4", "rg"],
        ["RG Emp 5", "rg"],
        ["Total Cost - RG Department", "rg-total"],
        ["RD Emp 1", "reserve"],
        ["RD Emp 2", "reserve"],
        ["Total Cost - RE Department", "reserve-total"],
        ["Ratio", "ratio"],
        ["AD Emp 1", "admin"],
        ["AD Emp 2", "admin"],
        ["Total Cost - AD Department", "admin-total"],
        ["Total Cost (RG+RE+AD)", "grand-total"],
        ["Total Cost Per Component", "grand-total"],
      ];
      const directRows = [
        ["Salary", [300000, 25000, 318000, 26500, 336000, 28000, 354000, 29500, 372000, 31000, 140000, 390000, 32500, 408000, 34000, 66500, 426000, 35500, 444000, 37000, 72500, 279000, 2178000]],
        ["Life insurance", [6453, 537.75, 6027, 502.25, 8570, 714.17, 7870, 655.83, 9000, 750, 3160, 9450, 787.5, 9900, 825, 1612.5, 11183, 931.92, 10850, 904.17, 1836.08, 6608.58, 50953]],
        ["Health Insurance", [12000, 1000, 12700, 1058.33, 13400, 1116.67, 8683, 723.58, 14800, 1233.33, 5131.92, 15500, 1291.67, 16200, 1350, 2641.67, 16900, 1408, 17600, 1467, 2875, 10648.58, 81283]],
        ["Holiday Bonus", [6000, 500, 6300, 525, 6600, 550, 6900, 575, 7200, 600, 2750, 7500, 625, 7800, 650, 1275, 8100, 675, 8400, 700, 1375, 5400, 42300]],
        ["Special Professional certification reimbursement", [4500, 375, 4750, 396, 5000, 417, 5250, 438, 5500, 458, "", 5750, 479, 6000, 500, "", 6250, 521, 6500, 542, "", "", 32250]],
        ["Total Direct Labour", [328953, 27412.75, 347777, 28981.58, 369570, 30797.5, 377453, 31454.42, 408500, 34041.33, 152687.58, 428200, 35683.17, 447900, 37325, 73008.17, 468433, 38514.92, 487350, 40071.17, 78586.08, 304281.83, 2384786], "total"],
        ["Dedicated Employee resource -(Depreciation)*", [18294.39, 1524.53, 9870.39, 822.53, 9945.99, 828.83, 11750.4, 979.2, 55169.63, 4597.47, 8752.57, 17009.73, 1417.48, 17142.31, 1428.53, 2846, 55169.63, 4597.47, 8517.15, 709.76, 5307.23, 16905.8, 113547.95]],
        ["Dedicated Employee software access cost*", [72306, 6025.5, 72306, 6025.5, 72306, 6025.5, 13221, 1101.75, 57600, 4800, 23978.25, 13221, 1101.75, 13221, 1101.75, 2203.5, 14521, 1210.08, 13221, 1101.75, 2311.83, 28493.58, 257881]],
        ["Total Direct Material", [90600.39, 7550.03, 82176.39, 6848.03, 82251.99, 6854.33, 24971.4, 2080.95, "", "", 23333.35, 30230.73, 2519.23, 30363.31, 2530.28, 5049.5, 69690.63, 5807.55, 21738.15, 1811.51, 7619.06, 36001.92, 371428.95], "total"],
        ["Total Direct Cost", [419553.39, 34962.78, 429953.39, 35829.62, 451821.99, 37651.83, 402424.4, 33535.37, 408500, 34041.33, 176020.93, 458430.73, 38202.39, 478263.31, 39855.28, 78057.67, 538123.63, 44322.47, 509088.15, "", 44322.47, 298401.07, 742857.89], "total"],
      ];
      const variableRows = [
        ["Office Rent", 654720],
        ["Electricity", 72763.64],
        ["Travel", 72000],
        ["Internet & Phone", 11760],
        ["Food & Water", 36240],
        ["Small tools & Equipment*", 17749],
        ["Software*", 25353.17],
        ["Bank Charges (Estimated)", 5000],
        ["Professional fees (Estimated)*", 96000],
        ["Registration & Legal Expenses (Estimated)", 15000],
        ["Marketing & Advertisement", 60000],
        ["Liability Insurance", 30000],
        ["Employee Recognition & Rewards (Estimated)*", 45000],
        ["Employee Related Events & trips (Estimated)*", 84000],
        ["Misc office Expenses (Estimated)*", 50000],
      ];
      const fixedRows = [
        ["Air conditioner", 13941.99],
        ["Furniture*", 11045.97],
        ["Printer", 7101],
        ["Inverter (UPS)", 6075],
        ["Mobile Phone", 4214.16],
        ["Security Camera", 8901.9],
        ["Water dispenser", 2770.2],
      ];
      function makeAllocatedValues(total, ratio = 0.111111) {
        const annual = total * ratio;
        const month = annual / 12;
        return [
          total,
          ratio,
          annual,
          month,
          annual,
          month,
          annual,
          month,
          annual,
          month,
          annual,
          month,
          month * 5,
          annual,
          month,
          annual,
          month,
          month * 2,
          ratio,
          annual,
          month,
          annual,
          month,
          month * 2,
          month * 9,
          total,
        ];
      }
      const sectionLabels = [
        ["Total Direct Cost + Total Variable cost + Total Fixed Cost depreciation", "total"],
        ["Absolute cost per Employee Before Apportionment from Administrative Department :", "section"],
        ["Cost per Hour (Direct)", "subsection"],
        ["Cost per Hour (Indirect)", "subsection"],
        ["Cost per Hour (Direct) + Cost per Hour (Indirect)", "total"],
        ["Cost per Month", "subsection"],
        ["Semi-Variable cost (Adminstrative)", "section"],
        ["Overheads apportioned from Administrative department", "subsection"],
        ["Total Semi-Variable cost", "total"],
        ["T.D.C + T.V.C + T.F.C (D) + Semi-Variable Cost", "total"],
      ];
      function formatTemplateValue(value) {
        if (value === "" || value === null || value === undefined) return "—";
        if (typeof value === "number") {
          return value.toLocaleString("en-IN", {
            maximumFractionDigits: 2,
          });
        }
        return value;
      }
      function renderTemplateSheet() {
        const table = document.getElementById("templateSheet");
        const columnWidths = Array.from({ length: 27 }, (_, index) =>
          `<col style="width: ${index === 0 ? 180 : index < 3 ? 75 : 96}px" />`,
        ).join("");
        const header = `
          <colgroup>${columnWidths}</colgroup>
          <thead>
            <tr class="sheet-title"><th colspan="27">Fully Loaded Cost Per Employee for 2026 (Cost per hour)</th></tr>
            <tr class="sheet-groups">
              <th colspan="3" rowspan="3">Direct Cost</th>
              <th colspan="11" class="group-rg">Revenue Generating Department</th>
              <th colspan="5" class="group-reserve">Reserve Department</th>
              <th colspan="6" class="group-admin">Administrative Department</th>
              <th colspan="2" class="group-total">Total Per year</th>
            </tr>
            <tr class="sheet-people">${employeeGroups.map(([name, group]) => `<th colspan="${group.includes("total") || group === "grand-total" ? 1 : 2}" class="${group}">${name}</th>`).join("")}</tr>
            <tr class="sheet-columns">${templateColumns.slice(3).map((name) => `<th>${name.replace(" ", "<br />")}</th>`).join("")}</tr>
          </thead>`;
        const rows = [];
        rows.push(`<tr class="section"><td class="text cost-label" colspan="3">Direct Cost</td><td colspan="24"></td></tr>`);
        rows.push(`<tr class="section"><td class="text cost-label" colspan="3">Direct Labour</td><td colspan="24"></td></tr>`);
        directRows.forEach(([label, values, kind]) => {
          const displayValues = [...values.slice(0, 16), "", ...values.slice(16)];
          const cells = displayValues.map((value) => `<td class="num">${formatTemplateValue(value)}</td>`).join("");
          rows.push(`<tr class="${kind || ""}"><td class="text cost-label" colspan="3">${label}</td>${cells}</tr>`);
        });
        rows.push(`<tr class="section"><td class="text cost-label" colspan="3">Indirect Overhead cost</td><td colspan="24"></td></tr>`);
        rows.push(`<tr class="subsection"><td class="text cost-label" colspan="3">Variable cost</td><td colspan="24"></td></tr>`);
        variableRows.forEach(([label, total]) => {
          const cells = makeAllocatedValues(total).map((value) => `<td class="num">${formatTemplateValue(value)}</td>`).join("");
          rows.push(`<tr><td class="text cost-label">${label}</td>${cells}</tr>`);
        });
        rows.push(`<tr class="total"><td class="text cost-label" colspan="3">Total Variable cost</td><td colspan="24">Formula cached</td></tr>`);
        rows.push(`<tr class="total"><td class="text cost-label" colspan="3">Total Direct Cost + Total Variable cost</td><td colspan="24">Formula cached</td></tr>`);
        rows.push(`<tr class="section"><td class="text cost-label" colspan="3">Fixed Cost (Depreciation)</td><td colspan="24"></td></tr>`);
        fixedRows.forEach(([label, total]) => {
          const cells = makeAllocatedValues(total).map((value) => `<td class="num">${formatTemplateValue(value)}</td>`).join("");
          rows.push(`<tr><td class="text cost-label">${label}</td>${cells}</tr>`);
        });
        rows.push(`<tr class="total"><td class="text cost-label" colspan="3">Total Fixed cost depreciation</td><td colspan="24">Formula cached</td></tr>`);
        sectionLabels.forEach(([label, kind]) => {
          rows.push(`<tr class="${kind}"><td class="text cost-label" colspan="3">${label}</td><td colspan="24">—</td></tr>`);
        });
        table.innerHTML = `${header}<tbody>${rows.join("")}</tbody>`;
      }
      // The original workbook grid is embedded below using cached numeric values only.
      const input = document.getElementById("fileInput"),
        state = document.getElementById("fileState"),
        process = document.getElementById("processBtn");
      input.addEventListener("change", () => {
        const f = input.files[0];
        if (!f) return;
        state.style.display = "block";
        state.innerHTML =
          "<b>✓ " +
          f.name +
          "</b><br><span>Selected for secure validation · " +
          (f.size / 1024 / 1024).toFixed(2) +
          " MB</span>";
        process.disabled = false;
      });
      process.addEventListener("click", () => {
        process.textContent = "Processing…";
        process.disabled = true;
        setTimeout(() => {
          process.textContent = "Process workbook →";
          go("excel");
        }, 650);
      });
      document.getElementById("resultSearch").addEventListener("input", (e) => {
        const q = e.target.value.toLowerCase();
        document
          .querySelectorAll("#resultTable tbody tr, #hourResultTable tbody tr")
          .forEach(
            (r) =>
              (r.style.display = r.textContent.toLowerCase().includes(q)
                ? ""
                : "none"),
          );
      });
