import express from "express";
import { authenticateUser } from "../../middlewares/auth-middleware.js";
import { createClientLocation, getClientLocationsByClient, updateClientLocation, updateClientLocationStatus } from "../../controllers/master-controllers/client-location-controller.js";
const router = express.Router();
router.post("/client-locations", authenticateUser, createClientLocation); router.get("/client-locations/client/:clientId", authenticateUser, getClientLocationsByClient); router.patch("/client-locations/:locationId", authenticateUser, updateClientLocation); router.patch("/client-locations/:locationId/status", authenticateUser, updateClientLocationStatus);
export default router;
