import mongoose from "mongoose";
import OperationalExpenseReport from "../models/operational-expense-models/operational-expense-report-model.js";
import { recalculateOperationalExpenseTotals } from "../services/operational-expense-services/operational-expense-calculation-service.js";

describe("recalculateOperationalExpenseTotals", () => {
  const createFinalizedReport = () => {
    const firstAllocationPercentage = (300000 / 336120) * 100;
    return new OperationalExpenseReport({
      reportCode: "OE-2026-10",
      reportName: "Operational Expense Report October 2026",
      reportMonth: "2026-10",
      reportDate: new Date("2026-10-01T00:00:00.000Z"),
      rows: [
        {
          componentName: "Direct Costs",
          financialCategoryName: "Direct Cost",
          amount: 225000,
          displayOrder: 1,
        },
        {
          componentName: "Indirect Costs",
          financialCategoryName: "Indirect Cost",
          amount: 53300,
          displayOrder: 2,
        },
        {
          componentName: "Misc Expenses",
          financialCategoryName: "Misc Expenses",
          amount: 1800,
          displayOrder: 3,
        },
      ],
      markup: {
        enabled: true,
        percentage: 20,
        baseType: "SUBTOTAL",
      },
      allocations: [
        {
          clientId: new mongoose.Types.ObjectId(),
          clientName: "Client One",
          allocationPercentage: firstAllocationPercentage,
          amount: 300000,
        },
        {
          clientId: new mongoose.Types.ObjectId(),
          clientName: "Client Two",
          allocationPercentage: 100 - firstAllocationPercentage,
          amount: 36120,
        },
      ],
      status: "FINALIZED",
      createdBy: new mongoose.Types.ObjectId(),
      updatedBy: new mongoose.Types.ObjectId(),
    });
  };

  test("includes Misc rows and reconciles allocations to zero", () => {
    const report = createFinalizedReport();
    recalculateOperationalExpenseTotals(report);

    expect(report.totals.subtotal).toBe(280100);
    expect(report.totals.operationalExpenseTotal).toBe(336120);
    expect(report.totals.allocatedTotal).toBe(336120);
    expect(report.totals.unallocatedBalance).toBe(0);
  });

  test("allows finalization when allocations equal the recalculated total", async () => {
    const report = createFinalizedReport();
    recalculateOperationalExpenseTotals(report);

    await expect(report.validate()).resolves.toBeUndefined();
  });
});
