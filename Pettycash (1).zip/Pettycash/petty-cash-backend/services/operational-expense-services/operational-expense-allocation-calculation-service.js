import { GST_RATE } from "../../config/invoice-config.js";

export const roundCurrency = (value) => Math.round((Number(value) + Number.EPSILON) * 100) / 100;
export const calculateLocationAllocatedTotal = (locationAllocations = []) => roundCurrency(locationAllocations.reduce((sum, item) => sum + (Number(item.amount) || 0), 0));
export const calculateClientRemainingBalance = (clientTotalAmount, locationAllocations = []) => roundCurrency(Number(clientTotalAmount) - calculateLocationAllocatedTotal(locationAllocations));
export const calculateReportAllocatedTotal = (allocations = []) => roundCurrency(allocations.reduce((sum, item) => sum + (Number(item.clientTotalAmount) || 0), 0));
export const calculateReportRemainingBalance = (operationalExpenseTotal, allocations = []) => roundCurrency(Number(operationalExpenseTotal) - calculateReportAllocatedTotal(allocations));
export const calculateGstPreview = (totalIncludingGst) => { const grandTotal = roundCurrency(Math.max(0, Number(totalIncludingGst) || 0)); const gstAmount = roundCurrency(grandTotal * GST_RATE / 100); const taxableAmount = roundCurrency(grandTotal - gstAmount); return { taxableAmount, gstAmount, grandTotal }; };
export const calculateInvoiceAmounts = calculateGstPreview;
