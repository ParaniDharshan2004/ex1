# petty-cash-backend

This repository contains the Express/Mongoose API for the petty-cash project.

## Operational Expense Reports

Operational Expense routes are mounted at `/api/operational-expense` and require
an authenticated bearer token.

| Method | Path | Description |
| --- | --- | --- |
| POST | `/generate` | Generate a monthly report from active Operational Expense components and Tally rows |
| GET | `/` | List reports; optionally filter with `reportMonth` and `status` query parameters |
| GET | `/:id` | Retrieve one report, including its fixed costs |
| PUT | `/:id` | Update draft report fields |
| PATCH | `/:id/status` | Finalize a draft report or archive a finalized report |
| DELETE | `/:id` | Delete a draft report |
| GET | `/:reportId/fixed-costs` | List a report's fixed costs |
| GET | `/:reportId/fixed-costs/:fixedCostId` | Retrieve one fixed cost |
| POST | `/:reportId/fixed-costs` | Add a fixed cost to a draft report |
| PATCH | `/:reportId/fixed-costs/:fixedCostId` | Update a fixed cost on a draft report |
| DELETE | `/:reportId/fixed-costs/:fixedCostId` | Delete a fixed cost from a draft report |

Example report-generation request:

```json
{
  "reportMonth": "2026-10",
  "tallyRows": [
    { "tallyLedgerName": "Office Rent", "amount": 25000, "excelRowNumber": 2 }
  ]
}
```

Tally ledger names are matched case-insensitively after removing punctuation
against active Operational Expense component/subcomponent names, codes, and
component descriptions. Unmatched ledgers are retained on the report for
resolution. The generator initializes `totals.totalDirectCost` from matched
report rows unless that total is supplied in the request. Fixed-cost changes
recalculate fixed-cost, markup, total, allocated, and unallocated figures.
Director remuneration is included in `totals.totalIndirectCost`; it is not added
as a separate amount to the operational expense total.
When generating a report, matched rows assigned to a Financial Category whose
name contains "indirect" or "misc" contribute to `totals.totalIndirectCost`;
other matched rows contribute to `totals.totalDirectCost`. Unmatched Tally
rows are recorded for resolution and do not contribute to the total until
matched to a report row.

The Operational Expense report embeds the extracted row, allocation, markup,
totals, unmatched-ledger, and fixed-cost schemas from
`models/operational-expense-models`.
