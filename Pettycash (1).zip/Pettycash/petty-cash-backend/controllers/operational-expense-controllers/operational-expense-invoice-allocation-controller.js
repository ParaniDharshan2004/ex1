import mongoose from 'mongoose';
import Client from '../../models/master-models/client-model.js';
import ClientLocation from '../../models/master-models/client-location-model.js';
import OperationalExpenseReport from '../../models/operational-expense-models/operational-expense-report-model.js';
import OperationalExpenseInvoiceAllocation from '../../models/operational-expense-models/operational-expense-invoice-allocation-model.js';
import {
  calculateClientRemainingBalance,
  calculateLocationAllocatedTotal,
  calculateReportAllocatedTotal,
  calculateReportRemainingBalance,
  roundCurrency,
} from '../../services/operational-expense-services/operational-expense-allocation-calculation-service.js';
const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

// Create New & Update the existing Allocation for the Particular Report & Client
export const upsertOperationalExpenseInvoiceAllocation = async (req, res) => {
  try {
    const { reportId } = req.params;
    const {
      clientId,
      clientTotalAmount,
      locationAllocations = [],
      allocationStatus = 'CONFIRMED',
    } = req.body;
    if (
      !actor(req) ||
      !mongoose.Types.ObjectId.isValid(reportId) ||
      !mongoose.Types.ObjectId.isValid(clientId)
    )
      return fail(res, 400, 'Valid report and client IDs are required');
    if (
      !['DRAFT', 'CONFIRMED'].includes(allocationStatus) ||
      !Number.isFinite(Number(clientTotalAmount)) ||
      Number(clientTotalAmount) < 0 ||
      !Array.isArray(locationAllocations)
    )
      return fail(res, 400, 'Invalid allocation data');
    const clean = locationAllocations
      .filter(
        (item) =>
          item?.locationId &&
          mongoose.Types.ObjectId.isValid(item.locationId) &&
          Number.isFinite(Number(item.amount)) &&
          Number(item.amount) >= 0,
      )
      .map((item) => ({
        locationId: item.locationId,
        amount: roundCurrency(item.amount),
      }));
    const [report, client, locations, others] = await Promise.all([
      OperationalExpenseReport.findById(reportId)
        .select('totals status')
        .lean(),
      Client.findOne({ _id: clientId, isActive: true }).select('_id').lean(),
      ClientLocation.find({
        _id: { $in: clean.map((item) => item.locationId) },
        clientId,
        isActive: true,
      })
        .select('_id')
        .lean(),
      OperationalExpenseInvoiceAllocation.find({
        operationalExpenseReportId: reportId,
        clientId: { $ne: clientId },
      })
        .select('clientTotalAmount isAutomatic locationAllocations')
        .lean(),
    ]);
    if (!report) return fail(res, 404, 'Operational Expense report not found');
    if (!client || locations.length !== clean.length)
      return fail(
        res,
        400,
        'The client or one or more locations is invalid or inactive',
      );
    if (report.status === 'INVOICED')
      return fail(res, 409, 'Operational Expense report is already invoiced');
    const clientTotal = roundCurrency(clientTotalAmount);
    const reportTotal = roundCurrency(
      report.totals?.operationalExpenseTotal || 0,
    );
    const otherTotal = calculateReportAllocatedTotal(others);
    const locationTotal = calculateLocationAllocatedTotal(clean);
    if (otherTotal + clientTotal > reportTotal + 0.01)
      return fail(
        res,
        400,
        'Client totals cannot exceed the Operational Expense total',
      );
    if (clean.length && Math.abs(locationTotal - clientTotal) > 0.01)
      return fail(
        res,
        400,
        'Location allocation total must equal the client total amount',
      );
    const saved = await OperationalExpenseInvoiceAllocation.findOneAndUpdate(
      { operationalExpenseReportId: reportId, clientId },
      {
        $set: {
          clientTotalAmount: clientTotal,
          locationAllocations: clean,
          allocationStatus,
          isAutomatic: false,
          updatedBy: actor(req),
        },
        $setOnInsert: { createdBy: actor(req) },
      },
      {
        upsert: true,
        returnDocument: 'after',
        runValidators: true,
        setDefaultsOnInsert: true,
      },
    ).populate('clientId locationAllocations.locationId');
    const otherClients = await Client.find({
      _id: { $ne: clientId },
      isActive: true,
    })
      .select('_id')
      .lean();
    const nextClientAmount = roundCurrency(reportTotal - clientTotal);
    let automaticAllocation = null;
    if (
      otherClients.length === 1 &&
      nextClientAmount > 0 &&
      (!others.length ||
        others.every(
          (item) => item.isAutomatic || !item.locationAllocations?.length,
        ))
    ) {
      automaticAllocation =
        await OperationalExpenseInvoiceAllocation.findOneAndUpdate(
          {
            operationalExpenseReportId: reportId,
            clientId: otherClients[0]._id,
          },
          {
            $set: {
              clientTotalAmount: nextClientAmount,
              locationAllocations: [],
              allocationStatus: 'CONFIRMED',
              isAutomatic: true,
              updatedBy: actor(req),
            },
            $setOnInsert: { createdBy: actor(req) },
          },
          {
            upsert: true,
            returnDocument: 'after',
            runValidators: true,
            setDefaultsOnInsert: true,
          },
        ).populate('clientId locationAllocations.locationId');
    }
    const allAllocations = await OperationalExpenseInvoiceAllocation.find({
      operationalExpenseReportId: reportId,
    })
      .populate('clientId locationAllocations.locationId')
      .lean();
    const clientAllocations = allAllocations.map((item) => ({
      ...item,
      locationAllocatedTotal: calculateLocationAllocatedTotal(
        item.locationAllocations,
      ),
      clientRemainingBalance: calculateClientRemainingBalance(
        item.clientTotalAmount,
        item.locationAllocations,
      ),
      availableClientBalance: roundCurrency(
        reportTotal -
          calculateReportAllocatedTotal(
            allAllocations.filter(
              (other) => String(other.clientId) !== String(item.clientId),
            ),
          ),
      ),
    }));
    return res.json({
      success: true,
      data: saved,
      automaticAllocation,
      calculations: {
        operationalExpenseTotal: reportTotal,
        clientAllocations,
        reportAllocatedTotal: calculateReportAllocatedTotal(allAllocations),
        reportRemainingBalance: calculateReportRemainingBalance(
          reportTotal,
          allAllocations,
        ),
      },
      message: 'Invoice allocation saved successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError')
      return fail(res, 400, error.message);
    return fail(res, 500, error.message || 'Unable to save invoice allocation');
  }
};

// CRUD Operational expense of allocation
// export const createOperationalExpenseInvoiceAllocation = async (req, res) => {
//   try {
//     const { reportId } = req.params;
//     const {
//       clientId,
//       clientTotalAmount,
//       locationAllocations = [],
//       allocationStatus = 'CONFIRMED',
//     } = req.body;

//     const exists = await OperationalExpenseInvoiceAllocation.findOne({
//       operationalExpenseReportId: reportId,
//       clientId,
//     });

//     if (exists) {
//       return res.status(409).json({
//         success: false,
//         message: 'Allocation already exists for this client',
//       });
//     }

//     const allocation = await OperationalExpenseInvoiceAllocation.create({
//       operationalExpenseReportId: reportId,
//       clientId,
//       clientTotalAmount,
//       locationAllocations,
//       allocationStatus,
//       isAutomatic: false,
//       createdBy: actor(req),
//       updatedBy: actor(req),
//     });

//     return res.status(201).json({
//       success: true,
//       data: allocation,
//       message: 'Allocation created successfully',
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

export const getOperationalExpenseInvoiceAllocation = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.reportId))
      return fail(res, 400, 'Invalid report ID');
    const [report, data] = await Promise.all([
      OperationalExpenseReport.findById(req.params.reportId)
        .select('totals')
        .lean(),
      OperationalExpenseInvoiceAllocation.find({
        operationalExpenseReportId: req.params.reportId,
      })
        .populate('clientId locationAllocations.locationId')
        .lean(),
    ]);
    if (!report) return fail(res, 404, 'Operational Expense report not found');
    const reportTotal = roundCurrency(
      report.totals?.operationalExpenseTotal || 0,
    );
    const clientAllocations = data.map((item) => ({
      ...item,
      locationAllocatedTotal: calculateLocationAllocatedTotal(
        item.locationAllocations,
      ),
      clientRemainingBalance: calculateClientRemainingBalance(
        item.clientTotalAmount,
        item.locationAllocations,
      ),
      availableClientBalance: roundCurrency(
        reportTotal -
          calculateReportAllocatedTotal(
            data.filter(
              (other) => String(other.clientId) !== String(item.clientId),
            ),
          ),
      ),
    }));
    return res.json({
      success: true,
      data: {
        allocations: data,
        calculations: {
          operationalExpenseTotal: reportTotal,
          clientAllocations,
          reportAllocatedTotal: calculateReportAllocatedTotal(data),
          reportRemainingBalance: calculateReportRemainingBalance(
            reportTotal,
            data,
          ),
        },
      },
      message: 'Invoice allocations retrieved successfully',
    });
  } catch (error) {
    return fail(res, 500, error.message);
  }
};

// export const updateOperationalExpenseInvoiceAllocation = async (req, res) => {
//   try {
//     const { allocationId } = req.params;

//     const { clientTotalAmount, locationAllocations, allocationStatus } =
//       req.body;

//     const allocation =
//       await OperationalExpenseInvoiceAllocation.findById(allocationId);

//     if (!allocation) {
//       return res.status(404).json({
//         success: false,
//         message: 'Allocation not found',
//       });
//     }

//     allocation.clientTotalAmount = clientTotalAmount;

//     allocation.locationAllocations = locationAllocations;

//     allocation.allocationStatus = allocationStatus;

//     allocation.updatedBy = actor(req);

//     await allocation.save();

//     return res.status(200).json({
//       success: true,
//       data: allocation,
//       message: 'Allocation updated successfully',
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

// export const deleteOperationalExpenseInvoiceAllocation = async (req, res) => {
//   try {
//     const { allocationId } = req.params;

//     const deleted =
//       await OperationalExpenseInvoiceAllocation.findByIdAndDelete(allocationId);

//     if (!deleted) {
//       return res.status(404).json({
//         success: false,
//         message: 'Allocation not found',
//       });
//     }

//     return res.status(200).json({
//       success: true,
//       message: 'Allocation deleted successfully',
//     });
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };
