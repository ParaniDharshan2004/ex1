import mongoose from 'mongoose';
import Component from '../../models/master-models/component-model.js';
import SubComponent from '../../models/master-models/subcomponent.js';
import OperationalExpenseReport from '../../models/operational-expense-models/operational-expense-report-model.js';
import { createAuditLog } from '../../services/audit-services.js';
import {
  getOperationalExpenseCategoryTotals,
  recalculateOperationalExpenseTotals,
} from '../../services/operational-expense-services/operational-expense-calculation-service.js';
import {
  matchOperationalExpenseTallyRows,
  OperationalExpenseInputError,
} from '../../services/operational-expense-services/operational-expense-matching-service.js';

const reportMonthPattern = /^\d{4}-(0[1-9]|1[0-2])$/;
const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

const recordAudit = async (req, action, report, beforeData = null) => {
  try {
    await createAuditLog({
      req,
      action,
      entityType: 'operational_expense_report',
      entityId: report._id,
      changedFields: beforeData ? ['report'] : Object.keys(report.toObject()),
      beforeData,
      afterData: action === 'REMOVE' ? null : report.toObject(),
    });
  } catch (error) {
    console.error('Operational Expense Audit Log Error:', error);
  }
};

export const generateOperationalExpenseReport = async (req, res) => {
  try {
    const {
      reportMonth,
      reportName,
      reportCode,
      reportDate,
      currencyCode = 'INR',
      sourceType = 'TALLY_IMPORT',
      tallyRows = [],
      fixedCosts = [],
      markup = {},
      totals = {},
      allocations = [],
    } = req.body;

    if (!reportMonthPattern.test(String(reportMonth || ''))) {
      return res.status(400).json({
        success: false,
        message: 'Report month must use YYYY-MM format',
      });
    }
    if (!Array.isArray(tallyRows)) {
      return res.status(400).json({
        success: false,
        message: 'Tally rows must be an array',
      });
    }
    if (!Array.isArray(fixedCosts)) {
      return res.status(400).json({
        success: false,
        message: 'Fixed costs must be an array',
      });
    }
    if (!['TALLY_IMPORT', 'MANUAL'].includes(sourceType)) {
      return res.status(400).json({
        success: false,
        message: 'Source type must be TALLY_IMPORT or MANUAL',
      });
    }
    if (!Array.isArray(allocations)) {
      return res.status(400).json({
        success: false,
        message: 'Allocations must be an array',
      });
    }

    const existing = await OperationalExpenseReport.exists({ reportMonth });
    if (existing) {
      return res.status(409).json({
        success: false,
        message: `An Operational Expense report already exists for ${reportMonth}`,
      });
    }

    const components = await Component.find({
      isOperationalExpense: true,
      isActive: true,
    })
      .populate('financialCategoryId', 'categoryCode categoryName displayOrder')
      .sort({ displayOrder: 1, componentName: 1 })
      .lean();

    if (components.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No active Operational Expense components found',
      });
    }

    const subComponents = await SubComponent.find({
      componentId: { $in: components.map((component) => component._id) },
      isOperationalExpense: true,
      isActive: true,
    }).lean();
    const { componentAmounts, unmatchedTallyRows } =
      matchOperationalExpenseTallyRows({
        tallyRows,
        components,
        subComponents,
      });

    const rows = components
      .map((component, index) => {
        const matched = componentAmounts.get(String(component._id)) || {
          directAmounts: [],
          subComponentAmounts: [],
        };

        const directTotal = matched.directAmounts.reduce(
          (sum, ledger) => sum + (Number(ledger.amount) || 0),
          0,
        );

        const subComponentTotal = matched.subComponentAmounts.reduce(
          (sum, ledger) => sum + (Number(ledger.amount) || 0),
          0,
        );

        const hasDirectMatch = matched.directAmounts.length > 0;

        const hasSubComponentMatch = matched.subComponentAmounts.length > 0;

        const amount = hasDirectMatch ? directTotal : subComponentTotal;

        const matchStatus = hasDirectMatch
          ? 'HEAD_COMPONENT_MATCHED'
          : hasSubComponentMatch
            ? 'CALCULATED_FROM_SUBCOMPONENTS'
            : 'NOT_PRESENT_IN_TALLY';

        return {
          componentId: component._id,
          componentCode: component.componentCode || '',
          componentName: component.componentName,

          rowSource: 'TALLY_IMPORT',

          financialCategoryId: component.financialCategoryId?._id || null,

          financialCategoryCode:
            component.financialCategoryId?.categoryCode || '',

          financialCategoryName:
            component.financialCategoryId?.categoryName || '',

          sourceAmount: amount,
          amount,

          matchStatus,

          hasTallyExpense: hasDirectMatch || hasSubComponentMatch,

          matchedTallyLedgers: [
            ...matched.directAmounts,
            ...matched.subComponentAmounts,
          ],

          isManuallyAdded: false,
          isEdited: false,

          displayOrder: component.displayOrder ?? index + 1,
        };
      })
      .filter(
        (row) =>
          row.matchStatus !== 'NOT_PRESENT_IN_TALLY' && row.hasTallyExpense,
      );

    const { totalDirectCost, totalIndirectCost } =
      getOperationalExpenseCategoryTotals(rows);

    const startingTotals = {
      totalDirectCost,
      totalIndirectCost,
      subtotal: 0,
      markupAmount: 0,
      directorRemunerationTotal: 0,
      fixedCostTotal: 0,
      operationalExpenseTotal: 0,
      allocatedTotal: 0,
      unallocatedBalance: 0,
    };
    const date = reportDate
      ? new Date(reportDate)
      : new Date(`${reportMonth}-01T00:00:00.000Z`);
    if (Number.isNaN(date.getTime())) {
      return res.status(400).json({
        success: false,
        message: 'Report date is invalid',
      });
    }

    const report = new OperationalExpenseReport({
      reportCode: reportCode || `OE-${reportMonth}`,
      reportName: reportName || `Operational Expense Report ${reportMonth}`,
      reportMonth,
      reportDate: date,
      currencyCode,
      sourceType,
      rows,
      unmatchedTallyRows,
      fixedCosts,
      markup,
      totals: startingTotals,
      allocations,
      status: 'DRAFT',
      generatedBy: req.user.userId,
      createdBy: req.user.userId,
      updatedBy: req.user.userId,
    });

    recalculateOperationalExpenseTotals(report);
    await report.save();
    await recordAudit(req, 'CREATE', report);

    return res.status(201).json({
      success: true,
      data: report,
      message: 'Operational Expense report generated successfully',
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message:
          'An Operational Expense report already exists for this month or code',
      });
    }
    if (
      error.name === 'ValidationError' ||
      error instanceof OperationalExpenseInputError
    ) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error('Generate Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to generate Operational Expense report',
    });
  }
};

export const getAllOperationalExpenseReports = async (req, res) => {
  try {
    const filter = {};
    if (req.query.reportMonth) {
      if (!reportMonthPattern.test(String(req.query.reportMonth))) {
        return res.status(400).json({
          success: false,
          message: 'Report month must use YYYY-MM format',
        });
      }
      filter.reportMonth = req.query.reportMonth;
    }
    if (req.query.status) filter.status = req.query.status;

    const reports = await OperationalExpenseReport.find(filter)
      .sort({ reportMonth: -1 })
      .lean();

    return res.status(200).json({
      success: true,
      data: reports,
      message: 'Operational Expense reports retrieved successfully',
    });
  } catch (error) {
    console.error('Get Operational Expense Reports Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to retrieve Operational Expense reports',
    });
  }
};

export const getOperationalExpenseReportById = async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }

    const report = await OperationalExpenseReport.findById(
      req.params.id,
    ).lean();
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: report,
      message: 'Operational Expense report retrieved successfully',
    });
  } catch (error) {
    console.error('Get Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to retrieve Operational Expense report',
    });
  }
};

export const updateOperationalExpenseReport = async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }

    const report = await OperationalExpenseReport.findById(req.params.id);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }
    if (report.status === 'INVOICED') {
      return res.status(409).json({
        success: false,
        message: 'Invoiced Operational Expense reports cannot be updated',
      });
    }
    if (!['DRAFT', 'FINALIZED'].includes(report.status)) {
      return res.status(409).json({
        success: false,
        message:
          'Only draft or finalized Operational Expense reports can be updated',
      });
    }

    const beforeData = report.toObject();
    const allowedFields = [
      'reportName',
      'reportDate',
      'currencyCode',
      'rows',
      'unmatchedTallyRows',
      'fixedCosts',
      'markup',
      'totals',
      'allocations',
    ];
    for (const field of allowedFields) {
      if (Object.hasOwn(req.body, field)) report[field] = req.body[field];
    }
    report.updatedBy = req.user.userId;
    recalculateOperationalExpenseTotals(report);
    await report.save();
    await recordAudit(req, 'UPDATE', report, beforeData);

    return res.status(200).json({
      success: true,
      data: report,
      message: 'Operational Expense report updated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError') {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error('Update Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to update Operational Expense report',
    });
  }
};

export const updateOperationalExpenseReportStatus = async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }
    const { status } = req.body;

    const report = await OperationalExpenseReport.findById(req.params.id);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }
    if (report.status === 'INVOICED') {
      return res.status(409).json({
        success: false,
        message: 'Invoiced Operational Expense reports cannot change status',
      });
    }
    if (
      (status === 'FINALIZED' && report.status !== 'DRAFT') ||
      (status === 'ARCHIVED' && report.status !== 'FINALIZED') ||
      (status === 'INVOICED' && !['DRAFT', 'FINALIZED'].includes(report.status))
    ) {
      return res.status(409).json({
        success: false,
        message:
          'Reports can only transition from DRAFT to FINALIZED and FINALIZED to ARCHIVED',
      });
    }

    const beforeData = report.toObject();
    recalculateOperationalExpenseTotals(report);
    report.status = status;
    report.updatedBy = req.user.userId;
    if (status === 'FINALIZED') {
      report.finalizedBy = req.user.userId;
      report.finalizedAt = new Date();
    }
    await report.save();
    await recordAudit(req, 'UPDATE', report, beforeData);

    return res.status(200).json({
      success: true,
      data: { reportId: report._id, status: report.status },
      message: 'Operational Expense report status updated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
    console.error('Update Operational Expense Report Status Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to update Operational Expense report status',
    });
  }
};

export const deleteOperationalExpenseReport = async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Operational Expense report ID',
      });
    }

    const report = await OperationalExpenseReport.findById(req.params.id);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense report not found',
      });
    }
    if (report.status === 'INVOICED') {
      return res.status(409).json({
        success: false,
        message: 'Invoiced Operational Expense reports cannot be deleted',
      });
    }
    if (!['DRAFT', 'FINALIZED'].includes(report.status)) {
      return res.status(409).json({
        success: false,
        message: 'Archived Operational Expense reports cannot be deleted',
      });
    }

    await recordAudit(req, 'REMOVE', report);
    await report.deleteOne();

    return res.status(200).json({
      success: true,
      message: 'Operational Expense report deleted successfully',
      data: { reportId: report._id },
    });
  } catch (error) {
    console.error('Delete Operational Expense Report Error:', error);
    return res.status(500).json({
      success: false,
      message: 'Unable to delete Operational Expense report',
    });
  }
};
