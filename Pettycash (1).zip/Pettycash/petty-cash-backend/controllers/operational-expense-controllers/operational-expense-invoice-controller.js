import mongoose from 'mongoose';
import Client from '../../models/master-models/client-model.js';
import ClientLocation from '../../models/master-models/client-location-model.js';
import OperationalExpenseReport from '../../models/operational-expense-models/operational-expense-report-model.js';
import Allocation from '../../models/operational-expense-models/operational-expense-invoice-allocation-model.js';
import Invoice from '../../models/operational-expense-models/operational-expense-invoice-model.js';
import { GST_RATE } from '../../config/invoice-config.js';
import { calculateInvoiceAmounts } from '../../services/operational-expense-services/operational-expense-allocation-calculation-service.js';

const actor = (req) => req.user?.userId || req.user?._id || req.user?.id;
const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

// To create a single invoice for selected clients based on location
export const createInvoice = async (req, res) => {
  try {
    const { reportId } = req.params;
    const { clientId, locationId = null } = req.body || {};
    if (
      !actor(req) ||
      !mongoose.Types.ObjectId.isValid(reportId) ||
      !mongoose.Types.ObjectId.isValid(clientId)
    )
      return fail(res, 400, 'Valid report and client IDs are required');
    if (locationId != null && !mongoose.Types.ObjectId.isValid(locationId))
      return fail(res, 400, 'Location ID is invalid');
    const [report, client, allocation] = await Promise.all([
      OperationalExpenseReport.findById(reportId).select('_id status').lean(),
      Client.findOne({ _id: clientId, isActive: true }).select('_id').lean(),
      Allocation.findOne({
        operationalExpenseReportId: reportId,
        clientId,
      }).lean(),
    ]);
    if (!report) return fail(res, 404, 'Operational Expense report not found');
    if (!client) return fail(res, 400, 'Client is invalid or inactive');
    if (!allocation || allocation.allocationStatus !== 'CONFIRMED')
      return fail(
        res,
        409,
        'Confirm the client allocation before generating an invoice',
      );
    const selectedLocation =
      locationId == null
        ? null
        : allocation.locationAllocations.find(
            (item) => String(item.locationId) === String(locationId),
          );
    if (locationId != null && !selectedLocation)
      return fail(
        res,
        400,
        'The selected location is not saved for this client',
      );
    if (locationId != null) {
      const validLocation = await ClientLocation.exists({
        _id: locationId,
        clientId,
        isActive: true,
      });
      if (!validLocation)
        return fail(res, 400, 'Location is invalid or inactive');
    }
    const { taxableAmount, gstAmount, grandTotal } = calculateInvoiceAmounts(
      selectedLocation?.amount ?? allocation.clientTotalAmount,
    );
    const invoice = await Invoice.findOneAndUpdate(
      { operationalExpenseReportId: reportId, clientId, locationId },
      {
        $set: {
          gstRate: GST_RATE,
          taxableAmount,
          status: 'DRAFT',
          gstAmount,
          grandTotal,
          createdBy: actor(req),
        },
      },
      {
        upsert: true,
        returnDocument: 'after',
        runValidators: true,
        setDefaultsOnInsert: true,
      },
    ).populate('clientId locationId');
    return res.json({
      success: true,
      data: invoice,
      message: 'Invoice generated successfully',
    });
  } catch (error) {
    if (error.name === 'ValidationError' || error.name === 'CastError')
      return fail(res, 400, error.message);
    return fail(res, 500, error.message || 'Unable to generate invoice');
  }
};

export const getAllInvoices = async (req, res) => {
  try {
    const invoices = await Invoice.find({}).sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      count: invoices.length,
      data: invoices,
      message: invoices.length
        ? 'Invoices fetched successfully'
        : 'No invoices found',
    });
  } catch (error) {
    console.error('Get All Invoices Error:', error);

    return res.status(500).json({
      success: false,
      message: 'Unable to fetch invoices',
      error: error.message,
    });
  }
};

// Update the status of invoice DRAFT -> GENERATED
export const updateInvoiceStatus = async (req, res) => {
  try {
    const { reportId, invoiceId } = req.params;
    const { status } = req.body || {};

    if (!actor(req)) {
      return res.status(400).json({
        success: false,
        message: 'User Required',
      });
    }

    if (
      !mongoose.Types.ObjectId.isValid(reportId) ||
      !mongoose.Types.ObjectId.isValid(invoiceId)
    ) {
      return res.status(400).json({
        success: false,
        message: 'Invalid Report ID or Invoice ID',
      });
    }

    const report = await OperationalExpenseReport.findById(reportId).lean();

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Operational Expense Report not found',
      });
    }

    const updatedInvoice = await Invoice.findOneAndUpdate(
      {
        _id: invoiceId,
        operationalExpenseReportId: reportId,
      },
      {
        $set: {
          status,
          updatedBy: actor(req),
        },
      },
      {
        new: true,
      },
    );

    if (!updatedInvoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: updatedInvoice,
      message: 'Invoice status updated successfully',
    });
  } catch (error) {
    console.error('Update Invoice Error:', error);

    return res.status(500).json({
      success: false,
      message: 'Unable to update invoice',
    });
  }
};

export const deleteInvoice = async (req, res) => {
  try {
    const { invoiceId } = req.params;

    const invoice = await Invoice.findById(invoiceId);

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found',
      });
    }

    await Invoice.findByIdAndDelete(invoiceId);

    return res.status(200).json({
      success: true,
      message: 'Invoice deleted successfully',
    });
  } catch (error) {
    console.error('Delete Invoice Error:', error);

    return res.status(500).json({
      success: false,
      message: 'Unable to delete invoice',
      error: error.message,
    });
  }
};

// To create a bulk invoice based on clients list and their locations
export const generateOperationalExpenseInvoices = async (req, res) => {
  try {
    const { reportId } = req.params;

    const allocations = await Allocation.find({
      operationalExpenseReportId: reportId,
    });

    if (!allocations.length) {
      return res.status(404).json({
        success: false,
        message: 'No allocations found',
      });
    }

    // Prevent duplicate invoice generation
    const existingInvoices = await Invoice.countDocuments({
      operationalExpenseReportId: reportId,
    });

    if (existingInvoices > 0) {
      return res.status(400).json({
        success: false,
        message: 'Invoices already generated for this report',
      });
    }

    const invoices = [];

    for (const allocation of allocations) {
      // Client has locations
      if (allocation.locationAllocations?.length > 0) {
        for (const location of allocation.locationAllocations) {
          const grandTotal = Number(location.amount || 0);

          const taxableAmount = Number((grandTotal / 1.18).toFixed(2));

          const gstAmount = Number((grandTotal - taxableAmount).toFixed(2));

          invoices.push({
            operationalExpenseReportId: reportId,

            clientId: allocation.clientId,
            locationId: location.locationId,

            taxableAmount,
            gstAmount,
            grandTotal,
            gstRate: 18,

            status: 'GENERATED',

            createdBy: actor(req),
            updatedBy: actor(req),
          });
        }
      }

      // Client has no locations
      else {
        const grandTotal = Number(allocation.clientTotalAmount || 0);

        const taxableAmount = Number((grandTotal / 1.18).toFixed(2));

        const gstAmount = Number((grandTotal - taxableAmount).toFixed(2));

        invoices.push({
          operationalExpenseReportId: reportId,

          clientId: allocation.clientId,

          locationId: null,

          taxableAmount,
          gstAmount,
          grandTotal,
          gstRate: 18,

          status: 'GENERATED',

          createdBy: actor(req),
          updatedBy: actor(req),
        });
      }
    }

    const createdInvoices = await Invoice.insertMany(invoices);

    await OperationalExpenseReport.findByIdAndUpdate(reportId, {
      status: 'INVOICED',
      updatedBy: actor(req),
    });

    return res.status(201).json({
      success: true,
      count: createdInvoices.length,
      data: createdInvoices,
      message: 'Invoices generated successfully',
    });
  } catch (error) {
    console.error('Generate Invoice Error:', error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
