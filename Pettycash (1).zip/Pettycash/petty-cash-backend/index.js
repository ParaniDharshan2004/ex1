import dotenv from "dotenv";
dotenv.config();
import express from "express";
import cors from "cors";
import helmet from "helmet";
import { connectDB } from "./config/db.js";
import transactionRouter from "./routes/pettycash-routes/transaction-routes.js";
import cashInflowRouter from "./routes/pettycash-routes/cashinflow-routes.js";
import componentRouter from "./routes/master-routes/component-routes.js";
import subComponentRouter from "./routes/master-routes/subcomponent-routes.js";

import permissionRouter from "./routes/auth-routes/permission-routes.js";
import roleRouter from "./routes/auth-routes/role-routes.js";
import userRouter from "./routes/auth-routes/user-routes.js";
import authRouter from "./routes/auth-routes/auth-routes.js";
import reportRouter from "./routes/pettycash-routes/report-routes.js";
import router from "./routes/migration-route.js";
import senderAccountRouter from "./routes/account-routes/sender-account-routes.js";
import pettyCashAccountRouter from "./routes/account-routes/cash-account-routes.js";
import summaryRouter from "./routes/pettycash-routes/monthly-summary-routes.js";
import cashFlowRouter from "./routes/cashflow-routes/cashflow-routes.js";
import clientRouter from "./routes/master-routes/client-routes.js";
import operationalExpenseRouter from "./routes/operational-expense-routes/operational-expense-route.js";
import clientLocationRouter from "./routes/master-routes/client-location-routes.js";

const app = express();

// Security Related Functions
app.disable("x-powered-by");
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(helmet());

// DB Connection Function
connectDB();

// Mount routes
app.use("/api/transactionRouter", transactionRouter);
app.use("/api/cashInflowRouter", cashInflowRouter);
app.use("/api/componentRouter", componentRouter);
app.use("/api/subComponentRouter", subComponentRouter);
app.use("/api/permissionRouter", permissionRouter);
app.use("/api/roleRouter", roleRouter);
app.use("/api/userRouter", userRouter);
app.use("/api/auth", authRouter);
app.use("/api/reportRouter", reportRouter);
app.use("/api/senderAccountRouter", senderAccountRouter);
app.use("/api/pettyCashAccountRouter", pettyCashAccountRouter);
app.use("/api/summaryRouter", summaryRouter)
app.use("/api/cashFlowRouter", cashFlowRouter)
app.use("/api/clientRouter", clientRouter)
app.use("/api/operationalExpenseRouter", operationalExpenseRouter);
app.use("/api", clientLocationRouter);

// Migration route
app.use("/api/migration", router);

app.get("/", (req, res) => {
  res.json("Backend is Running");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}...`);
});

export default app;
