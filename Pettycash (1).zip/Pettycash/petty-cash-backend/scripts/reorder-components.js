import mongoose from "mongoose";
import dotenv from "dotenv";

import Component from "../models/master-models/component-model.js";

dotenv.config();

const reorderComponents = async () => {
  try {
    /*
     * Connect to MongoDB.
     *
     * Change MONGODB_URI below if your .env
     * uses a different variable name.
     */
    await mongoose.connect(process.env.MONGO_URI);

    console.log("MongoDB connected successfully");

    /*
     * Load the existing Components.
     */
    const components = await Component.find({})
      .sort({ displayOrder: 1 })
      .lean();

    console.log(`Found ${components.length} components`);

    if (components.length === 0) {
      console.log("No components found");
      return;
    }

    let processedCount = 0;

    /*
     * Reconstruct each existing document
     * in the required field order.
     */
    for (const component of components) {
      const reorderedComponent = {
        _id: component._id,

        componentCode: component.componentCode,

        componentName: component.componentName,

        description: component.description ?? null,

        isPettyCash: component.isPettyCash ?? false,

        isCashFlowAnalysis: component.isCashFlowAnalysis ?? false,

        financialCategoryId: component.financialCategoryId ?? null,

        financialSubCategoryId: component.financialSubCategoryId ?? null,

        isOperationalExpense: component.isOperationalExpense ?? false,

        isFullyLoadedCost: component.isFullyLoadedCost ?? false,

        requiresBill: component.requiresBill ?? false,

        displayOrder: component.displayOrder ?? 1,

        isActive: component.isActive ?? true,

        createdBy: component.createdBy ?? null,

        updatedBy: component.updatedBy ?? null,

        createdAt: component.createdAt,

        updatedAt: component.updatedAt,

        version: component.version ?? 0,
      };

      /*
       * Replace the existing document
       * using its SAME _id.
       */
      const result = await Component.collection.replaceOne(
        {
          _id: component._id,
        },
        reorderedComponent,
        {
          upsert: false,
        },
      );

      if (result.matchedCount !== 1) {
        throw new Error(
          `Component not found during replacement: ${component.componentCode}`,
        );
      }

      processedCount++;

      console.log(
        `[${processedCount}/${components.length}] ${component.componentCode} - ${component.componentName}`,
      );
    }

    console.log("");
    console.log("Component reorder migration completed successfully");
    console.log(`Processed components: ${processedCount}`);
  } catch (error) {
    console.error("Component reorder migration failed:", error);

    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();

    console.log("MongoDB disconnected");
  }
};

reorderComponents();
