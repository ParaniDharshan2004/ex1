import mongoose from "mongoose";

const clientSchema = new mongoose.Schema(
  {
    clientCode: {
      type: String,
      required: [
        true,
        "Client code is required",
      ],
      trim: true,
      uppercase: true,
      unique: true,
      immutable: true,
    },

    clientName: {
      type: String,
      required: [
        true,
        "Client name is required",
      ],
      trim: true,
      maxlength: [
        150,
        "Client name cannot exceed 150 characters",
      ],
    },

    description: {
      type: String,
      trim: true,
      default: "",
      maxlength: [
        500,
        "Description cannot exceed 500 characters",
      ],
    },

    displayOrder: {
      type: Number,
      default: 1,
      min: 1,
    },

    isActive: {
      type: Boolean,
      default: true,
      required: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
      immutable: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: "version",
    optimisticConcurrency: true,
    collection: "clients",
  },
);

clientSchema.index(
  {
    clientCode: 1,
  },
  {
    unique: true,
    name: "uq_clients_clientCode",
  },
);

clientSchema.index(
  {
    clientName: 1,
  },
  {
    unique: true,
    name: "uq_clients_clientName",
    collation: {
      locale: "en",
      strength: 2,
    },
  },
);

clientSchema.index(
  {
    isActive: 1,
    displayOrder: 1,
  },
  {
    name: "idx_clients_active_order",
  },
);

const Client = mongoose.model(
  "Client",
  clientSchema,
);

export default Client;