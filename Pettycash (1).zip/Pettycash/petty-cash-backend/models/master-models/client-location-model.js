import mongoose from "mongoose";

const schema = new mongoose.Schema({
  clientId: { type: mongoose.Schema.Types.ObjectId, ref: "Client", required: true, index: true },
  locationCode: { type: String, required: true, trim: true, uppercase: true },
  locationName: { type: String, required: true, trim: true },
  billingName: { type: String, trim: true, default: "" }, billingAddress: { type: String, trim: true, default: "" },
  stateName: { type: String, trim: true, default: "" }, stateCode: { type: String, trim: true, uppercase: true, default: "" },
  gstin: { type: String, trim: true, uppercase: true, default: "" }, isActive: { type: Boolean, default: true },
  displayOrder: { type: Number, default: 1, min: 0 },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
}, { timestamps: true, collection: "client_locations" });
schema.index({ clientId: 1, locationCode: 1 }, { unique: true, name: "idx_client_location_code" });
schema.pre("validate", function normalize() { this.locationCode = String(this.locationCode || "").trim().toUpperCase(); this.locationName = String(this.locationName || "").trim(); });
export default mongoose.model("ClientLocation", schema);
