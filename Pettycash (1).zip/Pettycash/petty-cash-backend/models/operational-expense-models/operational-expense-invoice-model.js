import mongoose from 'mongoose';

const schema = new mongoose.Schema(
  {
    operationalExpenseReportId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'OperationalExpenseReport',
      required: true,
    },
    clientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Client',
      required: true,
    },
    locationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ClientLocation',
      default: null,
    },
    status: {
      type: String,
      enum: ['DRAFT', 'GENERATED'],
    },
    gstRate: { type: Number, required: true, min: 0 },
    taxableAmount: { type: Number, required: true, min: 0 },
    gstAmount: { type: Number, required: true, min: 0 },
    grandTotal: { type: Number, required: true, min: 0 },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  { timestamps: true, collection: 'operational_expense_invoices' },
);

schema.index(
  { operationalExpenseReportId: 1, clientId: 1, locationId: 1 },
  { unique: true, name: 'idx_operational_expense_invoice_target' },
);

export default mongoose.model('OperationalExpenseInvoice', schema);
