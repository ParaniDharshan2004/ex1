import mongoose from "mongoose";
import operationalExpenseAllocationSchema from "./operational-expense-allocation-schema.js";
import operationalExpenseFixedCostSchema from "./operational-expense-fixed-cost-schema.js";
import operationalExpenseMarkupSchema from "./operational-expense-markup-schema.js";
import operationalExpenseRowSchema from "./operational-expense-row-schema.js";
import operationalExpenseTotalsSchema from "./operational-expense-totals-schema.js";
import unmatchedTallyRowSchema from "./unmatched-tally-row-schema.js";

const MONTH_PATTERN = /^\d{4}-(0[1-9]|1[0-2])$/;

const operationalExpenseReportSchema = new mongoose.Schema(
  {
    reportCode: {
      type: String,
      required: true,
      trim: true,
    },
    reportName: {
      type: String,
      required: true,
      trim: true,
    },
    reportMonth: {
      type: String,
      required: true,
      trim: true,
      match: [MONTH_PATTERN, "Report month must use YYYY-MM format"],
    },
    reportDate: {
      type: Date,
      required: true,
    },
    currencyCode: {
      type: String,
      required: true,
      default: "INR",
      trim: true,
      uppercase: true,
      minlength: 3,
      maxlength: 3,
    },
    sourceType: {
      type: String,
      enum: ["TALLY_IMPORT", "MANUAL", "REGENERATED"],
      default: "TALLY_IMPORT",
      required: true,
    },
    rows: {
      type: [operationalExpenseRowSchema],
      default: [],
    },
    unmatchedTallyRows: {
      type: [unmatchedTallyRowSchema],
      default: [],
    },
    fixedCosts: {
      type: [operationalExpenseFixedCostSchema],
      default: [],
    },
    markup: {
      type: operationalExpenseMarkupSchema,
      default: () => ({}),
    },
    totals: {
      type: operationalExpenseTotalsSchema,
      default: () => ({}),
    },
    allocations: { type: [operationalExpenseAllocationSchema], default: [] },
    status: {
      type: String,
      enum: ["DRAFT", "FINALIZED", "INVOICED"],
      default: "DRAFT",
    },
    generatedAt: {
      type: Date,
      default: Date.now,
    },
    generatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    finalizedAt: {
      type: Date,
      default: null,
    },
    finalizedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
  },
  {
    timestamps: true,
    optimisticConcurrency: true,
    versionKey: "__v",
    collection: "operational_expense_reports",
  },
);

operationalExpenseReportSchema.pre("validate", function normalizeReport() {
  this.reportCode = String(this.reportCode || "")
    .trim()
    .toUpperCase();
  this.reportName = String(this.reportName || "").trim();
  this.currencyCode = String(this.currencyCode || "INR")
    .trim()
    .toUpperCase();

  for (const row of this.rows || []) {
    row.sourceAmount = Math.max(0, Number(row.sourceAmount) || 0);
    row.amount = Math.max(0, Number(row.amount) || 0);
    row.displayOrder = Math.max(0, Number(row.displayOrder) || 0);

    if (["MASTER_COMPONENT", "REPORT_ONLY"].includes(row.rowSource)) {
      row.isManuallyAdded = true;
      row.matchStatus = "MANUALLY_ADDED";
    } else {
      row.isManuallyAdded = false;
    }

    row.hasTallyExpense = [
      "HEAD_COMPONENT_MATCHED",
      "CALCULATED_FROM_SUBCOMPONENTS",
    ].includes(row.matchStatus);
  }

  this.markup.percentage = Math.max(0, Number(this.markup.percentage) || 0);
  this.markup.baseAmount = Math.max(0, Number(this.markup.baseAmount) || 0);
  this.markup.amount = Math.max(0, Number(this.markup.amount) || 0);

  for (const allocation of this.allocations || []) {
    allocation.allocationPercentage = Math.min(100, Math.max(0, Number(allocation.allocationPercentage) || 0));
    allocation.amount = Math.max(0, Number(allocation.amount) || 0);
  }

  if (this.status === "FINALIZED") {
    const percentageTotal = (this.allocations || []).reduce((total, allocation) => total + (Number(allocation.allocationPercentage) || 0), 0);
    if (Math.abs(percentageTotal - 100) > 0.01) {
      this.invalidate("allocations", "Client allocation percentages must total 100 before finalizing the report.");
      return;
    }
    if (Math.abs(Number(this.totals.unallocatedBalance) || 0) > 0.01) {
      this.invalidate(
        "totals.unallocatedBalance",
        "Unallocated balance must be zero before finalizing the report.",
      );
      return;
    }

    if (!this.finalizedAt) {
      this.finalizedAt = new Date();
    }
  }

});

operationalExpenseReportSchema.index(
  { reportCode: 1 },
  { unique: true, name: "idx_operationalExpense_reportCode" },
);
operationalExpenseReportSchema.index(
  { reportMonth: 1 },
  { unique: true, name: "idx_operationalExpense_reportMonth" },
);
operationalExpenseReportSchema.index(
  { "rows.financialCategoryId": 1 },
  { name: "idx_operationalExpense_category" },
);
operationalExpenseReportSchema.index(
  { status: 1, updatedAt: -1 },
  { name: "idx_operationalExpense_status_updatedAt" },
);

const OperationalExpenseReport = mongoose.model(
  "OperationalExpenseReport",
  operationalExpenseReportSchema,
);

export default OperationalExpenseReport;
