Analyze the complete attached “Invoice Allocation.txt” reference file and the current target project before modifying any code.

Implement the Operational Expense Dashboard, rename the existing Operational Expense Summary to Upload & Review, replace only the amount-allocation UI with the referenced Invoice Allocation dialog, add List/Kanban options to the existing Reports page, create an Invoices page, and implement an Audit Trail.

Follow the target project’s existing folder structure, routing, Material UI theme, fonts, colors, API abstraction, coding style, and component standards.

IMPORTANT: Preserve all existing APIs, request payloads, database structures, calculations, GST formulas, validation rules, save behavior, export behavior, and existing working functionality unless a requirement below explicitly asks for a UI or navigation change.

==================================================
1. ANALYZE BEFORE IMPLEMENTATION
==================================================

First analyze:

- The attached Invoice Allocation.txt file
- The target project structure
- Existing sidebar and routing
- Existing Operational Expense pages and components
- Existing API utility files
- Existing database-facing payloads
- Existing report statuses
- Existing invoice statuses
- Existing report save and update workflow
- Existing report PDF/export behavior
- Existing client and location APIs
- Existing invoice allocation APIs
- Existing invoice generation behavior
- Existing audit capability
- Existing theme, fonts, colors, spacing, and responsive patterns

Identify all reusable code from Invoice Allocation.txt, especially:

- InvoiceAllocationPage
- OperationalExpenseActions
- OperationalExpenseCalendarView
- OperationalExpenseReportPage
- OperationalExpensesPage
- Invoice dialogs
- GST calculation functions
- Client and location allocation logic
- Report status workflow
- Invoice-generation workflow
- Summary-mode navigation

Do not blindly replace the target project files.

Adapt the referenced features to the target project’s actual architecture.

Before coding, provide a concise implementation map containing:

1. Existing target files involved
2. New files required
3. Files to modify
4. Existing APIs that will be reused
5. Supported report and invoice statuses
6. Missing APIs or backend capabilities
7. Components being adapted from Invoice Allocation.txt

Do not invent APIs, fields, routes, database records, or status values.

==================================================
2. OPERATIONAL EXPENSE SIDEBAR
==================================================

Inside the Operational Expense sidebar group, add and order the navigation items as:

1. Dashboard
2. Upload & Review
3. Reports
4. Invoices
5. Audit Trail

Requirements:

- Add Dashboard inside the existing Operational Expense sidebar group.
- Preserve existing icons where possible.
- Preserve active-route highlighting.
- Preserve permissions and protected-route behavior.
- Preserve collapse and expand behavior.
- Do not create duplicate Operational Expense navigation entries.
- Follow the target project’s current route naming conventions.

==================================================
3. OPERATIONAL EXPENSE DASHBOARD
==================================================

Create a dedicated Operational Expense Dashboard using reusable components inside the existing Operational Expense components folder.

The Dashboard must display:

- Total operational expense records
- Draft reports
- Finalized reports
- Invoiced or completed reports
- Total operational expense value
- Pending actions
- Recently updated monthly records

Use actual API data only.

Do not use mock or synthetic report data.

Follow the target project’s theme:

- Same colors
- Same fonts
- Same typography scale
- Same border radius
- Same shadows
- Same spacing system
- Same responsive breakpoints

Create reusable components only where necessary, for example:

- OperationalExpenseDashboardCards.jsx
- OperationalExpenseDashboardTable.jsx
- OperationalExpenseCalendarView.jsx

Do not over-componentize simple markup.

==================================================
4. RENAME SUMMARY TO UPLOAD & REVIEW
==================================================

Rename the current “Operational Expense Summary” page and sidebar label to:

Upload & Review

Requirements:

- Change only the visible title, sidebar label, breadcrumb, and relevant navigation text.
- Keep the current page structure and functionality untouched.
- Preserve existing imports.
- Preserve existing Excel upload/import behavior.
- Preserve existing totals and calculation logic.
- Preserve fixed-cost functionality.
- Preserve direct-cost and indirect-cost functionality.
- Preserve manual expense functionality.
- Preserve existing report save and update payloads.
- Preserve report statuses.
- Preserve the existing PDF/export behavior.
- Preserve all current validations.
- Preserve the current database structure.

Do not rebuild the page from scratch.

The existing Upload & Review page must remain the single source of truth for:

- Creating reports
- Reviewing reports
- Editing reports
- Saving drafts
- Finalizing reports
- Viewing report summaries

==================================================
5. AMOUNT ALLOCATION UI
==================================================

Replace only the current amount-allocation UI/dialog with the Invoice Allocation implementation from Invoice Allocation.txt.

Do not replace unrelated Operational Expense code.

Reuse and adapt the referenced:

- InvoiceAllocationPage
- calculateGstAmounts()
- gstPreview()
- clientGstPreview
- locationGstTotal
- splitEvenly()
- Client allocation logic
- Location allocation logic
- CRKL automatic balance logic
- Validation behavior
- Allocation summary
- Save behavior
- Invoice generation confirmation

Preserve the existing target project APIs and API contracts.

The dialog must include:

Compact header:
- Invoice Allocation
- Status badge
- Selected client name
- X close button at the absolute top-right corner

Do not display a duplicate inner header.

Use a responsive 70/30 layout:

- Left: allocation form
- Right: sticky live allocation summary

Client section:

- Invoice Amount
- Taxable Amount
- GST Amount
- Total Including GST

Location cards:

- Location name
- Location code
- Invoice Amount
- Taxable Amount
- GST
- Total Including GST

Location grid:

- Desktop: two cards per row
- Tablet: two cards per row
- Mobile: one card per row

Live summary:

- Total Billable
- Client Allocation
- Location Allocation
- Remaining Allocation
- Taxable Amount
- GST
- Allocated Total
- Remaining Total
- Allocation status

Status colors:

- Green: Balanced
- Orange: Pending Allocation
- Red: Over Allocated

Footer:

- Sticky footer
- Close button on the left
- Save Allocation button on the right
- Preserve loading and disabled states

Do not change:

- saveInvoiceAllocation()
- getInvoiceAllocation()
- getClientLocations()
- generateOperationalExpenseInvoice()
- Existing allocation payload
- Existing database structure
- Existing GST formulas
- Existing validation rules
- Existing save order
- Existing CRKL automatic balancing
- Existing client and location relationships

==================================================
6. REPORTS PAGE WITH LIST AND KANBAN OPTIONS
==================================================

Keep the current Operational Expense Reports page and all existing behavior.

Do not replace or remove the existing report list.

Add a view switch with two options:

- List View
- Kanban View

List View:

- Must remain exactly as the current report list.
- Preserve the existing search.
- Preserve filters.
- Preserve report actions.
- Preserve pagination if it exists.
- Preserve loading and empty states.
- Preserve current mobile and desktop behavior.

Kanban View:

- Add as a new optional view.
- Do not display both views simultaneously.
- Default to the existing List View unless the current project has a saved preference pattern.
- Switching views must not trigger unnecessary duplicate API requests.
- Use the reports already loaded by the Reports page.
- Preserve currently selected filters and search where applicable.

Implement the Kanban view through:

src/components/operational-expense-components/OperationalExpenseCalendarView.jsx

or the equivalent components folder used by the target project.

The Kanban view must display exactly 12 month cards for the selected year.

Each month card must show:

- Month name
- Total operational expense
- Number of reports
- Report status
- Last updated date
- View Summary action

Status styles:

- Draft: warning/amber
- Finalized: info/blue
- Invoiced: success/green
- Archived: neutral/grey
- No report: muted

Rules:

- Empty months display ₹0.00.
- Empty months display “No report.”
- Empty months are not clickable.
- Populated months are keyboard accessible.
- Do not create a duplicate second calendar.
- Do not create a duplicate reports page.
- Do not remove the current List View.
- Use actual report data only.

Responsive grid:

- Mobile: one card per row
- Tablet: two cards per row
- Medium desktop: three cards per row
- Large desktop: four cards per row

If multiple reports exist in one month:

- Sum their operational expense totals for the month card.
- Display the correct report count.
- Select the most recently updated report for View Summary.
- Do not merge report rows into a fabricated report.

==================================================
7. VIEW SUMMARY BEHAVIOR
==================================================

When View Summary is clicked from List View or Kanban View:

- Navigate to the original Upload & Review page.
- Pass the selected report ID using the target project’s routing pattern.

Expected route state:

{
  operationalExpenseReportId: reportId,
  mode: 'summary'
}

The original Upload & Review UI must open in readonly summary mode.

Do not create a separate summary table on the Reports page.

Do not duplicate calculation or table code.

For a saved DRAFT report in summary mode, show:

- Edit
- Finalize Report

When Edit is clicked:

- Enable the existing Upload & Review controls.
- Replace actions with:
  - Cancel
  - Save Draft

Save Draft must:

- Update the existing report ID.
- Not create a duplicate report.
- Preserve status as DRAFT.
- Return to readonly summary mode after saving.

Finalize Report must:

- Show a confirmation dialog.
- Change the report status using the existing API.
- Redirect to the Reports page after success.
- Refresh the local report list without a full browser reload.

==================================================
8. INVOICES PAGE
==================================================

Create an Invoices page below Reports in the Operational Expense sidebar.

The page must display allocated and generated invoices using actual invoice allocation data.

Use the invoice functionality found in Invoice Allocation.txt as the reference.

The page must support:

- Year filter
- Month filter
- Client filter
- Report/month selection
- Client name
- Client code
- Location name or Corporate
- Allocated invoice amount
- Invoice status
- Generated status
- Preview Invoice
- Print / PDF
- Download Invoice

Use actual existing APIs such as:

- getInvoiceAllocations()
- generateOperationalExpenseInvoice()

Use any other invoice API only if that function exists in the target project.

Do not invent updateOperationalExpenseInvoice() if the API does not exist.

If the backend does not provide persistent invoice history:

- Clearly state the limitation.
- Use confirmed allocation data only if that matches the current backend design.
- Do not fabricate invoice records or statuses.

Invoice workflow:

FINALIZED
→ Open Invoice Allocation
→ Save confirmed allocations
→ Generate Invoice
→ Select client
→ Select location when available
→ Preview Invoice
→ Download Invoice
→ Mark report INVOICED only after successful download

Do not mark a report INVOICED merely when Generate Invoice is clicked.

After successful invoice download:

- Update the report status to INVOICED using the existing API.
- Refresh the local UI.
- Disable and mute Edit and Delete actions.
- Keep View Summary available.
- Keep report and invoice download available.
- Keep Preview Invoice available when supported.

==================================================
9. AUDIT TRAIL
==================================================

Implement an Operational Expense Audit Trail page.

Before implementation, analyze whether the backend has:

- Audit routes
- Audit controller
- Audit collection/model
- Created-by fields
- Updated-by fields
- Status history
- Report history
- Invoice history
- Allocation history

If a proper audit API exists, show actual events with:

- Date and time
- User
- Action
- Entity type
- Entity ID or reference
- Report month
- Old status
- New status
- Description
- Result
- Relevant metadata

Include filters where supported:

- Date range
- User
- Action
- Entity type
- Report month
- Status

If no audit API exists:

- Do not fabricate events.
- Display a professional empty state explaining that audit records are unavailable.
- Do not store fake audit history in localStorage or frontend state.
- If backend changes are permitted, implement the smallest audit feature that follows the current backend architecture.
- Do not modify unrelated models or middleware.

==================================================
10. REPORT ACTION RULES
==================================================

Use only statuses supported by the target backend.

Expected logical flow:

DRAFT
→ FINALIZED
→ INVOICED

Confirm these values before hardcoding them.

Action matrix:

New unsaved report:
- Save Draft

Saved DRAFT report in readonly summary mode:
- Edit
- Finalize Report

DRAFT report in edit mode:
- Cancel
- Save Draft

FINALIZED report:
- View Summary
- Generate Invoice
- Download Report
- Edit

INVOICED report:
- View Summary
- Preview or Download Invoice
- Download Report
- Edit visible but disabled/muted
- Delete visible but disabled/muted

Do not hide disabled Edit and Delete actions after invoicing.

Do not change the report to DRAFT merely by opening it.

==================================================
11. CODING STANDARDS
==================================================

Follow the target project’s current standards:

- React functional components
- Existing hooks pattern
- Existing Material UI version
- Existing route structure
- Existing API utilities
- Existing DataProvider or context pattern
- Existing formatting style
- Existing error handling
- Existing loading indicators
- Existing confirmation dialogs
- Existing Snackbar or Alert pattern
- Existing responsive breakpoints
- Existing naming conventions
- Existing import style

Requirements:

- No new UI framework
- No unnecessary dependency
- No mock data
- No fake API
- No duplicate calculations
- No duplicate calendar
- No duplicate header
- No duplicate summary page
- No console.log statements
- No unused imports
- No unused state
- No placeholder code
- No commented-out replacement implementations
- No unrelated refactoring

Use useMemo for derived report, calendar, and invoice data.

Use useCallback only where it provides a real benefit.

Use stable React keys.

Provide accessible labels, keyboard support, and visible focus styles.

==================================================
12. FILE ORGANIZATION
==================================================

Follow the target project structure.

Prefer placing new Operational Expense components inside:

src/components/operational-expense-components/

Expected reusable components may include:

- OperationalExpenseDashboardCards.jsx
- OperationalExpenseDashboardTable.jsx
- OperationalExpenseCalendarView.jsx
- OperationalExpenseViewToggle.jsx
- InvoiceAllocationPage.jsx
- InvoiceDialogs.jsx
- OperationalExpenseInvoiceList.jsx
- OperationalExpenseAuditTrail.jsx

Only create components that fit the current architecture.

Do not move existing working files unnecessarily.

==================================================
13. PRESERVE EXISTING FUNCTIONALITY
==================================================

Keep all unrelated Operational Expense code untouched.

Do not change:

- Report calculations
- Markup formulas
- Operational expense totals
- Fixed-cost calculations
- Client allocations
- Location allocations
- GST formulas
- Report save payloads
- Invoice allocation payloads
- Invoice-generation payloads
- Database schema
- PDF report structure
- Excel import behavior
- Existing validations
- Existing API routes
- Authentication
- Authorization
- Global theme
- Other application modules

==================================================
14. REQUIRED OUTPUT
==================================================

Return:

1. A concise analysis of the existing project and Invoice Allocation.txt
2. Exact files to create
3. Exact files to modify
4. Complete updated code for every modified file
5. Complete code for every new file
6. A short verification checklist

Do not return:

- Partial snippets
- Pseudocode
- “Keep the existing code here”
- Omitted sections
- Fabricated backend behavior
- Unverified imports
- Unverified API calls

==================================================
15. FINAL VERIFICATION
==================================================

Before returning the implementation, verify:

1. The project compiles.
2. All imported functions exist.
3. No unused imports or state remain.
4. Dashboard is available inside Operational Expense.
5. Operational Expense Summary is renamed to Upload & Review.
6. Existing Upload & Review behavior remains unchanged.
7. The new allocation dialog uses the Invoice Allocation reference.
8. No duplicate allocation header appears.
9. Existing allocation APIs and payloads remain unchanged.
10. Reports retain the current List View.
11. Kanban View is available as a separate option.
12. List and Kanban views do not render simultaneously.
13. Exactly 12 month cards appear in Kanban View.
14. Empty months are not clickable.
15. View Summary opens the original Upload & Review UI.
16. No duplicate summary page exists.
17. Invoices page displays actual allocated/generated invoice data.
18. Report status becomes INVOICED only after successful invoice download.
19. Audit Trail uses actual backend data or shows a truthful empty state.
20. Mobile, tablet, and desktop layouts work without overflow.
21. Existing report calculations, export, save, and invoice behavior remain intact.
22. No unrelated file or functionality is changed.