import {
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
} from "@mui/material";

import { Icons } from "../../theme/icons.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { formatIST } from "../../utils/dateFormatter.js";

const formatCurrency = (value) => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(value) || 0);
};

export default function CashFlowEntryTable({
  rows = [],
  onEdit,
  onDeleteRequest,
}) {
  const { permissions } = useAuth();

  const showActions = permissions?.write || permissions?.delete;

  return (
    <TableContainer
      component={Paper}
      sx={{
        border: "1px solid",
        borderColor: "divider",
        boxShadow: "none",
        borderRadius: 1,
      }}
    >
      <Table size="small">
        <TableHead>
          <TableRow
            sx={{
              bgcolor: "background.default",
            }}
          >
            <TableCell
              sx={{
                fontWeight: 700,
              }}
            >
              Date
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 700,
              }}
            >
              Component
            </TableCell>

            <TableCell
              sx={{
                fontWeight: 700,
              }}
            >
              Description
            </TableCell>

            <TableCell
              align="right"
              sx={{
                fontWeight: 700,
              }}
            >
              Amount
            </TableCell>

            {showActions && (
              <TableCell
                align="center"
                sx={{
                  fontWeight: 700,
                  width: 120,
                }}
              >
                Actions
              </TableCell>
            )}
          </TableRow>
        </TableHead>

        <TableBody>
          {rows.length === 0 ? (
            <TableRow>
              <TableCell
                colSpan={showActions ? 5 : 4}
                align="center"
                sx={{
                  py: 6,
                }}
              >
                <Typography
                  sx={{
                    fontWeight: 700,
                  }}
                >
                  No cash flow entries found
                </Typography>

                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{
                    mt: 0.5,
                  }}
                >
                  Add a cash flow entry to get started.
                </Typography>
              </TableCell>
            </TableRow>
          ) : (
            rows.map((row) => (
              <TableRow key={row._id} hover>
                <TableCell>{formatIST(row.entryDate)}</TableCell>

                <TableCell>
                  <Typography variant="body2">
                    {row.componentId?.componentName || "-"}
                  </Typography>
                </TableCell>

                <TableCell>{row.description || "-"}</TableCell>

                <TableCell
                  align="right"
                  sx={{
                    fontWeight: 600,
                    whiteSpace: "nowrap",
                    fontVariantNumeric: "tabular-nums",
                  }}
                >
                  {formatCurrency(row.amount)}
                </TableCell>

                {showActions && (
                  <TableCell align="center">
                    <Stack
                      direction="row"
                      spacing={0.5}
                      justifyContent="center"
                    >
                      {permissions?.write && (
                        <Tooltip title="Edit">
                          <IconButton size="small" onClick={() => onEdit(row)}>
                            <Icons.EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}

                      {permissions?.delete && (
                        <Tooltip title="Delete">
                          <IconButton
                            size="small"
                            onClick={() => onDeleteRequest(row)}
                            sx={{
                              color: "error.main",
                            }}
                          >
                            <Icons.DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                    </Stack>
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
