import { Box, Card, CardContent, Grid, Stack, Typography } from "@mui/material";

import CurrencyRupeeOutlinedIcon from "@mui/icons-material/CurrencyRupeeOutlined";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";
import { Icons } from "../../theme/icons";

/* -------------------------------------------------------------------------- */
/*                                  Helpers                                   */
/* -------------------------------------------------------------------------- */

const formatINR = (value) => {
  const numericValue = Number(value) || 0;

  return `${numericValue.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
};

const SUMMARY_CARD_CONFIG = [
  {
    key: "sourceTotal",
    title: "Source Month Total",
    icon: CurrencyRupeeOutlinedIcon,
    color: "#1565C0",
    backgroundColor: "rgba(21, 101, 192, 0.1)",
    type: "currency",
  },
  {
    key: "forecastTotal",
    title: "3 Months Total Expense (Estimated)",
    icon: TrendingUpRoundedIcon,
    color: "#3EB8AF",
    backgroundColor: "rgba(62, 184, 175, 0.12)",
    type: "currency",
  },
];

/* -------------------------------------------------------------------------- */
/*                              Summary Card                                  */
/* -------------------------------------------------------------------------- */

function SummaryCard({
  title,
  value,
  icon: Icon,
  color,
  backgroundColor,
  helperText,
  type,
}) {
  const displayedValue =
    type === "currency"
      ? formatINR(value)
      : Number(value || 0).toLocaleString("en-IN");

  return (
    <Card
      sx={{
        width: "100%",
        height: "100%",
        minWidth: 0,
        borderRadius: 1,
        border: "1px solid",
        borderColor: "divider",
        overflow: "hidden",
        transition: "transform 160ms ease, box-shadow 160ms ease",

        "&:hover": {
          transform: "translateY(-2px)",
        },
      }}
    >
      <CardContent
        sx={{
          p: {
            xs: 2,
            sm: 2.25,
          },

          "&:last-child": {
            pb: {
              xs: 2,
              sm: 2.25,
            },
          },
        }}
      >
        <Stack
          direction="row"
          sx={{ alignItems: "flex-start", justifyContent: "space-between" }}
          gap={1.5}
        >
          <Box sx={{ minWidth: 0 }}>
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                fontWeight: 600,
              }}
            >
              {title}
            </Typography>

            <Typography
              sx={{
                mt: 0.75,
                fontSize: {
                  xs: "1.25rem",
                  sm: "1.45rem",
                },
                lineHeight: 1.25,
                fontWeight: 700,
                color: "text.primary",
                whiteSpace: "nowrap",
                fontVariantNumeric: "tabular-nums",
                display: "flex",
                alignItems: "center"
              }}
            >
              <Icons.CurrencyRupeeOutlinedIcon />
              {displayedValue}
            </Typography>

            {helperText && (
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                  display: "block",
                  mt: 0.75,
                  fontFamily: '"DM Sans", sans-serif',
                }}
              >
                {helperText}
              </Typography>
            )}
          </Box>

          <Box
            sx={{
              width: 42,
              height: 42,
              display: "grid",
              placeItems: "center",
              flexShrink: 0,
              borderRadius: 2,
              color,
              bgcolor: backgroundColor,
            }}
          >
            <Icon fontSize="small" />
          </Box>
        </Stack>
      </CardContent>
    </Card>
  );
}

/* -------------------------------------------------------------------------- */
/*                              Main Component                                */
/* -------------------------------------------------------------------------- */

export default function ForecastSummaryCards({
  sourceTotal = 0,
  forecastTotal = 0,
  sourcePeriod = "",
}) {
  const sourceMonthName = sourcePeriod ? sourcePeriod.split(" ")[0] : "Source";

  const sourceMonthTitle =
    sourceMonthName === "Source"
      ? "Source Month Total"
      : `${sourceMonthName} Month Total Expense`;

  const values = {
    sourceTotal,
    forecastTotal,
  };

  return (
    <Grid container spacing={2}>
      {SUMMARY_CARD_CONFIG.map((cardConfig) => (
        <Grid
          key={cardConfig.key}
          size={{
            xs: 12,
            sm: 6,
            lg: 6,
          }}
        >
          <SummaryCard
            title={
              cardConfig.key === "sourceTotal"
                ? sourceMonthTitle
                : cardConfig.title
            }
            value={values[cardConfig.key]}
            icon={cardConfig.icon}
            color={cardConfig.color}
            backgroundColor={cardConfig.backgroundColor}
            type={cardConfig.type}
          />
        </Grid>
      ))}
    </Grid>
  );
}
