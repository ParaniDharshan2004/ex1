import { useMemo } from "react";

import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Chip,
  Divider,
  IconButton,
  InputAdornment,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";

import RestartAltRoundedIcon from "@mui/icons-material/RestartAltRounded";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import CircularProgress from "@mui/material/CircularProgress";
import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";
import PictureAsPdfOutlinedIcon from "@mui/icons-material/PictureAsPdfOutlined";

/* -------------------------------------------------------------------------- */
/*                                  Helpers                                   */
/* -------------------------------------------------------------------------- */

const formatINR = (value) => {
  const numericValue = Number(value) || 0;

  return `${numericValue.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
};

const getRowForecastTotal = (row) => {
  return (
    (Number(row.month1) || 0) +
    (Number(row.month2) || 0) +
    (Number(row.month3) || 0)
  );
};

/* -------------------------------------------------------------------------- */
/*                         Editable Forecast Cell                             */
/* -------------------------------------------------------------------------- */

function EditableAmountCell({ value, rowId, field, onCellChange }) {
  return (
    <TextField
      fullWidth
      size="small"
      type="number"
      value={value}
      onChange={(event) => onCellChange(rowId, field, event.target.value)}
      inputProps={{
        min: 0,
        step: "0.01",
        inputMode: "decimal",
        style: {
          textAlign: "right",
          fontFamily: "DM Sans",
          fontVariantNumeric: "tabular-nums",
        },
      }}
      InputProps={{
        startAdornment: <InputAdornment position="start"></InputAdornment>,
      }}
      sx={{
        minWidth: 135,

        "& .MuiOutlinedInput-root": {
          borderRadius: 1.5,
          bgcolor: "background.paper",
        },

        "& .MuiInputAdornment-root": {
          mr: 0.5,
          fontFamily: '"DM Sans", sans-serif',
        },
      }}
    />
  );
}

/* -------------------------------------------------------------------------- */
/*                              Main Component                                */
/* -------------------------------------------------------------------------- */

export default function ForecastTable({
  rows = [],
  sourcePeriod = "",
  forecastMonths = [],
  importing = false,
  exporting = false,
  onImport = () => {},
  onExport = () => {},
  onCellChange = () => {},
  onResetRow = () => {},
}) {
  const month1Label = forecastMonths[0]?.shortLabel || "Month 1";

  const month2Label = forecastMonths[1]?.shortLabel || "Month 2";

  const month3Label = forecastMonths[2]?.shortLabel || "Month 3";

  const sourceTotal = useMemo(() => {
    return rows.reduce((total, row) => {
      return total + (Number(row.sourceAmount) || 0);
    }, 0);
  }, [rows]);

  const month1Total = useMemo(() => {
    return rows.reduce((total, row) => {
      return total + (Number(row.month1) || 0);
    }, 0);
  }, [rows]);

  const month2Total = useMemo(() => {
    return rows.reduce((total, row) => {
      return total + (Number(row.month2) || 0);
    }, 0);
  }, [rows]);

  const month3Total = useMemo(() => {
    return rows.reduce((total, row) => {
      return total + (Number(row.month3) || 0);
    }, 0);
  }, [rows]);

  const threeMonthTotal = month1Total + month2Total + month3Total;

  const editedRows = rows.filter((row) => row.isEdited).length;

  return (
    <Card
      sx={{
        width: "100%",
        minWidth: 0,
        borderRadius: 1,
        border: "1px solid",
        borderColor: "divider",
        boxShadow: "0 4px 18px rgba(15, 23, 42, 0.055)",
        overflow: "hidden",
      }}
    >
      <CardHeader
        avatar={
          <Box
            sx={{
              width: 42,
              height: 42,
              display: "grid",
              placeItems: "center",
              flexShrink: 0,
              borderRadius: 2,
              bgcolor: "rgba(29, 137, 200, 0.1)",
              color: "primary.main",
            }}
          >
            <TableChartOutlinedIcon />
          </Box>
        }
        title="Three-Month Forecast"
        subheader={`Source period: ${sourcePeriod}`}
        action={
          <Chip
            icon={<EditOutlinedIcon />}
            label={`${editedRows} edited`}
            size="small"
            variant="outlined"
            sx={{
              mt: 0.75,
              mr: 1,
              fontWeight: 600,
            }}
          />
        }
        titleTypographyProps={{
          sx: {
            fontFamily: '"DM Sans", sans-serif',
            fontSize: "1.05rem",
            fontWeight: 700,
          },
        }}
        subheaderTypographyProps={{
          sx: {
            mt: 0.35,
            fontFamily: '"DM Sans", sans-serif',
            fontSize: "0.82rem",
          },
        }}
        sx={{
          px: {
            xs: 2,
            sm: 3,
          },
          py: 2,

          "& .MuiCardHeader-content": {
            minWidth: 0,
          },

          "& .MuiCardHeader-action": {
            alignSelf: "center",
            m: 0,
          },
        }}
      />

      <Divider />

      <CardContent
        sx={{
          width: "100%",
          minWidth: 0,
          p: 0,

          "&:last-child": {
            pb: 0,
          },
        }}
      >
        <TableContainer
          sx={{
            width: "100%",
            maxWidth: "100%",
            overflowX: "auto",
          }}
        >
          <Table
            stickyHeader
            sx={{
              width: "100%",
              minWidth: 1120,
              tableLayout: "fixed",
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell
                  align="left"
                  sx={{
                    width: 70,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  S.No
                </TableCell>

                <TableCell
                  align="left"
                  sx={{
                    width: 230,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  Component
                </TableCell>

                <TableCell
                  align="right"
                  sx={{
                    width: 150,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  {sourcePeriod}
                </TableCell>

                <TableCell
                  align="right"
                  sx={{
                    width: 170,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  {month1Label}
                </TableCell>

                <TableCell
                  align="right"
                  sx={{
                    width: 170,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  {month2Label}
                </TableCell>

                <TableCell
                  align="right"
                  sx={{
                    width: 170,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  {month3Label}
                </TableCell>

                <TableCell
                  align="right"
                  sx={{
                    width: 170,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  Forecast Total
                </TableCell>

                <TableCell
                  align="center"
                  sx={{
                    width: 80,
                    fontWeight: 700,
                    bgcolor: "#F8FAFC",
                  }}
                >
                  Action
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {rows.length > 0 ? (
                rows.map((row, index) => (
                  <TableRow
                    key={row.id || index}
                    hover
                    sx={{
                      bgcolor: row.isEdited
                        ? "rgba(29, 137, 200, 0.025)"
                        : "background.paper",
                    }}
                  >
                    <TableCell
                      align="left"
                      sx={{
                        color: "text.secondary",
                      }}
                    >
                      {index + 1}
                    </TableCell>

                    <TableCell align="left">
                      <Stack
                        direction="row"
                        alignItems="center"
                        gap={1}
                        sx={{
                          minWidth: 0,
                        }}
                      >
                        <Box sx={{ minWidth: 0 }}>
                          <Typography
                            variant="body2"
                            sx={{
                              fontFamily: '"DM Sans", sans-serif',
                              fontWeight: 600,
                              lineHeight: 1.4,
                              overflowWrap: "anywhere",
                            }}
                          >
                            {row.componentName || "-"}
                          </Typography>

                          <Stack
                            direction="row"
                            gap={0.75}
                            flexWrap="wrap"
                            sx={{
                              mt: 0.5,
                            }}
                          >
                            <Chip
                              size="small"
                              label={
                                row.source === "TALLY"
                                  ? "Tally"
                                  : "Component Master"
                              }
                              color={
                                row.source === "TALLY" ? "primary" : "default"
                              }
                              variant="outlined"
                              sx={{
                                height: 22,
                                fontSize: "0.68rem",
                              }}
                            />

                            {row.isNewComponent && (
                              <Chip
                                size="small"
                                label="New"
                                color="warning"
                                variant="outlined"
                                sx={{
                                  height: 22,
                                  fontSize: "0.68rem",
                                }}
                              />
                            )}

                            {row.isEdited && (
                              <Chip
                                size="small"
                                label="Edited"
                                color="info"
                                variant="outlined"
                                sx={{
                                  height: 22,
                                  fontSize: "0.68rem",
                                }}
                              />
                            )}
                          </Stack>
                        </Box>
                      </Stack>
                    </TableCell>

                    <TableCell align="right">
                      <Typography
                        sx={{
                          fontFamily: '"DM Sans", sans-serif',
                          fontSize: "0.9rem",
                          fontWeight: 600,
                          whiteSpace: "nowrap",
                          fontVariantNumeric: "tabular-nums",
                        }}
                      >
                        {formatINR(row.sourceAmount)}
                      </Typography>
                    </TableCell>

                    <TableCell align="right">
                      <EditableAmountCell
                        value={row.month1}
                        rowId={row.id}
                        field="month1"
                        onCellChange={onCellChange}
                      />
                    </TableCell>

                    <TableCell align="right">
                      <EditableAmountCell
                        value={row.month2}
                        rowId={row.id}
                        field="month2"
                        onCellChange={onCellChange}
                      />
                    </TableCell>

                    <TableCell align="right">
                      <EditableAmountCell
                        value={row.month3}
                        rowId={row.id}
                        field="month3"
                        onCellChange={onCellChange}
                      />
                    </TableCell>

                    <TableCell align="right">
                      <Typography
                        sx={{
                          fontFamily: '"DM Sans", sans-serif',
                          fontSize: "0.9rem",
                          fontWeight: 700,
                          whiteSpace: "nowrap",
                          fontVariantNumeric: "tabular-nums",
                        }}
                      >
                        {formatINR(getRowForecastTotal(row))}
                      </Typography>
                    </TableCell>

                    <TableCell align="center">
                      <Tooltip title="Reset to source amount">
                        <span>
                          <IconButton
                            size="small"
                            disabled={!row.isEdited}
                            onClick={() => onResetRow(row.id)}
                            sx={{
                              border: "1px solid",
                              borderColor: "divider",
                              borderRadius: 1.5,
                            }}
                          >
                            <RestartAltRoundedIcon fontSize="small" />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={8}
                    align="center"
                    sx={{
                      py: {
                        xs: 7,
                        sm: 9,
                      },
                    }}
                  >
                    <UploadFileRoundedIcon
                      sx={{
                        fontSize: 44,
                        color: "text.disabled",
                      }}
                    />

                    <Typography
                      sx={{
                        mt: 1,
                        fontWeight: 700,
                      }}
                    >
                      No Excel file imported
                    </Typography>

                    <Typography
                      variant="body2"
                      color="text.secondary"
                      sx={{
                        mt: 0.5,
                      }}
                    >
                      Import a Tally Excel sheet to generate the editable
                      three-month forecast.
                    </Typography>

                    <Button
                      variant="outlined"
                      startIcon={
                        importing ? (
                          <CircularProgress size={16} />
                        ) : (
                          <UploadFileRoundedIcon />
                        )
                      }
                      disabled={importing || exporting}
                      onClick={onImport}
                      sx={{
                        mt: 2,
                        borderRadius: 2,
                        textTransform: "none",
                        fontWeight: 700,
                      }}
                    >
                      {importing ? "Importing..." : "Select Excel File"}
                    </Button>
                  </TableCell>
                </TableRow>
              )}

              {rows.length > 0 && (
                <TableRow
                  sx={{
                    bgcolor: "rgba(29, 137, 200, 0.08)",
                  }}
                >
                  <TableCell />

                  <TableCell>
                    <Typography
                      sx={{
                        fontFamily: '"DM Sans", sans-serif',
                        fontWeight: 700,
                      }}
                    >
                      Total Amount
                    </Typography>
                  </TableCell>

                  <TableCell align="right">
                    <Typography
                      sx={{
                        fontFamily: '"DM Sans", sans-serif',
                        fontWeight: 700,
                        whiteSpace: "nowrap",
                        fontVariantNumeric: "tabular-nums",
                      }}
                    >
                      {formatINR(sourceTotal)}
                    </Typography>
                  </TableCell>

                  <TableCell align="right">
                    <Typography
                      sx={{
                        fontFamily: '"DM Sans", sans-serif',
                        fontWeight: 700,
                        whiteSpace: "nowrap",
                        fontVariantNumeric: "tabular-nums",
                      }}
                    >
                      {formatINR(month1Total)}
                    </Typography>
                  </TableCell>

                  <TableCell align="right">
                    <Typography
                      sx={{
                        fontFamily: '"DM Sans", sans-serif',
                        fontWeight: 700,
                        whiteSpace: "nowrap",
                        fontVariantNumeric: "tabular-nums",
                      }}
                    >
                      {formatINR(month2Total)}
                    </Typography>
                  </TableCell>

                  <TableCell align="right">
                    <Typography
                      sx={{
                        fontFamily: '"DM Sans", sans-serif',
                        fontWeight: 700,
                        whiteSpace: "nowrap",
                        fontVariantNumeric: "tabular-nums",
                      }}
                    >
                      {formatINR(month3Total)}
                    </Typography>
                  </TableCell>

                  <TableCell align="right">
                    <Typography
                      sx={{
                        fontFamily: '"DM Sans", sans-serif',
                        fontWeight: 800,
                        whiteSpace: "nowrap",
                        fontVariantNumeric: "tabular-nums",
                      }}
                    >
                      {formatINR(threeMonthTotal)}
                    </Typography>
                  </TableCell>

                  <TableCell />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </CardContent>

      {rows.length > 0 && (
        <>
          <Divider />

          <CardActions
            sx={{
              px: {
                xs: 2,
                sm: 3,
              },
              py: 1.5,
              display: "flex",
              flexDirection: {
                xs: "column",
                sm: "row",
              },
              alignItems: {
                xs: "stretch",
                sm: "center",
              },
              justifyContent: "space-between",
              gap: 1.5,
              bgcolor: "#FAFCFE",
            }}
          >
            <Box>
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                  display: "block",
                  fontFamily: '"DM Sans", sans-serif',
                }}
              >
                Every forecast value can be edited. Select reset to restore the
                source amount.
              </Typography>

              <Typography
                sx={{
                  mt: 0.35,
                  fontFamily: '"DM Sans", sans-serif',
                  fontSize: "1rem",
                  fontWeight: 800,
                  whiteSpace: "nowrap",
                  fontVariantNumeric: "tabular-nums",
                }}
              >
                Forecast: {formatINR(threeMonthTotal)}
              </Typography>
            </Box>

            <Stack
              direction={{
                xs: "column",
                sm: "row",
              }}
              gap={1}
            >
              <Button
                variant="outlined"
                startIcon={<UploadFileRoundedIcon />}
                disabled={importing || exporting}
                onClick={onImport}
                sx={{
                  minWidth: 150,
                  minHeight: 42,
                  borderRadius: 2,
                  textTransform: "none",
                  fontWeight: 700,
                }}
              >
                Import Another
              </Button>

              <Button
                variant="contained"
                startIcon={
                  exporting ? (
                    <CircularProgress size={18} color="inherit" />
                  ) : (
                    <PictureAsPdfOutlinedIcon />
                  )
                }
                disabled={importing || exporting}
                onClick={onExport}
                sx={{
                  minWidth: 150,
                  minHeight: 42,
                  borderRadius: 2,
                  boxShadow: "none",
                  textTransform: "none",
                  fontWeight: 700,
                }}
              >
                {exporting ? "Preparing PDF..." : "Export PDF"}
              </Button>
            </Stack>
          </CardActions>
        </>
      )}
    </Card>
  );
}
