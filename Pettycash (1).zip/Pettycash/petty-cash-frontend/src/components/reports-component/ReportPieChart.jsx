import { useMemo } from 'react';

import {
  Box,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Divider,
  Grid,
  Skeleton,
  Stack,
  Typography,
  useMediaQuery,
  useTheme,
} from '@mui/material';

import DonutLargeOutlinedIcon from '@mui/icons-material/DonutLargeOutlined';

import {
  Cell,
  Label,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';

import { CHART_COLORS } from './ReportBarGraph';

/* -------------------------------------------------------------------------- */
/*                                  Helpers                                   */
/* -------------------------------------------------------------------------- */

const formatINRNumber = (value) => {
  const numericValue = Number(value) || 0;

  return numericValue.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

const formatINR = (value) => {
  return `₹${formatINRNumber(value)}`;
};

const calculatePercentage = (value, total) => {
  const numericValue = Number(value) || 0;
  const numericTotal = Number(total) || 0;

  if (!numericTotal) {
    return '0.0%';
  }

  return `${((numericValue / numericTotal) * 100).toFixed(1)}%`;
};

/* -------------------------------------------------------------------------- */
/*                         Shared Currency Component                          */
/* -------------------------------------------------------------------------- */

function CurrencyAmount({
  value,
  fontSize = '0.9rem',
  fontWeight = 700,
  align = 'right',
  fullWidth = false,
}) {
  return (
    <Typography
      component="span"
      sx={{
        display: 'inline-flex',
        width: fullWidth ? '100%' : 'auto',
        alignItems: 'baseline',
        justifyContent:
          align === 'right'
            ? 'flex-end'
            : align === 'center'
              ? 'center'
              : 'flex-start',
        gap: 0,
        fontFamily: '"DM Sans", sans-serif',
        fontSize,
        fontWeight,
        lineHeight: 1.4,
        letterSpacing: 0,
        color: 'text.primary',
        whiteSpace: 'nowrap',
        fontVariantNumeric: 'tabular-nums',
      }}
    >
      <Box
        component="span"
        sx={{
          display: 'inline',
          flexShrink: 0,
          m: 0,
          p: 0,
          fontFamily: 'inherit',
          fontSize: '1em',
          fontWeight: 'inherit',
          lineHeight: 'inherit',
          letterSpacing: 0,
        }}
      >
        ₹
      </Box>

      <Box
        component="span"
        sx={{
          display: 'inline',
          m: 0,
          p: 0,
          fontFamily: 'inherit',
          fontSize: '1em',
          fontWeight: 'inherit',
          lineHeight: 'inherit',
          letterSpacing: 0,
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        {formatINRNumber(value)}
      </Box>
    </Typography>
  );
}

/* -------------------------------------------------------------------------- */
/*                                Tooltip                                     */
/* -------------------------------------------------------------------------- */

function CustomPieTooltip({ active, payload, totalExpense, dataKey, nameKey }) {
  if (!active || !payload?.length) {
    return null;
  }

  const selectedItem = payload[0]?.payload;

  return (
    <Box
      sx={{
        minWidth: 210,
        maxWidth: 290,
        p: 1.75,
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: 2,
        backgroundColor: 'background.paper',
        boxShadow: '0 12px 32px rgba(15, 23, 42, 0.14)',
        fontFamily: '"DM Sans", sans-serif',
      }}
    >
      <Typography
        variant="body2"
        sx={{
          mb: 1,
          fontFamily: 'inherit',
          fontWeight: 700,
          overflowWrap: 'anywhere',
        }}
      >
        {selectedItem?.[nameKey] || '-'}
      </Typography>

      <Stack spacing={0.75}>
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 2,
          }}
        >
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{
              fontFamily: 'inherit',
            }}
          >
            Amount
          </Typography>

          <CurrencyAmount
            value={selectedItem?.[dataKey]}
            fontSize="0.88rem"
            fontWeight={700}
            align="left"
          />
        </Box>

        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 2,
          }}
        >
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{
              fontFamily: 'inherit',
            }}
          >
            Share
          </Typography>

          <Typography
            variant="body2"
            sx={{
              fontFamily: 'inherit',
              fontWeight: 700,
            }}
          >
            {calculatePercentage(selectedItem?.[dataKey], totalExpense)}
          </Typography>
        </Box>
      </Stack>
    </Box>
  );
}

/* -------------------------------------------------------------------------- */
/*                           SVG Center Label                                 */
/* -------------------------------------------------------------------------- */

function PieCenterLabel({ viewBox, totalExpense, exportMode, isMobile }) {
  const cx = Number(viewBox?.cx);
  const cy = Number(viewBox?.cy);

  if (!Number.isFinite(cx) || !Number.isFinite(cy)) {
    return null;
  }

  const titleSize = exportMode ? 11 : isMobile ? 10 : 11;
  const amountSize = exportMode ? 14 : isMobile ? 13 : 15;

  return (
    <g>
      <text
        x={cx}
        y={cy - 9}
        textAnchor="middle"
        dominantBaseline="middle"
        fill="#64748b"
        style={{
          fontFamily: 'DM Sans',
          fontSize: titleSize,
          fontWeight: 500,
        }}
      >
        Total expense
      </text>

      <text
        x={cx}
        y={cy + 15}
        textAnchor="middle"
        dominantBaseline="middle"
        fill="#0f172a"
        style={{
          fontFamily: 'DM Sans',
          fontSize: amountSize,
          fontWeight: 700,
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        {formatINR(totalExpense || 0)}
      </text>
    </g>
  );
}

/* -------------------------------------------------------------------------- */
/*                              Main Component                                */
/* -------------------------------------------------------------------------- */

export default function ReportPieChart({
  title = 'Expense Distribution',
  subtitle = "Understand each component's share of the total expense.",
  data = [],
  loading = false,
  dataKey = 'totalExpense',
  nameKey = 'component',
  exportMode = false,
}) {
  const theme = useTheme();

  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  const safeData = useMemo(() => {
    if (!Array.isArray(data)) {
      return [];
    }

    return data.filter((item) => Number(item?.[dataKey]) > 0);
  }, [data, dataKey]);

  const totalExpense = useMemo(() => {
    return safeData.reduce((sum, item) => {
      return sum + (Number(item?.[dataKey]) || 0);
    }, 0);
  }, [safeData, dataKey]);

  const chartHeight = useMemo(() => {
    if (exportMode) {
      return 400;
    }

    if (isMobile) {
      return 290;
    }

    if (isTablet) {
      return 330;
    }

    return 370;
  }, [exportMode, isMobile, isTablet]);

  const pieSize = useMemo(() => {
    if (exportMode) {
      return {
        innerRadius: 76,
        outerRadius: 128,
      };
    }

    if (isMobile) {
      return {
        innerRadius: 58,
        outerRadius: 100,
      };
    }

    if (isTablet) {
      return {
        innerRadius: 68,
        outerRadius: 116,
      };
    }

    return {
      innerRadius: 78,
      outerRadius: 138,
    };
  }, [exportMode, isMobile, isTablet]);

  return (
    <Card
      sx={{
        width: '100%',
        borderRadius: exportMode ? 0 : 3,
        border: exportMode ? 'none' : '1px solid',
        borderColor: 'divider',
        boxShadow: exportMode ? 'none' : '0 4px 18px rgba(15, 23, 42, 0.06)',
        overflow: 'hidden',
        backgroundColor: '#ffffff',
      }}
    >
      {!exportMode && (
        <>
          <CardHeader
            avatar={
              <Box
                sx={{
                  width: 40,
                  height: 40,
                  display: 'grid',
                  placeItems: 'center',
                  borderRadius: 2,
                  color: 'primary.main',
                  backgroundColor: 'rgba(29, 137, 200, 0.1)',
                }}
              >
                <DonutLargeOutlinedIcon fontSize="small" />
              </Box>
            }
            title={title}
            subheader={subtitle}
            slotProps={{
              title: {
                sx: {
                  fontFamily: '"DM Sans", sans-serif',
                  fontSize: '1.05rem',
                  fontWeight: 700,
                },
              },
              subheader: {
                sx: {
                  mt: 0.35,
                  fontFamily: '"DM Sans", sans-serif',
                  fontSize: '0.82rem',
                },
              },
            }}
            sx={{
              px: {
                xs: 2,
                sm: 3,
              },
              py: 2,
            }}
          />

          <Divider />
        </>
      )}

      <CardContent
        sx={{
          p: exportMode
            ? 0
            : {
                xs: 2,
                sm: 2.5,
                md: 3,
              },
          '&:last-child': {
            pb: exportMode
              ? 0
              : {
                  xs: 2,
                  sm: 2.5,
                  md: 3,
                },
          },
        }}
      >
        {loading ? (
          <Grid container spacing={3}>
            <Grid size={{ xs: 12, md: 6 }}>
              <Skeleton
                variant="circular"
                width={isMobile ? 205 : 280}
                height={isMobile ? 205 : 280}
                sx={{
                  mx: 'auto',
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Grid container spacing={1.25}>
                {Array.from({ length: 6 }).map((_, index) => (
                  <Grid key={`pie-loading-${index}`} size={{ xs: 12, sm: 6 }}>
                    <Skeleton variant="rounded" height={68} />
                  </Grid>
                ))}
              </Grid>
            </Grid>
          </Grid>
        ) : safeData.length === 0 ? (
          <Box
            sx={{
              minHeight: 320,
              display: 'grid',
              placeItems: 'center',
              textAlign: 'center',
              px: 2,
            }}
          >
            <Box>
              <Typography
                fontWeight={700}
                sx={{
                  fontFamily: '"DM Sans", sans-serif',
                }}
              >
                No distribution data available
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
                sx={{
                  mt: 0.75,
                  fontFamily: '"DM Sans", sans-serif',
                }}
              >
                Select another reporting period to view expenses.
              </Typography>
            </Box>
          </Box>
        ) : exportMode ? (
          <Box
            sx={{
              width: '100%',
            }}
          >
            <Box
              sx={{
                width: '100%',
                height: chartHeight,
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart
                  margin={{
                    top: 20,
                    right: 20,
                    bottom: 20,
                    left: 20,
                  }}
                >
                  <Pie
                    data={safeData}
                    dataKey={dataKey}
                    nameKey={nameKey}
                    cx="50%"
                    cy="50%"
                    innerRadius={pieSize.innerRadius}
                    outerRadius={pieSize.outerRadius}
                    paddingAngle={1.5}
                    stroke="#ffffff"
                    strokeWidth={3}
                    isAnimationActive={false}
                  >
                    {safeData.map((item, index) => (
                      <Cell
                        key={item._id || `${item[nameKey]}-${index}`}
                        fill={CHART_COLORS[index % CHART_COLORS.length]}
                      />
                    ))}

                    <Label
                      position="center"
                      content={(labelProps) => (
                        <PieCenterLabel
                          {...labelProps}
                          totalExpense={totalExpense}
                          exportMode
                          isMobile={false}
                        />
                      )}
                    />
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </Box>

            <Grid
              container
              spacing={1}
              sx={{
                mt: 1,
              }}
            >
              {safeData.map((item, index) => (
                <Grid
                  key={`export-legend-${item[nameKey]}-${index}`}
                  size={{ xs: 6 }}
                >
                  <Box
                    sx={{
                      minHeight: 50,
                      display: 'grid',
                      gridTemplateColumns: '10px minmax(0, 1fr) auto',
                      alignItems: 'center',
                      gap: 1,
                      px: 1.25,
                      py: 0.75,
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                    }}
                  >
                    <Box
                      sx={{
                        width: 9,
                        height: 9,
                        borderRadius: '50%',
                        backgroundColor:
                          CHART_COLORS[index % CHART_COLORS.length],
                      }}
                    />

                    <Box sx={{ minWidth: 0 }}>
                      <Typography
                        sx={{
                          fontFamily: '"DM Sans", sans-serif',
                          fontSize: '9px',
                          lineHeight: 1.25,
                          fontWeight: 600,
                          color: '#1e293b',
                          overflowWrap: 'anywhere',
                        }}
                      >
                        {item[nameKey] || '-'}
                      </Typography>

                      <Typography
                        sx={{
                          mt: 0.2,
                          fontFamily: '"DM Sans", sans-serif',
                          fontSize: '8px',
                          color: '#64748b',
                        }}
                      >
                        {calculatePercentage(item[dataKey], totalExpense)}
                      </Typography>
                    </Box>

                    <Typography
                      sx={{
                        fontFamily: '"DM Sans", sans-serif',
                        fontSize: '9px',
                        fontWeight: 700,
                        whiteSpace: 'nowrap',
                        color: '#0f172a',
                        fontVariantNumeric: 'tabular-nums',
                      }}
                    >
                      {formatINR(item[dataKey])}
                    </Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Box>
        ) : (
          <Grid
            container
            spacing={{
              xs: 2,
              md: 3,
            }}
            sx={{
              alignItems: 'center',
            }}
          >
            <Grid size={{ xs: 12, md: 6 }}>
              <Box
                sx={{
                  width: '100%',
                  height: chartHeight,
                  minWidth: 0,
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart
                    margin={{
                      top: 12,
                      right: 12,
                      bottom: 12,
                      left: 12,
                    }}
                  >
                    <Pie
                      data={safeData}
                      dataKey={dataKey}
                      nameKey={nameKey}
                      cx="50%"
                      cy="50%"
                      innerRadius={pieSize.innerRadius}
                      outerRadius={pieSize.outerRadius}
                      paddingAngle={1.5}
                      stroke="#ffffff"
                      strokeWidth={3}
                      isAnimationActive
                    >
                      {safeData.map((item, index) => (
                        <Cell
                          key={item._id || `${item[nameKey]}-${index}`}
                          fill={CHART_COLORS[index % CHART_COLORS.length]}
                        />
                      ))}

                      <Label
                        position="center"
                        content={(labelProps) => (
                          <PieCenterLabel
                            {...labelProps}
                            totalExpense={totalExpense}
                            exportMode={false}
                            isMobile={isMobile}
                          />
                        )}
                      />
                    </Pie>

                    <Tooltip
                      content={
                        <CustomPieTooltip
                          totalExpense={totalExpense}
                          dataKey={dataKey}
                          nameKey={nameKey}
                        />
                      }
                    />
                  </PieChart>
                </ResponsiveContainer>
              </Box>
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <Grid container spacing={1.25}>
                {safeData.map((item, index) => (
                  <Grid
                    key={item._id || `${item[nameKey]}-${index}`}
                    size={{
                      xs: 12,
                      sm: 6,
                      md: 12,
                      lg: 6,
                    }}
                  >
                    <Box
                      sx={{
                        height: '100%',
                        minHeight: 72,
                        display: 'grid',
                        gridTemplateColumns: '12px minmax(0, 1fr)',
                        alignItems: 'start',
                        gap: 1.25,
                        px: 1.5,
                        py: 1.25,
                        border: '1px solid',
                        borderColor: 'divider',
                        borderRadius: 2,
                        backgroundColor: 'background.paper',
                        transition:
                          'background-color 160ms ease, border-color 160ms ease',
                        '&:hover': {
                          backgroundColor: 'action.hover',
                          borderColor: 'rgba(29, 137, 200, 0.4)',
                        },
                      }}
                    >
                      <Box
                        sx={{
                          width: 10,
                          height: 10,
                          mt: 0.5,
                          borderRadius: '50%',
                          backgroundColor:
                            CHART_COLORS[index % CHART_COLORS.length],
                        }}
                      />

                      <Box sx={{ minWidth: 0 }}>
                        <Typography
                          variant="body2"
                          sx={{
                            fontFamily: '"DM Sans", sans-serif',
                            fontWeight: 600,
                            lineHeight: 1.35,
                            color: 'text.primary',
                            overflowWrap: 'anywhere',
                          }}
                        >
                          {item[nameKey] || '-'}
                        </Typography>

                        <Stack
                          direction="row"
                          spacing={1}
                          sx={{
                            mt: 0.75,
                            alignItems: 'center',
                            justifyContent: 'space-between',
                          }}
                        >
                          <Typography
                            variant="caption"
                            color="text.secondary"
                            sx={{
                              flexShrink: 0,
                              fontFamily: '"DM Sans", sans-serif',
                              fontWeight: 600,
                            }}
                          >
                            {calculatePercentage(item[dataKey], totalExpense)}
                          </Typography>

                          <CurrencyAmount
                            value={item[dataKey]}
                            fontSize="0.82rem"
                            fontWeight={700}
                            align="right"
                          />
                        </Stack>
                      </Box>
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </Grid>
          </Grid>
        )}
      </CardContent>

      {!loading && safeData.length > 0 && !exportMode && (
        <>
          <Divider />

          <CardActions
            sx={{
              minHeight: 62,
              px: {
                xs: 2,
                sm: 3,
              },
              py: 1.25,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              backgroundColor: 'rgba(29, 137, 200, 0.06)',
            }}
          >
            <Typography
              variant="body2"
              sx={{
                fontFamily: '"DM Sans", sans-serif',
                fontWeight: 700,
              }}
            >
              Total expense
            </Typography>

            <CurrencyAmount
              value={totalExpense}
              fontSize="1rem"
              fontWeight={700}
              align="right"
            />
          </CardActions>
        </>
      )}
    </Card>
  );
}
