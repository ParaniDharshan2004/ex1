import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Typography,
} from '@mui/material';

const MONTHS = [
  '01',
  '02',
  '03',
  '04',
  '05',
  '06',
  '07',
  '08',
  '09',
  '10',
  '11',
  '12',
];

const getAvailableYears = (selectedYear) => {
  const currentYear = new Date().getFullYear();
  const years = new Set(
    Array.from({ length: 11 }, (_, index) => currentYear - 5 + index),
  );
  if (selectedYear) years.add(Number(selectedYear));
  return [...years].sort((first, second) => second - first);
};

export default function OperationalExpenseHeader({
  fileName,
  hasImportedReport,
  importing,
  loading,
  loadingMonth,
  sourceMonth,
  onMonthChange,
  fileInputRef,
  onImport,
}) {
  const [selectedYear = '', selectedMonth = ''] = String(sourceMonth || '').split('-');
  const availableYears = getAvailableYears(selectedYear);

  const handleMonthPartChange = (part, value) => {
    const nextYear = part === 'year' ? value : selectedYear;
    const nextMonth = part === 'month' ? value : selectedMonth;
    if (nextYear && nextMonth) onMonthChange(`${nextYear}-${nextMonth}`);
  };

  return (
    <Box
      sx={{
        px: 2,
        py: 1.5,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 2,
        bgcolor: 'background.default',
        borderBottom: '1px solid',
        borderColor: 'divider',
      }}
    >
      <Box>
        <Typography variant="h6" fontWeight={800}>
          Operational Expense Analysis
        </Typography>
        {hasImportedReport && fileName && (
          <Typography variant="body2" color="text.secondary">
            Imported from {fileName}
          </Typography>
        )}
      </Box>
      <Stack direction="row" alignItems="center" spacing={1.5}>
        <FormControl size="small" sx={{ minWidth: 110 }}>
          <InputLabel id="operational-expense-month-label">Month</InputLabel>
          <Select
            labelId="operational-expense-month-label"
            label="Month"
            value={selectedMonth}
            disabled={loading || loadingMonth}
            onChange={(event) => handleMonthPartChange('month', event.target.value)}
          >
            {MONTHS.map((month) => (
              <MenuItem key={month} value={month}>
                {new Date(2000, Number(month) - 1, 1).toLocaleString('en-IN', {
                  month: 'short',
                })}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 100 }}>
          <InputLabel id="operational-expense-year-label">Year</InputLabel>
          <Select
            labelId="operational-expense-year-label"
            label="Year"
            value={selectedYear}
            disabled={loading || loadingMonth}
            onChange={(event) => handleMonthPartChange('year', event.target.value)}
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 280,
                  overflowY: 'auto',
                },
              },
            }}
          >
            {availableYears.map((year) => (
              <MenuItem key={year} value={String(year)}>
                {year}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button
          component="label"
          variant="outlined"
          disabled={importing || loading || loadingMonth}
        >
          {importing ? 'Importing...' : 'Upload Data'}
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            hidden
            onChange={onImport}
          />
        </Button>
      </Stack>
    </Box>
  );
}