import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  Dialog,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  FormHelperText,
  InputAdornment,
  InputLabel,
  LinearProgress,
  ListItemText,
  MenuItem,
  Paper,
  Select,
  Stack,
  Step,
  StepLabel,
  Stepper,
  TextField,
  Typography,
  IconButton,
} from '@mui/material';
import {
  AccountBalanceWalletOutlined,
  ApartmentOutlined,
  CheckCircleOutlined,
  CloseOutlined,
  DeleteOutlineOutlined,
  LocationOnOutlined,
  PersonAddOutlined,
  SaveOutlined,
  ScaleOutlined,
  TuneOutlined,
  WarningAmberOutlined,
  ExpandMoreOutlined,
} from '@mui/icons-material';
import {
  generateOperationalExpenseInvoice,
  getClientLocations,
  getInvoiceAllocation,
  saveInvoiceAllocation,
} from '../../utils/operational-expense/operationalExpenseApi.js';
import { InvoiceGenerationConfirmationDialog } from './InvoiceDialogs.jsx';

const formatCurrency = (value) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number(value) || 0);

const calculateGstAmounts = (totalAmount, gstRate = 18) => {
  const total = Number(totalAmount) || 0;
  const taxableAmount = total / (1 + gstRate / 100);
  const gstAmount = total - taxableAmount;
  return { taxableAmount, gstAmount, totalAmount: total };
};

const gstPreview = (amount) => calculateGstAmounts(amount);

const getId = (value) =>
  value && typeof value === 'object' ? value._id || value.id : value;

const getClientCode = (client) =>
  `${client?.clientCode || ''} ${client?.clientName || ''}`.toUpperCase();

const splitEvenly = (amount, count) => {
  if (!count) return [];
  const totalPaise = Math.round((Number(amount) || 0) * 100);
  const basePaise = Math.floor(totalPaise / count);
  let remainingPaise = totalPaise;
  return Array.from({ length: count }, (_, index) => {
    const value = index === count - 1 ? remainingPaise : basePaise;
    remainingPaise -= value;
    return (value / 100).toFixed(2);
  });
};

const getLocationId = (location) =>
  String(location?.locationId || location?._id || location?.id || '');

const surfaceSx = {
  border: '1px solid',
  borderColor: 'divider',
  borderRadius: 3,
  bgcolor: 'background.paper',
  boxShadow: '0 12px 36px rgba(15, 23, 42, 0.06)',
};

function SaveButton({ isSaving, disabled, onSave, fullWidth = false }) {
  return (
    <Button
      variant="contained"
      size="large"
      startIcon={
        isSaving ? (
          <CircularProgress size={18} color="inherit" />
        ) : (
          <SaveOutlined />
        )
      }
      disabled={disabled}
      onClick={onSave}
      fullWidth={fullWidth}
      sx={{
        minHeight: 46,
        px: 3,
        borderRadius: 2,
        whiteSpace: 'nowrap',
        boxShadow: 2,
      }}
      aria-label="Save allocations and exit"
    >
      {isSaving ? 'Saving…' : 'Save & Exit'}
    </Button>
  );
}

function PageHeader({ status, clientName, onClose }) {
  return (
    <Paper
      elevation={0}
      sx={{ ...surfaceSx, px: { xs: 2, sm: 2.5 }, py: 1.75, mb: 2 }}
    >
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        spacing={2}
      >
        <Box minWidth={0}>
          <Stack direction="row" spacing={1} alignItems="center">
            <Typography
              component="h1"
              sx={{ fontSize: 18, fontWeight: 800, lineHeight: 1.25 }}
            >
              Invoice Allocation
            </Typography>
            <Chip
              label={status}
              size="small"
              color={
                status === 'Saved'
                  ? 'success'
                  : status === 'Pending'
                    ? 'warning'
                    : 'default'
              }
              variant={status === 'Draft' ? 'outlined' : 'filled'}
              sx={{ height: 24, fontWeight: 700 }}
            />
          </Stack>
          <Typography
            noWrap
            sx={{
              mt: 0.4,
              fontSize: 14,
              color: 'text.secondary',
              fontWeight: 600,
            }}
          >
            {clientName || 'Client'}
          </Typography>
        </Box>
        <Button
          aria-label="Close invoice allocation"
          onClick={onClose}
          disabled={!onClose}
          sx={{
            minWidth: 40,
            width: 40,
            height: 40,
            p: 0,
            borderRadius: 2.5,
            color: 'text.secondary',
          }}
        >
          <CloseOutlined fontSize="small" />
        </Button>
      </Stack>
    </Paper>
  );
}

function AllocationStepper() {
  const steps = ['Import', 'Review', 'Allocation', 'Invoices'];
  return (
    <Paper
      elevation={0}
      sx={{ ...surfaceSx, px: { xs: 1.5, sm: 3 }, py: 2, mb: 2.5 }}
      aria-label="Invoice workflow progress"
    >
      <Stepper
        activeStep={2}
        alternativeLabel
        sx={{
          '& .MuiStepLabel-label': { fontSize: { xs: 11, sm: 13 }, mt: 0.5 },
          '& .MuiStepIcon-root': { fontSize: { xs: 24, sm: 28 } },
        }}
      >
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </Paper>
  );
}

function SummaryMetricCard({ label, value, note, icon, color, prominent }) {
  return (
    <Paper
      elevation={0}
      sx={{
        ...surfaceSx,
        p: { xs: 2, sm: 2.25 },
        minWidth: 0,
        ...(prominent && {
          borderColor: 'primary.main',
          boxShadow: '0 12px 32px rgba(25,118,210,.10)',
        }),
      }}
    >
      <Stack direction="row" spacing={1.5} alignItems="center">
        <Box
          sx={{
            width: 44,
            height: 44,
            borderRadius: 2.25,
            display: 'grid',
            placeItems: 'center',
            color: `${color}.main`,
            bgcolor: `${color}.light`,
            flexShrink: 0,
          }}
        >
          {icon}
        </Box>
        <Box minWidth={0}>
          <Typography
            variant="caption"
            color="text.secondary"
            fontWeight={700}
            textTransform="uppercase"
            letterSpacing={0.6}
          >
            {label}
          </Typography>
          <Typography variant={prominent ? 'h5' : 'h6'} fontWeight={800} noWrap>
            {formatCurrency(value)}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {note}
          </Typography>
        </Box>
      </Stack>
    </Paper>
  );
}

function ClientSelector({
  clients,
  selectedClientIds,
  activeClientId,
  balanceClientId,
  savedClientIds,
  onSelectionChange,
  onActivate,
  onRemove,
  disabled,
}) {
  return (
    <Accordion
      defaultExpanded
      disableGutters
      elevation={0}
      sx={{
        border: 0,
        bgcolor: 'transparent',
        '&:before': { display: 'none' },
      }}
    >
      <AccordionSummary
        expandIcon={<ExpandMoreOutlined />}
        sx={{
          px: 0,
          minHeight: 48,
          '& .MuiAccordionSummary-content': { my: 1 },
        }}
      >
        <Stack direction="row" spacing={1} alignItems="center" mb={0.75}>
          <PersonAddOutlined color="primary" />
          <Typography id="client-selection-title" variant="h6" fontWeight={800}>
            Client selection
          </Typography>
        </Stack>
      </AccordionSummary>
      <AccordionDetails sx={{ px: 0, pb: 0 }}>
        <Typography variant="body2" color="text.secondary" mb={2}>
          Select a client, then choose its chip to edit the allocation.
        </Typography>
        <FormControl fullWidth disabled={disabled}>
          <InputLabel id="client-selector-label">Clients</InputLabel>
          <Select
            multiple
            labelId="client-selector-label"
            label="Clients"
            value={selectedClientIds}
            onChange={onSelectionChange}
            inputProps={{
              'aria-label': 'Select clients for invoice allocation',
            }}
            renderValue={(ids) =>
              `${ids.length} client${ids.length === 1 ? '' : 's'} selected`
            }
            MenuProps={{ PaperProps: { sx: { maxHeight: 360 } } }}
          >
            {clients.map((client) => {
              const id = String(getId(client._id || client.id));
              const mandatory = id === balanceClientId;
              return (
                <MenuItem
                  key={id}
                  value={id}
                  disabled={mandatory}
                  sx={{ minHeight: 48 }}
                >
                  <Checkbox checked={selectedClientIds.includes(id)} />
                  <ListItemText
                    primary={client.clientName || client.clientCode || 'Client'}
                    secondary={
                      mandatory
                        ? 'CRKL · Automatic balance client'
                        : client.clientCode || undefined
                    }
                  />
                </MenuItem>
              );
            })}
          </Select>
          <FormHelperText>
            CRKL is always included and cannot be removed.
          </FormHelperText>
        </FormControl>
        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap mt={2}>
          {selectedClientIds.map((id) => {
            const client = clients.find(
              (item) => String(getId(item._id || item.id)) === id,
            );
            const saved = savedClientIds.includes(id);
            const active = id === activeClientId;
            const mandatory = id === balanceClientId;
            return (
              <Chip
                key={id}
                clickable
                onClick={() => onActivate(id)}
                onDelete={mandatory ? undefined : () => onRemove(id)}
                deleteIcon={<DeleteOutlineOutlined />}
                color={active ? 'primary' : saved ? 'success' : 'default'}
                variant={active ? 'filled' : 'outlined'}
                icon={
                  saved ? (
                    <CheckCircleOutlined />
                  ) : mandatory ? (
                    <AccountBalanceWalletOutlined />
                  ) : undefined
                }
                label={`${client?.clientName || client?.clientCode || 'Client'}${saved ? ' · Saved' : mandatory ? ' · Auto' : ''}`}
                aria-pressed={active}
                sx={{
                  minHeight: 36,
                  maxWidth: '100%',
                  '& .MuiChip-label': {
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  },
                }}
              />
            );
          })}
        </Stack>
      </AccordionDetails>
    </Accordion>
  );
}

function KpiCard({ label, value, emphasis = false }) {
  return (
    <Box
      sx={{
        p: 1.5,
        minHeight: 88,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: 3,
        bgcolor: emphasis ? 'primary.50' : 'background.paper',
      }}
    >
      <Typography
        sx={{ fontSize: 13, color: 'text.secondary', fontWeight: 700 }}
      >
        {label}
      </Typography>
      <Typography
        sx={{
          mt: 0.5,
          fontSize: 15,
          fontWeight: 800,
          fontVariantNumeric: 'tabular-nums',
        }}
      >
        {formatCurrency(value)}
      </Typography>
    </Box>
  );
}

function LocationAllocationList({
  locations,
  locationAmounts,
  splitMethod,
  onAmountChange,
}) {
  if (!locations.length) return null;
  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))' },
        gap: 2,
        columnGap: { sm: 3 },
      }}
    >
      {locations.map((location, index) => {
        const id = getLocationId(location);
        const autoSplit = splitMethod === 'equal';
        const amount = Number(locationAmounts[id]) || 0;
        const preview = gstPreview(amount);
        return (
          <Paper
            key={id}
            variant="outlined"
            sx={{
              p: 2,
              borderRadius: 3,
              boxShadow: '0 8px 24px rgba(15,23,42,.05)',
              minWidth: 0,
              minHeight: 300,
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="flex-start"
              spacing={2}
              mb={2}
            >
              <Box minWidth={0}>
                <Typography noWrap sx={{ fontSize: 16, fontWeight: 800 }}>
                  {location.locationName ||
                    location.locationCode ||
                    `Location ${index + 1}`}
                </Typography>
              </Box>
              <Chip
                size="small"
                label={autoSplit ? 'Auto' : 'Manual'}
                color={autoSplit ? 'info' : 'default'}
                variant="outlined"
              />
            </Stack>
            <TextField
              fullWidth
              value={locationAmounts[id] ?? ''}
              onChange={(event) => onAmountChange(id, event.target.value)}
              error={amount < 0}
              label="Invoice Amount"
              placeholder="0.00"
              type="number"
              inputProps={{
                min: 0,
                step: '0.01',
                'aria-label': `Invoice amount for ${location.locationName || location.locationCode || 'location'}`,
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">₹</InputAdornment>
                ),
              }}
              sx={{ '& .MuiInputBase-root': { minHeight: 48 } }}
            />
            <Divider sx={{ my: 1.75 }} />
            <Stack spacing={2}>
              {[
                ['Taxable Amount', preview.taxableAmount],
                ['GST (18%)', preview.gstAmount],
                ['Total Including GST', preview.totalAmount],
              ].map(([label, value]) => (
                <Stack
                  key={label}
                  direction="row"
                  justifyContent="space-between"
                  spacing={2}
                >
                  <Typography sx={{ fontSize: 14, color: 'text.secondary' }}>
                    {label}
                  </Typography>
                  <Typography
                    sx={{
                      fontSize: 15,
                      fontWeight: 800,
                      fontVariantNumeric: 'tabular-nums',
                      textAlign: 'right',
                    }}
                  >
                    {formatCurrency(value)}
                  </Typography>
                </Stack>
              ))}
            </Stack>
          </Paper>
        );
      })}
    </Box>
  );
}

function ValidationStatus({
  isValid,
  isLocationBalanced,
  isWithinClientBalance,
  locationDifference,
  selectedTotal,
  availableForSelected,
}) {
  let severity = 'success';
  let message = 'Allocation complete and ready to save.';
  if (!isWithinClientBalance || selectedTotal > availableForSelected + 0.01) {
    severity = 'error';
    message = `Client allocations exceed the available balance of ${formatCurrency(availableForSelected)}.`;
  } else if (!isLocationBalanced) {
    severity = 'warning';
    message = `Location amounts must be adjusted by ${formatCurrency(Math.abs(locationDifference))}.`;
  } else if (!isValid) {
    severity = 'warning';
    message = 'Complete all required allocation values before saving.';
  }
  return (
    <Alert
      severity={severity}
      role={severity === 'error' ? 'alert' : 'status'}
      sx={{ borderRadius: 2.5 }}
    >
      {message}
    </Alert>
  );
}

function AllocationSummary({
  reportTotal,
  clientName,
  clientAmount,
  locationTotal,
  allocatedTotal,
  remainingTotal,
  rawAllocatedTotal,
  isValid,
  isLocationBalanced,
  clientGstPreview,
}) {
  const overAmount = Math.max(0, rawAllocatedTotal - reportTotal);
  const pendingAmount = Math.max(0, reportTotal - rawAllocatedTotal);
  const exceeded = overAmount > 0.01;
  const complete =
    !exceeded && pendingAmount <= 0.01 && isValid && isLocationBalanced;
  const statusLabel = complete
    ? 'Balanced'
    : exceeded
      ? 'Over Allocated'
      : 'Pending Allocation';
  const statusColor = complete ? 'success' : exceeded ? 'error' : 'warning';
  const exactDifference = exceeded ? overAmount : pendingAmount;
  const rows = [
    ['Total Billable', reportTotal],
    ['Client Allocation', clientAmount],
    ['Location Allocation', locationTotal],
    [exceeded ? 'Over Allocation' : 'Remaining Allocation', exactDifference],
  ];
  return (
    <Paper
      component="aside"
      elevation={0}
      sx={{
        ...surfaceSx,
        p: 2.25,
        position: { lg: 'sticky' },
        top: { lg: 16 },
        alignSelf: 'start',
      }}
    >
      <Typography sx={{ fontSize: 18, fontWeight: 800 }}>
        Invoice Summary
      </Typography>
      <Typography
        sx={{ mt: 0.4, mb: 1.5, fontSize: 14, color: 'text.secondary' }}
      >
        Client:{' '}
        <Box component="span" sx={{ color: 'text.primary', fontWeight: 700 }}>
          {clientName || 'Client'}
        </Box>
      </Typography>
      <Divider />
      {rows.map(([label, value]) => (
        <Stack
          key={label}
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          spacing={2}
          sx={{ py: 1.2, borderBottom: '1px solid', borderColor: 'divider' }}
        >
          <Typography sx={{ fontSize: 14, color: 'text.secondary' }}>
            {label}
          </Typography>
          <Typography
            sx={{
              fontSize: 15,
              fontWeight: 800,
              fontVariantNumeric: 'tabular-nums',
              color: label.includes('Over') ? 'error.main' : 'text.primary',
              textAlign: 'right',
            }}
          >
            {formatCurrency(value)}
          </Typography>
        </Stack>
      ))}
      <Box sx={{ py: 1.5 }}>
        <Stack direction="row" justifyContent="space-between" py={0.5}>
          <Typography sx={{ fontSize: 14, color: 'text.secondary' }}>
            Taxable Amount
          </Typography>
          <Typography sx={{ fontSize: 15, fontWeight: 800 }}>
            {formatCurrency(clientGstPreview.taxableAmount)}
          </Typography>
        </Stack>
        <Stack direction="row" justifyContent="space-between" py={0.5}>
          <Typography sx={{ fontSize: 14, color: 'text.secondary' }}>
            GST (18%)
          </Typography>
          <Typography sx={{ fontSize: 15, fontWeight: 800 }}>
            {formatCurrency(clientGstPreview.gstAmount)}
          </Typography>
        </Stack>
      </Box>
      <Divider />
      <Box
        sx={{
          mt: 1.75,
          p: 1.5,
          borderRadius: 3,
          bgcolor: `${statusColor}.50`,
          border: '1px solid',
          borderColor: `${statusColor}.light`,
        }}
      >
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          spacing={1}
        >
          <Box>
            <Typography
              sx={{ fontSize: 13, color: 'text.secondary', fontWeight: 700 }}
            >
              Status
            </Typography>
            <Typography
              sx={{
                mt: 0.25,
                fontSize: 15,
                fontWeight: 800,
                color: `${statusColor}.dark`,
              }}
            >
              {complete ? '✓ ' : ''}
              {statusLabel}
            </Typography>
          </Box>
          <Chip
            size="small"
            label={formatCurrency(exactDifference)}
            color={statusColor}
            variant="outlined"
          />
        </Stack>
        <Stack direction="row" justifyContent="space-between" mt={1.25}>
          <Typography sx={{ fontSize: 13, color: 'text.secondary' }}>
            Allocated Total
          </Typography>
          <Typography sx={{ fontSize: 14, fontWeight: 800 }}>
            {formatCurrency(rawAllocatedTotal)}
          </Typography>
        </Stack>
        <Stack direction="row" justifyContent="space-between" mt={0.75}>
          <Typography sx={{ fontSize: 13, color: 'text.secondary' }}>
            Remaining Total
          </Typography>
          <Typography
            sx={{
              fontSize: 14,
              fontWeight: 800,
              color: exceeded
                ? 'error.main'
                : complete
                  ? 'success.main'
                  : 'warning.main',
            }}
          >
            {formatCurrency(exactDifference)}
          </Typography>
        </Stack>
      </Box>
    </Paper>
  );
}

export default function InvoiceAllocationPage({
  reportId,
  clients = [],
  clientAllocations = [],
  initialClientId,
  clickedClientAmount,
  operationalExpenseTotal = 0,
  subTotal = 0,
  markup = 0,
  onSaved,
  onExit,
  onContinue,
  open = false,
  onClose,
  singleClient = clients.length === 1 && Boolean(initialClientId),
}) {
  const balanceClient = clients.find((client) =>
    getClientCode(client).includes('CRKL'),
  );
  const balanceClientId = String(
    getId(balanceClient?._id || balanceClient?.id) || '',
  );
  const defaultClientId = String(
    getId(
      clients.find(
        (client) =>
          String(getId(client._id || client.id)) === String(initialClientId),
      )?._id || initialClientId,
    ) ||
      getId(
        clients.find((client) => getClientCode(client).includes('MKPL'))?._id,
      ) ||
      getId(clients[0]?._id || clients[0]?.id) ||
      '',
  );
  const [selectedClientIds, setSelectedClientIds] = useState(() =>
    singleClient
      ? [defaultClientId].filter(Boolean)
      : [...new Set([defaultClientId, balanceClientId].filter(Boolean))],
  );
  const [activeClientId, setActiveClientId] = useState(defaultClientId);
  const [clientDrafts, setClientDrafts] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [savedClientIds, setSavedClientIds] = useState([]);
  const [failedClientIds, setFailedClientIds] = useState([]);
  const [confirmationItems, setConfirmationItems] = useState([]);
  const [confirmationOpen, setConfirmationOpen] = useState(false);
  const [isGeneratingInvoices, setIsGeneratingInvoices] = useState(false);
  const isLoading =
    selectedClientIds.length > 0 &&
    selectedClientIds.some(
      (clientId) =>
        !clientDrafts[clientId] && !failedClientIds.includes(clientId),
    );

  const reportTotal = Number(operationalExpenseTotal) || 0;
  const allocationByClientId = useMemo(
    () =>
      new Map(
        clientAllocations.map((allocation) => [
          String(getId(allocation.clientId)),
          allocation,
        ]),
      ),
    [clientAllocations],
  );
  const getClientDraft = (clientId) => {
    const draft = clientDrafts[clientId] || {
      locations: [],
      locationAmounts: {},
      clientTotalAmount: '',
      splitMethod: 'equal',
    };
    if (!balanceClientId || clientId !== balanceClientId) return draft;

    const otherAllocatedTotal = clients.reduce((total, client) => {
      const id = String(getId(client._id || client.id));
      if (id === balanceClientId) return total;
      const amount = selectedClientIds.includes(id)
        ? (clientDrafts[id]?.clientTotalAmount ??
          allocationByClientId.get(id)?.clientTotalAmount ??
          allocationByClientId.get(id)?.amount)
        : (allocationByClientId.get(id)?.clientTotalAmount ??
          allocationByClientId.get(id)?.amount);
      return total + (Number(amount) || 0);
    }, 0);
    // CRKL automatically receives the balance left after other client allocations.
    const remainingAmount =
      Math.round(Math.max(0, reportTotal - otherAllocatedTotal) * 100) / 100;
    return {
      ...draft,
      clientTotalAmount: remainingAmount.toFixed(2),
      splitMethod: 'equal',
      locationAmounts: Object.fromEntries(
        draft.locations.map((location, index) => [
          getLocationId(location),
          splitEvenly(remainingAmount, draft.locations.length)[index] || '0.00',
        ]),
      ),
    };
  };
  const allocationClient = clients.find(
    (client) => String(getId(client._id || client.id)) === activeClientId,
  );
  const activeDraft = getClientDraft(activeClientId);
  const { locations, locationAmounts, clientTotalAmount, splitMethod } =
    activeDraft;
  const clientAmount = Number(clientTotalAmount) || 0;
  const locationTotal = locations.reduce(
    (total, location) =>
      total + (Number(locationAmounts[getLocationId(location)]) || 0),
    0,
  );
  const locationDifference =
    Math.round((clientAmount - locationTotal) * 100) / 100;
  const selectedIds = new Set(selectedClientIds);
  const existingUnselectedTotal = clientAllocations.reduce(
    (total, allocation) => {
      const clientId = String(getId(allocation.clientId));
      return selectedIds.has(clientId) || clientId === balanceClientId
        ? total
        : total +
            (Number(
              allocation.clientTotalAmount ??
                allocation.savedInvoiceAllocation?.clientTotalAmount ??
                allocation.amount,
            ) || 0);
    },
    0,
  );
  const selectedTotal = selectedClientIds.reduce(
    (total, clientId) =>
      total + (Number(getClientDraft(clientId).clientTotalAmount) || 0),
    0,
  );
  const availableForSelected = Math.max(
    0,
    reportTotal - existingUnselectedTotal,
  );
  const availableAmount = balanceClientId && activeClientId === balanceClientId
    ? Math.max(0, reportTotal - existingUnselectedTotal)
    : reportTotal;
  const nonBalanceAllocatedTotal = clientAllocations.reduce(
    (total, allocation) => {
      const clientId = String(getId(allocation.clientId));
      if (clientId === balanceClientId) return total;
      const amount = selectedIds.has(clientId)
        ? getClientDraft(clientId).clientTotalAmount
        : allocation.clientTotalAmount ??
          allocation.savedInvoiceAllocation?.clientTotalAmount ??
          allocation.amount;
      return total + (Number(amount) || 0);
    },
    0,
  );
  const rawAllocatedTotal = nonBalanceAllocatedTotal;
  const isWithinClientBalance =
    clientAmount <= reportTotal + 0.01 &&
    nonBalanceAllocatedTotal <= reportTotal + 0.01;
  const isLocationBalanced =
    !locations.length || Math.abs(locationDifference) <= 0.01;
  const isValid =
    Boolean(allocationClient) &&
    reportTotal > 0 &&
    selectedClientIds.length > 0 &&
    selectedClientIds.every(
      (clientId) =>
        Boolean(clientDrafts[clientId]) ||
        (clientId === balanceClientId && Boolean(balanceClientId)),
    ) &&
    clientTotalAmount !== '' &&
    clientAmount >= 0 &&
    isWithinClientBalance &&
    isLocationBalanced &&
    selectedClientIds.every((clientId) => {
      const draft = getClientDraft(clientId);
      const amount = Number(draft?.clientTotalAmount);
      const allocated = (draft?.locations || []).reduce(
        (sum, location) =>
          sum + (Number(draft.locationAmounts[getLocationId(location)]) || 0),
        0,
      );
      return (
        draft &&
        draft.clientTotalAmount !== '' &&
        Number.isFinite(amount) &&
        amount >= 0 &&
        (!(draft.locations || []).length ||
          Math.abs(amount - allocated) <= 0.01)
      );
    }) &&
    nonBalanceAllocatedTotal <= reportTotal + 0.01;
  const allocationProgress =
    clientAmount > 0
      ? Math.min(100, Math.max(0, (locationTotal / clientAmount) * 100))
      : 0;
  const allocatedTotal = Math.min(reportTotal, rawAllocatedTotal);
  const remainingTotal = Math.max(0, reportTotal - nonBalanceAllocatedTotal);
  const clientGstPreview = useMemo(
    () => calculateGstAmounts(clientAmount),
    [clientAmount],
  );
  const locationGstTotal = useMemo(
    () => calculateGstAmounts(locationTotal),
    [locationTotal],
  );

  const selectedClientsKey = selectedClientIds.join(',');
  const requestedClientIds = useMemo(
    () => (selectedClientsKey ? selectedClientsKey.split(',') : []),
    [selectedClientsKey],
  );
  // Load locations and any saved allocation for newly selected clients.
  useEffect(() => {
    let isCurrent = true;
    const clientsToLoad = requestedClientIds.filter(
      (clientId) =>
        !clientDrafts[clientId] && !failedClientIds.includes(clientId),
    );

    if (!reportId || !clientsToLoad.length) {
      return () => {
        isCurrent = false;
      };
    }

    Promise.all(
      clientsToLoad.map(async (clientId) => {
        const client = clients.find(
          (item) => String(getId(item._id || item.id)) === clientId,
        );
        if (!client) throw new Error('A selected client is no longer active.');

        const [locationsResponse, allocationResponse] = await Promise.all([
          getClientLocations(clientId),
          getInvoiceAllocation(reportId, clientId),
        ]);
        const activeLocations = (locationsResponse.data?.data || []).filter(
          (location) => location?.isActive !== false,
        );
        const allocation =
          allocationResponse.data?.data ||
          allocationByClientId.get(clientId)?.savedInvoiceAllocation ||
          null;
        const storedLocationAmounts = Object.fromEntries(
          (allocation?.locationAllocations || []).map((item) => [
            String(getId(item.locationId)),
            Number(item.amount || 0).toFixed(2),
          ]),
        );
        const fallback = allocationByClientId.get(clientId);
        const initialAmount =
          allocation?.clientTotalAmount ??
          (fallback?.savedInvoiceAllocation
            ? (fallback.amount ?? fallback.clientTotalAmount ?? '')
            : (fallback?.amount ?? clickedClientAmount ?? ''));
        const equalAmounts = activeLocations.map((location) =>
          Number(storedLocationAmounts[getLocationId(location)] || 0),
        );
        const savedSplitIsEqual =
          equalAmounts.length < 2 ||
          equalAmounts.every(
            (amount) => Math.abs(amount - equalAmounts[0]) <= 0.01,
          );

        return [
          clientId,
          {
            locations: activeLocations,
            clientTotalAmount:
              initialAmount === '' ? '' : Number(initialAmount).toFixed(2),
            splitMethod: savedSplitIsEqual ? 'equal' : 'custom',
            locationAmounts: allocation?.locationAllocations?.length
              ? Object.fromEntries(
                  activeLocations.map((location) => [
                    getLocationId(location),
                    storedLocationAmounts[getLocationId(location)] || '0.00',
                  ]),
                )
              : Object.fromEntries(
                  activeLocations.map((location, index) => [
                    getLocationId(location),
                    splitEvenly(initialAmount, activeLocations.length)[index] ||
                      '0.00',
                  ]),
                ),
          },
        ];
      }),
    )
      .then((entries) => {
        if (isCurrent) {
          setClientDrafts((current) => ({
            ...current,
            ...Object.fromEntries(entries),
          }));
          setFailedClientIds((current) =>
            current.filter((clientId) => !clientsToLoad.includes(clientId)),
          );
        }
      })
      .catch((error) => {
        if (isCurrent) {
          setFailedClientIds((current) => [
            ...new Set([...current, ...clientsToLoad]),
          ]);
          setErrorMessage(
            error.response?.data?.message ||
              error.message ||
              'Unable to load client allocations.',
          );
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [
    reportId,
    selectedClientsKey,
    requestedClientIds,
    clients,
    clientDrafts,
    allocationByClientId,
    failedClientIds,
    clickedClientAmount,
  ]);

  const updateActiveDraft = (updater) => {
    setClientDrafts((current) => ({
      ...current,
      [activeClientId]: updater(current[activeClientId] || activeDraft),
    }));
  };

  const updateClientAmount = (value) => {
    setSuccessMessage('');
    updateActiveDraft((draft) => ({
      ...draft,
      clientTotalAmount: value,
      locationAmounts:
        draft.splitMethod === 'equal'
          ? Object.fromEntries(
              locations.map((location, index) => [
                getLocationId(location),
                splitEvenly(value, locations.length)[index] || '0.00',
              ]),
            )
          : draft.locationAmounts,
    }));
  };

  const updateLocationAmount = (locationId, value) => {
    setSuccessMessage('');
    updateActiveDraft((draft) => ({
      ...draft,
      splitMethod: 'custom',
      locationAmounts: { ...draft.locationAmounts, [locationId]: value },
    }));
  };

  const changeSplitMethod = (value) => {
    updateActiveDraft((draft) => ({
      ...draft,
      splitMethod: value,
      locationAmounts:
        value === 'equal'
          ? Object.fromEntries(
              locations.map((location, index) => [
                getLocationId(location),
                splitEvenly(draft.clientTotalAmount, locations.length)[index] ||
                  '0.00',
              ]),
            )
          : draft.locationAmounts,
    }));
  };

  const updateSelectedClients = (nextSelectedIds) => {
    const uniqueIds = [
      ...new Set(
        [...nextSelectedIds.map(String), balanceClientId].filter(Boolean),
      ),
    ];
    setSelectedClientIds(uniqueIds);
    setFailedClientIds([]);
    setErrorMessage('');
    if (!uniqueIds.includes(activeClientId)) {
      setActiveClientId(uniqueIds[0] || '');
    }
    setSuccessMessage('');
  };

  const removeClient = (clientId) => {
    updateSelectedClients(selectedClientIds.filter((id) => id !== clientId));
  };

  const handleClientSelectionChange = (event) => {
    const selection = event.target.value;
    const nextIds = (
      Array.isArray(selection) ? selection : selection.split(',')
    ).map(String);
    const addedClientId = nextIds.find(
      (clientId) => !selectedClientIds.includes(clientId),
    );
    updateSelectedClients(nextIds);
    if (addedClientId) setActiveClientId(addedClientId);
  };

  const retryClientLoading = () => {
    setFailedClientIds([]);
    setErrorMessage('');
  };

  // Validate and save each client using the existing API contract and save order.
  const saveAllocation = async ({
    exitAfterSave = false,
    continueAfterSave = false,
  } = {}) => {
    setErrorMessage('');
    setSuccessMessage('');
    if (!selectedClientIds.length) {
      setErrorMessage('Select at least one client to allocate.');
      return;
    }
    if (!isValid) {
      setErrorMessage(
        selectedTotal > availableForSelected + 0.01
          ? `Selected client allocations exceed the available report balance of ${formatCurrency(availableForSelected)}.`
          : 'Enter valid client amounts and balance each location allocation.',
      );
      return;
    }

    const invoiceItems = selectedClientIds.flatMap((clientId) => {
      const draft = getClientDraft(clientId);
      const client = clients.find(
        (item) => String(getId(item._id || item.id)) === clientId,
      );
      const locations = (draft?.locations || []).filter(
        (location) =>
          Number(draft.locationAmounts[getLocationId(location)]) > 0,
      );
      if (locations.length) {
        return locations.map((location) => ({
          clientId,
          clientName: client?.clientName || client?.clientCode || 'Client',
          locationId: getLocationId(location),
          locationName:
            location.locationName || location.locationCode || 'Location',
          amount: Number(draft.locationAmounts[getLocationId(location)]) || 0,
        }));
      }
      const amount = Number(draft?.clientTotalAmount) || 0;
      return amount > 0
        ? [
            {
              clientId,
              clientName: client?.clientName || client?.clientCode || 'Client',
              locationId: null,
              locationName: '',
              amount,
            },
          ]
        : [];
    });
    if (continueAfterSave && !invoiceItems.length) {
      setErrorMessage('Enter a positive invoice amount before continuing.');
      return;
    }

    setIsSaving(true);
    let savedCount = 0;
    try {
      const orderedClientIds = [...selectedClientIds].sort(
        (leftId, rightId) => {
          const leftChange =
            Number(getClientDraft(leftId).clientTotalAmount || 0) -
            (Number(
              allocationByClientId.get(leftId)?.savedInvoiceAllocation
                ?.clientTotalAmount ?? allocationByClientId.get(leftId)?.amount,
            ) || 0);
          const rightChange =
            Number(getClientDraft(rightId).clientTotalAmount || 0) -
            (Number(
              allocationByClientId.get(rightId)?.savedInvoiceAllocation
                ?.clientTotalAmount ??
                allocationByClientId.get(rightId)?.amount,
            ) || 0);
          return leftChange - rightChange;
        },
      );
      for (const clientId of orderedClientIds) {
        const draft = getClientDraft(clientId);
        const response = await saveInvoiceAllocation(reportId, {
          clientId,
          clientTotalAmount: Number(draft.clientTotalAmount),
          allocationStatus: 'CONFIRMED',
          allocations: draft.locations.map((location) => ({
            locationId: getLocationId(location),
            amount: Number(draft.locationAmounts[getLocationId(location)]) || 0,
          })),
        });
        onSaved?.(response.data?.data);
        setSavedClientIds((current) =>
          current.includes(clientId) ? current : [...current, clientId],
        );
        savedCount += 1;
      }
      setSuccessMessage(
        `${savedCount} client allocation${savedCount === 1 ? '' : 's'} saved successfully.`,
      );
      if (exitAfterSave) onExit?.();
      if (continueAfterSave) {
        setConfirmationItems(invoiceItems);
        setConfirmationOpen(true);
      }
    } catch (error) {
      const message =
        error.response?.data?.message || 'Unable to save allocations.';
      setErrorMessage(
        savedCount
          ? `${savedCount} of ${selectedClientIds.length} allocations were saved. ${message} Please retry to finish the remaining allocations.`
          : message,
      );
    } finally {
      setIsSaving(false);
    }
  };

  // Generate invoices without changing the report status. The report becomes
  // invoiced only after the generated invoice PDF is downloaded successfully.
  const generateInvoicesAndContinue = async () => {
    setErrorMessage('');
    setIsGeneratingInvoices(true);
    try {
      await Promise.all(
        confirmationItems.map((item) =>
          generateOperationalExpenseInvoice(reportId, {
            clientId: item.clientId,
            locationId: item.locationId,
          }),
        ),
      );
      setConfirmationOpen(false);
      onContinue?.();
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message ||
          'Unable to generate all invoices. Retry to complete generation.',
      );
    } finally {
      setIsGeneratingInvoices(false);
    }
  };

  const status = isSaving
    ? 'Pending'
    : successMessage
      ? 'Saved'
      : selectedTotal > 0
        ? 'Pending'
        : 'Draft';
  const saveDisabled = isLoading || isSaving || !isValid;
  const handleSaveAndExit = () => saveAllocation({ exitAfterSave: true });

  return (
    <Dialog
      open={open}
      onClose={isSaving ? undefined : onClose || onExit}
      fullWidth
      maxWidth="xl"
      scroll="paper"
      PaperProps={{
        sx: {
          width: 'min(1480px, calc(100% - 24px))',
          maxHeight: 'calc(100% - 24px)',
          borderRadius: { xs: 2, sm: 3 },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '1px solid',
          borderColor: 'divider',
          py: 1.5,
        }}
      >
        <Box>
          <Typography variant="h6" fontWeight={800}>
            Allocate Invoice Amount
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Assign the client amount and distribute it across locations.
          </Typography>
        </Box>
        <IconButton
          aria-label="Close allocation dialog"
          onClick={onClose || onExit}
          disabled={isSaving}
        >
          <CloseOutlined />
        </IconButton>
      </DialogTitle>
      <DialogContent sx={{ p: 0 }}>
        <Box
          sx={{
            minHeight: '100%',
            bgcolor: 'background.default',
            p: { xs: 1.25, sm: 2, lg: 2.5 },
          }}
        >
          <Box sx={{ maxWidth: 1480, mx: 'auto' }}>
            {!singleClient && (
              <PageHeader
                status={status}
                clientName={
                  allocationClient?.clientName || allocationClient?.clientCode
                }
                onClose={onExit}
              />
            )}
            {failedClientIds.length > 0 && (
              <Alert
                severity="error"
                action={
                  <Button
                    color="inherit"
                    size="small"
                    onClick={retryClientLoading}
                  >
                    Retry
                  </Button>
                }
                sx={{ mb: 2, borderRadius: 3 }}
              >
                Some client allocation data could not be loaded.
              </Alert>
            )}
            {errorMessage && (
              <Alert
                severity="error"
                onClose={() => setErrorMessage('')}
                sx={{ mb: 2, borderRadius: 3 }}
              >
                {errorMessage}
              </Alert>
            )}
            {successMessage && (
              <Alert
                severity="success"
                onClose={() => setSuccessMessage('')}
                sx={{ mb: 2, borderRadius: 3 }}
              >
                {successMessage}
              </Alert>
            )}

            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: {
                  xs: 'minmax(0, 1fr)',
                  lg: 'minmax(0, 7fr) minmax(300px, 3fr)',
                },
                gap: 2,
                alignItems: 'start',
              }}
            >
              <Paper
                component="main"
                elevation={0}
                sx={{ ...surfaceSx, p: { xs: 2, sm: 2.5 }, minWidth: 0 }}
              >
                {isLoading ? (
                  <Stack alignItems="center" spacing={1.5} py={8} role="status">
                    <CircularProgress />
                    <Typography color="text.secondary">
                      Loading client allocation…
                    </Typography>
                  </Stack>
                ) : allocationClient ? (
                  <Stack spacing={2.5}>
                    <Box>
                      <Stack
                        direction="row"
                        justifyContent="space-between"
                        alignItems="center"
                        mb={1.5}
                      >
                        <Typography
                          sx={{
                            fontSize: 16,
                            fontWeight: 800,
                            transform: { sm: 'translateY(6px)' },
                          }}
                        >
                          Invoice Amount
                        </Typography>
                        {activeClientId === balanceClientId && (
                          <Chip
                            size="small"
                            icon={<AccountBalanceWalletOutlined />}
                            label="Automatic balance"
                            color="info"
                            variant="outlined"
                          />
                        )}
                      </Stack>
                      <TextField
                        fullWidth
                        label="Invoice Amount"
                        value={clientTotalAmount}
                        onChange={(event) =>
                          updateClientAmount(event.target.value)
                        }
                        disabled={activeClientId === balanceClientId}
                        error={!isWithinClientBalance || clientAmount < 0}
                        helperText={
                          clientAmount > reportTotal
                            ? `Amount cannot exceed total billable: ${formatCurrency(reportTotal)}`
                            : undefined
                        }
                        type="number"
                        inputProps={{
                          min: 0,
                          step: '0.01',
                          'aria-label': 'Invoice amount',
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">₹</InputAdornment>
                          ),
                        }}
                        sx={{
                          maxWidth: 520,
                          '& .MuiInputBase-root': { minHeight: 48 },
                        }}
                      />
                      <Box
                        sx={{
                          mt: 1.75,
                          display: 'grid',
                          gridTemplateColumns: {
                            xs: '1fr',
                            sm: 'repeat(3, minmax(0, 1fr))',
                          },
                          gap: 2,
                          alignItems: 'stretch',
                        }}
                      >
                        <KpiCard
                          label="Taxable Amount"
                          value={clientGstPreview.taxableAmount}
                        />
                        <KpiCard
                          label="GST Amount"
                          value={clientGstPreview.gstAmount}
                        />
                        <KpiCard
                          label="Total Including GST"
                          value={clientGstPreview.totalAmount}
                          emphasis
                        />
                      </Box>
                    </Box>

                    <Divider />

                    <Box sx={{ display: 'grid', gap: 1.5 }}>
                      <Stack
                        display="flex"
                        direction={{ xs: 'column', sm: 'row' }}
                        justifyContent="center"
                        alignItems="center"
                        spacing={1}
                        sx={{ columnGap: { sm: 1 } }}
                      >
                        <Typography sx={{ fontSize: 16, fontWeight: 800 }}>
                          Location Allocation
                        </Typography>
                        <FormControl
                          size="small"
                          sx={{ minWidth: { sm: 210 } }}
                        >
                          <InputLabel id="split-method-label">
                            Split Method
                          </InputLabel>
                          <Select
                            labelId="split-method-label"
                            label="Split Method"
                            value={splitMethod}
                            onChange={(event) =>
                              changeSplitMethod(event.target.value)
                            }
                          >
                            <MenuItem value="equal">
                              Equal Split · Automatic
                            </MenuItem>
                            <MenuItem value="custom">
                              Custom Split · Manual
                            </MenuItem>
                          </Select>
                        </FormControl>
                      </Stack>

                      <LocationAllocationList
                        locations={locations}
                        locationAmounts={locationAmounts}
                        splitMethod={splitMethod}
                        onAmountChange={updateLocationAmount}
                      />
                      {!locations.length && (
                        <Box
                          sx={{
                            p: 1.5,
                            borderRadius: 3,
                            bgcolor: 'action.hover',
                            color: 'text.secondary',
                            fontSize: 14,
                          }}
                        >
                          No active locations. The invoice amount will be saved
                          at client level.
                        </Box>
                      )}
                    </Box>

                    <ValidationStatus
                      isValid={isValid}
                      isLocationBalanced={isLocationBalanced}
                      isWithinClientBalance={isWithinClientBalance}
                      locationDifference={locationDifference}
                      selectedTotal={selectedTotal}
                      availableForSelected={availableForSelected}
                    />
                  </Stack>
                ) : null}
              </Paper>

              <AllocationSummary
                reportTotal={reportTotal}
                clientName={
                  allocationClient?.clientName || allocationClient?.clientCode
                }
                clientAmount={clientAmount}
                locationTotal={locationTotal}
                allocatedTotal={allocatedTotal}
                remainingTotal={remainingTotal}
                rawAllocatedTotal={rawAllocatedTotal}
                isValid={isValid}
                isLocationBalanced={isLocationBalanced}
                clientGstPreview={clientGstPreview}
              />
            </Box>

            <Paper
              elevation={8}
              sx={{
                position: 'sticky',
                bottom: 0,
                zIndex: 20,
                mt: 2,
                px: 2,
                py: 1.5,
                borderRadius: 3,
                border: '1px solid',
                borderColor: 'divider',
                bgcolor: 'background.paper',
              }}
            >
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                spacing={1.5}
              >
                <Button
                  variant="outlined"
                  onClick={onExit}
                  disabled={isSaving}
                  sx={{ minWidth: 128, height: 44, borderRadius: 2.5 }}
                >
                  Close
                </Button>
                <Button
                  variant="contained"
                  startIcon={
                    isSaving ? (
                      <CircularProgress size={18} color="inherit" />
                    ) : (
                      <SaveOutlined />
                    )
                  }
                  disabled={saveDisabled}
                  onClick={handleSaveAndExit}
                  sx={{
                    minWidth: 150,
                    height: 44,
                    borderRadius: 2.5,
                    fontWeight: 700,
                  }}
                >
                  {isSaving ? 'Saving…' : 'Save Allocation'}
                </Button>
              </Stack>
            </Paper>
          </Box>
          <InvoiceGenerationConfirmationDialog
            open={confirmationOpen}
            invoiceItems={confirmationItems}
            generating={isGeneratingInvoices}
            errorMessage={errorMessage}
            onClose={() => setConfirmationOpen(false)}
            onConfirm={generateInvoicesAndContinue}
          />
        </Box>
      </DialogContent>
    </Dialog>
  );
}
