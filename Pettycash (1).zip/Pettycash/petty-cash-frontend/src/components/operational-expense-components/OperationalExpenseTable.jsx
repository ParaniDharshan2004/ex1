import { Fragment } from 'react';
import {
  Box,
  Button,
  Collapse,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import { getOperationalExpenseHeadAmount } from '../../utils/operational-expense/operationalExpenseCalculations.js';
import { amountIncludingGst } from '../../utils/gst.js';
 
const formatAmount = (amount) =>
  (Number(amount) || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
 
const formatInclusiveAmount = (amount) =>
  Number(amount) > 0
    ? amountIncludingGst(amount).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })
    : '';
 
function ReadOnlyAmount({ id, label, amounts, amountErrors, showValidation }) {
  const error = amountErrors[`amount-${id}`];
 
  return (
    <TextField
      size="small"
      value={formatAmount(amounts[String(id)])}
      inputProps={{ readOnly: true, 'aria-label': label }}
      error={showValidation && Boolean(error)}
      helperText={showValidation && error ? error : undefined}
      sx={{
        width: '100%',
        '& input': { py: 0.7, textAlign: 'right' },
      }}
    />
  );
}
 
function ReadOnlyTotalAmount({ label, value }) {
  return (
    <TextField
      size="small"
      value={formatAmount(value)}
      inputProps={{ readOnly: true, 'aria-label': label }}
      sx={{
        width: '100%',
        '& input': {
          py: 0.7,
          textAlign: 'right',
          fontWeight: 800,
        },
      }}
    />
  );
}
 
function TotalRow({ label, value, id, actions }) {
  return (
    <TableRow
      key={id}
      sx={{
        bgcolor:
          id === 'total-direct' ||
          id === 'total-indirect' ||
          id === 'operational-expense-total'
            ? '#D1D5DB'
            : '#FAFAFA',
      }}
    >
      <TableCell colSpan={2} align="right" sx={{ fontWeight: 800 }}>
        {label}
      </TableCell>
      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
        <ReadOnlyTotalAmount label={label} value={value} />
      </TableCell>
      <TableCell align="center" sx={{ px: 0.25 }}>
        {actions}
      </TableCell>
    </TableRow>
  );
}
 
function FixedCostRows({
  fixedCosts,
  fixedCostTotal,
  canEditFixedCosts,
  onFixedCostAmountChange,
}) {
  return (
    <>
      <TableRow sx={{ bgcolor: '#F8FAFC' }}>
        <TableCell colSpan={3} sx={{ fontWeight: 800 }}>
          Fixed Cost
        </TableCell>
      </TableRow>
      {fixedCosts.length === 0 ? (
        <TableRow>
          <TableCell
            colSpan={3}
            align="center"
            sx={{ py: 2, color: 'text.secondary' }}
          >
            No Fixed Costs Items have been added.
          </TableCell>
        </TableRow>
      ) : (
        fixedCosts.map((fixedCost) => (
          <TableRow key={fixedCost._id} hover>
            <TableCell colSpan={2} align="right" sx={{ pr: 2 }}>
              <Typography variant="body2" fontWeight={500} textAlign="right">
                {fixedCost.itemName}
              </Typography>
              {fixedCost.description && (
                <Typography
                  variant="caption"
                  color="text.secondary"
                  display="block"
                  textAlign="right"
                >
                  {fixedCost.description}
                </Typography>
              )}
            </TableCell>
            <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
              <TextField
                size="small"
                type="number"
                value={fixedCost.amount ?? ''}
                disabled={!canEditFixedCosts}
                onChange={(event) =>
                  onFixedCostAmountChange?.(fixedCost._id, event.target.value)
                }
                inputProps={{
                  min: 0,
                  step: '0.01',
                  'aria-label': `${fixedCost.itemName} amount`,
                }}
                sx={{ width: '100%', '& input': { textAlign: 'right' } }}
              />
            </TableCell>
          </TableRow>
        ))
      )}
      <TableRow sx={{ bgcolor: '#FAFAFA' }}>
        <TableCell
          colSpan={2}
          align="right"
          sx={{ fontWeight: 800, color: 'error.main' }}
        >
          Total Fixed Cost
        </TableCell>
        <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
          <ReadOnlyTotalAmount
            label="Total Fixed Cost"
            value={fixedCostTotal}
          />
        </TableCell>
      </TableRow>
    </>
  );
}
 
function CategoryRows({
  groups,
  amounts,
  amountErrors,
  showValidation,
  expandedComponents,
}) {
  return groups.flatMap((group) =>
    group.components.map((component, index) => {
      const headComponentAmount = getOperationalExpenseHeadAmount(
        component,
        amounts,
      );
      const expanded = Boolean(expandedComponents[String(component._id)]);
 
      return (
        <Fragment key={component._id}>
          <TableRow>
            <TableCell sx={{ fontWeight: index === 0 ? 700 : 400 }}>
              {index === 0 ? group.categoryName : ''}
            </TableCell>
            <TableCell>
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  gap: 1,
                }}
              >
                <Typography sx={{ textAlign: 'right' }} variant="body2">
                  {component.componentName}
                </Typography>
              </Box>
            </TableCell>
            <TableCell align="right">
              {component.subComponents.length ? (
                <Typography fontWeight={600}>
                  {formatAmount(headComponentAmount)}
                </Typography>
              ) : (
                <ReadOnlyAmount
                  id={component._id}
                  label={`${component.componentName} monthly amount`}
                  amounts={amounts}
                  amountErrors={amountErrors}
                  showValidation={showValidation}
                />
              )}
            </TableCell>
          </TableRow>
          {component.subComponents.length > 0 && (
            <TableRow>
              <TableCell colSpan={3} sx={{ py: 0, borderBottom: 0 }}>
                <Collapse in={expanded} timeout="auto" unmountOnExit>
                  <Table
                    size="small"
                    aria-label={`${component.componentName} subcomponents`}
                    sx={{ width: '100%', tableLayout: 'fixed' }}
                  >
                    <colgroup>
                      <col style={{ width: '22%' }} />
                      <col style={{ width: '53%' }} />
                      <col style={{ width: '25%' }} />
                    </colgroup>
                    <TableBody>
                      <TableRow>
                        <TableCell />
                        <TableCell sx={{ pl: 3, fontWeight: 600 }}>
                          Direct Cost
                        </TableCell>
                        <TableCell align="right">
                          <ReadOnlyAmount
                            id={component._id}
                            label={`${component.componentName} direct monthly amount`}
                            amounts={amounts}
                            amountErrors={amountErrors}
                            showValidation={showValidation}
                          />
                        </TableCell>
                      </TableRow>
                      {component.subComponents.map((subComponent) => (
                        <TableRow key={subComponent._id}>
                          <TableCell />
                          <TableCell sx={{ pl: 3 }}>
                            {subComponent.subComponentName}
                          </TableCell>
                          <TableCell align="right">
                            <ReadOnlyAmount
                              id={subComponent._id}
                              label={`${subComponent.subComponentName} monthly amount`}
                              amounts={amounts}
                              amountErrors={amountErrors}
                              showValidation={showValidation}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Collapse>
              </TableCell>
            </TableRow>
          )}
        </Fragment>
      );
    }),
  );
}
 
export default function OperationalExpenseTable({
  categoriesWithComponents,
  reportTableRef,
  fixedCosts,
  fixedCostTotal,
  sourcePeriod,
  directGroups,
  indirectGroups,
  otherGroups,
  amounts,
  amountErrors,
  showValidation,
  isFinalized,
  expandedComponents,
  totalDirectCost,
  totalIndirectCost,
  subTotal,
  markup,
  operationalExpenseTotal,
  clientAllocationRows,
  onAddInvoiceAmount,
  clientAllocationsLocked = false,
  canEditFixedCosts = false,
  onFixedCostAmountChange,
}) {
  return (
    <TableContainer
      ref={reportTableRef}
      data-operational-expense-report="true"
      component={Paper}
      variant="outlined"
      sx={{ width: '100%', maxWidth: '100%', overflowX: 'auto' }}
    >
      <Table
        size="small"
        sx={{
          width: '100%',
          minWidth: 1150,
          tableLayout: 'fixed',
          '& td, & th': {
            border: '1px solid #111827',
            boxSizing: 'border-box',
            py: 0.8,
            px: 1,
          },
        }}
      >
        <colgroup>
          <col style={{ width: '18%' }} />
          <col style={{ width: '62%' }} />
          <col style={{ width: '20%' }} />
        </colgroup>
        <TableHead>
          <TableRow>
            <TableCell colSpan={3} align="center" sx={{ fontWeight: 800 }}>
              Operational Expense Summary
            </TableCell>
          </TableRow>
          <TableRow>
            <TableCell colSpan={3} align="center" sx={{ fontWeight: 800 }}>
              {sourcePeriod}
            </TableCell>
          </TableRow>
          <TableRow sx={{ bgcolor: '#D1D5DB' }}>
            <TableCell sx={{ fontWeight: 800 }}>Category</TableCell>
            <TableCell align="center" sx={{ fontWeight: 800 }}>
              Description
            </TableCell>
            <TableCell align="center" sx={{ fontWeight: 800 }}>
              Monthly Amount (Estimated in Rs)
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {categoriesWithComponents.length === 0 ? (
            <TableRow>
              <TableCell colSpan={3} align="center" sx={{ py: 4 }}>
                No active Operational Expense components are configured in
                Master Data.
              </TableCell>
            </TableRow>
          ) : (
            <>
              <CategoryRows
                groups={directGroups}
                amounts={amounts}
                amountErrors={amountErrors}
                showValidation={showValidation}
                expandedComponents={expandedComponents}
              />
              <TotalRow
                label="Total Direct Cost"
                value={totalDirectCost}
                id="total-direct"
              />
              <CategoryRows
                groups={indirectGroups}
                amounts={amounts}
                amountErrors={amountErrors}
                showValidation={showValidation}
                expandedComponents={expandedComponents}
              />
              <TotalRow
                label="Total Indirect Cost"
                value={totalIndirectCost}
                id="total-indirect"
              />
              <TotalRow label="Sub Total" value={subTotal} id="subtotal" />
              <TotalRow
                label="20% Markup over Sub Total"
                value={markup}
                id="markup"
              />
              <CategoryRows
                groups={otherGroups}
                amounts={amounts}
                amountErrors={amountErrors}
                showValidation={showValidation}
                expandedComponents={expandedComponents}
              />
              <FixedCostRows
                fixedCosts={fixedCosts}
                fixedCostTotal={fixedCostTotal}
                canEditFixedCosts={canEditFixedCosts}
                onFixedCostAmountChange={onFixedCostAmountChange}
              />
              <TableRow>
                <TableCell colSpan={3} sx={{ p: 0.45 }} />
              </TableRow>
              <TotalRow
                label="Operational Expense Total"
                value={operationalExpenseTotal}
                id="operational-expense-total"
              />
              {clientAllocationRows.map((clientAllocation) => {
                return (
                  <TableRow key={String(clientAllocation.clientId)}>
                    <TableCell
                      colSpan={2}
                      align="right"
                      sx={{ fontWeight: 800 }}
                    >
                      Total Amount Charged to {clientAllocation.clientName}
                    </TableCell>
                    <TableCell
                      align="right"
                      sx={{ minWidth: 180, whiteSpace: 'nowrap' }}
                    >
                      <TextField
                        fullWidth
                        size="small"
                        value={
                          formatInclusiveAmount(clientAllocation.amount) ||
                          '0.00'
                        }
                        disabled={clientAllocationsLocked}
                        onClick={() =>
                          !clientAllocationsLocked &&
                          onAddInvoiceAmount?.(clientAllocation)
                        }
                        inputProps={{
                          readOnly: true,
                          'aria-label': `Amount charged to ${clientAllocation.clientName}`,
                        }}
                        sx={{
                          '& input': {
                            textAlign: 'right',
                            cursor: 'pointer',
                            color: '#1976d2',
                            fontWeight: 700,
                          },
                        }}
                      />
                    </TableCell>
                  </TableRow>
                );
              })}
            </>
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
 
