import { Box, Card, CardContent, Typography } from '@mui/material';
import LayersOutlinedIcon from '@mui/icons-material/LayersOutlined';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';
import CurrencyRupeeOutlinedIcon from '@mui/icons-material/CurrencyRupeeOutlined';

const getAmount = (report) => Number(report?.totals?.operationalExpenseTotal ?? report?.monthlyTotal) || (report?.rows || []).reduce((total, row) => total + (Number(row.amount) || 0), 0);
const formatCurrency = (value) => `₹${(Number(value) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export default function OperationalExpenseDashboardCards({ reports = [] }) {
  const invoiced = reports.filter((report) => report.status === 'INVOICED');
  const items = [
    { label: 'Total Records', value: reports.length, caption: 'Active monthly records', color: '#1769ff', tint: '#eaf1ff', icon: <LayersOutlinedIcon /> },
    { label: 'Pending Actions', value: reports.filter((report) => report.status !== 'INVOICED').length, caption: 'Requires user action', color: '#d78508', tint: '#fff4df', icon: <AccessTimeOutlinedIcon /> },
    { label: 'Completed', value: invoiced.length, caption: 'Invoice batches locked', color: '#18876a', tint: '#e9f8f3', icon: <CheckCircleOutlineRoundedIcon /> },
    { label: 'Invoiced Value', value: formatCurrency(invoiced.reduce((total, report) => total + getAmount(report), 0)), caption: 'Across completed records', color: '#7357e8', tint: '#f0edff', icon: <CurrencyRupeeOutlinedIcon /> },
  ];
  return <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(4, minmax(0, 1fr))' }, gap: 1.5 }}>{items.map((item) => <Card key={item.label} variant="outlined" sx={{ position: 'relative', overflow: 'hidden', minHeight: 158, borderRadius: 2.5, borderColor: '#dce4ef', boxShadow: '0 8px 24px rgba(19, 47, 89, 0.05)', '&::after': { content: '""', position: 'absolute', top: -30, right: -30, width: 86, height: 86, borderRadius: '50%', bgcolor: item.tint } }}><CardContent sx={{ position: 'relative', zIndex: 1, p: 2.25, '&:last-child': { pb: 2.25 } }}><Box sx={{ width: 42, height: 42, display: 'grid', placeItems: 'center', borderRadius: 1.75, color: item.color, bgcolor: item.tint }}>{item.icon}</Box><Typography sx={{ mt: 1.5, color: '#52647d', fontSize: 14, fontWeight: 500 }}>{item.label}</Typography><Typography sx={{ mt: 0.35, color: '#102a52', fontSize: { xs: 25, sm: 28 }, lineHeight: 1.1, fontWeight: 800, fontVariantNumeric: 'tabular-nums' }}>{item.value}</Typography><Typography variant="caption" color="text.secondary">{item.caption}</Typography></CardContent></Card>)}</Box>;
}
