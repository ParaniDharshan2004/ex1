import { Button, Paper, Stack } from '@mui/material';

export default function OperationalExpenseActions({
  saving,
  exporting,
  reportStatus,
  hasReportData,
  onSaveReport,
}) {
  const canEditReport = ['DRAFT', 'FINALIZED'].includes(reportStatus);
  const isFinalized = reportStatus === 'FINALIZED';

  return (
    <Paper variant="outlined" sx={{ p: 2, overflow: 'hidden', borderRadius: 0 }}>
      <Stack
        direction={{ xs: 'column', sm: 'row' }}
        alignItems={{ xs: 'stretch', sm: 'center' }}
        sx={{ justifyContent: 'flex-end', alignItems: { xs: 'stretch', sm: 'center' } }}
        spacing={2}
      >
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <Button
            variant="contained"
            disabled={
              saving ||
              exporting ||
              !canEditReport ||
              !hasReportData ||
              isFinalized
            }
            onClick={() => onSaveReport('DRAFT')}
          >
            {saving && !exporting
              ? 'Saving...'
              : reportStatus === 'FINALIZED'
                ? 'Save Changes'
                : 'Save Draft'}
          </Button>
        </Stack>
      </Stack>
    </Paper>
  );
}
