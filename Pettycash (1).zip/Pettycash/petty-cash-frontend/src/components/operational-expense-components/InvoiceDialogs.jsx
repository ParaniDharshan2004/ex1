import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Avatar,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Alert,
  Paper,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import BusinessRoundedIcon from '@mui/icons-material/BusinessRounded';
import AccountBalanceRoundedIcon from '@mui/icons-material/AccountBalanceRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import DescriptionRoundedIcon from '@mui/icons-material/DescriptionRounded';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import LocationOnRoundedIcon from '@mui/icons-material/LocationOnRounded';
import ReceiptLongRoundedIcon from '@mui/icons-material/ReceiptLongRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { INVOICE_COMPANY } from '../../config/invoiceConfig.js';
import { calculateGstAmounts } from '../../utils/gst.js';

const money = (v) =>
  Number(v || 0).toLocaleString('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
  });

const dateLabel = (m) =>
  m
    ? new Date(`${m}-01T00:00:00`).toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })
    : new Date().toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });

const dialogPaperSx = {
  borderRadius: { xs: 2.5, sm: 4 },
  boxShadow: 24,
  overflow: 'hidden',
  backgroundImage: 'none',
};

const dialogTitleSx = {
  px: { xs: 2, sm: 3 },
  py: 2.25,
  borderBottom: '1px solid',
  borderColor: 'divider',
};

const dialogActionsSx = {
  px: { xs: 2, sm: 3 },
  py: 2,
  gap: 1,
  borderTop: '1px solid',
  borderColor: 'divider',
  bgcolor: 'background.paper',
};

const selectionCardSx = {
  p: 2,
  borderRadius: 1,
  border: '1px solid',
  borderColor: 'divider',
  transition: (theme) =>
    theme.transitions.create(['border-color', 'box-shadow', 'transform']),
  '&:hover': {
    borderColor: 'primary.main',
    boxShadow: 3,
    transform: 'translateY(-1px)',
  },
  '&:focus-within': {
    borderColor: 'primary.main',
    boxShadow: (theme) => `0 0 0 3px ${theme.palette.primary.main}20`,
  },
};

function DialogHeading({ icon, title, subtitle, titleId }) {
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Avatar
        sx={{
          width: 44,
          height: 44,
          bgcolor: 'primary.main',
          color: 'primary.contrastText',
          borderRadius: 1,
        }}
      >
        {icon}
      </Avatar>
      <Box sx={{ minWidth: 0 }}>
        <Typography id={titleId} variant="h6" component="h2" fontWeight={800}>
          {title}
        </Typography>
        {subtitle && (
          <Typography variant="body2" color="text.secondary">
            {subtitle}
          </Typography>
        )}
      </Box>
    </Stack>
  );
}

function EmptyState({ icon, title, description }) {
  return (
    <Paper
      variant="outlined"
      sx={{ p: 4, borderRadius: 1, textAlign: 'center', borderStyle: 'dashed' }}
    >
      <Avatar
        sx={{
          mx: 'auto',
          mb: 1.5,
          bgcolor: 'action.hover',
          color: 'text.secondary',
        }}
      >
        {icon}
      </Avatar>
      <Typography fontWeight={700}>{title}</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
        {description}
      </Typography>
    </Paper>
  );
}

export function InvoiceClientDialog({
  open,
  allocations = [],
  loading,
  onClose,
  onSelect,
}) {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="sm"
      aria-labelledby="select-client-title"
      PaperProps={{ sx: dialogPaperSx }}
    >
      <DialogTitle sx={dialogTitleSx}>
        <DialogHeading
          titleId="select-client-title"
          icon={<BusinessRoundedIcon />}
          title="Select Client"
          subtitle="Choose a confirmed client to continue with invoice creation."
        />
      </DialogTitle>
      <DialogContent
        sx={{
          px: { xs: 2, sm: 3 },
          py: 1.5,
          bgcolor: 'grey.50',
          '&:first-of-type': { pt: 1.5 },
        }}
      >
        {allocations.length ? (
          <Stack spacing={1.5}>
            {allocations.map((a) => {
              const amount = Number(a.clientTotalAmount) || 0;
              const ready = a.allocationStatus === 'CONFIRMED' && amount > 0;
              const locationCount = a.locationAllocations?.length || 0;
              return (
                <Paper
                  key={String(a.clientId)}
                  component="article"
                  variant="outlined"
                  sx={{
                    ...selectionCardSx,
                    opacity: ready ? 1 : 0.68,
                    bgcolor: ready
                      ? 'background.paper'
                      : 'action.disabledBackground',
                    '&:hover': ready ? selectionCardSx['&:hover'] : {},
                  }}
                >
                  <Box
                    sx={{
                      display: 'grid',
                      gridTemplateColumns: 'auto minmax(0, 1fr) auto',
                      alignItems: 'center',
                      columnGap: { xs: 1.25, sm: 2 },
                      rowGap: 1.25,
                      '@media (max-width: 420px)': {
                        gridTemplateColumns: 'auto minmax(0, 1fr)',
                        '& > button': {
                          gridColumn: '1 / -1',
                          width: '100%',
                        },
                      },
                    }}
                  >
                    <Avatar
                      sx={{
                        bgcolor: ready ? 'primary.main' : 'action.disabled',
                        flexShrink: 0,
                      }}
                    >
                      {ready ? (
                        <CheckCircleRoundedIcon />
                      ) : (
                        <WarningAmberRoundedIcon />
                      )}
                    </Avatar>
                    <Box sx={{ minWidth: 0 }}>
                      <Stack
                        direction="row"
                        spacing={1}
                        alignItems="center"
                        flexWrap="wrap"
                        useFlexGap
                      >
                        <Typography fontWeight={800} noWrap>
                          {a.clientName || a.clientCode || 'Client'}
                        </Typography>
                        <Chip
                          size="small"
                          color={ready ? 'success' : 'default'}
                          label={ready ? 'Confirmed' : 'Unavailable'}
                        />
                      </Stack>
                      <Stack
                        direction="row"
                        spacing={1}
                        sx={{ mt: 1 }}
                        flexWrap="wrap"
                        useFlexGap
                      >
                        <Chip
                          size="small"
                          variant="outlined"
                          label={money(amount)}
                        />
                        <Chip
                          size="small"
                          variant="outlined"
                          icon={<LocationOnRoundedIcon />}
                          label={`${locationCount} location${locationCount === 1 ? '' : 's'}`}
                        />
                      </Stack>
                    </Box>
                    <Button
                      variant="contained"
                      disabled={loading || !ready}
                      onClick={() => onSelect(a)}
                      sx={{ minHeight: 44, minWidth: 104, alignSelf: 'center' }}
                    >
                      Select
                    </Button>
                  </Box>
                </Paper>
              );
            })}
          </Stack>
        ) : (
          <EmptyState
            icon={<BusinessRoundedIcon />}
            title="No clients available"
            description="Client invoice allocations will appear here when available."
          />
        )}
      </DialogContent>
      <DialogActions sx={dialogActionsSx}>
        <Button onClick={onClose} disabled={loading} sx={{ minHeight: 42 }}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export function InvoiceGenerationConfirmationDialog({
  open,
  invoiceItems = [],
  generating = false,
  errorMessage = '',
  onClose,
  onConfirm,
}) {
  const count = invoiceItems.length;
  const label = `${count} invoice${count === 1 ? '' : 's'}`;

  return (
    <Dialog
      open={open}
      onClose={generating ? undefined : onClose}
      fullWidth
      maxWidth="sm"
      aria-labelledby="generate-invoices-title"
      PaperProps={{ sx: dialogPaperSx }}
    >
      <DialogTitle sx={dialogTitleSx}>
        <Stack direction="row" justifyContent="space-between" spacing={2}>
          <DialogHeading
            titleId="generate-invoices-title"
            icon={<ReceiptLongRoundedIcon />}
            title={`Generate ${label}?`}
            subtitle="Review the allocation before locking the month."
          />
          <Button
            aria-label="Close"
            onClick={onClose}
            disabled={generating}
            sx={{ minWidth: 44, alignSelf: 'flex-start', fontSize: 22 }}
          >
            ×
          </Button>
        </Stack>
      </DialogTitle>
      <DialogContent
        sx={{
          px: { xs: 2, sm: 3 },
          py: 2.5,
          bgcolor: 'background.paper',
          '&:first-of-type': { pt: 2.5 },
        }}
      >
        <Stack spacing={1.5}>
          {errorMessage && <Alert severity="error">{errorMessage}</Alert>}
          {invoiceItems.map((item) => (
            <Paper
              key={`${item.clientId}-${item.locationId || 'client'}`}
              component="article"
              variant="outlined"
              sx={{
                ...selectionCardSx,
                display: 'flex',
                alignItems: 'center',
                gap: 2,
              }}
            >
              <Avatar sx={{ bgcolor: 'action.hover', color: 'text.primary' }}>
                {item.locationName ? (
                  <BusinessRoundedIcon />
                ) : (
                  <AccountBalanceRoundedIcon />
                )}
              </Avatar>
              <Box sx={{ minWidth: 0 }}>
                <Typography fontWeight={800}>
                  {item.clientName}
                  {item.locationName ? ` – ${item.locationName}` : ''}
                </Typography>
                <Typography color="text.secondary">
                  {money(item.amount)}
                </Typography>
              </Box>
            </Paper>
          ))}
          <Alert
            severity="warning"
            icon={<LockRoundedIcon />}
            sx={{ border: '1px solid', borderColor: 'warning.light' }}
          >
            After generation, the uploaded data and allocations will be locked.
          </Alert>
        </Stack>
      </DialogContent>
      <DialogActions sx={dialogActionsSx}>
        <Button
          onClick={onClose}
          disabled={generating}
          sx={{ minHeight: 42, px: 2.5 }}
        >
          Go back
        </Button>
        <Button
          variant="contained"
          color="success"
          disabled={generating || !count}
          onClick={onConfirm}
          startIcon={
            generating ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              <ReceiptLongRoundedIcon />
            )
          }
          sx={{ minHeight: 48, px: 2.5, fontWeight: 700 }}
        >
          {generating ? 'Generating...' : `Generate ${label}`}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

export function InvoiceLocationDialog({
  open,
  allocation,
  loading,
  onClose,
  onSelect,
}) {
  const locations = allocation?.locationAllocations || [];
  const amount = Number(allocation?.clientTotalAmount) || 0;
  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="sm"
      aria-labelledby="select-location-title"
      PaperProps={{ sx: dialogPaperSx }}
    >
      <DialogTitle sx={dialogTitleSx}>
        <DialogHeading
          titleId="select-location-title"
          icon={<LocationOnRoundedIcon />}
          title={
            locations.length
              ? 'Select Invoice Location'
              : 'Create Client Invoice'
          }
          subtitle={
            allocation?.clientName ||
            allocation?.clientCode ||
            'Selected client'
          }
        />
      </DialogTitle>
      <DialogContent sx={{ p: { xs: 2, sm: 3 }, bgcolor: 'grey.50' }}>
        <Stack spacing={1.5}>
          {locations.length ? (
            <>
              <Paper
                component="article"
                variant="outlined"
                sx={{
                  ...selectionCardSx,
                  borderColor: 'primary.main',
                  bgcolor: 'primary.main',
                  color: 'primary.contrastText',
                }}
              >
                <Stack
                  direction={{ xs: 'column', sm: 'row' }}
                  spacing={2}
                  alignItems={{ xs: 'stretch', sm: 'center' }}
                >
                  <Avatar
                    sx={{
                      bgcolor: 'primary.contrastText',
                      color: 'primary.main',
                    }}
                  >
                    <ReceiptLongRoundedIcon />
                  </Avatar>
                  <Box sx={{ flex: 1 }}>
                    <Typography fontWeight={800}>
                      All client locations
                    </Typography>
                    <Typography variant="body2" sx={{ opacity: 0.86 }}>
                      {money(calculateGstAmounts(amount).totalIncludingGst)}
                    </Typography>
                  </Box>
                  <Button
                    variant="outlined"
                    disabled={amount <= 0}
                    onClick={() => onSelect(null)}
                    sx={{
                      minHeight: 42,
                      color: 'primary.contrastText',
                      borderColor: 'primary.contrastText',
                      '&:hover': {
                        borderColor: 'primary.contrastText',
                        bgcolor: 'rgba(255,255,255,.08)',
                      },
                    }}
                  >
                    Create Consolidated Invoice
                  </Button>
                </Stack>
              </Paper>
              <Divider sx={{ my: 0.5 }}>OR SELECT A LOCATION</Divider>
              {locations.map((item) => (
                <Paper
                  key={String(item.locationId)}
                  component="article"
                  variant="outlined"
                  sx={selectionCardSx}
                >
                  <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    spacing={2}
                    alignItems={{ xs: 'stretch', sm: 'center' }}
                  >
                    <Avatar sx={{ bgcolor: 'primary.main' }}>
                      <LocationOnRoundedIcon />
                    </Avatar>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography fontWeight={800}>
                        {item.locationName}
                      </Typography>
                      <Chip
                        size="small"
                        variant="outlined"
                        sx={{ mt: 0.75 }}
                        label={money(
                          calculateGstAmounts(item.amount).totalIncludingGst,
                        )}
                      />
                    </Box>
                    <Button
                      variant="contained"
                      disabled={Number(item.amount) <= 0}
                      onClick={() => onSelect(item)}
                      sx={{ minHeight: 42 }}
                    >
                      Create Draft Invoice
                    </Button>
                  </Stack>
                </Paper>
              ))}
            </>
          ) : allocation ? (
            <Paper component="article" variant="outlined" sx={selectionCardSx}>
              <Stack
                direction={{ xs: 'column', sm: 'row' }}
                spacing={2}
                alignItems={{ xs: 'stretch', sm: 'center' }}
              >
                <Avatar sx={{ bgcolor: 'primary.main' }}>
                  <BusinessRoundedIcon />
                </Avatar>
                <Box sx={{ flex: 1 }}>
                  <Typography fontWeight={800}>
                    {allocation?.clientName}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {money(calculateGstAmounts(amount).totalIncludingGst)}
                  </Typography>
                </Box>
                <Button
                  variant="contained"
                  disabled={amount <= 0}
                  onClick={() => onSelect(null)}
                  sx={{ minHeight: 42 }}
                >
                  Create Draft Invoice
                </Button>
              </Stack>
            </Paper>
          ) : (
            <EmptyState
              icon={<LocationOnRoundedIcon />}
              title="No location data available"
              description="Select a client with invoice allocation data to continue."
            />
          )}
        </Stack>
      </DialogContent>
      <DialogActions sx={dialogActionsSx}>
        <Button onClick={onClose} disabled={loading} sx={{ minHeight: 42 }}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}

function InvoicePaper({ allocation, location, reportMonth, paperRef }) {
  const amount = calculateGstAmounts(
    location?.amount ?? allocation?.clientTotalAmount,
  );
  const c = INVOICE_COMPANY;
  const bank = c.bankDetails || {};
  const client = location?.billingName || allocation?.clientName || '';
  const cell = {
    border: '1px solid #222',
    padding: '7px 9px',
    verticalAlign: 'top',
  };
  return (
    <div
      ref={paperRef}
      style={{
        width: 794,
        minHeight: 1123,
        boxSizing: 'border-box',
        padding: '42px 47px',
        background: '#fff',
        color: '#111',
        fontFamily: 'Arial, Helvetica, sans-serif',
        fontSize: 12,
        lineHeight: 1.35,
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          borderBottom: '2px solid #111',
          paddingBottom: 14,
        }}
      >
        <div style={{ width: '58%' }}>
          <div style={{ fontSize: 22, fontWeight: 700 }}>
            {c.legalName || c.companyName}
          </div>
          {(c.addressLines || []).map((x) => (
            <div key={x}>{x}</div>
          ))}
          <div>
            {[c.city, c.stateName, c.postalCode].filter(Boolean).join(' - ')}
          </div>
          <div>GSTIN/UIN : {c.gstin || '—'}</div>
          <div>PAN NO : {c.pan || '—'}</div>
        </div>
        <div style={{ textAlign: 'right', width: '36%' }}>
          <div style={{ fontSize: 25, fontWeight: 700, marginBottom: 10 }}>
            TAX INVOICE
          </div>
          <div>
            <b>Invoice No :</b>{' '}
            {allocation?.invoiceNumber || allocation?.invoiceNo || 'DRAFT'}
          </div>
          <div>
            <b>Invoice Date :</b> {dateLabel(reportMonth)}
          </div>
          <div>
            <b>Report Month :</b> {reportMonth || '—'}
          </div>
        </div>
      </div>
      <div
        style={{
          marginTop: 19,
          border: '1px solid #222',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
        }}
      >
        <div style={{ padding: 12, minHeight: 125 }}>
          <b>Billed To:</b>
          <div style={{ fontSize: 15, fontWeight: 700, marginTop: 9 }}>
            {client}
          </div>
          <div>{location?.billingAddress}</div>
          <div>
            {[location?.stateName, location?.stateCode]
              .filter(Boolean)
              .join(' - ')}
          </div>
          <div>GSTIN/UIN : {location?.gstin || '—'}</div>
        </div>
        <div style={{ padding: 12, borderLeft: '1px solid #222' }}>
          <b>Supply meant for:</b>
          <div style={{ marginTop: 9 }}>
            Accounting Services for the month of{' '}
            {reportMonth || 'the selected report period'}
          </div>
          <div style={{ marginTop: 12 }}>
            <b>Location:</b> {location?.locationName || 'All client locations'}
          </div>
        </div>
      </div>
      <table
        style={{ width: '100%', borderCollapse: 'collapse', marginTop: 20 }}
      >
        <thead>
          <tr style={{ background: '#f0f0f0' }}>
            <th style={{ ...cell, width: '8%', textAlign: 'center' }}>S.No</th>
            <th style={{ ...cell, width: '52%', textAlign: 'left' }}>
              Description
            </th>
            <th style={{ ...cell, width: '15%', textAlign: 'center' }}>
              HSN / SAC
            </th>
            <th style={{ ...cell, width: '25%', textAlign: 'right' }}>
              Amount (INR)
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ ...cell, textAlign: 'center', height: 135 }}>001</td>
            <td style={cell}>
              Accounting Services for the month of{' '}
              {reportMonth || 'the selected report period'}
            </td>
            <td style={{ ...cell, textAlign: 'center' }}>998222</td>
            <td style={{ ...cell, textAlign: 'right' }}>
              {money(amount.taxableAmount)}
            </td>
          </tr>
        </tbody>
      </table>
      <div
        style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 17 }}
      >
        <table style={{ borderCollapse: 'collapse', width: '47%' }}>
          <tbody>
            {[
              ['Taxable Amount', amount.taxableAmount],
              ['IGST @ 18%', amount.gstAmount],
              ['Total Amount', amount.totalIncludingGst],
            ].map(([label, value]) => (
              <tr key={label}>
                <td
                  style={{
                    ...cell,
                    fontWeight: label === 'Total Amount' ? 700 : 400,
                  }}
                >
                  {label}
                </td>
                <td style={{ ...cell, textAlign: 'right', fontWeight: 700 }}>
                  {money(value)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{ marginTop: 16, fontWeight: 700 }}>
        Amount in Words :{' '}
        <span style={{ fontWeight: 400 }}>
          {money(amount.totalIncludingGst).replace('₹', '').trim()} only
        </span>
      </div>
      <div
        style={{
          marginTop: 22,
          borderTop: '1px solid #222',
          paddingTop: 12,
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <div>
          <b>Bank Details</b>
          <div>Beneficiary Name: {bank.accountName || c.legalName || '—'}</div>
          <div>Bank Name: {bank.bankName || '—'}</div>
          <div>Beneficiary Account Number: {bank.accountNumber || '—'}</div>
          <div>IFSC Code: {bank.ifscCode || '—'}</div>
          <div>Branch: {bank.branchName || '—'}</div>
        </div>
        <div
          style={{ textAlign: 'right', alignSelf: 'flex-end', fontWeight: 700 }}
        >
          For {c.legalName || c.companyName}
          <div style={{ marginTop: 42, fontWeight: 400 }}>
            Authorised Signatory
          </div>
        </div>
      </div>
      <div
        style={{
          marginTop: 22,
          borderTop: '1px solid #222',
          paddingTop: 9,
          fontSize: 10,
        }}
      >
        Supply meant for Export under LUT without payment of Integrated Tax
        (IGST).
        <br />
        This is a computer generated invoice.
      </div>
    </div>
  );
}

export function InvoiceDraftDialog({
  open,
  allocation,
  location,
  reportMonth,
  autoDownload = false,
  onClose,
  onDownloaded,
}) {
  const captureRef = useRef(null);
  const autoDownloadStartedRef = useRef(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState('');

  // Capture only the fixed-size invoice paper so preview UI never enters the PDF.
  const download = useCallback(async () => {
    if (!captureRef.current) return;
    setDownloading(true);
    setDownloadError('');
    try {
      const canvas = await html2canvas(captureRef.current, {
        scale: 2,
        backgroundColor: '#fff',
      });
      const pdf = new jsPDF('p', 'mm', 'a4');
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, 210, 297);
      pdf.save(
        `invoice-${location?.locationCode || allocation?.clientCode || 'client'}.pdf`,
      );
      await onDownloaded?.();
    } catch (error) {
      setDownloadError(error.message || 'Unable to download the invoice PDF.');
    } finally {
      setDownloading(false);
    }
  }, [allocation, location, onDownloaded]);

  useEffect(() => {
    if (!open) {
      autoDownloadStartedRef.current = false;
      return undefined;
    }
    if (!autoDownload || autoDownloadStartedRef.current) return undefined;
    const timer = window.setTimeout(() => {
      autoDownloadStartedRef.current = true;
      void download();
    }, 100);
    return () => window.clearTimeout(timer);
  }, [autoDownload, download, open]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="md"
      aria-labelledby="invoice-preview-title"
      PaperProps={{
        sx: {
          ...dialogPaperSx,
          maxHeight: { xs: 'calc(100% - 16px)', sm: 'calc(100% - 48px)' },
        },
      }}
    >
      <DialogTitle sx={dialogTitleSx}>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          spacing={2}
        >
          <DialogHeading
            titleId="invoice-preview-title"
            icon={<DescriptionRoundedIcon />}
            title="Invoice Preview"
            subtitle="Review the invoice before downloading the PDF."
          />
          <Chip
            label="DRAFT"
            color="warning"
            size="small"
            sx={{ fontWeight: 800 }}
          />
        </Stack>
      </DialogTitle>
      <DialogContent
        sx={{
          p: { xs: 1.5, sm: 3 },
          bgcolor: 'grey.200',
          overflow: 'auto',
        }}
      >
        {downloadError && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {downloadError}
          </Alert>
        )}
        {/* Preview shell is excluded because html2canvas captures only InvoicePaper. */}
        <Box sx={{ minWidth: 794, width: 'fit-content', mx: 'auto' }}>
          <Paper
            elevation={12}
            sx={{
              width: 794,
              minHeight: 1123,
              overflow: 'hidden',
              bgcolor: 'background.paper',
            }}
          >
            <InvoicePaper
              paperRef={captureRef}
              allocation={allocation}
              location={location}
              reportMonth={reportMonth || allocation?.reportMonth}
            />
          </Paper>
        </Box>
      </DialogContent>
      <DialogActions
        sx={{
          ...dialogActionsSx,
          position: 'sticky',
          bottom: 0,
          zIndex: 2,
          boxShadow: '0 -8px 20px rgba(0,0,0,.05)',
        }}
      >
        <Tooltip title="Close invoice preview">
          <Button
            onClick={onClose}
            startIcon={<CloseRoundedIcon />}
            sx={{ minHeight: 42 }}
          >
            Close
          </Button>
        </Tooltip>
        <Button
          variant="contained"
          disabled={downloading}
          onClick={download}
          startIcon={
            downloading ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              <DownloadRoundedIcon />
            )
          }
          sx={{ minHeight: 42, minWidth: 150 }}
        >
          {downloading ? 'Preparing...' : 'Download PDF'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
