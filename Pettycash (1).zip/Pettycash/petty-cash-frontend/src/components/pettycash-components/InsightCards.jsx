import { Grid, Card, CardContent, Typography } from "@mui/material";

export default function InsightCards({
  openingBalance,
  cashAdded,
  totalExpense,
  availableCash,
}) {
  // const cardData = [
  //   {
  //     title: "Opening Balance",
  //     value: "₹5,000",
  //   },
  //   {
  //     title: "Cash Added",
  //     value: "₹15,000",
  //   },
  //   {
  //     title: "Total Expense",
  //     value: "₹5,000",
  //   },
  //   {
  //     title: "Available Cash",
  //     value: "₹15,000",
  //   },
  // ];

  const cardData = [
    {
      title: "Opening Balance",
      value: `₹${openingBalance.toLocaleString()}`,
    },
    {
      title: "Cash Added",
      value: `₹${cashAdded.toLocaleString()}`,
    },
    {
      title: "Total Expense",
      value: `₹${totalExpense.toLocaleString()}`,
    },
    {
      title: "Available Cash",
      value: `₹${availableCash.toLocaleString()}`,
    },
  ];

  return (
    <Grid container spacing={3}>
      {cardData.map((item) => (
        <Grid size={{ xs: 12, sm: 6, md: 3 }} key={item.title}>
          <Card sx={{ width: "100%", height: "100%" }}>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                {item.title}
              </Typography>

              <Typography variant="h5" fontWeight={700} sx={{ mt: 1 }}>
                {item.value}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
}
