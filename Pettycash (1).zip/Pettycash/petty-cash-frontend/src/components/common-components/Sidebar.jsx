import {
  Box,
  Divider,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  Avatar,
  alpha,
  useTheme,
  Button,
} from "@mui/material";

import { NAV_ITEMS } from "../../data/dummy-data";

import { NavLink, useLocation, useNavigate } from "react-router-dom";

import Collapse from "@mui/material/Collapse";
import { useState } from "react";

import { Icons } from "../../theme/icons";
import { useAuth } from "../../context/AuthContext";

const SIDEBAR_WIDTH = 240;

export default function Sidebar({
  onSelect,
  mobileOpen,
  onClose,
  isMobile,
}) {
  const theme = useTheme();
  const navigate = useNavigate();
  const currentLocation = useLocation();
  const isExactChildRoute = (child) => {
    const targetPath = new URL(child.to, window.location.origin).pathname;
    return currentLocation.pathname === targetPath;
  };

  const { user, logout, permissions } = useAuth();

  const [openMenus, setOpenMenus] = useState({
    Dashboard: true,
  });

  const filteredNavItems = NAV_ITEMS.filter((item) => {
    if (
      item.label === "Masters" &&
      !permissions?.write &&
      !permissions?.delete
    ) {
      return false;
    }

    if (item.label === "Cash Flow" && !permissions?.write && !permissions?.delete) {
      return false;
    }

    if (
      item.label === "Operational Expense" &&
      !permissions?.write &&
      !permissions?.delete
    ) {
      return false;
    }

    return true;
  });

  const handleMenuClick = (label) => {
    setOpenMenus((prev) => ({
      ...prev,
      [label]: !prev[label],
    }));
  };

  /*
   * Close only the temporary mobile sidebar.
   * The permanent desktop sidebar remains visible.
   */
  const closeMobileSidebar = () => {
    if (isMobile && typeof onClose === "function") {
      onClose();
    }
  };

  /*
   * Called when a direct menu or child menu is selected.
   */
  const handleNavigation = (label) => {
    if (typeof onSelect === "function") {
      onSelect(label);
    }

    closeMobileSidebar();
  };

  const handleLogout = () => {
    closeMobileSidebar();
    logout();
    navigate("/login", {
      replace: true,
    });
  };

  const content = (
    <Box
      sx={{
        position: "sticky",
        width: SIDEBAR_WIDTH,
        height: "100%",
        bgcolor: "background.paper",
        color: "textPrimary",
        display: "flex",
        flexDirection: "column",
        overflowY: "auto",
        scrollbarWidth: "none",
        borderRight: "1px solid",
        borderColor: `${alpha(theme.palette.primary.main, 0.4)}`,
      }}
    >
      <Box
        sx={{
          px: 5,
          py: 3,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 1.5,
          position: "sticky",
          top: 0,
          bgcolor: "background.paper",
          zIndex: 2,
        }}
      >
        <Box
          component={"img"}
          src="/KOPL_LOGO.webp"
          sx={{
            width: 66,
            height: 66,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transform: "scale(2.5)",
          }}
        ></Box>
      </Box>

      <Divider
        sx={{
          borderColor: `${alpha(theme.palette.primary.main, 0.4)}`,
        }}
      />

      <List sx={{ flex: 1, py: 1 }}>
        {filteredNavItems.map((item) => {
          const Icon = item.icon;

          if (item.children) {
            const hasActiveChild = item.children.some(
              (child) => isExactChildRoute(child),
            );
            return (
              <Box key={item.label}>
                <ListItemButton onClick={() => handleMenuClick(item.label)}>
                  <ListItemIcon>
                    <Icon />
                  </ListItemIcon>

                  <ListItemText primary={item.label} />

                  {openMenus[item.label] ? (
                    <Icons.ExpandLessIcon />
                  ) : (
                    <Icons.ExpandMoreIcon />
                  )}
                </ListItemButton>

                <Collapse
                  in={Boolean(openMenus[item.label] || hasActiveChild)}
                  timeout="auto"
                  unmountOnExit
                >
                  <List component="div" disablePadding>
                    {item.children.map((child) => (
                      <ListItemButton
                        key={child.label}
                        component={NavLink}
                        to={child.to}
                        className={isExactChildRoute(child) ? 'active' : ''}
                        onClick={() => handleNavigation(child.label)}
                        sx={{
                          pl: 6,

                          bgcolor: isExactChildRoute(child)
                            ? "primary.light !important"
                            : "transparent !important",
                          color: isExactChildRoute(child)
                            ? "primary.dark"
                            : "text.primary",
                          "&.active": {
                            bgcolor: "primary.light !important",
                            color: "primary.dark",
                          },
                          "& .MuiListItemIcon-root": {
                            color: isExactChildRoute(child)
                              ? "primary.dark"
                              : "inherit",
                          },
                          "&:hover": { bgcolor: "action.hover" },
                        }}
                      >
                        <ListItemText primary={child.label} />
                      </ListItemButton>
                    ))}
                  </List>
                </Collapse>
              </Box>
            );
          }

          return (
            <ListItemButton
              key={item.label}
              component={NavLink}
              to={item.to}
              onClick={() => handleNavigation(item.label)}
            >
              <ListItemIcon>
                <Icon />
              </ListItemIcon>

              <ListItemText primary={item.label} />
            </ListItemButton>
          );
        })}
      </List>

      <Divider
        sx={{
          borderColor: `${alpha(theme.palette.primary.main, 0.4)}`,
        }}
      />

      <Box
        sx={{
          position: "sticky",
          bottom: 0,
          bgcolor: "background.paper",
          p: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 1.5,
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: 1,
            alignItems: "center",
          }}
        >
          <Avatar
            sx={{
              width: 32,
              height: 32,
              bgcolor: "primary.main",
              color: "textPrimary",
              fontSize: 13,
              fontWeight: 700,
            }}
          >
            {user?.username?.charAt(0)?.toUpperCase() || "U"}
          </Avatar>

          <Typography
            variant="body2"
            sx={{
              fontWeight: 600,
              color: "text.primary",
            }}
          >
            {user?.username || "User"}
          </Typography>
        </Box>

        <Button
          variant="outlined"
          color="error"
          size="small"
          startIcon={<Icons.LogoutIcon />}
          onClick={handleLogout}
        >
          Logout
        </Button>
      </Box>
    </Box>
  );

  if (isMobile) {
    return (
      <Drawer
        variant="temporary"
        anchor="left"
        open={Boolean(mobileOpen)}
        onClose={onClose}
        ModalProps={{
          keepMounted: true,
        }}
      >
        <Box
          sx={{
            width: SIDEBAR_WIDTH,
            height: "100%",
          }}
        >
          {content}
        </Box>
      </Drawer>
    );
  }

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: SIDEBAR_WIDTH,
        flexShrink: 0,

        "& .MuiDrawer-paper": {
          width: SIDEBAR_WIDTH,
          boxSizing: "border-box",
          border: "none",
        },
      }}
    >
      {content}
    </Drawer>
  );
}
