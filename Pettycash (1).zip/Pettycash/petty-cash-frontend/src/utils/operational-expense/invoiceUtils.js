import { roundCurrency } from '../../utils/currency.js';
export const getAllocatedTotal = (locations = []) => roundCurrency(locations.reduce((sum, item) => sum + (Number(item.amount) || 0), 0));
export const getRemainingBalance = (total, locations = []) => roundCurrency(Number(total) - getAllocatedTotal(locations));
export const formatInvoiceAmount = (value) => Number(value || 0).toLocaleString('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2 });
export const sanitizeInvoiceFilename = (value) => String(value || 'draft').replace(/[^a-z0-9_-]+/gi, '-').toLowerCase();
