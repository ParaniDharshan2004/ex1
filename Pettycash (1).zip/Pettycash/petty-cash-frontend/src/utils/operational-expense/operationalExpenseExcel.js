import * as XLSX from 'xlsx';
import { parseTallyWorksheet } from '../cash-flow-forecast/tallyExcelParser.js';

const normalizeHeader = (value) =>
  String(value ?? '')
    .replace(/\u00a0/g, ' ')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

const getAmountHeaderPriority = (value) => {
  const header = normalizeHeader(value);
  const words = new Set(header.split(' '));

  if (words.has('monthly') && words.has('amount')) return 0;
  if (words.has('expense') && words.has('amount')) return 1;
  if (words.has('amount')) return 2;
  if (words.has('debit') && words.has('amount')) return 3;
  if (words.has('debit') || words.has('dr')) return 4;
  if (words.has('balance')) return 5;
  return Number.POSITIVE_INFINITY;
};

const findHeader = (rows, startIndex, endIndex, matcher) => {
  for (let rowIndex = startIndex; rowIndex < endIndex; rowIndex += 1) {
    const row = rows[rowIndex] || [];
    const columnIndex = row.findIndex((cell) => matcher(normalizeHeader(cell)));
    if (columnIndex >= 0) return { rowIndex, columnIndex, row };
  }

  return null;
};

const findAmountHeader = (rows, startIndex, endIndex) => {
  const candidates = [];

  for (let rowIndex = startIndex; rowIndex < endIndex; rowIndex += 1) {
    const row = rows[rowIndex] || [];
    row.forEach((header, columnIndex) => {
      const priority = getAmountHeaderPriority(header);
      if (Number.isFinite(priority)) {
        candidates.push({ rowIndex, columnIndex, priority, row });
      }
    });
  }

  return candidates.sort(
    (first, second) =>
      first.priority - second.priority || first.rowIndex - second.rowIndex,
  )[0] || null;
};

export const parseOperationalExpenseWorksheet = (worksheet) => {
  const worksheetRows = XLSX.utils.sheet_to_json(worksheet, {
    header: 1,
    defval: '',
    raw: true,
    blankrows: false,
  });

  if (!worksheetRows.length) {
    throw new Error('The selected worksheet does not contain any data.');
  }

  const particularsHeader = findHeader(
    worksheetRows,
    0,
    worksheetRows.length,
    (header) => ['particulars', 'particular', 'description'].includes(header),
  );
  if (!particularsHeader) {
    throw new Error('Unable to find a Particulars or Description column.');
  }

  const amountSearchEnd = Math.min(
    worksheetRows.length,
    particularsHeader.rowIndex + 7,
  );
  const amountHeader = findAmountHeader(
    worksheetRows,
    particularsHeader.rowIndex,
    amountSearchEnd,
  );
  const headers = amountHeader?.row || particularsHeader.row;
  console.log(headers);

  const worksheetForParser = { ...worksheet };
  if (amountHeader) {
    const address = XLSX.utils.encode_cell({
      r: amountHeader.rowIndex,
      c: amountHeader.columnIndex,
    });
    worksheetForParser[address] = {
      ...worksheet[address],
      t: 's',
      v: 'Debit',
      w: 'Debit',
    };
  }

  return parseTallyWorksheet(worksheetForParser);
};