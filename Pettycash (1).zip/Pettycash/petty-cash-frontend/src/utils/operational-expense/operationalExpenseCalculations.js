export const normalizeOperationalExpenseLabel = (value) =>
  String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

export const isOperationalExpenseCategory = (category, name) =>
  normalizeOperationalExpenseLabel(category.categoryName) ===
  normalizeOperationalExpenseLabel(name);

export const sumOperationalExpenseGroup = (group, amounts) =>
  group.components.reduce(
    (total, component) =>
      total +
      (Number(amounts[String(component._id)]) || 0) +
      component.subComponents.reduce(
        (subTotal, subComponent) =>
          subTotal + (Number(amounts[String(subComponent._id)]) || 0),
        0,
      ),
    0,
  );

export const getOperationalExpenseHeadAmount = (component, amounts) =>
  (Number(amounts[String(component._id)]) || 0) +
  (component.subComponents || []).reduce(
    (total, subComponent) =>
      total + (Number(amounts[String(subComponent._id)]) || 0),
    0,
  );

export const calculateOperationalExpenseTotals = (components, amounts, mkplAmount) => {
  const subTotal = components.reduce(
    (total, component) =>
      total + getOperationalExpenseHeadAmount(component, amounts),
    0,
  );
  const markup = subTotal * 0.2;
  const operationalExpenseTotal = subTotal + markup;
  const mkpl = Number(mkplAmount);

  return {
    subTotal,
    markup,
    operationalExpenseTotal,
    mkplAmount: Number.isFinite(mkpl) ? mkpl : 0,
    crklinAmount: operationalExpenseTotal - (Number.isFinite(mkpl) ? mkpl : 0),
  };
};

export const validateOperationalExpenseReport = ({
  sourceMonth,
  amounts,
  clientAllocations = [],
  operationalExpenseTotal,
}) => {
  const errors = {};

  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(sourceMonth || ''))) {
    errors.sourceMonth = 'A valid report month is required.';
  }

  Object.entries(amounts).forEach(([id, amount]) => {
    if (amount === '' || !Number.isFinite(Number(amount))) {
      errors[`amount-${id}`] = 'Enter a valid number.';
    } else if (Number(amount) < 0) {
      errors[`amount-${id}`] = 'Amount cannot be negative.';
    }
  });

  const allocatedTotal = clientAllocations.reduce(
    (total, allocation) => {
      const amount = allocation?.amount;
      if (amount === '' || !Number.isFinite(Number(amount))) {
        errors[`allocation-${allocation?.clientId || 'unknown'}`] =
          'Enter a valid number.';
      } else if (Number(amount) < 0) {
        errors[`allocation-${allocation?.clientId || 'unknown'}`] =
          'Amount cannot be negative.';
      }
      return total + (Number(amount) || 0);
    },
    0,
  );

  if (allocatedTotal > operationalExpenseTotal) {
    errors.clientAllocations =
      'Client allocations cannot exceed the Operational Expense Total.';
  }

  return errors;
};
