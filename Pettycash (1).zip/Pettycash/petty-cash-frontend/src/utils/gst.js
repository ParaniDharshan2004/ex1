import { GST_RATE } from '../config/invoiceConfig.js';
import { roundCurrency } from './currency.js';

export const calculateGstAmounts = (value) => {
  const totalIncludingGst = roundCurrency(Math.max(0, Number(value) || 0));
  const gstAmount = roundCurrency(totalIncludingGst * GST_RATE / 100);
  const taxableAmount = roundCurrency(totalIncludingGst - gstAmount);
  return {
    taxableAmount,
    gstAmount,
    totalIncludingGst,
  };
};

export const amountIncludingGst = (value) => calculateGstAmounts(value).totalIncludingGst;
