export const INVOICE_ENABLED_CLIENT_CODES = ['CRKLINC'];
export const GST_RATE = 18;
export const isInvoiceEnabledClient = (client) => INVOICE_ENABLED_CLIENT_CODES.includes(String(client?.clientCode || '').trim().toUpperCase());
export const INVOICE_COMPANY = { companyName: '', legalName: 'Kamala Outsourcing Private Limited', addressLines: [], city: '', stateName: '', stateCode: '', postalCode: '', gstin: '', pan: '', email: '', phone: '', bankDetails: { accountName: '', bankName: '', accountNumber: '', ifscCode: '', branchName: '' } };
