import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Container,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Paper,
  Snackbar,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import * as XLSX from 'xlsx';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { useLocation, useNavigate } from 'react-router-dom';
import { useDataContext } from '../context/DataContext.jsx';
import { parseOperationalExpenseWorksheet } from '../utils/operational-expense/operationalExpenseExcel';
import {
  calculateOperationalExpenseTotals,
  getOperationalExpenseHeadAmount,
  isOperationalExpenseCategory,
  sumOperationalExpenseGroup,
  validateOperationalExpenseReport,
} from '../utils/operational-expense/operationalExpenseCalculations.js';
import {
  addOperationalExpenseFixedCost,
  deleteOperationalExpenseFixedCost,
  generateOperationalExpenseReport,
  getInvoiceAllocation,
  getOperationalExpenseReport,
  getOperationalExpenseReports,
  generateOperationalExpenseInvoice,
  updateOperationalExpenseFixedCost,
  updateOperationalExpenseReport,
  updateOperationalExpenseReportStatus,
} from '../utils/operational-expense/operationalExpenseApi.js';
import ConfirmDialog from '../components/common-components/ConfirmDialog.jsx';
import OperationalExpenseActions from '../components/operational-expense-components/OperationalExpenseActions.jsx';
import OperationalExpenseHeader from '../components/operational-expense-components/OperationalExpenseHeader.jsx';
import OperationalExpenseTable from '../components/operational-expense-components/OperationalExpenseTable.jsx';
import InvoiceAllocationDialog from '../components/operational-expense-components/InvoiceAllocationPage.jsx';
import {
  InvoiceLocationDialog,
  InvoiceDraftDialog,
} from '../components/operational-expense-components/InvoiceDialogs.jsx';

const getId = (value) =>
  value && typeof value === 'object' ? value._id : value;

const getReportId = (report) => report?._id || report?.id;

const getAllocationAmounts = (allocations = []) =>
  Object.fromEntries(
    allocations
      .map((allocation) => [
        String(getId(allocation.clientId) || ''),
        Number(allocation.amount) || 0,
      ])
      .filter(([clientId]) => clientId),
  );

const getSourcePeriod = (reportMonth) => {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(reportMonth || ''))) return '';
  return new Date(`${reportMonth}-01T00:00:00`).toLocaleString('en-IN', {
    month: 'long',
    year: 'numeric',
  });
};

const getCurrentReportMonth = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
};

const getAmountsFromReport = (report, components) => {
  const amounts = Object.fromEntries(
    components.flatMap((component) => [
      [String(component._id), 0],
      ...(component.subComponents || []).map((subComponent) => [
        String(subComponent._id),
        0,
      ]),
    ]),
  );

  (report.rows || []).forEach((row) => {
    const componentId = String(getId(row.componentId));
    const matchedLedgers = row.matchedTallyLedgers || [];
    if (!matchedLedgers.length) {
      if (componentId in amounts)
        amounts[componentId] = Number(row.amount) || 0;
      return;
    }

    matchedLedgers.forEach((ledger) => {
      const targetId =
        ledger.matchType === 'SUBCOMPONENT' && ledger.subComponentId
          ? String(getId(ledger.subComponentId))
          : componentId;
      if (targetId in amounts) {
        amounts[targetId] =
          (Number(amounts[targetId]) || 0) + (Number(ledger.amount) || 0);
      }
    });
  });

  return amounts;
};

export default function OperationalExpensesPage({
  exportReportId = '',
  onExportComplete,
}) {
  const location = useLocation();
  const navigate = useNavigate();
  const {
    components,
    subComponents,
    clients,
    getComponents,
    getSubComponents,
    getActiveClients,
    getFinancialCategories,
    getFinancialSubCategoriesByCategory,
  } = useDataContext();
  const safeComponents = Array.isArray(components) ? components : [];
  const safeSubComponents = Array.isArray(subComponents) ? subComponents : [];
  const safeClients = Array.isArray(clients) ? clients : [];
  const fileInputRef = useRef(null);
  const reportTableRef = useRef(null);
  const monthReportRequestRef = useRef(0);
  const [financialCategories, setFinancialCategories] = useState([]);
  const [financialSubCategories, setFinancialSubCategories] = useState([]);
  const [amounts, setAmounts] = useState({});
  const [reportRows, setReportRows] = useState([]);
  const [manualExpenseRows, setManualExpenseRows] = useState([]);
  const [expenseItemDialog, setExpenseItemDialog] = useState({
    open: false,
    mode: 'add',
    rowKey: '',
    section: 'DIRECT',
    itemName: '',
    amount: '0',
  });
  const [fixedCosts, setFixedCosts] = useState([]);
  const [fixedCostDialog, setFixedCostDialog] = useState({
    open: false,
    mode: 'add',
    fixedCostId: '',
    itemName: '',
    description: '',
    amount: '0',
  });
  const [fixedCostToDelete, setFixedCostToDelete] = useState(null);
  const [expenseToDelete, setExpenseToDelete] = useState(null);
  const [, setClientAllocationAmounts] = useState({});
  const [hasImportedReport, setHasImportedReport] = useState(false);
  const [sourcePeriod, setSourcePeriod] = useState(() =>
    getSourcePeriod(getCurrentReportMonth()),
  );
  const [sourceMonth, setSourceMonth] = useState(getCurrentReportMonth);
  const [fileName, setFileName] = useState('');
  const [loading, setLoading] = useState(true);
  const [loadingMonthReport, setLoadingMonthReport] = useState(false);
  const [importing, setImporting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [autoExportRequested, setAutoExportRequested] = useState(false);
  const [savingFixedCost, setSavingFixedCost] = useState(false);
  const [, setDraftSaved] = useState(false);
  const [, setHasUnsavedChanges] = useState(false);
  const [reportStatus, setReportStatus] = useState('DRAFT');
  const [reportId, setReportId] = useState('');
  const [showValidation, setShowValidation] = useState(false);
  const [expandedComponents, setExpandedComponents] = useState({});
  const [unmatchedRows, setUnmatchedRows] = useState([]);
  const [message, setMessage] = useState({
    open: false,
    text: '',
    severity: 'success',
  });
  const [invoiceDialogOpen, setInvoiceDialogOpen] = useState(false);
  const [invoiceAllocation, setInvoiceAllocation] = useState(null);
  const [invoiceAllocations, setInvoiceAllocations] = useState({});
  const [invoiceDialogClientId, setInvoiceDialogClientId] = useState('');
  const [, setInvoiceDataLoading] = useState(false);
  const [invoiceLocationDialogOpen, setInvoiceLocationDialogOpen] =
    useState(false);
  const [invoiceDraftLocation, setInvoiceDraftLocation] = useState(null);

  useEffect(() => {
    let mounted = true;

    const loadReportMasters = async () => {
      setLoading(true);
      try {
        const [
          componentsResult,
          subComponentsResult,
          categoryResult,
          clientsResult,
        ] = await Promise.allSettled([
          getComponents(),
          getSubComponents(),
          getFinancialCategories(),
          getActiveClients(),
        ]);

        if (componentsResult.status === 'rejected') {
          throw componentsResult.reason;
        }
        if (categoryResult.status === 'rejected') {
          throw categoryResult.reason;
        }
        if (clientsResult.status === 'rejected') {
          console.error(
            'Load Operational Expense Clients Error:',
            clientsResult.reason,
          );
        }

        const categories = Array.isArray(categoryResult.value.data)
          ? categoryResult.value.data
          : [];
        const subcategoryResults = await Promise.allSettled(
          categories.map((category) =>
            getFinancialSubCategoriesByCategory(category._id),
          ),
        );
        const subcategoryResponses = subcategoryResults
          .filter((result) => result.status === 'fulfilled')
          .map((result) => result.value);
        const failedSubcategory = subcategoryResults.find(
          (result) => result.status === 'rejected',
        );

        if (!mounted) return;

        setFinancialCategories(categories);
        setFinancialSubCategories(
          subcategoryResponses.flatMap(
            (response) => response.data?.financialSubCategories || [],
          ),
        );

        if (subComponentsResult.status === 'rejected' || failedSubcategory) {
          const failedRequest =
            failedSubcategory?.reason || subComponentsResult.reason;
          console.error('Operational Expense Optional Master Data Error:', {
            url: failedRequest?.config?.url,
            status: failedRequest?.response?.status,
            message:
              failedRequest?.response?.data?.message || failedRequest?.message,
          });
          setMessage({
            open: true,
            text: `Some subcomponent data could not be loaded${failedRequest?.config?.url ? ` from ${failedRequest.config.url}` : ''}${failedRequest?.response?.status ? ` (HTTP ${failedRequest.response.status})` : ''}. Head component expenses remain available.`,
            severity: 'warning',
          });
        }
      } catch (error) {
        console.error('Load Operational Expense Masters Error:', error);
        if (mounted) {
          setMessage({
            open: true,
            text:
              error.response?.data?.message ||
              `Unable to load Operational Expense master data${error.config?.url ? ` from ${error.config.url}` : ''}${error.response?.status ? ` (HTTP ${error.response.status})` : ''}.`,
            severity: 'error',
          });
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };

    loadReportMasters();
    return () => {
      mounted = false;
    };
    // Data context methods are recreated on render; load master data once per page mount.
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const operationalComponents = useMemo(
    () =>
      safeComponents.filter(
        (component) =>
          component.isOperationalExpense === true && component.isActive,
      ),
    [safeComponents],
  );

  // To listdown all the components with value 0
  const categoriesWithComponents = useMemo(() => {
    const sortedComponents = [...operationalComponents].sort(
      (first, second) => {
        const firstSubcategory = financialSubCategories.find(
          (subcategory) =>
            String(subcategory._id) ===
            String(getId(first.financialSubCategoryId)),
        );
        const secondSubcategory = financialSubCategories.find(
          (subcategory) =>
            String(subcategory._id) ===
            String(getId(second.financialSubCategoryId)),
        );

        return (
          (Number(firstSubcategory?.displayOrder) || 0) -
            (Number(secondSubcategory?.displayOrder) || 0) ||
          (Number(first.displayOrder) || 0) -
            (Number(second.displayOrder) || 0) ||
          first.componentName.localeCompare(second.componentName)
        );
      },
    );

    const expenseSubComponents = safeSubComponents.filter(
      (subComponent) =>
        subComponent.isOperationalExpense === true && subComponent.isActive,
    );
    const componentsWithSubComponents = sortedComponents.map((component) => ({
      ...component,
      subComponents: expenseSubComponents
        .filter(
          (subComponent) =>
            String(getId(subComponent.componentId)) === String(component._id),
        )
        .sort(
          (first, second) =>
            (Number(first.displayOrder) || 0) -
              (Number(second.displayOrder) || 0) ||
            first.subComponentName.localeCompare(second.subComponentName),
        ),
    }));
    const groups = financialCategories.map((category) => ({
      ...category,
      components: componentsWithSubComponents.filter(
        (component) =>
          String(getId(component.financialCategoryId)) === String(category._id),
      ),
    }));

    const categorizedComponentIds = new Set(
      groups.flatMap((group) =>
        group.components.map((component) => String(component._id)),
      ),
    );
    const ungroupedComponents = componentsWithSubComponents.filter(
      (component) => !categorizedComponentIds.has(String(component._id)),
    );

    if (ungroupedComponents.length) {
      groups.push({
        _id: 'uncategorized',
        categoryName: 'Uncategorized',
        components: ungroupedComponents,
      });
    }

    return groups.filter((group) => group.components.length > 0);
  }, [
    financialCategories,
    financialSubCategories,
    operationalComponents,
    safeSubComponents,
  ]);

  // To listdown only the components in Tally with value
  const visibleReportComponentIds = useMemo(() => {
    return new Set(
      reportRows
        .filter(
          (row) =>
            row.rowSource !== 'REPORT_ONLY' &&
            row.componentId &&
            (row.hasTallyExpense === true ||
              row.matchStatus === 'HEAD_COMPONENT_MATCHED' ||
              row.matchStatus === 'CALCULATED_FROM_SUBCOMPONENTS'),
        )
        .map((row) => String(getId(row.componentId)))
        .filter(Boolean),
    );
  }, [reportRows]);

  // To listdown only the components in Tally with value
  const visibleCategoriesWithComponents = useMemo(() => {
    if (!hasImportedReport || visibleReportComponentIds.size === 0) {
      return [];
    }

    return categoriesWithComponents
      .map((group) => ({
        ...group,

        components: group.components.filter((component) =>
          visibleReportComponentIds.has(String(component._id)),
        ),
      }))
      .filter((group) => group.components.length > 0);
  }, [categoriesWithComponents, hasImportedReport, visibleReportComponentIds]);

  const directGroups = useMemo(
    () =>
      visibleCategoriesWithComponents.filter((group) =>
        isOperationalExpenseCategory(group, 'Direct Cost'),
      ),
    [visibleCategoriesWithComponents],
  );

  const indirectGroups = useMemo(
    () =>
      visibleCategoriesWithComponents.filter((group) =>
        isOperationalExpenseCategory(group, 'Indirect Cost'),
      ),
    [visibleCategoriesWithComponents],
  );

  const otherGroups = useMemo(
    () =>
      visibleCategoriesWithComponents.filter(
        (group) =>
          !isOperationalExpenseCategory(group, 'Direct Cost') &&
          !isOperationalExpenseCategory(group, 'Indirect Cost'),
      ),
    [visibleCategoriesWithComponents],
  );

  const activeClients = useMemo(
    () => safeClients.filter((client) => client.isActive === true),
    [safeClients],
  );
  const balanceClientId = String(
    activeClients.find((client) =>
      `${client.clientCode || ''} ${client.clientName || ''}`
        .toLowerCase()
        .includes('crkl'),
    )?._id || '',
  );
  const totalDirectCost = directGroups.reduce(
    (total, group) => total + sumOperationalExpenseGroup(group, amounts),
    0,
  );
  const totalIndirectCost = indirectGroups.reduce(
    (total, group) => total + sumOperationalExpenseGroup(group, amounts),
    0,
  );
  const allHeadComponents = useMemo(
    () => visibleCategoriesWithComponents.flatMap((group) => group.components),
    [visibleCategoriesWithComponents],
  );
  const allOperationalMasterComponents = useMemo(
    () => categoriesWithComponents.flatMap((group) => group.components),
    [categoriesWithComponents],
  );
  const fixedCostTotal = fixedCosts.reduce(
    (total, fixedCost) => total + (Number(fixedCost.amount) || 0),
    0,
  );
  const manualDirectCost = manualExpenseRows
    .filter((row) => row.section === 'DIRECT')
    .reduce((total, row) => total + (Number(row.amount) || 0), 0);
  const manualIndirectCost = manualExpenseRows
    .filter((row) => row.section === 'INDIRECT')
    .reduce((total, row) => total + (Number(row.amount) || 0), 0);
  const totalDirectCostWithManual = totalDirectCost + manualDirectCost;
  const totalIndirectCostWithManual = totalIndirectCost + manualIndirectCost;
  const baseTotals = calculateOperationalExpenseTotals(
    allHeadComponents,
    amounts,
  );
  const subTotal = baseTotals.subTotal + manualDirectCost + manualIndirectCost;
  const markup = subTotal * 0.2;
  const operationalExpenseTotal = subTotal + markup + fixedCostTotal;

  const clientAllocationRows = useMemo(() => {
    const savedTotals = activeClients.reduce(
      (total, client) =>
        total +
        (Number(invoiceAllocations[String(client._id)]?.clientTotalAmount) ||
          0),
      0,
    );
    return activeClients.map((client) => {
      const clientId = String(client._id);
      const saved = invoiceAllocations[clientId] || null;
      const otherSavedTotal =
        savedTotals - (Number(saved?.clientTotalAmount) || 0);
      const availableAmount = Number.isFinite(
        Number(saved?.availableClientBalance),
      )
        ? Number(saved.availableClientBalance)
        : Math.max(0, operationalExpenseTotal - otherSavedTotal);
      return {
        clientId: client._id,
        clientCode: client.clientCode || '',
        clientName: client.clientName || '',
        amount: Number(saved?.clientTotalAmount) || 0,
        availableAmount,
        totalAllocated: (saved?.locationAllocations || []).reduce(
          (total, item) => total + (Number(item.amount) || 0),
          0,
        ),
        savedInvoiceAllocation: saved,
        allocationStatus: saved?.allocationStatus || '',
        locationAllocations: saved?.locationAllocations || [],
      };
    });
  }, [activeClients, invoiceAllocations, operationalExpenseTotal]);

  const amountErrors = validateOperationalExpenseReport({
    sourceMonth,
    amounts,
    clientAllocations: clientAllocationRows,
    operationalExpenseTotal,
  });

  const clientAllocationIds = useMemo(
    () => clientAllocationRows.map((row) => String(row.clientId)).join(','),
    [clientAllocationRows],
  );

  useEffect(() => {
    if (!reportId || !clientAllocationIds) {
      return undefined;
    }

    let active = true;
    const clientIds = clientAllocationIds.split(',');
    Promise.resolve()
      .then(() => {
        if (!active) return null;
        setInvoiceDataLoading(true);
        return Promise.all(
          clientIds.map((clientId) =>
            getInvoiceAllocation(reportId, clientId)
              .then((response) => [clientId, response.data?.data || null])
              .catch((error) =>
                error.response?.status === 404
                  ? [clientId, null]
                  : Promise.reject(error),
              ),
          ),
        );
      })
      .then((entries) => {
        if (active && entries) {
          setInvoiceAllocations(Object.fromEntries(entries));
        }
      })
      .catch((error) => {
        if (active) {
          setMessage({
            open: true,
            text:
              error.response?.data?.message ||
              'Unable to load client allocations.',
            severity: 'error',
          });
        }
      })
      .finally(() => {
        if (active) setInvoiceDataLoading(false);
      });

    return () => {
      active = false;
    };
  }, [clientAllocationIds, reportId]);

  const handleSourceMonthChange = (value) => {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(value)) return;
    setSourceMonth(value);
    setSourcePeriod(getSourcePeriod(value));
  };

  const handleClientAllocationChange = (clientId, value) => {
    setClientAllocationAmounts((current) => ({
      ...current,
      [String(clientId)]: value,
    }));
    setHasUnsavedChanges(true);
  };

  useEffect(() => {
    const requestedReportId =
      exportReportId ||
      location.state?.operationalExpenseReportId ||
      new URLSearchParams(location.search).get('reportId');
    if (!requestedReportId || !categoriesWithComponents.length) return;

    let active = true;
    const loadReport = async () => {
      try {
        const response = await getOperationalExpenseReport(requestedReportId);
        if (!active) return;
        const report = response.data?.data;
        if (!report) throw new Error('The report response was empty.');
        const loadedReportId = String(getReportId(report));
        const loadedAmounts = getAmountsFromReport(
          report,
          allOperationalMasterComponents,
        );
        setReportRows(report.rows || []);
        setManualExpenseRows(
          (report.rows || [])
            .filter((row) => row.rowSource === 'REPORT_ONLY')
            .map((row) => ({
              _id: row._id,
              clientKey: String(row._id),
              section: String(row.financialCategoryName || '')
                .toLowerCase()
                .includes('indirect')
                ? 'INDIRECT'
                : 'DIRECT',
              itemName: row.componentName,
              amount: Number(row.amount) || 0,
              financialCategoryId: getId(row.financialCategoryId),
              financialCategoryCode: row.financialCategoryCode || '',
              financialCategoryName: row.financialCategoryName || '',
              displayOrder: row.displayOrder || 0,
            })),
        );
        setFixedCosts(report.fixedCosts || []);
        setAmounts(loadedAmounts);
        setClientAllocationAmounts(
          getAllocationAmounts(report.allocations || []),
        );
        setSourceMonth(report.reportMonth || '');
        setSourcePeriod(getSourcePeriod(report.reportMonth));
        setFileName(
          report.reportName ||
            report.reportCode ||
            'Operational Expense Report',
        );
        setReportId(loadedReportId);
        setReportStatus(report.status || 'DRAFT');
        setDraftSaved(true);
        setHasUnsavedChanges(false);
        setHasImportedReport(true);
        if (exportReportId || location.state?.exportAfterLoad) {
          setAutoExportRequested(true);
        }
        setUnmatchedRows(report.unmatchedTallyRows || []);
      } catch (error) {
        if (active) {
          setMessage({
            open: true,
            text:
              error.response?.data?.message ||
              'Unable to load the selected Operational Expense report.',
            severity: 'error',
          });
        }
      }
    };

    loadReport();
    return () => {
      active = false;
    };
  }, [
    activeClients,
    allOperationalMasterComponents,
    categoriesWithComponents.length,
    exportReportId,
    location.search,
    location.state,
  ]);

  useEffect(() => {
    const requestedReportId =
      exportReportId ||
      location.state?.operationalExpenseReportId ||
      new URLSearchParams(location.search).get('reportId');
    if (requestedReportId || !sourceMonth || !categoriesWithComponents.length) {
      return;
    }

    let active = true;
    const requestId = ++monthReportRequestRef.current;
    queueMicrotask(() => {
      if (active && requestId === monthReportRequestRef.current) {
        setLoadingMonthReport(true);
      }
    });

    const loadMonthReport = async () => {
      try {
        const reportsResponse = await getOperationalExpenseReports({
          reportMonth: sourceMonth,
        });
        if (!active) return;

        const matchingReport = (reportsResponse.data?.data || []).find(
          (report) => report.reportMonth === sourceMonth,
        );
        if (matchingReport) {
          const response = await getOperationalExpenseReport(
            getReportId(matchingReport),
          );
          if (!active) return;
          const report = response.data?.data;
          if (!report) throw new Error('The report response was empty.');

          setReportRows(report.rows || []);
          setManualExpenseRows(
            (report.rows || [])
              .filter((row) => row.rowSource === 'REPORT_ONLY')
              .map((row) => ({
                _id: row._id,
                clientKey: String(row._id),
                section: String(row.financialCategoryName || '')
                  .toLowerCase()
                  .includes('indirect')
                  ? 'INDIRECT'
                  : 'DIRECT',
                itemName: row.componentName,
                amount: Number(row.amount) || 0,
                financialCategoryId: getId(row.financialCategoryId),
                financialCategoryCode: row.financialCategoryCode || '',
                financialCategoryName: row.financialCategoryName || '',
                displayOrder: row.displayOrder || 0,
              })),
          );
          setFixedCosts(report.fixedCosts || []);
          setAmounts(
            getAmountsFromReport(report, allOperationalMasterComponents),
          );
          setClientAllocationAmounts(
            getAllocationAmounts(report.allocations || []),
          );
          setFileName(
            report.reportName ||
              report.reportCode ||
              'Operational Expense Report',
          );
          setReportId(String(getReportId(report)));
          setReportStatus(report.status || 'DRAFT');
          setDraftSaved(true);
          setHasUnsavedChanges(false);
          setUnmatchedRows(report.unmatchedTallyRows || []);
          setHasImportedReport(true);
        } else {
          setReportRows([]);
          setManualExpenseRows([]);
          setFixedCosts([]);
          setAmounts({});
          setClientAllocationAmounts({});
          setFileName('');
          setReportId('');
          setReportStatus('DRAFT');
          setDraftSaved(false);
          setHasUnsavedChanges(false);
          setUnmatchedRows([]);
          setShowValidation(false);
          setHasImportedReport(true);
        }
        setSourcePeriod(getSourcePeriod(sourceMonth));
      } catch (error) {
        if (active) {
          setMessage({
            open: true,
            text:
              error.response?.data?.message ||
              'Unable to load Operational Expense data for the selected month.',
            severity: 'error',
          });
        }
      } finally {
        if (active && requestId === monthReportRequestRef.current) {
          setLoadingMonthReport(false);
        }
      }
    };

    loadMonthReport();
    return () => {
      active = false;
    };
  }, [
    activeClients,
    allOperationalMasterComponents,
    categoriesWithComponents.length,
    exportReportId,
    location.search,
    location.state,
    sourceMonth,
  ]);

  const handleAmountChange = (id, value) => {
    setAmounts((current) => ({ ...current, [String(id)]: value }));
    setHasUnsavedChanges(true);
  };

  const openAddReportOnlyItem = (section) => {
    setExpenseItemDialog({
      open: true,
      mode: 'add',
      rowKey: '',
      section,
      itemName: '',
      amount: '0',
    });
  };

  const openEditReportOnlyItem = (row) => {
    setExpenseItemDialog({
      open: true,
      mode: 'edit',
      rowKey: row.clientKey || String(row._id),
      section: row.section,
      itemName: row.itemName,
      amount: String(row.amount ?? 0),
    });
  };

  const saveReportOnlyItem = () => {
    const amount = Number(expenseItemDialog.amount);
    if (
      !expenseItemDialog.itemName.trim() ||
      expenseItemDialog.amount === '' ||
      !Number.isFinite(amount) ||
      amount < 0
    ) {
      setMessage({
        open: true,
        text: 'Enter an item name and a valid non-negative amount.',
        severity: 'error',
      });
      return;
    }

    const category =
      expenseItemDialog.section === 'INDIRECT'
        ? indirectGroups[0]
        : directGroups[0];
    const nextRow = {
      clientKey:
        expenseItemDialog.rowKey ||
        `manual-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      section: expenseItemDialog.section,
      itemName: expenseItemDialog.itemName.trim(),
      amount,
      financialCategoryId: getId(category?._id) || null,
      financialCategoryCode: category?.categoryCode || '',
      financialCategoryName:
        category?.categoryName ||
        (expenseItemDialog.section === 'INDIRECT'
          ? 'Indirect Cost'
          : 'Direct Cost'),
      displayOrder: manualExpenseRows.length + 1,
    };

    setManualExpenseRows((current) =>
      expenseItemDialog.mode === 'add'
        ? [...current, nextRow]
        : current.map((row) =>
            String(row.clientKey || row._id) ===
            String(expenseItemDialog.rowKey)
              ? { ...row, ...nextRow }
              : row,
          ),
    );
    setHasUnsavedChanges(true);
    setExpenseItemDialog((current) => ({ ...current, open: false }));
  };

  const requestDeleteExpenseAmount = (ids, label) => {
    setExpenseToDelete({
      ids: (Array.isArray(ids) ? ids : [ids]).map(String),
      label,
    });
  };

  const requestDeleteReportOnlyItem = (row) => {
    setExpenseToDelete({
      manualRowKey: row.clientKey || String(row._id),
      ids: [],
      label: row.itemName,
    });
  };

  const confirmDeleteExpenseAmount = () => {
    if (!expenseToDelete) return;
    if (expenseToDelete.manualRowKey) {
      setManualExpenseRows((current) =>
        current.filter(
          (row) =>
            String(row.clientKey || row._id) !==
            String(expenseToDelete.manualRowKey),
        ),
      );
    } else {
      setAmounts((current) => ({
        ...current,
        ...Object.fromEntries(expenseToDelete.ids.map((id) => [id, 0])),
      }));
    }
    setHasUnsavedChanges(true);
    setMessage({
      open: true,
      text: `${expenseToDelete.label} amount removed. Save the report to apply it.`,
      severity: 'success',
    });
    setExpenseToDelete(null);
  };

  const openAddFixedCost = () =>
    setFixedCostDialog({
      open: true,
      mode: 'add',
      fixedCostId: '',
      itemName: '',
      description: '',
      amount: '0',
    });

  const openEditFixedCost = (fixedCostId) => {
    const fixedCost = fixedCosts.find(
      (item) => String(item._id) === String(fixedCostId),
    );
    if (!fixedCost) {
      setMessage({
        open: true,
        text: 'Unable to find this fixed cost in the selected report.',
        severity: 'error',
      });
      return;
    }

    setFixedCostDialog({
      open: true,
      mode: 'edit',
      fixedCostId,
      itemName: fixedCost.itemName || '',
      description: fixedCost.description || '',
      amount: String(fixedCost.amount ?? 0),
    });
  };

  const handleFixedCostAmountChange = (fixedCostId, value) => {
    setFixedCosts((current) =>
      current.map((fixedCost) =>
        String(fixedCost._id) === String(fixedCostId)
          ? { ...fixedCost, amount: value }
          : fixedCost,
      ),
    );
  };

  const handleSaveFixedCost = async () => {
    const amount = Number(fixedCostDialog.amount);
    if (
      !fixedCostDialog.itemName.trim() ||
      !Number.isFinite(amount) ||
      amount < 0
    ) {
      setMessage({
        open: true,
        text: 'Enter an item name and a non-negative amount for the fixed cost.',
        severity: 'error',
      });
      return;
    }

    const payload = {
      itemName: fixedCostDialog.itemName.trim(),
      description: fixedCostDialog.description,
      amount,
    };
    try {
      setSavingFixedCost(true);
      const response =
        fixedCostDialog.mode === 'add'
          ? await addOperationalExpenseFixedCost(reportId, payload)
          : await updateOperationalExpenseFixedCost(
              reportId,
              fixedCostDialog.fixedCostId,
              payload,
            );
      const savedFixedCost = response.data?.data;
      setFixedCosts((current) =>
        fixedCostDialog.mode === 'add'
          ? [...current, savedFixedCost]
          : current.map((fixedCost) =>
              String(fixedCost._id) === String(fixedCostDialog.fixedCostId)
                ? savedFixedCost
                : fixedCost,
            ),
      );
      setHasUnsavedChanges(true);
      setFixedCostDialog((current) => ({ ...current, open: false }));
      setMessage({
        open: true,
        text:
          fixedCostDialog.mode === 'add'
            ? 'Fixed cost added.'
            : 'Fixed cost updated.',
        severity: 'success',
      });
    } catch (error) {
      setMessage({
        open: true,
        text: error.response?.data?.message || 'Unable to save the fixed cost.',
        severity: 'error',
      });
    } finally {
      setSavingFixedCost(false);
    }
  };

  const handleDeleteFixedCost = async () => {
    if (!fixedCostToDelete || savingFixedCost) return;
    try {
      setSavingFixedCost(true);
      await deleteOperationalExpenseFixedCost(reportId, fixedCostToDelete._id);
      setFixedCosts((current) =>
        current.filter(
          (fixedCost) =>
            String(fixedCost._id) !== String(fixedCostToDelete._id),
        ),
      );
      setHasUnsavedChanges(true);
      setFixedCostToDelete(null);
      setMessage({
        open: true,
        text: 'Fixed cost deleted.',
        severity: 'success',
      });
    } catch (error) {
      setMessage({
        open: true,
        text:
          error.response?.data?.message || 'Unable to delete the fixed cost.',
        severity: 'error',
      });
    } finally {
      setSavingFixedCost(false);
    }
  };

  const exportOperationalExpensePdf = async () => {
    const reportTable = reportTableRef.current;
    if (!reportTable) {
      setMessage({
        open: true,
        text: 'Operational Expense report content is not available for export.',
        severity: 'error',
      });
      return;
    }

    try {
      setExporting(true);
      if (document.fonts?.ready) await document.fonts.ready;

      const canvas = await html2canvas(reportTable, {
        scale: 2,
        useCORS: true,
        allowTaint: false,
        backgroundColor: '#ffffff',
        logging: false,
        width: reportTable.scrollWidth,
        height: reportTable.scrollHeight,
        windowWidth: Math.max(window.innerWidth, reportTable.scrollWidth),
        windowHeight: window.innerHeight,
        scrollX: 0,
        scrollY: -window.scrollY,
        onclone: (clonedDocument) => {
          const clonedRoot = clonedDocument.querySelector(
            '[data-operational-expense-report="true"]',
          );
          if (!clonedRoot) return;

          clonedRoot.style.overflow = 'visible';
          clonedRoot.querySelectorAll('table').forEach((clonedTable) => {
            clonedTable.style.width = '100%';
            clonedTable.style.minWidth = '0';
            clonedTable.style.tableLayout = 'fixed';
            const actionColumn = clonedTable.querySelector(
              'colgroup col:last-child',
            );
            if (actionColumn) actionColumn.remove();
            const columnWidths = ['18%', '56%', '20%'];
            clonedTable
              .querySelectorAll('colgroup col')
              .forEach((column, index) => {
                column.style.width = columnWidths[index] || '';
              });
            clonedTable.querySelectorAll('tr').forEach((row) => {
              const lastCell = row.cells[row.cells.length - 1];
              Array.from(row.cells).forEach((cell) => {
                if (cell.colSpan === 4) cell.colSpan = 3;
              });
              if (row.cells.length > 1 && lastCell?.colSpan === 1) {
                lastCell.remove();
              } else if (lastCell) {
                lastCell.style.paddingRight = '16px';
                lastCell.style.whiteSpace = 'nowrap';
              }
            });
          });

          clonedRoot.querySelectorAll('button').forEach((button) => {
            button.style.display = 'none';
          });
          clonedRoot.querySelectorAll('input').forEach((input) => {
            const field = input.closest('.MuiFormControl-root');
            if (!field) return;
            const value = clonedDocument.createElement('span');
            value.textContent = input.value;
            value.style.display = 'block';
            value.style.textAlign = 'right';
            value.style.padding = '4px 8px';
            field.replaceWith(value);
          });
        },
      });
      if (!canvas.width || !canvas.height) {
        throw new Error('Operational Expense report could not be captured.');
      }

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true,
      });
      const margin = 6;
      const printableWidth = pdf.internal.pageSize.getWidth() - margin * 2;
      const printableHeight = pdf.internal.pageSize.getHeight() - margin * 2;
      const sliceHeight = Math.floor(
        (canvas.width * printableHeight) / printableWidth,
      );

      for (
        let pageIndex = 0, sourceY = 0;
        sourceY < canvas.height;
        pageIndex += 1
      ) {
        const currentSliceHeight = Math.min(
          sliceHeight,
          canvas.height - sourceY,
        );
        const pageCanvas = document.createElement('canvas');
        pageCanvas.width = canvas.width;
        pageCanvas.height = currentSliceHeight;
        const pageContext = pageCanvas.getContext('2d');
        if (!pageContext) throw new Error('Unable to prepare the PDF page.');
        pageContext.drawImage(
          canvas,
          0,
          sourceY,
          canvas.width,
          currentSliceHeight,
          0,
          0,
          canvas.width,
          currentSliceHeight,
        );

        if (pageIndex > 0) pdf.addPage('a4', 'portrait');
        const imageHeight =
          (currentSliceHeight * printableWidth) / canvas.width;
        pdf.addImage(
          pageCanvas.toDataURL('image/jpeg', 0.96),
          'JPEG',
          margin,
          margin,
          printableWidth,
          imageHeight,
          undefined,
          'FAST',
        );
        sourceY += currentSliceHeight;
      }

      pdf.save(`Operational-Expense-Report-${sourceMonth}.pdf`);
      setMessage({
        open: true,
        text: 'Operational Expense report exported successfully.',
        severity: 'success',
      });
    } catch (error) {
      setMessage({
        open: true,
        text:
          error.message || 'Unable to export the Operational Expense report.',
        severity: 'error',
      });
    } finally {
      setExporting(false);
    }
  };

  useEffect(() => {
    if (!autoExportRequested || !reportId || loading || loadingMonthReport) {
      return undefined;
    }

    const timer = window.setTimeout(async () => {
      await exportOperationalExpensePdf();
      setAutoExportRequested(false);
    }, 0);

    return () => {
      window.clearTimeout(timer);
      onExportComplete?.();
    };
    // The export function intentionally uses the current rendered report table.
    }, [autoExportRequested, reportId, loading, loadingMonthReport, onExportComplete]);

  const handleSaveReport = async (status) => {
    const nextStatus = reportStatus === 'FINALIZED' ? 'FINALIZED' : status;
    setShowValidation(true);
    if (!sourceMonth) {
      setMessage({
        open: true,
        text: 'Select a month before saving the report.',
        severity: 'error',
      });
      return;
    }

    if (Object.keys(amountErrors).length) {
      setMessage({
        open: true,
        text: 'Correct the highlighted values before saving this report.',
        severity: 'error',
      });
      return;
    }

    setSaving(true);
    try {
      const rows = allHeadComponents
        .map((component) => {
          const componentId = String(component._id);
          const existingRow = reportRows.find(
            (row) => String(getId(row.componentId)) === componentId,
          );
          const existingLedgers = existingRow?.matchedTallyLedgers || [];
          const directAmount = Number(amounts[componentId]) || 0;
          const subComponentAmounts = component.subComponents.map(
            (subComponent) => ({
              subComponent,
              amount: Number(amounts[String(subComponent._id)]) || 0,
            }),
          );

          const resizeLedgerAmounts = (ledgers, amount, defaults) => {
            if (amount <= 0) return [];
            if (!ledgers.length) return [{ ...defaults, amount }];

            const oldTotal = ledgers.reduce(
              (total, ledger) => total + (Number(ledger.amount) || 0),
              0,
            );
            let distributedAmount = 0;

            return ledgers.map((ledger, index) => {
              const nextAmount =
                index === ledgers.length - 1
                  ? amount - distributedAmount
                  : oldTotal > 0
                    ? (amount * (Number(ledger.amount) || 0)) / oldTotal
                    : amount / ledgers.length;
              distributedAmount += nextAmount;
              return { ...ledger, amount: nextAmount };
            });
          };

          const directLedgers = resizeLedgerAmounts(
            existingLedgers.filter(
              (ledger) => ledger.matchType === 'HEAD_COMPONENT',
            ),
            directAmount,
            {
              tallyLedgerName: component.componentName,
              excelRowNumber: null,
              matchType: 'HEAD_COMPONENT',
            },
          );
          const subComponentLedgers = subComponentAmounts.flatMap(
            ({ subComponent, amount }) => {
              const subComponentId = String(subComponent._id);
              const existing = existingLedgers.filter(
                (ledger) =>
                  ledger.matchType === 'SUBCOMPONENT' &&
                  String(getId(ledger.subComponentId)) === subComponentId,
              );
              return resizeLedgerAmounts(existing, amount, {
                tallyLedgerName: subComponent.subComponentName,
                excelRowNumber: null,
                matchType: 'SUBCOMPONENT',
                subComponentId,
                subComponentName: subComponent.subComponentName,
              });
            },
          );
          const matchedTallyLedgers = [
            ...directLedgers,
            ...subComponentLedgers,
          ];
          const amount = getOperationalExpenseHeadAmount(component, amounts);
          const hasDirectAmount = directAmount > 0;

          return {
            componentId,
            componentCode: component.componentCode || '',
            componentName: component.componentName,
            rowSource: existingRow?.rowSource || 'TALLY_IMPORT',
            financialCategoryId: getId(component.financialCategoryId) || null,
            financialCategoryCode:
              component.financialCategoryId?.categoryCode || '',
            financialCategoryName:
              financialCategories.find(
                (category) =>
                  String(category._id) ===
                  String(getId(component.financialCategoryId)),
              )?.categoryName || '',
            sourceAmount: Number(existingRow?.sourceAmount ?? amount) || 0,
            amount,
            matchStatus: hasDirectAmount
              ? 'HEAD_COMPONENT_MATCHED'
              : subComponentLedgers.length
                ? 'CALCULATED_FROM_SUBCOMPONENTS'
                : 'NOT_PRESENT_IN_TALLY',
            hasTallyExpense: amount > 0,
            matchedTallyLedgers,
            isManuallyAdded: Boolean(existingRow?.isManuallyAdded),
            isEdited: true,
            displayOrder: Number(component.displayOrder) || 0,
          };
        })
        .filter(
          (row) =>
            row.rowSource !== 'REPORT_ONLY' ||
            row.hasTallyExpense === true ||
            row.amount > 0,
        );
      const manualRows = manualExpenseRows.map((row, index) => ({
        componentId: null,
        componentCode: '',
        componentName: row.itemName,
        rowSource: 'REPORT_ONLY',
        financialCategoryId: row.financialCategoryId || null,
        financialCategoryCode: row.financialCategoryCode || '',
        financialCategoryName: row.financialCategoryName,
        sourceAmount: 0,
        amount: Number(row.amount) || 0,
        matchStatus: 'MANUALLY_ADDED',
        hasTallyExpense: false,
        matchedTallyLedgers: [],
        isManuallyAdded: true,
        isEdited: true,
        displayOrder: 10000 + index,
      }));
      rows.push(...manualRows);

      if (nextStatus === 'FINALIZED' && !balanceClientId) {
        throw new Error(
          'Add or activate the CRKL client before finalizing the report.',
        );
      }
      const allocations = clientAllocationRows.map((allocation) => ({
        clientId: allocation.clientId,
        clientCode: allocation.clientCode,
        clientName: allocation.clientName,
        allocationPercentage:
          operationalExpenseTotal > 0
            ? (Number(allocation.amount) / operationalExpenseTotal) * 100
            : 0,
        amount: Number(allocation.amount) || 0,
      }));

      const payload = {
        reportName: `Operational Expense Report ${sourceMonth}`,
        reportDate: new Date(`${sourceMonth}-01T00:00:00.000Z`).toISOString(),
        currencyCode: 'INR',
        rows,
        unmatchedTallyRows: unmatchedRows,
        markup: {
          enabled: true,
          percentage: 20,
          baseType: 'SUBTOTAL',
          baseAmount: subTotal,
          amount: markup,
        },
        totals: {
          totalDirectCost: totalDirectCostWithManual,
          totalIndirectCost: totalIndirectCostWithManual,
          directorRemunerationTotal: 0,
        },
        fixedCosts,
        allocations,
      };

      let savedReportId = reportId;
      if (!savedReportId) {
        try {
          const generatedResponse = await generateOperationalExpenseReport({
            reportMonth: sourceMonth,
            reportName: payload.reportName,
            reportCode: `OE-${sourceMonth}`,
            reportDate: payload.reportDate,
            currencyCode: payload.currencyCode,
            sourceType: 'MANUAL',
            tallyRows: [],
            fixedCosts,
          });
          savedReportId = String(getReportId(generatedResponse.data?.data));
        } catch (error) {
          if (error.response?.status !== 409) throw error;
          const reportsResponse = await getOperationalExpenseReports({
            reportMonth: sourceMonth,
          });
          const existingReport = (reportsResponse.data?.data || []).find(
            (report) => report.reportMonth === sourceMonth,
          );
          savedReportId = String(getReportId(existingReport) || '');
          if (!savedReportId) throw error;
        }
        if (!savedReportId) {
          throw new Error(
            'The manually created report did not include a report ID.',
          );
        }
        setReportId(savedReportId);
      }

      const response = await updateOperationalExpenseReport(
        savedReportId,
        payload,
      );
      const savedReport = response.data?.data;
      setReportRows(savedReport?.rows || rows);
      if (nextStatus === 'FINALIZED' && reportStatus !== 'FINALIZED') {
        await updateOperationalExpenseReportStatus(savedReportId, 'FINALIZED');
      }
      setDraftSaved(true);
      setHasUnsavedChanges(false);
      setReportStatus(nextStatus);
      navigate('/operational-expense-reports', {
        replace: true,
        state: { operationalExpenseReportId: savedReportId },
      });
      setMessage({
        open: true,
        text:
          nextStatus === 'FINALIZED'
            ? 'Finalized Operational Expense report changes saved.'
            : 'Operational Expense draft saved.',
        severity: 'success',
      });
    } catch (error) {
      setMessage({
        open: true,
        text:
          error.response?.data?.message ||
          error.message ||
          'Unable to save the Operational Expense report.',
        severity: 'error',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleTallyImport = async (event) => {
    const selectedFile = event.target.files?.[0];
    event.target.value = '';
    if (!selectedFile) return;

    try {
      setImporting(true);
      const extension = selectedFile.name.split('.').pop()?.toLowerCase();
      if (!['xlsx', 'xls'].includes(extension)) {
        throw new Error('Please select a valid Excel file.');
      }

      const workbook = XLSX.read(await selectedFile.arrayBuffer(), {
        type: 'array',
        cellDates: true,
      });
      const worksheetName = workbook.SheetNames[0];
      if (!worksheetName) {
        throw new Error('The workbook does not contain a worksheet.');
      }

      const parsed = parseOperationalExpenseWorksheet(
        workbook.Sheets[worksheetName],
      );
      const tallyRows = parsed.rows.map((row, index) => ({
        tallyLedgerName: row.component,
        sourceAmount: Number(row.sourceAmount) || 0,
        excelRowNumber: row.excelRowNumber || index + 1,
      }));
      let response;
      let loadedExistingReport = false;
      try {
        response = await generateOperationalExpenseReport({
          reportMonth: parsed.sourceMonth,
          reportName: `Operational Expense Report ${parsed.sourceMonth}`,
          reportCode: `OE-${parsed.sourceMonth}`,
          reportDate: parsed.sourceDate.toISOString(),
          currencyCode: 'INR',
          tallyRows,
        });
      } catch (error) {
        if (error.response?.status !== 409) throw error;
        const reportsResponse = await getOperationalExpenseReports({
          reportMonth: parsed.sourceMonth,
        });
        const existingReport = (reportsResponse.data?.data || []).find(
          (report) => report.reportMonth === parsed.sourceMonth,
        );
        if (!existingReport) throw error;
        response = await getOperationalExpenseReport(
          getReportId(existingReport),
        );
        loadedExistingReport = true;
      }

      const report = response.data?.data;
      const savedId = getReportId(report);
      if (!report || !savedId) {
        throw new Error(
          'The generated report response did not include a report ID.',
        );
      }

      setReportRows(report.rows || []);
      setFixedCosts(report.fixedCosts || []);
      setManualExpenseRows(
        (report.rows || [])
          .filter((row) => row.rowSource === 'REPORT_ONLY')
          .map((row) => ({
            _id: row._id,
            clientKey: String(row._id),
            section: String(row.financialCategoryName || '')
              .toLowerCase()
              .includes('indirect')
              ? 'INDIRECT'
              : 'DIRECT',
            itemName: row.componentName,
            amount: Number(row.amount) || 0,
            financialCategoryId: getId(row.financialCategoryId),
            financialCategoryCode: row.financialCategoryCode || '',
            financialCategoryName: row.financialCategoryName || '',
            displayOrder: row.displayOrder || 0,
          })),
      );
      const importedAmounts = getAmountsFromReport(
        report,
        allOperationalMasterComponents,
      );
      setAmounts(importedAmounts);
      setClientAllocationAmounts(
        getAllocationAmounts(report.allocations || []),
      );
      setDraftSaved(true);
      setHasUnsavedChanges(false);
      setHasImportedReport(true);
      setSourceMonth(report.reportMonth);
      setSourcePeriod(getSourcePeriod(report.reportMonth));
      setFileName(selectedFile.name);
      setUnmatchedRows(report.unmatchedTallyRows || []);
      setReportId(String(savedId));
      setReportStatus(report.status || 'DRAFT');
      setShowValidation(false);
      navigate('/operational-expenses', {
        replace: true,
        state: { operationalExpenseReportId: savedId },
      });
      setMessage({
        open: true,
        text: loadedExistingReport
          ? 'An existing report for this month was loaded.'
          : 'Tally data imported into the Operational Expense Summary.',
        severity: 'success',
      });
    } catch (error) {
      console.error('Operational Expense Tally Import Error:', error);
      setMessage({
        open: true,
        text: error.message || 'Unable to import the selected Tally file.',
        severity: 'error',
      });
    } finally {
      setImporting(false);
    }
  };

  return (
    <Box sx={{ width: '100%', minHeight: '100vh', bgcolor: '#F8FAFC' }}>
      <Container maxWidth="xl" sx={{ py: { xs: 2, sm: 2.5, md: 3 } }}>
        <Stack spacing={2}>
          <Paper
            variant="outlined"
            sx={{ width: '100%', overflow: 'hidden', borderRadius: 0 }}
          >
            <OperationalExpenseHeader
              fileName={fileName}
              hasImportedReport={hasImportedReport}
              importing={importing}
              loading={loading}
              loadingMonth={loadingMonthReport}
              sourceMonth={sourceMonth}
              onMonthChange={handleSourceMonthChange}
              fileInputRef={fileInputRef}
              onImport={handleTallyImport}
            />

            {loading ? (
              <Box sx={{ py: 8, textAlign: 'center' }}>
                <Typography fontWeight={700}>
                  Loading Operational Expense categories...
                </Typography>
              </Box>
            ) : (
              <Stack spacing={2} sx={{ p: 2 }}>
                {message.open && message.severity === 'error' && (
                  <Alert
                    severity="error"
                    onClose={() =>
                      setMessage((current) => ({ ...current, open: false }))
                    }
                  >
                    {message.text}
                  </Alert>
                )}
                {/* Temporarily hidden; retain this field for later. */}
                {/* <TextField
                    label="Report month"
                    type="month"
                    size="small"
                    value={sourceMonth}
                    disabled={reportStatus === 'FINALIZED'}
                    onChange={(event) => {
                      setSourceMonth(event.target.value);
                      const selectedDate = new Date(`${event.target.value}-01T00:00:00`);
                      setSourcePeriod(
                        Number.isNaN(selectedDate.getTime())
                          ? ''
                          : selectedDate.toLocaleString('en-IN', {
                              month: 'long',
                              year: 'numeric',
                            }),
                      );
                    }}
                    error={showValidation && Boolean(amountErrors.sourceMonth)}
                    helperText={showValidation ? amountErrors.sourceMonth || ' ' : ' '}
                    sx={{ maxWidth: 260 }}
                  /> */}
                {/* Temporarily hidden; retain the unmatched-item review for later.
                  {unmatchedRows.length > 0 && (
                    <Paper variant="outlined" sx={{ p: 2 }}>
                      <Stack spacing={1.5}>
                        <Box>
                          <Typography fontWeight={700}>
                            Review unmatched Tally items ({unmatchedRows.length})
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Map each ledger to a head component or subcomponent to include it in totals.
                          </Typography>
                        </Box>
                        {unmatchedRows.map((row) => (
                          <Stack
                            key={row.id}
                            direction={{ xs: 'column', md: 'row' }}
                            alignItems={{ xs: 'stretch', md: 'center' }}
                            spacing={1.5}
                          >
                            <Box sx={{ flex: 1, minWidth: 0 }}>
                              <Typography fontWeight={600}>{row.name}</Typography>
                              <Typography variant="caption" color="text.secondary">
                                {formatAmount(row.amount)} ·{' '}
                                {row.ambiguous
                                  ? 'Several possible matches'
                                  : 'No matching component'}
                              </Typography>
                            </Box>
                            <FormControl size="small" sx={{ minWidth: { xs: '100%', md: 320 } }}>
                              <InputLabel id={`mapping-${row.id}`}>Map to</InputLabel>
                              <Select
                                labelId={`mapping-${row.id}`}
                                label="Map to"
                                value={row.targetId || ''}
                                onChange={(event) =>
                                  setUnmatchedRows((current) =>
                                    current.map((item) =>
                                      item.id === row.id
                                        ? { ...item, targetId: event.target.value }
                                        : item,
                                    ),
                                  )
                                }
                              >
                                {mappingTargets.map((target) => (
                                  <MenuItem key={target.id} value={target.id}>
                                    {target.label}
                                  </MenuItem>
                                ))}
                              </Select>
                            </FormControl>
                            <Button
                              variant="outlined"
                              disabled={!row.targetId}
                              onClick={() => mapUnmatchedRow(row)}
                            >
                              Map item
                            </Button>
                          </Stack>
                        ))}
                      </Stack>
                    </Paper>
                  )}
                  */}
                <OperationalExpenseTable
                  categoriesWithComponents={visibleCategoriesWithComponents}
                  reportTableRef={reportTableRef}
                  fixedCosts={fixedCosts}
                  fixedCostTotal={fixedCostTotal}
                  directManualRows={manualExpenseRows.filter(
                    (row) => row.section === 'DIRECT',
                  )}
                  indirectManualRows={manualExpenseRows.filter(
                    (row) => row.section === 'INDIRECT',
                  )}
                  canEditFixedCosts={
                    Boolean(reportId) && reportStatus === 'DRAFT'
                  }
                  onAddFixedCost={openAddFixedCost}
                  onEditFixedCost={openEditFixedCost}
                  onDeleteFixedCost={setFixedCostToDelete}
                  onFixedCostAmountChange={handleFixedCostAmountChange}
                  onAddReportOnlyItem={openAddReportOnlyItem}
                  onEditReportOnlyItem={openEditReportOnlyItem}
                  onDeleteReportOnlyItem={requestDeleteReportOnlyItem}
                  sourcePeriod={sourcePeriod}
                  directGroups={directGroups}
                  indirectGroups={indirectGroups}
                  otherGroups={otherGroups}
                  amounts={amounts}
                  amountErrors={amountErrors}
                  showValidation={showValidation}
                  isFinalized={reportStatus === 'ARCHIVED' || saving}
                  clientAllocationsLocked={reportStatus === 'INVOICED'}
                  expandedComponents={expandedComponents}
                  onToggleComponent={(id) =>
                    setExpandedComponents((current) => ({
                      ...current,
                      [String(id)]: !current[String(id)],
                    }))
                  }
                  onAmountChange={handleAmountChange}
                  onDeleteAmount={requestDeleteExpenseAmount}
                  totalDirectCost={totalDirectCostWithManual}
                  totalIndirectCost={totalIndirectCostWithManual}
                  subTotal={subTotal}
                  markup={markup}
                  operationalExpenseTotal={operationalExpenseTotal}
                  reportId={reportId}
                  clientAllocationRows={clientAllocationRows}
                  onAddInvoiceAmount={(clientAllocation) => {
                    if (reportStatus === 'INVOICED') return;
                    setInvoiceDialogClientId(String(clientAllocation.clientId));
                    setInvoiceAllocation(
                      clientAllocation.savedInvoiceAllocation || null,
                    );
                    setInvoiceDialogOpen(true);
                  }}
                  onClientAllocationChange={handleClientAllocationChange}
                />
                <OperationalExpenseActions
                  saving={saving}
                  exporting={exporting}
                  reportStatus={reportStatus}
                  hasReportData={
                    Boolean(
                      sourceMonth &&
                        (operationalExpenseTotal > 0 ||
                          manualExpenseRows.some((row) => Number(row.amount) > 0) ||
                          fixedCosts.some((row) => Number(row.amount) > 0)),
                    )
                  }
                  onSaveReport={handleSaveReport}
                />
              </Stack>
            )}
          </Paper>
        </Stack>
      </Container>

      <InvoiceAllocationDialog
        key={`${invoiceDialogClientId}-${invoiceDialogOpen ? 'open' : 'closed'}`}
        open={invoiceDialogOpen}
        reportId={reportId}
        subTotal={subTotal}
        markup={markup}
        operationalExpenseTotal={operationalExpenseTotal}
        clientAllocations={clientAllocationRows}
        clients={activeClients.filter(
          (client) =>
            String(client?._id || client?.id || '') ===
            String(invoiceDialogClientId),
        )}
        initialClientId={invoiceDialogClientId}
        clickedClientAmount={
          clientAllocationRows.find(
            (row) => String(row.clientId) === String(invoiceDialogClientId),
          )?.amount ?? 0
        }
        availableAmount={
          clientAllocationRows.find(
            (row) => String(row.clientId) === String(invoiceDialogClientId),
          )?.availableAmount ?? operationalExpenseTotal
        }
        onClose={() => setInvoiceDialogOpen(false)}
        onSaved={(allocation) => {
          setInvoiceAllocation(allocation);
          setInvoiceAllocations((current) => ({
            ...current,
            [String(allocation.clientId)]: allocation,
            ...(allocation.automaticAllocation
              ? {
                  [String(allocation.automaticAllocation.clientId)]:
                    allocation.automaticAllocation,
                }
              : {}),
          }));
          setInvoiceDialogClientId(String(allocation.clientId));
          setMessage({
            open: true,
            text: 'Invoice allocation saved successfully.',
            severity: 'success',
          });
        }}
      />
      <InvoiceLocationDialog
        open={invoiceLocationDialogOpen}
        allocation={invoiceAllocation}
        loading={false}
        onClose={() => setInvoiceLocationDialogOpen(false)}
        onSelect={(location) => {
          setInvoiceLocationDialogOpen(false);
          generateOperationalExpenseInvoice(reportId, {
            clientId: invoiceDialogClientId,
            locationId: location?.locationId || null,
          })
            .then(() =>
              setInvoiceDraftLocation(
                location || { locationId: null, isClientLevel: true },
              ),
            )
            .catch((error) =>
              setMessage({
                open: true,
                text:
                  error.response?.data?.message ||
                  'Unable to generate invoice.',
                severity: 'error',
              }),
            );
        }}
      />
      <InvoiceDraftDialog
        open={Boolean(invoiceDraftLocation)}
        allocation={invoiceAllocation}
        location={invoiceDraftLocation}
        reportMonth={sourceMonth}
        onClose={() => setInvoiceDraftLocation(null)}
        onDownloaded={async () => {
          await updateOperationalExpenseReportStatus(reportId, 'INVOICED');
          setReportStatus('INVOICED');
          setMessage({
            open: true,
            text: 'Invoice downloaded and report marked as invoiced.',
            severity: 'success',
          });
        }}
      />

      <Snackbar
        open={message.open}
        autoHideDuration={4000}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        onClose={() => setMessage((current) => ({ ...current, open: false }))}
      >
        <Alert
          severity={message.severity}
          variant="filled"
          onClose={() => setMessage((current) => ({ ...current, open: false }))}
        >
          {message.text}
        </Alert>
      </Snackbar>
      <Dialog
        open={expenseItemDialog.open}
        onClose={() =>
          setExpenseItemDialog((current) => ({ ...current, open: false }))
        }
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>
          {expenseItemDialog.mode === 'add' ? 'Add Item' : 'Edit Item'} to{' '}
          {expenseItemDialog.section === 'INDIRECT'
            ? 'Indirect Cost'
            : 'Direct Cost'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ pt: 1 }}>
            <TextField
              label="Item name"
              value={expenseItemDialog.itemName}
              onChange={(event) =>
                setExpenseItemDialog((current) => ({
                  ...current,
                  itemName: event.target.value,
                }))
              }
              required
              autoFocus
            />
            <TextField
              label="Amount"
              type="number"
              value={expenseItemDialog.amount}
              onChange={(event) =>
                setExpenseItemDialog((current) => ({
                  ...current,
                  amount: event.target.value,
                }))
              }
              inputProps={{ min: 0, step: '0.01', inputMode: 'decimal' }}
              required
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() =>
              setExpenseItemDialog((current) => ({ ...current, open: false }))
            }
          >
            Cancel
          </Button>
          <Button onClick={saveReportOnlyItem} variant="contained">
            Save Item
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={fixedCostDialog.open}
        onClose={() =>
          !savingFixedCost &&
          setFixedCostDialog((current) => ({ ...current, open: false }))
        }
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>
          {fixedCostDialog.mode === 'add'
            ? 'Add fixed cost'
            : 'Edit fixed cost'}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ pt: 1 }}>
            <TextField
              label="Item name"
              value={fixedCostDialog.itemName}
              onChange={(event) =>
                setFixedCostDialog((current) => ({
                  ...current,
                  itemName: event.target.value,
                }))
              }
              required
              autoFocus
            />
            <TextField
              label="Description"
              value={fixedCostDialog.description}
              onChange={(event) =>
                setFixedCostDialog((current) => ({
                  ...current,
                  description: event.target.value,
                }))
              }
              multiline
              minRows={2}
            />
            <TextField
              label="Amount"
              type="number"
              value={fixedCostDialog.amount}
              onChange={(event) =>
                setFixedCostDialog((current) => ({
                  ...current,
                  amount: event.target.value,
                }))
              }
              inputProps={{ min: 0, step: '0.01', inputMode: 'decimal' }}
              required
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() =>
              setFixedCostDialog((current) => ({ ...current, open: false }))
            }
            disabled={savingFixedCost}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSaveFixedCost}
            disabled={savingFixedCost}
            variant="contained"
          >
            {savingFixedCost ? 'Saving...' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
      <ConfirmDialog
        open={Boolean(fixedCostToDelete)}
        title="Remove this fixed cost?"
        message={
          fixedCostToDelete
            ? `Remove ${fixedCostToDelete.itemName} from this report?`
            : ''
        }
        confirmLabel={savingFixedCost ? 'Removing...' : 'Remove'}
        confirmColor="error.main"
        onConfirm={handleDeleteFixedCost}
        onCancel={() => {
          if (!savingFixedCost) setFixedCostToDelete(null);
        }}
      />
      <ConfirmDialog
        open={Boolean(expenseToDelete)}
        title="Remove this expense amount?"
        message={
          expenseToDelete
            ? `Remove ${expenseToDelete.label} from this report? The amount will be cleared when you save.`
            : ''
        }
        confirmLabel="Remove"
        confirmColor="error.main"
        onConfirm={confirmDeleteExpenseAmount}
        onCancel={() => setExpenseToDelete(null)}
      />
    </Box>
  );
}
