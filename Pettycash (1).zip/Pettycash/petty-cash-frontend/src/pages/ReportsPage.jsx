import { useEffect, useMemo, useRef, useState } from 'react';

import {
  Alert,
  Box,
  Button,
  CircularProgress,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';

import DownloadIcon from '@mui/icons-material/Download';

import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

import ReportBarGraph from '../components/reports-component/ReportBarGraph';
import ReportPieChart from '../components/reports-component/ReportPieChart';
import { useDataContext } from '../context/DataContext';

/* -------------------------------------------------------------------------- */
/*                                  Constants                                 */
/* -------------------------------------------------------------------------- */

const MONTH_OPTIONS = [
  { value: 1, label: 'January' },
  { value: 2, label: 'February' },
  { value: 3, label: 'March' },
  { value: 4, label: 'April' },
  { value: 5, label: 'May' },
  { value: 6, label: 'June' },
  { value: 7, label: 'July' },
  { value: 8, label: 'August' },
  { value: 9, label: 'September' },
  { value: 10, label: 'October' },
  { value: 11, label: 'November' },
  { value: 12, label: 'December' },
];

const YEAR_OPTIONS = [2026, 2025];

/*
 * A4 page dimensions at approximately 96 DPI.
 * html2canvas captures these pages and jsPDF places them on A4 pages.
 */
const A4_PAGE_WIDTH_PX = 794;
const A4_PAGE_HEIGHT_PX = 1123;

/*
 * A lower number of rows provides enough room for:
 * - Report heading
 * - Month and year
 * - Table header
 * - Total section
 * - Footer
 *
 * This also prevents long component names from overflowing.
 */
const FIRST_PAGE_ROW_LIMIT = 16;
const CONTINUATION_PAGE_ROW_LIMIT = 19;

/* -------------------------------------------------------------------------- */
/*                                  Formatting                                */
/* -------------------------------------------------------------------------- */

const formatINR = (value) => {
  const numericValue = Number(value) || 0;

  const formattedAmount = numericValue.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return `₹${formattedAmount}`;
};

const waitForRender = () => {
  return new Promise((resolve) => {
    requestAnimationFrame(() => {
      requestAnimationFrame(resolve);
    });
  });
};

const chunkReportData = (data) => {
  if (!Array.isArray(data) || data.length === 0) {
    return [];
  }

  const pages = [];

  pages.push(data.slice(0, FIRST_PAGE_ROW_LIMIT));

  let currentIndex = FIRST_PAGE_ROW_LIMIT;

  while (currentIndex < data.length) {
    pages.push(
      data.slice(currentIndex, currentIndex + CONTINUATION_PAGE_ROW_LIMIT),
    );

    currentIndex += CONTINUATION_PAGE_ROW_LIMIT;
  }

  return pages;
};

/* -------------------------------------------------------------------------- */
/*                            PDF Page Components                             */
/* -------------------------------------------------------------------------- */

function PDFPageFooter({ pageNumber, totalPages }) {
  return (
    <Box
      sx={{
        position: 'absolute',
        left: 48,
        right: 48,
        bottom: 30,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderTop: '1px solid #e5e7eb',
        pt: 1.5,
        fontFamily: '"DM Sans", sans-serif',
      }}
    >
      <Typography
        sx={{
          fontFamily: 'inherit',
          color: '#6b7280',
          fontSize: '10px',
        }}
      >
        Expense Report
      </Typography>

      <Typography
        sx={{
          fontFamily: 'inherit',
          color: '#6b7280',
          fontSize: '10px',
        }}
      >
        Page {pageNumber} of {totalPages}
      </Typography>
    </Box>
  );
}

function PDFReportTablePage({
  rows,
  pageIndex,
  tablePageCount,
  totalPDFPages,
  selectedMonthName,
  year,
  totalExpense,
}) {
  const isFirstPage = pageIndex === 0;
  const isLastTablePage = pageIndex === tablePageCount - 1;

  const previousItemCount =
    pageIndex === 0
      ? 0
      : FIRST_PAGE_ROW_LIMIT + (pageIndex - 1) * CONTINUATION_PAGE_ROW_LIMIT;

  return (
    <Box
      sx={{
        position: 'relative',
        width: `${A4_PAGE_WIDTH_PX}px`,
        height: `${A4_PAGE_HEIGHT_PX}px`,
        boxSizing: 'border-box',
        overflow: 'hidden',
        backgroundColor: '#ffffff',
        color: '#111827',
        px: '48px',
        pt: '44px',
        pb: '68px',
        fontFamily: '"DM Sans", sans-serif',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'flex-start',
          mb: 2.5,
        }}
      >
        <Box>
          <Typography
            sx={{
              fontFamily: 'inherit',
              fontSize: '25px',
              lineHeight: 1.2,
              fontWeight: 700,
              color: '#111827',
            }}
          >
            Expense Report
          </Typography>

          <Typography
            sx={{
              mt: 0.75,
              fontFamily: 'inherit',
              fontSize: '12px',
              lineHeight: 1.5,
              color: '#6b7280',
            }}
          >
            Component-wise expense summary
          </Typography>
        </Box>

        <Box
          sx={{
            minWidth: '180px',
            border: '1px solid #dbe4ea',
            borderRadius: '8px',
            px: 2,
            py: 1.25,
            backgroundColor: '#f8fafc',
          }}
        >
          <Typography
            sx={{
              fontFamily: 'inherit',
              fontSize: '11px',
              color: '#6b7280',
            }}
          >
            Reporting period
          </Typography>

          <Typography
            sx={{
              mt: 0.25,
              fontFamily: 'inherit',
              fontSize: '14px',
              fontWeight: 700,
              color: '#111827',
            }}
          >
            {selectedMonthName} {year}
          </Typography>
        </Box>
      </Box>

      {!isFirstPage && (
        <Typography
          sx={{
            mb: 1.5,
            fontFamily: 'inherit',
            fontSize: '11px',
            color: '#6b7280',
          }}
        >
          Expense details continued
        </Typography>
      )}

      <Box
        sx={{
          width: '100%',
          border: '1px solid #dfe5ea',
          borderRadius: '8px',
          overflow: 'hidden',
        }}
      >
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: '65px minmax(0, 1fr) 190px',
            alignItems: 'center',
            minHeight: '44px',
            px: 2,
            backgroundColor: '#1d89c8',
            color: '#ffffff',
          }}
        >
          <Typography
            sx={{
              fontFamily: 'inherit',
              fontSize: '11px',
              fontWeight: 700,
              textAlign: 'center',
            }}
          >
            S.No
          </Typography>

          <Typography
            sx={{
              pl: 1.5,
              fontFamily: 'inherit',
              fontSize: '11px',
              fontWeight: 700,
            }}
          >
            Component
          </Typography>

          <Typography
            sx={{
              fontFamily: 'inherit',
              fontSize: '11px',
              fontWeight: 700,
              textAlign: 'right',
            }}
          >
            Amount
          </Typography>
        </Box>

        {rows.map((row, rowIndex) => {
          const serialNumber = previousItemCount + rowIndex + 1;

          return (
            <Box
              key={row._id || `${row.component}-${serialNumber}`}
              sx={{
                display: 'grid',
                gridTemplateColumns: '65px minmax(0, 1fr) 190px',
                alignItems: 'center',
                minHeight: '43px',
                px: 2,
                borderTop: '1px solid #e5e7eb',
                backgroundColor: rowIndex % 2 === 0 ? '#ffffff' : '#f8fafc',
              }}
            >
              <Typography
                sx={{
                  fontFamily: 'inherit',
                  fontSize: '11px',
                  lineHeight: 1.35,
                  textAlign: 'center',
                  color: '#374151',
                }}
              >
                {serialNumber}
              </Typography>

              <Typography
                sx={{
                  pl: 1.5,
                  pr: 2,
                  fontFamily: 'inherit',
                  fontSize: '11px',
                  lineHeight: 1.35,
                  fontWeight: 500,
                  color: '#1f2937',
                  overflowWrap: 'break-word',
                }}
              >
                {row.component || '-'}
              </Typography>

              <Typography
                var
                sx={{
                  fontFamily: 'inherit',
                  fontSize: '11px',
                  lineHeight: 1.35,
                  fontWeight: 600,
                  color: '#111827',
                  textAlign: 'right',
                  whiteSpace: 'nowrap',
                  fontVariantNumeric: 'tabular-nums',
                }}
              >
                {formatINR(row.totalExpense)}
              </Typography>
            </Box>
          );
        })}
      </Box>

      {isLastTablePage && (
        <Box
          sx={{
            mt: 2.5,
            minHeight: '58px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            px: 2.5,
            border: '1px solid #cfe4f1',
            borderRadius: '8px',
            backgroundColor: '#edf7fc',
          }}
        >
          <Typography
            sx={{
              fontFamily: 'inherit',
              fontSize: '14px',
              fontWeight: 700,
              color: '#111827',
            }}
          >
            Total Amount
          </Typography>

          <Typography
            sx={{
              fontFamily: 'inherit',
              fontSize: '16px',
              fontWeight: 700,
              color: '#111827',
              textAlign: 'right',
              whiteSpace: 'nowrap',
              fontVariantNumeric: 'tabular-nums',
            }}
          >
            {formatINR(totalExpense)}
          </Typography>
        </Box>
      )}

      <PDFPageFooter pageNumber={pageIndex + 1} totalPages={totalPDFPages} />
    </Box>
  );
}

function PDFChartPage({
  title,
  selectedMonthName,
  year,
  pageNumber,
  totalPages,
  children,
}) {
  return (
    <Box
      sx={{
        position: 'relative',
        width: `${A4_PAGE_WIDTH_PX}px`,
        height: `${A4_PAGE_HEIGHT_PX}px`,
        boxSizing: 'border-box',
        overflow: 'hidden',
        backgroundColor: '#ffffff',
        color: '#111827',
        px: '48px',
        pt: '44px',
        pb: '68px',
        fontFamily: '"DM Sans", sans-serif',
      }}
    >
      <Box
        sx={{
          mb: 2,
          pb: 2,
          borderBottom: '1px solid #e5e7eb',
        }}
      >
        <Typography
          sx={{
            fontFamily: 'inherit',
            fontSize: '23px',
            lineHeight: 1.25,
            fontWeight: 700,
            color: '#111827',
          }}
        >
          {title}
        </Typography>

        <Typography
          sx={{
            mt: 0.75,
            fontFamily: 'inherit',
            fontSize: '12px',
            color: '#6b7280',
          }}
        >
          {selectedMonthName} {year}
        </Typography>
      </Box>

      <Box
        sx={{
          width: '100%',
          height: '920px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
          backgroundColor: '#ffffff',
        }}
      >
        <Box
          sx={{
            width: '100%',
            backgroundColor: '#ffffff',
          }}
        >
          {children}
        </Box>
      </Box>

      <PDFPageFooter pageNumber={pageNumber} totalPages={totalPages} />
    </Box>
  );
}

/* -------------------------------------------------------------------------- */
/*                               Main Component                               */
/* -------------------------------------------------------------------------- */

export default function ReportsPage() {
  const { getComponentExpenseSummary } = useDataContext();

  const [month, setMonth] = useState(9);
  const [year, setYear] = useState(2026);
  const [reportData, setReportData] = useState([]);

  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState('');

  const pdfPagesRef = useRef(null);

  const selectedMonthName = useMemo(() => {
    return (
      MONTH_OPTIONS.find((monthOption) => monthOption.value === Number(month))
        ?.label || ''
    );
  }, [month]);

  const totalExpense = useMemo(() => {
    return reportData.reduce((sum, item) => {
      return sum + (Number(item.totalExpense) || 0);
    }, 0);
  }, [reportData]);

  const reportTablePages = useMemo(() => {
    return chunkReportData(reportData);
  }, [reportData]);

  const tablePageCount = reportTablePages.length;

  /*
   * Table pages plus:
   * - One bar-chart page
   * - One pie-chart page
   */
  const totalPDFPages = reportData.length > 0 ? tablePageCount + 2 : 0;

  /* ------------------------------------------------------------------------ */
  /*                             Load Report Data                             */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    let isMounted = true;

    const loadReport = async () => {
      try {
        setLoading(true);
        setError('');

        const response = await getComponentExpenseSummary(
          Number(month),
          Number(year),
        );

        if (!isMounted) {
          return;
        }

        if (response?.success) {
          setReportData(Array.isArray(response.data) ? response.data : []);
        } else {
          setReportData([]);

          setError(response?.message || 'Unable to load the expense report.');
        }
      } catch (loadError) {
        console.error('Load report error:', loadError);

        if (!isMounted) {
          return;
        }

        setReportData([]);

        setError(
          loadError?.response?.data?.message ||
            loadError?.message ||
            'Unable to load the expense report.',
        );
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadReport();

    return () => {
      isMounted = false;
    };
  }, [month, year, getComponentExpenseSummary]);

  /* ------------------------------------------------------------------------ */
  /*                           Capture A4 PDF Page                            */
  /* ------------------------------------------------------------------------ */

  const capturePDFPage = async (pageElement) => {
    if (!pageElement) {
      throw new Error('PDF page is not available.');
    }

    if (document.fonts?.ready) {
      await document.fonts.ready;
    }

    await waitForRender();

    const canvas = await html2canvas(pageElement, {
      scale: 2,
      useCORS: true,
      allowTaint: false,
      backgroundColor: '#ffffff',
      logging: false,
      scrollX: 0,
      scrollY: 0,
      width: A4_PAGE_WIDTH_PX,
      height: A4_PAGE_HEIGHT_PX,
      windowWidth: A4_PAGE_WIDTH_PX,
      windowHeight: A4_PAGE_HEIGHT_PX,
    });

    if (!canvas.width || !canvas.height) {
      throw new Error('Unable to capture the PDF page.');
    }

    return canvas.toDataURL('image/jpeg', 0.95);
  };

  /* ------------------------------------------------------------------------ */
  /*                              Export PDF                                  */
  /* ------------------------------------------------------------------------ */

  const handleExportPDF = async () => {
    if (loading || exporting) {
      return;
    }

    if (!reportData.length) {
      setError(
        `No expense records are available for ${selectedMonthName} ${year}.`,
      );

      return;
    }

    try {
      setExporting(true);
      setError('');

      if (document.fonts?.ready) {
        await document.fonts.ready;
      }

      await waitForRender();

      const pdfPageElements = pdfPagesRef.current?.querySelectorAll(
        "[data-pdf-page='true']",
      );

      if (!pdfPageElements?.length) {
        throw new Error('No PDF pages are available for export.');
      }

      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true,
      });

      const pdfWidth = doc.internal.pageSize.getWidth();
      const pdfHeight = doc.internal.pageSize.getHeight();

      for (
        let pageIndex = 0;
        pageIndex < pdfPageElements.length;
        pageIndex += 1
      ) {
        const pageImage = await capturePDFPage(pdfPageElements[pageIndex]);

        if (pageIndex > 0) {
          doc.addPage('a4', 'portrait');
        }

        doc.addImage(
          pageImage,
          'JPEG',
          0,
          0,
          pdfWidth,
          pdfHeight,
          undefined,
          'FAST',
        );
      }

      doc.save(`Expense-Report-${selectedMonthName}-${year}.pdf`);
    } catch (exportError) {
      console.error('PDF export error:', exportError);

      setError(exportError?.message || 'Unable to generate the PDF report.');
    } finally {
      setExporting(false);
    }
  };

  /* ------------------------------------------------------------------------ */
  /*                                  UI                                      */
  /* ------------------------------------------------------------------------ */

  return (
    <Box
      sx={{
        p: {
          xs: 1.5,
          sm: 3,
        },
        fontFamily: '"DM Sans", sans-serif',
      }}
    >
      <Paper
        elevation={1}
        sx={{
          p: {
            xs: 2,
            sm: 3,
          },
          borderRadius: 2,
        }}
      >
        <Stack
          direction={{
            xs: 'column',
            sm: 'row',
          }}
          justifyContent="space-between"
          alignItems={{
            xs: 'flex-start',
            sm: 'center',
          }}
          gap={2}
          sx={{
            mb: 3,
          }}
        >
          <Box>
            <Typography variant="h5" fontWeight={600}>
              Expense Report
            </Typography>

            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                mt: 1,
              }}
            >
              Component-wise expense summary
            </Typography>
          </Box>
        </Stack>

        {error && (
          <Alert
            severity="error"
            onClose={() => setError('')}
            sx={{
              mb: 2,
            }}
          >
            {error}
          </Alert>
        )}

        <Grid
          container
          spacing={2}
          sx={{
            mb: 3,
          }}
        >
          <Grid size={{ xs: 12, md: 4 }}>
            <FormControl fullWidth size="small">
              <InputLabel>Month</InputLabel>

              <Select
                value={month}
                label="Month"
                disabled={loading || exporting}
                onChange={(event) => {
                  setMonth(Number(event.target.value));
                }}
              >
                {MONTH_OPTIONS.map((monthOption) => (
                  <MenuItem key={monthOption.value} value={monthOption.value}>
                    {monthOption.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          <Grid size={{ xs: 12, md: 4 }}>
            <FormControl fullWidth size="small">
              <InputLabel>Year</InputLabel>

              <Select
                value={year}
                label="Year"
                disabled={loading || exporting}
                onChange={(event) => {
                  setYear(Number(event.target.value));
                }}
              >
                {YEAR_OPTIONS.map((yearOption) => (
                  <MenuItem key={yearOption} value={yearOption}>
                    {yearOption}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          <Grid
            size={{ xs: 12, md: 4 }}
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: {
                xs: 'stretch',
                md: 'flex-end',
              },
            }}
          >
            <Button
              fullWidth
              variant="contained"
              disabled={loading || exporting || !reportData.length}
              startIcon={
                exporting ? (
                  <CircularProgress size={18} color="inherit" />
                ) : (
                  <DownloadIcon />
                )
              }
              onClick={handleExportPDF}
              sx={{
                width: {
                  xs: '100%',
                  md: 'auto',
                },
                minWidth: 160,
                minHeight: 40,
              }}
            >
              {exporting ? 'Exporting...' : 'Export PDF'}
            </Button>
          </Grid>
        </Grid>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    width: 80,
                    fontWeight: 600,
                  }}
                >
                  S.No
                </TableCell>

                <TableCell
                  sx={{
                    fontWeight: 600,
                  }}
                >
                  Component
                </TableCell>

                <TableCell
                  sx={{
                    width: {
                      xs: 135,
                      sm: 190,
                    },
                    fontWeight: 600,
                  }}
                >
                  Amount
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell
                    colSpan={3}
                    align="center"
                    sx={{
                      py: 6,
                    }}
                  >
                    <CircularProgress size={30} />

                    <Typography
                      variant="body2"
                      color="text.secondary"
                      sx={{
                        mt: 2,
                      }}
                    >
                      Loading report...
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : reportData.length > 0 ? (
                <>
                  {reportData.map((row, index) => (
                    <TableRow
                      key={row._id || `${row.component}-${index}`}
                      hover
                    >
                      <TableCell>{index + 1}</TableCell>

                      <TableCell>{row.component || '-'}</TableCell>

                      <TableCell
                        sx={{
                          px: {
                            xs: 1.5,
                            sm: 2,
                          },
                        }}
                      >
                        <Typography
                          component="span"
                          sx={{
                            display: 'inline-block',
                            width: '100%',
                            fontFamily: '"DM Sans", sans-serif',
                            fontSize: {
                              xs: '0.95rem',
                              sm: '1rem',
                            },
                            fontWeight: 500,
                            lineHeight: 1.4,
                            letterSpacing: 0,
                            whiteSpace: 'nowrap',
                            fontVariantNumeric: 'tabular-nums',
                          }}
                        >
                          {formatINR(row.totalExpense)}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}

                  <TableRow
                    sx={{
                      backgroundColor: 'rgba(29, 137, 200, 0.09)',
                    }}
                  >
                    <TableCell />

                    <TableCell>
                      <Typography
                        sx={{
                          fontFamily: '"DM Sans", sans-serif',
                          fontSize: '1rem',
                          fontWeight: 700,
                        }}
                      >
                        Total Amount
                      </Typography>
                    </TableCell>

                    <TableCell
                      sx={{
                        px: {
                          xs: 1.5,
                          sm: 2,
                        },
                      }}
                    >
                      <Typography
                        component="span"
                        sx={{
                          display: 'inline-block',
                          width: '100%',
                          fontFamily: '"DM Sans", sans-serif',
                          fontSize: {
                            xs: '0.95rem',
                            sm: '1rem',
                          },
                          fontWeight: 700,
                          lineHeight: 1.4,
                          letterSpacing: 0,
                          whiteSpace: 'nowrap',
                          fontVariantNumeric: 'tabular-nums',
                        }}
                      >
                        {formatINR(totalExpense)}
                      </Typography>
                    </TableCell>
                  </TableRow>
                </>
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={3}
                    align="center"
                    sx={{
                      py: 6,
                    }}
                  >
                    <Typography color="text.secondary">
                      No expense records found for {selectedMonthName} {year}.
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Grid
        container
        spacing={3}
        sx={{
          mt: 1,
        }}
      >
        <Grid size={{ xs: 12 }}>
          <Box
            sx={{
              width: '100%',
              backgroundColor: '#ffffff',
            }}
          >
            <ReportBarGraph title="Expense By Component" data={reportData} />
          </Box>
        </Grid>

        <Grid size={{ xs: 12 }}>
          <Box
            sx={{
              width: '100%',
              backgroundColor: '#ffffff',
            }}
          >
            <ReportPieChart title="Expense Distribution" data={reportData} />
          </Box>
        </Grid>
      </Grid>

      {/* -------------------------------------------------------------------- */}
      {/*                         Hidden A4 PDF Pages                          */}
      {/* -------------------------------------------------------------------- */}

      {/*
       * Do not use display: none.
       *
       * Recharts and html2canvas require rendered elements with measurable
       * width and height. The pages remain outside the visible browser area.
       */}

      {reportData.length > 0 && (
        <Box
          ref={pdfPagesRef}
          aria-hidden="true"
          sx={{
            position: 'fixed',
            left: '-20000px',
            top: 0,
            width: `${A4_PAGE_WIDTH_PX}px`,
            backgroundColor: '#ffffff',
            pointerEvents: 'none',
            zIndex: -1000,
            fontFamily: '"DM Sans", sans-serif',
          }}
        >
          {reportTablePages.map((pageRows, pageIndex) => (
            <Box key={`pdf-table-page-${pageIndex}`} data-pdf-page="true">
              <PDFReportTablePage
                rows={pageRows}
                pageIndex={pageIndex}
                tablePageCount={tablePageCount}
                totalPDFPages={totalPDFPages}
                selectedMonthName={selectedMonthName}
                year={year}
                totalExpense={totalExpense}
              />
            </Box>
          ))}

          <Box data-pdf-page="true" key="pdf-bar-chart-page">
            <PDFChartPage
              title="Expense By Component"
              selectedMonthName={selectedMonthName}
              year={year}
              pageNumber={tablePageCount + 1}
              totalPages={totalPDFPages}
            >
              <ReportBarGraph title="Expense By Component" data={reportData} />
            </PDFChartPage>
          </Box>

          <Box data-pdf-page="true" key="pdf-pie-chart-page">
            <PDFChartPage
              title="Expense Distribution"
              selectedMonthName={selectedMonthName}
              year={year}
              pageNumber={tablePageCount + 2}
              totalPages={totalPDFPages}
            >
              <ReportPieChart title="Expense Distribution" data={reportData} />
            </PDFChartPage>
          </Box>
        </Box>
      )}
    </Box>
  );
}
