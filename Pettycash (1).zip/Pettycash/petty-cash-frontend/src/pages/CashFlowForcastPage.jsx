import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useBlocker } from 'react-router-dom';
import { flushSync } from 'react-dom';
import {
  Alert,
  Box,
  Button,
  Container,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Paper,
  Snackbar,
  Stack,
  Tooltip,
  Typography,
} from '@mui/material';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

import { A4_HEIGHT_PX, A4_WIDTH_PX } from '../data/dummy-data.js';
import { calculateForecastTotals } from '../utils/cash-flow-forecast/forecastCalculations';
import {
  buildForecastMonths,
  getFullPeriodLabel,
  parseTallyWorksheet,
} from '../utils/cash-flow-forecast/tallyExcelParser.js';

import ForecastSummaryCards from '../components/cash-flow-components/ForecastSummaryCards.jsx';
import ForecastStatementTable from '../components/cash-flow-components/ForecastStatementTable.jsx';
import CashFlowSummaryTable from '../components/cash-flow-components/CashFlowSummaryTable.jsx';
import ForecastPdfPages from '../components/cash-flow-components/ForecastPdfPages.jsx';
import EntityFormDialog from '../components/common-components/EntityFormDialog.jsx';
import ConfirmDialog from '../components/common-components/ConfirmDialog.jsx';
import api from '../services/auth-service.js';
import { Icons } from '../theme/icons.js';

const waitForRender = () =>
  new Promise((resolve) => {
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  });

const wait = (milliseconds) =>
  new Promise((resolve) => window.setTimeout(resolve, milliseconds));

const getRowId = (row) =>
  row._id || row.id || row.componentId?._id || row.componentId;

const mapForecastRows = (rows = []) =>
  rows.map((row) => {
    const category =
      row.financialCategoryId && typeof row.financialCategoryId === 'object'
        ? row.financialCategoryId
        : null;

    const subCategory =
      row.financialSubCategoryId &&
      typeof row.financialSubCategoryId === 'object'
        ? row.financialSubCategoryId
        : null;

    return {
      ...row,
      id: row._id || row.id || row.componentId?._id || row.componentId,
      parentComponentId:
        row.parentComponentId?._id || row.parentComponentId || null,
      rowSource:
        row.rowSource || (row.isManuallyAdded ? 'REPORT_ONLY' : 'TALLY_IMPORT'),
      isManuallyAdded: Boolean(row.isManuallyAdded),
      financialCategoryId: category?._id || row.financialCategoryId || null,
      financialCategoryCode:
        row.financialCategoryCode || category?.categoryCode || '',
      financialCategoryName:
        row.financialCategoryName || category?.categoryName || '',
      financialSubCategoryId:
        subCategory?._id || row.financialSubCategoryId || null,
      financialSubCategoryCode:
        row.financialSubCategoryCode || subCategory?.subCategoryCode || '',
      financialSubCategoryName:
        row.financialSubCategoryName || subCategory?.subCategoryName || '',
      month1: Number(row.month1 ?? row.forecastAmounts?.[0]?.amount) || 0,
      month2: Number(row.month2 ?? row.forecastAmounts?.[1]?.amount) || 0,
      month3: Number(row.month3 ?? row.forecastAmounts?.[2]?.amount) || 0,
      forecastAmounts: row.forecastAmounts || [],
    };
  });

const mapFixedCosts = (fixedCosts = []) =>
  fixedCosts.map((item) => ({
    _id: item._id,
    itemName: item.itemName,
    description: item.description || '',
    month1Amount: Number(item.forecastAmounts?.[0]?.amount) || 0,
    month2Amount: Number(item.forecastAmounts?.[1]?.amount) || 0,
    month3Amount: Number(item.forecastAmounts?.[2]?.amount) || 0,
  }));

const getMonthKey = (month) => {
  if (/^\d{4}-(0[1-9]|1[0-2])$/.test(month?.key || '')) {
    return month.key;
  }

  const date = month?.date instanceof Date ? month.date : new Date(month?.date);

  if (!Number.isNaN(date.getTime())) {
    return [
      date.getFullYear(),
      String(date.getMonth() + 1).padStart(2, '0'),
    ].join('-');
  }

  return '';
};

const getReferenceId = (value) => {
  if (!value) return '';

  if (typeof value === 'string') {
    return value;
  }

  return value._id || value.$oid || '';
};

const getUnmatchedTallyRowId = (row) =>
  `${row?.excelRowNumber ?? ''}-${row?.tallyLedgerName || ''}`;

// Get Summary Amount
const getSummaryAmount = (forecastAmounts = [], month) => {
  const monthKey = typeof month === 'string' ? month : getMonthKey(month);

  const matchingAmount = forecastAmounts.find(
    (item) => item.month === monthKey,
  );

  return Number(matchingAmount?.amount) || 0;
};

const calculateSummaryValues = ({
  forecastMonths,
  clientInflows,
  discountsAndRefunds,
  openingSurplusDeficit,
  cashOutflowTotals,
}) => {
  const previousMonthSurplusDeficit = [];
  const surplusDeficit = [];

  forecastMonths.forEach((month, index) => {
    const monthKey = getMonthKey(month);

    const clientInflowTotal = clientInflows.reduce(
      (total, clientRow) =>
        total + getSummaryAmount(clientRow.forecastAmounts, monthKey),
      0,
    );

    const discountAmount = getSummaryAmount(discountsAndRefunds, monthKey);

    const previousMonthAmount =
      index === 0
        ? Number(openingSurplusDeficit) || 0
        : Number(surplusDeficit[index - 1]?.amount) || 0;

    const cashOutflow = Number(cashOutflowTotals[index]) || 0;

    const calculatedAmount =
      clientInflowTotal - discountAmount + previousMonthAmount - cashOutflow;

    previousMonthSurplusDeficit.push({
      month: monthKey,
      amount: previousMonthAmount,
    });

    surplusDeficit.push({
      month: monthKey,
      amount: calculatedAmount,
    });
  });

  return {
    previousMonthSurplusDeficit,
    surplusDeficit,
  };
};

const PAGE_NAME_BY_PATH = {
  '/': 'Dashboard',
  '/dashboard': 'Dashboard',
  '/cash-flow-analysis': 'Cash Flow Analysis',
  '/cash-flow-report': 'Cash Flow Report',
  '/petty-cash': 'Petty Cash',
  '/masters': 'Masters',
  '/masters/components': 'Component Masters',
  '/masters/sub-components': 'Subcomponent Masters',
  '/masters/clients': 'Client Masters',
};

const getPageNameFromPath = (pathname = '') => {
  if (PAGE_NAME_BY_PATH[pathname]) {
    return PAGE_NAME_BY_PATH[pathname];
  }

  const matchedRoute = Object.keys(PAGE_NAME_BY_PATH)
    .filter((path) => path !== '/')
    .sort((firstPath, secondPath) => secondPath.length - firstPath.length)
    .find((path) => pathname === path || pathname.startsWith(`${path}/`));

  if (matchedRoute) {
    return PAGE_NAME_BY_PATH[matchedRoute];
  }

  const finalPathPart = pathname.split('/').filter(Boolean).pop();

  if (!finalPathPart) {
    return 'the selected page';
  }

  return finalPathPart
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, (character) => character.toUpperCase());
};

export default function CashFlowForecastPage() {
  const pdfPagesRef = useRef(null);

  const [forecastId, setForecastId] = useState(null);
  const [forecastRows, setForecastRows] = useState([]);
  const [fixedCostRows, setFixedCostRows] = useState([]);
  const [unmatchedTallyRows, setUnmatchedTallyRows] = useState([]);
  const [pendingUnmatchedDiscard, setPendingUnmatchedDiscard] = useState(null);
  const [discardingUnknownRowKey, setDiscardingUnknownRowKey] = useState(null);
  const [unknownComponentsDialogOpen, setUnknownComponentsDialogOpen] =
    useState(false);
  const [activeUnknownTallyRow, setActiveUnknownTallyRow] = useState(null);
  const [unknownMasterDialogOpen, setUnknownMasterDialogOpen] = useState(false);
  const [unknownReportOnlyDialogOpen, setUnknownReportOnlyDialogOpen] =
    useState(false);
  const [availableFinancialCategories, setAvailableFinancialCategories] =
    useState([]);
  const [availableFinancialSubCategories, setAvailableFinancialSubCategories] =
    useState([]);
  const [resolvingUnknownRow, setResolvingUnknownRow] = useState(false);
  const [sourceDate, setSourceDate] = useState(null);
  const [reportStatus, setReportStatus] = useState('DRAFT');
  const [pdfExported, setPdfExported] = useState(false);
  const [importedMonths, setImportedMonths] = useState([]);
  const [currentMonth, setCurrentMonth] = useState(() =>
    getMonthKey({ date: new Date() }),
  );

  const [loadingForecast, setLoadingForecast] = useState(true);
  const [loadingImportedMonths, setLoadingImportedMonths] = useState(true);
  const [importing, setImporting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingFixedCost, setSavingFixedCost] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const shouldBlockNavigation = useCallback(
    ({ currentLocation, nextLocation }) => {
      return isDirty && currentLocation.pathname !== nextLocation.pathname;
    },
    [isDirty],
  );

  const navigationBlocker = useBlocker(shouldBlockNavigation);

  const navigationDestinationName = useMemo(
    () => getPageNameFromPath(navigationBlocker.location?.pathname || ''),
    [navigationBlocker.location?.pathname],
  );
  const [deletedFixedCostIds, setDeletedFixedCostIds] = useState([]);
  const [renderPDFPages, setRenderPDFPages] = useState(false);

  const [fixedCostDialog, setFixedCostDialog] = useState({
    open: false,
    mode: 'create',
    initialValues: {},
  });
  const [addForecastRowDialog, setAddForecastRowDialog] = useState({
    open: false,
    category: null,
    subCategory: null,
    sectionName: '',
    initialValues: {},
  });
  const [addCashInflowDialog, setAddCashInflowDialog] = useState({
    open: false,
    initialValues: {},
  });

  const [cashInflowAddType, setCashInflowAddType] = useState('MASTER_CLIENT');
  const [availableSummaryClients, setAvailableSummaryClients] = useState([]);
  const [loadingSummaryClients, setLoadingSummaryClients] = useState(false);
  const [savingCashInflow, setSavingCashInflow] = useState(false);
  const [removeCashInflowTarget, setRemoveCashInflowTarget] = useState(null);
  const [removingCashInflow, setRemovingCashInflow] = useState(false);
  const [availableMasterComponents, setAvailableMasterComponents] = useState(
    [],
  );
  const [forecastRowAddType, setForecastRowAddType] =
    useState('MASTER_COMPONENT');
  const [loadingMasterComponents, setLoadingMasterComponents] = useState(false);
  const [savingForecastRow, setSavingForecastRow] = useState(false);
  const [removeTarget, setRemoveTarget] = useState(null);
  const [removingItem, setRemovingItem] = useState(false);
  const [cashFlowSummary, setCashFlowSummary] = useState({
    clientInflows: [],
    discountsAndRefunds: [],
    openingSurplusDeficit: 0,
  });

  const [loadingCashFlowSummary, setLoadingCashFlowSummary] = useState(false);

  const [cashFlowSummaryLoaded, setCashFlowSummaryLoaded] = useState(false);

  const [message, setMessage] = useState({
    open: false,
    text: '',
    severity: 'success',
  });

  const sourcePeriod = useMemo(
    () => (sourceDate ? getFullPeriodLabel(sourceDate) : 'Not imported'),
    [sourceDate],
  );

  const currentMonthAlreadyImported = importedMonths.includes(currentMonth);

  const forecastMonths = useMemo(
    () => buildForecastMonths(sourceDate),
    [sourceDate],
  );

  const totals = useMemo(
    () => calculateForecastTotals(forecastRows),
    [forecastRows],
  );

  const fixedCostGrandTotal = useMemo(
    () =>
      fixedCostRows.reduce(
        (total, row) =>
          total +
          (Number(row.month1Amount) || 0) +
          (Number(row.month2Amount) || 0) +
          (Number(row.month3Amount) || 0),
        0,
      ),
    [fixedCostRows],
  );

  // Total Cash Out Flow calculation , Fixed cost total + Total Forecast row total
  const cashOutflowTotals = useMemo(
    () =>
      forecastMonths.map((month, index) => {
        const forecastRowsTotal = forecastRows.reduce(
          (total, row) => total + (Number(row[`month${index + 1}`]) || 0),
          0,
        );

        const fixedCostTotal = fixedCostRows.reduce(
          (total, row) => total + (Number(row[`month${index + 1}Amount`]) || 0),
          0,
        );

        return forecastRowsTotal + fixedCostTotal;
      }),
    [forecastRows, fixedCostRows, forecastMonths],
  );

  const calculatedCashFlowSummary = useMemo(
    () =>
      calculateSummaryValues({
        forecastMonths,

        clientInflows: cashFlowSummary.clientInflows,

        discountsAndRefunds: cashFlowSummary.discountsAndRefunds,

        openingSurplusDeficit: cashFlowSummary.openingSurplusDeficit,

        cashOutflowTotals,
      }),
    [
      forecastMonths,
      cashFlowSummary.clientInflows,
      cashFlowSummary.discountsAndRefunds,
      cashFlowSummary.openingSurplusDeficit,
      cashOutflowTotals,
    ],
  );

  const fixedCostFields = useMemo(
    () => [
      {
        name: 'itemName',
        label: 'Fixed Cost Item',
        type: 'text',
        required: true,
      },
      {
        name: 'description',
        label: 'Description',
        type: 'text',
        required: false,
      },
      {
        name: 'month1Amount',
        label: forecastMonths[0]?.fullLabel || 'Month 1',
        type: 'number',
        required: true,
        min: 0,
      },
      {
        name: 'month2Amount',
        label: forecastMonths[1]?.fullLabel || 'Month 2',
        type: 'number',
        required: true,
        min: 0,
      },
      {
        name: 'month3Amount',
        label: forecastMonths[2]?.fullLabel || 'Month 3',
        type: 'number',
        required: true,
        min: 0,
      },
    ],
    [forecastMonths],
  );

  const unknownMasterFields = useMemo(() => {
    const fields = [
      {
        name: 'financialCategoryId',
        label: 'Financial Category',
        type: 'select',
        required: true,
        resetFields: ['financialSubCategoryId'],
        options: availableFinancialCategories.map((category) => ({
          label: category.categoryName,
          value: category._id,
        })),
      },
    ];

    if (availableFinancialSubCategories.length > 0) {
      fields.push({
        name: 'financialSubCategoryId',
        label: 'Financial Subcategory',
        type: 'select',
        required: true,
        options: availableFinancialSubCategories.map((subCategory) => ({
          label: subCategory.subCategoryName,
          value: subCategory._id,
        })),
      });
    }

    fields.push(
      {
        name: 'componentName',
        label: 'Component Name',
        type: 'text',
        required: true,
      },
      {
        name: 'description',
        label: 'Description',
        type: 'text',
        required: false,
      },
      {
        name: 'isPettyCash',
        label: 'Petty Cash',
        type: 'checkbox',
      },
      {
        name: 'isCashFlowAnalysis',
        label: 'Cash Flow Analysis',
        type: 'checkbox',
        disabled: true,
      },
      {
        name: 'isOperationalExpense',
        label: 'Operational Expense',
        type: 'checkbox',
      },
      {
        name: 'isFullyLoadedCost',
        label: 'Fully Loaded Cost',
        type: 'checkbox',
      },
      {
        name: 'isActive',
        label: 'Status',
        type: 'select',
        required: true,
        options: [
          { label: 'Active', value: true },
          { label: 'Inactive', value: false },
        ],
      },
    );

    return fields;
  }, [availableFinancialCategories, availableFinancialSubCategories]);

  const unknownReportOnlyFields = useMemo(() => {
    const fields = [
      {
        name: 'financialCategoryId',
        label: 'Financial Category',
        type: 'select',
        required: true,
        options: availableFinancialCategories.map((category) => ({
          label: category.categoryName,
          value: category._id,
        })),
      },
    ];

    if (availableFinancialSubCategories.length > 0) {
      fields.push({
        name: 'financialSubCategoryId',
        label: 'Financial Subcategory',
        type: 'select',
        required: true,
        options: availableFinancialSubCategories.map((subCategory) => ({
          label: subCategory.subCategoryName,
          value: subCategory._id,
        })),
      });
    }

    fields.push(
      {
        name: 'itemName',
        label: 'Component Name',
        type: 'text',
        required: true,
      },
      {
        name: 'description',
        label: 'Description',
        type: 'text',
        required: false,
      },
    );

    return fields;
  }, [
    availableFinancialCategories,
    availableFinancialSubCategories,
  ]);

  const unknownMasterInitialValues = useMemo(
    () => ({
      financialCategoryId: '',
      financialSubCategoryId: '',
      componentName: activeUnknownTallyRow?.tallyLedgerName || '',
      description: '',
      isPettyCash: false,
      isCashFlowAnalysis: true,
      isOperationalExpense: false,
      isFullyLoadedCost: false,
      isActive: true,
    }),
    [activeUnknownTallyRow],
  );

  const unknownReportOnlyInitialValues = useMemo(
    () => ({
      financialCategoryId: '',
      financialSubCategoryId: '',
      itemName: activeUnknownTallyRow?.tallyLedgerName || '',
      description: '',
    }),
    [activeUnknownTallyRow],
  );

  const addForecastRowFields = useMemo(() => {
    const fields = [
      {
        name: 'addType',
        label: 'Add Item From',
        type: 'select',
        required: true,
        resetFields: ['componentId', 'itemName', 'description'],
        options: [
          {
            label: 'Component Masters',
            value: 'MASTER_COMPONENT',
          },
          {
            label: 'Report-only Item',
            value: 'REPORT_ONLY',
          },
        ],
      },
    ];

    if (forecastRowAddType === 'MASTER_COMPONENT') {
      fields.push({
        name: 'componentId',
        label: 'Select Component',
        type: 'select',
        required: true,
        options: availableMasterComponents.map((component) => ({
          label: component.componentName,
          value: component._id,
        })),
      });
    }

    if (forecastRowAddType === 'REPORT_ONLY') {
      fields.push(
        {
          name: 'itemName',
          label: 'Item Name',
          type: 'text',
          required: true,
        },
        {
          name: 'description',
          label: 'Description',
          type: 'text',
          required: false,
        },
      );
    }

    fields.push(
      {
        name: 'month1Amount',
        label: forecastMonths[0]?.fullLabel || 'Month 1',
        type: 'number',
        required: true,
        min: 0,
      },
      {
        name: 'month2Amount',
        label: forecastMonths[1]?.fullLabel || 'Month 2',
        type: 'number',
        required: true,
        min: 0,
      },
      {
        name: 'month3Amount',
        label: forecastMonths[2]?.fullLabel || 'Month 3',
        type: 'number',
        required: true,
        min: 0,
      },
    );

    return fields;
  }, [forecastRowAddType, availableMasterComponents, forecastMonths]);

  const addCashInflowFields = useMemo(() => {
    const fields = [
      {
        name: 'addType',
        label: 'Add Cash Inflow From',
        type: 'select',
        required: true,
        resetFields: ['clientId', 'itemName', 'inflowType'],
        options: [
          {
            label: 'Client Masters',
            value: 'MASTER_CLIENT',
          },
          {
            label: 'Report-only Item',
            value: 'REPORT_ONLY',
          },
        ],
      },
    ];

    if (cashInflowAddType === 'MASTER_CLIENT') {
      fields.push({
        name: 'clientId',
        label: 'Select Client',
        type: 'select',
        required: true,
        options:
          availableSummaryClients.length > 0
            ? availableSummaryClients.map((client) => ({
                label: client.clientName,
                value: client._id,
              }))
            : [
                {
                  label: 'No additional Clients available',
                  value: '',
                  disabled: true,
                },
              ],
      });
    }

    if (cashInflowAddType === 'REPORT_ONLY') {
      fields.push({
        name: 'itemName',
        label: 'Cash Inflow Item',
        type: 'text',
        required: true,
      });
    }

    fields.push(
      {
        name: 'month1Amount',
        label: forecastMonths[0]?.fullLabel || 'Month 1',
        type: 'number',
        required: true,
        min: 0,
      },
      {
        name: 'month2Amount',
        label: forecastMonths[1]?.fullLabel || 'Month 2',
        type: 'number',
        required: true,
        min: 0,
      },
      {
        name: 'month3Amount',
        label: forecastMonths[2]?.fullLabel || 'Month 3',
        type: 'number',
        required: true,
        min: 0,
      },
    );

    return fields;
  }, [cashInflowAddType, availableSummaryClients, forecastMonths]);

  const showMessage = useCallback((text, severity = 'success') => {
    setMessage({ open: true, text, severity });
  }, []);

  // Load Cash Flow Summary
  const loadCashFlowSummary = useCallback(async (currentForecastId) => {
    if (!currentForecastId) {
      return;
    }

    try {
      setLoadingCashFlowSummary(true);

      const response = await api.get(
        `/api/cashFlowRouter/forecast/${currentForecastId}/cash-flow-summary`,
      );

      const summaryData = response.data?.data;

      setCashFlowSummary({
        clientInflows: summaryData?.clientInflows || [],

        discountsAndRefunds: summaryData?.discountsAndRefunds || [],

        openingSurplusDeficit: Number(summaryData?.openingSurplusDeficit) || 0,
      });

      setCashFlowSummaryLoaded(true);
    } catch {
      setCashFlowSummaryLoaded(false);

      showMessage('Failed to load data', 'error');
    } finally {
      setLoadingCashFlowSummary(false);
    }
  }, [showMessage]);

  // Restore saved forecast after refresh
  useEffect(() => {
    let mounted = true;

    const loadImportedMonths = async () => {
      try {
        const response = await api.get('/api/cashFlowRouter/forecast/all');
        const months = (response.data?.data || [])
          .map((forecast) => forecast.sourceMonth)
          .filter(Boolean);

        if (mounted) {
          setImportedMonths((existingMonths) =>
            Array.from(new Set([...existingMonths, ...months])),
          );
        }
      } catch {
        console.error('Load Imported Forecast Months Error', 'error');
      } finally {
        if (mounted) setLoadingImportedMonths(false);
      }
    };

    const loadSavedForecast = async () => {
      const savedId = localStorage.getItem('cashFlowForecastId');

      if (!savedId) {
        if (mounted) setLoadingForecast(false);
        return;
      }

      try {
        const response = await api.get(
          `/api/cashFlowRouter/forecast/${savedId}`,
        );

        if (!mounted) return;

        const data = response.data.data;

        setForecastId(data._id);
        setReportStatus(data.status || 'DRAFT');
        setSourceDate(
          data.sourceDate
            ? new Date(data.sourceDate)
            : new Date(`${data.sourceMonth}-01T00:00:00.000Z`),
        );
        setForecastRows(mapForecastRows(data.rows));
        setFixedCostRows(mapFixedCosts(data.fixedCosts));
        const unmatchedRows = data.unmatchedTallyRows || [];
        setUnmatchedTallyRows(unmatchedRows);
        setUnknownComponentsDialogOpen(unmatchedRows.length > 0);
        setDeletedFixedCostIds([]);
        if (data.sourceMonth) {
          setImportedMonths((months) =>
            months.includes(data.sourceMonth)
              ? months
              : [...months, data.sourceMonth],
          );
        }
        await loadCashFlowSummary(data._id);
        setIsDirty(false);
      } catch {
        if (!mounted) return;

        localStorage.removeItem('cashFlowForecastId');
      } finally {
        if (mounted) setLoadingForecast(false);
      }
    };

    loadImportedMonths();
    loadSavedForecast();

    return () => {
      mounted = false;
    };
  }, [loadCashFlowSummary]);

  useEffect(() => {
    const updateCurrentMonth = () =>
      setCurrentMonth(getMonthKey({ date: new Date() }));
    const now = new Date();
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const timeoutId = window.setTimeout(
      updateCurrentMonth,
      nextMonth.getTime() - now.getTime() + 50,
    );

    window.addEventListener('focus', updateCurrentMonth);
    return () => {
      window.clearTimeout(timeoutId);
      window.removeEventListener('focus', updateCurrentMonth);
    };
  }, [currentMonth]);

  // Protect refresh and tab close
  useEffect(() => {
    if (!isDirty) return undefined;

    const handleBeforeUnload = (event) => {
      event.preventDefault();
      event.returnValue = '';
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isDirty]);

  const handleStayOnCurrentPage = () => {
    if (navigationBlocker.state === 'blocked') {
      navigationBlocker.reset();
    }
  };

  const handleContinueNavigation = () => {
    if (navigationBlocker.state !== 'blocked') {
      return;
    }

    setIsDirty(false);

    navigationBlocker.proceed();
  };

  const handleExcelImport = async (event) => {
    const selectedFile = event.target.files?.[0];

    if (!selectedFile) {
      return;
    }

    try {
      setImporting(true);

      const extension = selectedFile.name.split('.').pop()?.toLowerCase() || '';

      if (!['xlsx', 'xls'].includes(extension)) {
        throw new Error('Please select a valid Excel file.');
      }

      const fileBuffer = await selectedFile.arrayBuffer();

      const workbook = XLSX.read(fileBuffer, {
        type: 'array',
        cellDates: true,
      });
      const firstWorksheetName = workbook.SheetNames[0];
      if (!firstWorksheetName) {
        throw new Error('The workbook does not contain a worksheet.');
      }
      const worksheet = workbook.Sheets[firstWorksheetName];
      const parsedResult = parseTallyWorksheet(worksheet);
      if (!parsedResult.rows?.length) {
        throw new Error('No valid Tally rows were found in the worksheet.');
      }
      const detectedSourceDate = parsedResult.sourceDate;
      if (!detectedSourceDate || Number.isNaN(detectedSourceDate.getTime())) {
        throw new Error(
          'Unable to identify the report month from the imported Tally file.',
        );
      }

      const sourceMonth =
        parsedResult.sourceMonth ||
        [
          detectedSourceDate.getFullYear(),
          String(detectedSourceDate.getMonth() + 1).padStart(2, '0'),
        ].join('-');

      if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(sourceMonth)) {
        throw new Error('The detected source month is invalid.');
      }

      const tallyRows = parsedResult.rows.map((row, index) => ({
        tallyLedgerName: row.component,

        sourceAmount: Math.max(0, Number(row.sourceAmount) || 0),

        excelRowNumber: row.excelRowNumber || index + 1,
      }));

      const response = await api.post('/api/cashFlowRouter/generate', {
        sourceMonth,
        sourceFileName: selectedFile.name,
        worksheetName: firstWorksheetName,
        tallyRows,
      });

      if (!response.data?.success) {
        throw new Error(
          response.data?.message || 'Unable to generate forecast.',
        );
      }

      const data = response.data?.data;
      if (!data?.forecastId) {
        throw new Error('The generated forecast response is invalid.');
      }
      setForecastId(data.forecastId);
      setReportStatus(data.status || 'DRAFT');
      setImportedMonths((months) =>
        months.includes(sourceMonth) ? months : [...months, sourceMonth],
      );
      setSourceDate(
        new Date(
          detectedSourceDate.getFullYear(),
          detectedSourceDate.getMonth(),
          1,
        ),
      );

      setForecastRows(mapForecastRows(data.rows || []));
      setFixedCostRows(mapFixedCosts(data.fixedCosts || []));
      const unmatchedRows = data.unmatchedTallyRows || [];
      setUnmatchedTallyRows(unmatchedRows);
      setUnknownComponentsDialogOpen(unmatchedRows.length > 0);
      await loadCashFlowSummary(data.forecastId);
      setIsDirty(false);
      localStorage.setItem('cashFlowForecastId', String(data.forecastId));

      const savedForecastIds = JSON.parse(
        localStorage.getItem('cashFlowForecastIds') || '[]',
      );
      const updatedForecastIds = Array.from(
        new Set([...savedForecastIds, String(data.forecastId)]),
      );

      localStorage.setItem(
        'cashFlowForecastIds',
        JSON.stringify(updatedForecastIds),
      );

      showMessage('Report Imported Successfully');
    } catch (error) {
      console.error('Excel Import Error:', {
        message: error.message,
        status: error.response?.status,
        response: error.response?.data,
        url: error.config?.url,
        method: error.config?.method,
      });

      showMessage(
        error.response?.data?.message ||
          error.message ||
          'Failed to import the file',
        'error',
      );
    } finally {
      setImporting(false);

      if (event.target) {
        event.target.value = '';
      }
    }
  };

  const handleOpenUnknownMasterForm = async (row) => {
    try {
      let categories = availableFinancialCategories;

      if (!categories.length) {
        const response = await api.get(
          '/api/componentRouter/financial-categories',
        );
        categories = response.data?.data || [];
        setAvailableFinancialCategories(categories);
      }

      if (!categories.length) {
        showMessage('No active Financial Categories are available.', 'error');
        return;
      }

      setAvailableFinancialSubCategories([]);
      setActiveUnknownTallyRow(row);
      setUnknownMasterDialogOpen(true);
    } catch (error) {
      showMessage(
        error.response?.data?.message || 'Unable to load Financial Categories.',
        'error',
      );
    }
  };

  const handleOpenUnknownReportOnlyForm = async (row) => {
    try {
      let categories = availableFinancialCategories;

      if (!categories.length) {
        const response = await api.get(
          '/api/componentRouter/financial-categories',
        );
        categories = response.data?.data || [];
        setAvailableFinancialCategories(categories);
      }

      if (!categories.length) {
        showMessage('No active Financial Categories are available.', 'error');
        return;
      }

      setAvailableFinancialSubCategories([]);
      setActiveUnknownTallyRow(row);
      setUnknownReportOnlyDialogOpen(true);
    } catch (error) {
      showMessage(
        error.response?.data?.message || 'Unable to load Financial Categories.',
        'error',
      );
    }
  };

  const handleUnknownReportOnlyFieldChange = (fieldName, value) => {
    if (fieldName === 'financialCategoryId') {
      handleUnknownMasterFieldChange(fieldName, value);
    }
  };

  const handleDiscardUnmatchedTallyRow = async (row) => {
    const rowKey = getUnmatchedTallyRowId(row);

    if (!forecastId || discardingUnknownRowKey) return;

    try {
      setDiscardingUnknownRowKey(rowKey);
      await api.delete(
        `/api/cashFlowRouter/forecast/${forecastId}/unmatched-tally-row`,
        {
          data: {
            tallyLedgerName: row.tallyLedgerName,
            excelRowNumber: row.excelRowNumber,
          },
        },
      );

      const remainingRows = unmatchedTallyRows.filter(
        (unmatchedRow) => getUnmatchedTallyRowId(unmatchedRow) !== rowKey,
      );
      setUnmatchedTallyRows(remainingRows);

      if (!remainingRows.length) {
        setUnknownComponentsDialogOpen(false);
      }

      showMessage(
        `${row.tallyLedgerName || 'Value'} discarded from this report.`,
      );
    } catch (error) {
      showMessage(
        error.response?.data?.message ||
          'Unable to discard this unmatched value.',
        'error',
      );
    } finally {
      setDiscardingUnknownRowKey(null);
    }
  };

  const handleConfirmUnmatchedDiscard = async () => {
    if (!pendingUnmatchedDiscard) return;

    await handleDiscardUnmatchedTallyRow(pendingUnmatchedDiscard);
    setPendingUnmatchedDiscard(null);
  };

  const handleUnknownMasterFieldChange = async (fieldName, value) => {
    if (fieldName !== 'financialCategoryId') return;

    setAvailableFinancialSubCategories([]);

    if (!value) return;

    try {
      const response = await api.get(
        `/api/componentRouter/financial-subcategories/${value}`,
      );
      setAvailableFinancialSubCategories(
        response.data?.data?.financialSubCategories || [],
      );
    } catch {
      showMessage('Unable to load Financial Subcategories.', 'error');
    }
  };

  const handleResolveUnknownTallyRow = async (values, addType) => {
    if (!forecastId || !activeUnknownTallyRow || resolvingUnknownRow) return;

    const sourceAmount = Math.max(0, Number(activeUnknownTallyRow.amount) || 0);
    const forecastAmounts = forecastMonths.map((month) => ({
      month: getMonthKey(month),
      amount: sourceAmount,
    }));

    try {
      setResolvingUnknownRow(true);

      let component = null;

      if (addType === 'MASTER_COMPONENT') {
        const componentPayload = {
          componentName: values.componentName?.trim(),
          description: values.description?.trim() || '',
          financialCategoryId: values.financialCategoryId,
          financialSubCategoryId: values.financialSubCategoryId || null,
          isPettyCash: Boolean(values.isPettyCash),
          isCashFlowAnalysis: true,
          isOperationalExpense: Boolean(values.isOperationalExpense),
          isFullyLoadedCost: Boolean(values.isFullyLoadedCost),
          isActive: values.isActive !== false,
        };
        const existingComponentsResponse = await api.get(
          '/api/componentRouter/getAllComponents',
        );
        const existingComponent = (
          existingComponentsResponse.data?.data || []
        ).find(
          (item) =>
            item.componentName?.trim().toLocaleLowerCase() ===
            componentPayload.componentName?.toLocaleLowerCase(),
        );
        const componentResponse = existingComponent
          ? await api.patch(
              `/api/componentRouter/updateComponent/${existingComponent._id}`,
              {
                financialCategoryId: componentPayload.financialCategoryId,
                financialSubCategoryId: componentPayload.financialSubCategoryId,
                isCashFlowAnalysis: true,
                isActive: true,
              },
            )
          : await api.post(
              '/api/componentRouter/createComponent',
              componentPayload,
            );
        component = componentResponse.data?.data;

        if (!component?._id) {
          throw new Error('The new Component response was invalid.');
        }
      }

      const response = await api.post(
        `/api/cashFlowRouter/forecast/${forecastId}/row`,
        {
          addType,
          componentId: component?._id || null,
          itemName:
            addType === 'REPORT_ONLY' ? values.itemName?.trim() : undefined,
          description: values.description?.trim() || '',
          financialCategoryId:
            component?.financialCategoryId?._id ||
            component?.financialCategoryId ||
            values.financialCategoryId,
          financialSubCategoryId:
            component?.financialSubCategoryId?._id ||
            component?.financialSubCategoryId ||
            values.financialSubCategoryId ||
            null,
          parentComponentId: values.parentComponentId || null,
          sourceAmount,
          tallyLedgerName: activeUnknownTallyRow.tallyLedgerName,
          excelRowNumber: activeUnknownTallyRow.excelRowNumber,
          forecastAmounts,
        },
      );

      const addedRow = mapForecastRows([response.data?.data])[0];
      setForecastRows((rows) => [...rows, addedRow]);

      const remainingRows = unmatchedTallyRows.filter(
        (row) =>
          !(
            row.tallyLedgerName === activeUnknownTallyRow.tallyLedgerName &&
            String(row.excelRowNumber) ===
              String(activeUnknownTallyRow.excelRowNumber)
          ),
      );
      setUnmatchedTallyRows(remainingRows);
      if (!remainingRows.length) {
        setUnknownComponentsDialogOpen(false);
      }

      setUnknownMasterDialogOpen(false);
      setUnknownReportOnlyDialogOpen(false);
      setActiveUnknownTallyRow(null);
      setIsDirty(false);
      showMessage(
        addType === 'MASTER_COMPONENT'
          ? 'Component added to Master Data and this report.'
          : 'Report-only value added to this report.',
      );
    } catch (error) {
      showMessage(
        error.response?.data?.message ||
          error.message ||
          'Unable to resolve this imported value.',
        'error',
      );
    } finally {
      setResolvingUnknownRow(false);
    }
  };

  // Forecast Editing
  const handleForecastCellChange = useCallback((rowId, field, value) => {
    if (!['month1', 'month2', 'month3'].includes(field)) return;

    setForecastRows((rows) =>
      rows.map((row) => {
        if (String(getRowId(row)) !== String(rowId)) return row;

        const updatedRow = {
          ...row,
          [field]: value === '' ? '' : Number(value),
          isEdited: true,
        };

        updatedRow.forecastAmounts = forecastMonths.map((month, index) => ({
          month: getMonthKey(month),
          amount: Number(updatedRow[`month${index + 1}`]) || 0,
        }));

        return updatedRow;
      }),
    );

    setIsDirty(true);
  }, [forecastMonths]);

  const handleFixedCostCellChange = useCallback((fixedCostId, field, value) => {
    const allowedFields = ['month1Amount', 'month2Amount', 'month3Amount'];

    if (!allowedFields.includes(field)) {
      return;
    }

    // Allow empty value while editing
    if (value !== '' && Number(value) < 0) {
      return;
    }

    setFixedCostRows((currentRows) =>
      currentRows.map((row) => {
        if (String(row._id) !== String(fixedCostId)) {
          return row;
        }

        return {
          ...row,
          [field]: value === '' ? '' : Number(value),
          isEdited: true,
        };
      }),
    );

    setIsDirty(true);
  }, []);

  const handleResetRow = (rowId) => {
    let rowFound = false;

    setForecastRows((currentRows) =>
      currentRows.map((row) => {
        const currentRowId = getRowId(row);

        if (String(currentRowId) !== String(rowId)) {
          return row;
        }

        rowFound = true;

        const isManualRow =
          row.rowSource === 'MASTER_COMPONENT' ||
          row.rowSource === 'REPORT_ONLY' ||
          row.isManuallyAdded === true;

        /*
         * Imported rows reset to their Tally source amount.
         * Manually added rows reset to zero.
         */
        const resetAmount = isManualRow ? 0 : Number(row.sourceAmount) || 0;

        const forecastAmounts = forecastMonths.map((month) => ({
          month: getMonthKey(month),
          amount: resetAmount,
        }));

        return {
          ...row,

          month1: resetAmount,
          month2: resetAmount,
          month3: resetAmount,

          forecastAmounts,
          isEdited: true,
        };
      }),
    );

    if (!rowFound) {
      console.warn('Unable to find forecast row for reset:', rowId);
      return;
    }

    setIsDirty(true);
  };

  const handleRemoveForecastRowRequest = (rowId, row) => {
    if (!rowId) {
      showMessage('Unable to find the selected forecast.', 'error');
      return;
    }

    setRemoveTarget({
      type: 'FORECAST_ROW',
      id: rowId,
      name: row.componentName || row.componentId?.componentName || 'this item',
    });
  };

  // Add new Forecast Row
  const handleAddForecastRow = async ({
    categoryCode,
    subCategoryCode = null,
    sectionName,
  }) => {
    if (!forecastId) {
      showMessage(
        'No report found. Please import it before adding items.',
        'warning',
      );
      return;
    }

    const sectionRow = forecastRows.find((row) => {
      const categoryMatches = row.financialCategoryCode === categoryCode;

      const subCategoryMatches = subCategoryCode
        ? row.financialSubCategoryCode === subCategoryCode
        : true;

      return categoryMatches && subCategoryMatches;
    });

    if (!sectionRow) {
      showMessage(`Unable to identify the ${sectionName} section.`, 'error');
      return;
    }

    const financialCategoryId = getReferenceId(sectionRow.financialCategoryId);

    const financialSubCategoryId = subCategoryCode
      ? getReferenceId(sectionRow.financialSubCategoryId)
      : null;

    if (!financialCategoryId) {
      showMessage(
        'Category information is unavailable for this section.',
        'error',
      );
      return;
    }

    if (subCategoryCode && !financialSubCategoryId) {
      showMessage('Subcategory data is unavailable', 'error');
      return;
    }

    try {
      setLoadingMasterComponents(true);

      const response = await api.get(
        `/api/cashFlowRouter/forecast/${forecastId}/available-components`,
        {
          params: {
            financialCategoryId,
            ...(financialSubCategoryId
              ? {
                  financialSubCategoryId,
                }
              : {}),
          },
        },
      );

      setAvailableMasterComponents(response.data.data || []);

      setForecastRowAddType('MASTER_COMPONENT');

      setAddForecastRowDialog({
        open: true,

        category: {
          id: financialCategoryId,
          code: sectionRow.financialCategoryCode,
          name: sectionRow.financialCategoryName || sectionName,
        },

        subCategory: financialSubCategoryId
          ? {
              id: financialSubCategoryId,
              code: sectionRow.financialSubCategoryCode,
              name: sectionRow.financialSubCategoryName || sectionName,
            }
          : null,

        sectionName,

        initialValues: {
          addType: 'MASTER_COMPONENT',
          componentId: '',
          itemName: '',
          description: '',
          month1Amount: 0,
          month2Amount: 0,
          month3Amount: 0,
        },
      });
    } catch (error) {
      console.error('Load Available Components Error:', error);

      showMessage('Unable to load available Components.', 'error');
    } finally {
      setLoadingMasterComponents(false);
    }
  };

  const handleAddForecastRowFieldChange = (fieldName, value) => {
    if (fieldName === 'addType') {
      setForecastRowAddType(value);
    }
  };

  const handleSaveForecastRow = async (values) => {
    if (!forecastId) return;

    try {
      setSavingForecastRow(true);

      const payload = {
        addType: values.addType,

        componentId:
          values.addType === 'MASTER_COMPONENT' ? values.componentId : null,

        itemName:
          values.addType === 'REPORT_ONLY' ? values.itemName?.trim() : '',

        description:
          values.addType === 'REPORT_ONLY'
            ? values.description?.trim() || ''
            : '',

        financialCategoryId: addForecastRowDialog.category?.id,

        financialSubCategoryId: addForecastRowDialog.subCategory?.id || null,

        forecastAmounts: forecastMonths.map((month, index) => ({
          month: getMonthKey(month),
          amount: Number(values[`month${index + 1}Amount`]) || 0,
        })),
      };

      const response = await api.post(
        `/api/cashFlowRouter/forecast/${forecastId}/row`,
        payload,
      );

      const addedRows = mapForecastRows([response.data.data]);

      setForecastRows((rows) => [...rows, ...addedRows]);

      setAddForecastRowDialog({
        open: false,
        category: null,
        subCategory: null,
        sectionName: '',
        initialValues: {},
      });

      setAvailableMasterComponents([]);
      setForecastRowAddType('MASTER_COMPONENT');

      showMessage('Item added successfully.');
    } catch (error) {
      console.error('Add Forecast Row Error:', error);

      showMessage('Unable to add the item.', 'error');
    } finally {
      setSavingForecastRow(false);
    }
  };

  const handleConfirmRemove = async () => {
    if (!forecastId || !removeTarget || removingItem) {
      return;
    }

    try {
      setRemovingItem(true);

      if (removeTarget.type === 'FORECAST_ROW') {
        setForecastRows((currentRows) =>
          currentRows.filter(
            (row) => String(row._id) !== String(removeTarget.id),
          ),
        );

        showMessage(`${removeTarget.name} is removed.`);
      }

      if (removeTarget.type === 'FIXED_COST') {
        setFixedCostRows((currentRows) =>
          currentRows.filter(
            (row) => String(row._id) !== String(removeTarget.id),
          ),
        );
        setDeletedFixedCostIds((currentIds) =>
          currentIds.includes(removeTarget.id)
            ? currentIds
            : [...currentIds, removeTarget.id],
        );

        showMessage(
          `${removeTarget.name} removed. Save the report to apply it.`,
        );
      }

      setIsDirty(true);
      setRemoveTarget(null);
    } catch (error) {
      console.error('Remove Forecast Item Error:', error);

      showMessage(
        error.response?.data?.message || 'Failed to remove the item.',
        'error',
      );
    } finally {
      setRemovingItem(false);
    }
  };

  // Fixed Cost
  const handleAddFixedCost = () => {
    if (!forecastId || !forecastRows.length) {
      showMessage('Import a report to add Fixed Costs.', 'warning');
      return;
    }

    setFixedCostDialog({
      open: true,
      mode: 'create',
      initialValues: {
        itemName: '',
        description: '',
        month1Amount: 0,
        month2Amount: 0,
        month3Amount: 0,
      },
    });
  };

  const handleDeleteFixedCostRequest = (fixedCostId, row) => {
    if (!fixedCostId) {
      showMessage('Unable to identify the selected Fixed Cost.', 'error');
      return;
    }

    setRemoveTarget({
      type: 'FIXED_COST',
      id: fixedCostId,
      name: row?.itemName || 'this Fixed Cost',
    });
  };

  const handleSaveFixedCost = async (values) => {
    if (!forecastId) {
      showMessage('Import the Tally report first.', 'warning');
      return;
    }

    if (!values.itemName?.trim()) {
      showMessage('Enter the Fixed Cost item name.', 'warning');
      return;
    }

    try {
      setSavingFixedCost(true);

      const forecastAmounts = forecastMonths.map((month, index) => ({
        month: getMonthKey(month),
        amount: Number(values[`month${index + 1}Amount`]) || 0,
      }));

      const hasInvalidMonth = forecastAmounts.some(
        (item) => !/^\d{4}-(0[1-9]|1[0-2])$/.test(item.month),
      );

      if (hasInvalidMonth) {
        throw new Error('Unable to identify the forecast months.');
      }

      const payload = {
        itemName: values.itemName.trim(),
        description: values.description?.trim() || '',
        forecastAmounts,
      };

      const response = await api.post(
        `/api/cashFlowRouter/forecast/${forecastId}/fixed-cost`,
        payload,
      );

      setFixedCostRows((rows) => [
        ...rows,
        ...mapFixedCosts([response.data.data]),
      ]);

      setFixedCostDialog({
        open: false,
        mode: 'create',
        initialValues: {},
      });

      showMessage(response.data.message || 'Fixed Cost added successfully.');
    } catch (error) {
      console.error('Add Fixed Cost Error:', error);

      showMessage(
        error.response?.data?.message ||
          error.message ||
          'Unable to add Fixed Cost.',
        'error',
      );
    } finally {
      setSavingFixedCost(false);
    }
  };

  const handleResetFixedCost = (row) => {
    if (!row?._id) {
      return;
    }

    setFixedCostRows((currentRows) =>
      currentRows.map((item) => {
        if (String(item._id) !== String(row._id)) {
          return item;
        }

        return {
          ...item,
          month1Amount: 0,
          month2Amount: 0,
          month3Amount: 0,
          isEdited: true,
        };
      }),
    );

    setIsDirty(true);
  };

  // Client Inflow Change controller
  const handleClientInflowChange = useCallback((clientRow, month, index, value) => {
    const normalizedValue = value === '' ? '' : Math.max(0, Number(value) || 0);

    setCashFlowSummary((current) => ({
      ...current,
      clientInflows: current.clientInflows.map((row) => {
        if (String(row._id) !== String(clientRow._id)) {
          return row;
        }
        const nextForecastAmounts = forecastMonths.map(
          (forecastMonth, amountIndex) => {
            const forecastMonthKey = getMonthKey(forecastMonth);
            const existingAmount = row.forecastAmounts?.find(
              (item) => item.month === forecastMonthKey,
            );
            return {
              month: forecastMonthKey,
              amount:
                amountIndex === index
                  ? normalizedValue
                  : Math.max(0, Number(existingAmount?.amount) || 0),
            };
          },
        );

        return {
          ...row,
          forecastAmounts: nextForecastAmounts,
        };
      }),
    }));

    setIsDirty(true);
  }, [forecastMonths]);

  const handleAddCashInflow = async () => {
    if (!forecastId) {
      showMessage(
        'Import the Tally report before adding Cash Inflow.',
        'warning',
      );
      return;
    }

    try {
      setLoadingSummaryClients(true);

      const response = await api.get(
        `/api/cashFlowRouter/forecast/${forecastId}/cash-summary/available-clients`,
      );

      setAvailableSummaryClients(response.data?.data || []);

      setCashInflowAddType('MASTER_CLIENT');

      setAddCashInflowDialog({
        open: true,
        initialValues: {
          addType: 'MASTER_CLIENT',
          clientId: '',
          itemName: '',
          inflowType: 'ACTUAL',
          month1Amount: 0,
          month2Amount: 0,
          month3Amount: 0,
        },
      });
    } catch (error) {
      console.error('Load Available Summary Clients Error:', error);

      showMessage(
        error.response?.data?.message || 'Unable to load available Clients.',
        'error',
      );
    } finally {
      setLoadingSummaryClients(false);
    }
  };

  const handleCashInflowFieldChange = (fieldName, value) => {
    if (fieldName === 'addType') {
      setCashInflowAddType(value);
    }
  };

  const handleSaveCashInflow = async (values) => {
    if (!forecastId) {
      return;
    }

    const currentInflows = cashFlowSummary.clientInflows;

    if (values.addType === 'MASTER_CLIENT' && !values.clientId) {
      showMessage('Select a Client.', 'warning');
      return;
    }

    if (values.addType === 'REPORT_ONLY' && !values.itemName?.trim()) {
      showMessage('Enter the Cash Inflow item name.', 'warning');
      return;
    }

    try {
      setSavingCashInflow(true);

      await saveCashFlowSummary();

      const payload = {
        addType: values.addType,

        clientId: values.addType === 'MASTER_CLIENT' ? values.clientId : null,

        itemName:
          values.addType === 'REPORT_ONLY' ? values.itemName.trim() : '',

        inflowType: 'ACTUAL',

        forecastAmounts: forecastMonths.map((month, index) => ({
          month: getMonthKey(month),
          amount: Number(values[`month${index + 1}Amount`]) || 0,
        })),
      };

      const response = await api.post(
        `/api/cashFlowRouter/forecast/${forecastId}/cash-summary/item`,
        payload,
      );

      const responseData = response.data?.data;
      const updatedClientInflows = responseData?.clientInflows?.map(
        (row, index) => {
          const previousRow =
            currentInflows.find(
              (currentRow) => String(currentRow._id) === String(row._id),
            ) || currentInflows[index];

          return previousRow
            ? { ...row, forecastAmounts: previousRow.forecastAmounts }
            : row;
        },
      );

      setCashFlowSummary((current) => ({
        ...current,

        clientInflows: updatedClientInflows || current.clientInflows,
      }));

      setAddCashInflowDialog({
        open: false,
        initialValues: {},
      });

      setAvailableSummaryClients([]);

      setCashInflowAddType('MASTER_CLIENT');

      const successMessage =
        values.addType === 'MASTER_CLIENT'
          ? 'Client added to cash inflow successfully.'
          : 'Cash Inflow item added successfully.';

      showMessage(successMessage, 'success');
    } catch {
      showMessage('Unable to add Cash Inflow.', 'error');
    } finally {
      setSavingCashInflow(false);
    }
  };

  const handleRemoveCashInflowRequest = (clientRow) => {
    if (!clientRow?._id) {
      showMessage('Unable to identify the selected Cash Inflow row.', 'error');
      return;
    }

    setRemoveCashInflowTarget({
      itemId: clientRow._id,
      name: clientRow.clientName || 'this Cash Inflow item',
    });
  };

  const handleConfirmRemoveCashInflow = async () => {
    if (!removeCashInflowTarget || removingCashInflow) {
      return;
    }

    try {
      setRemovingCashInflow(true);

      setCashFlowSummary((current) => ({
        ...current,
        clientInflows: current.clientInflows.filter(
          (row) => String(row._id) !== String(removeCashInflowTarget.itemId),
        ),
      }));

      setRemoveCashInflowTarget(null);
      setIsDirty(true);

      const successMessage =
        removeCashInflowTarget?.addType === 'MASTER_CLIENT'
          ? 'Client removed from Cash Inflow successfully.'
          : 'Cash Inflow item removed successfully.';

      showMessage(successMessage, 'success');
    } catch {
      showMessage('Unable to remove Cash Inflow.', 'error');
    } finally {
      setRemovingCashInflow(false);
    }
  };

  const handleResetClientInflow = (clientRow) => {
    const targetClientId = String(
      clientRow.clientId?._id || clientRow.clientId,
    );

    setCashFlowSummary((current) => ({
      ...current,
      clientInflows: current.clientInflows.map((row) => {
        const rowClientId = String(row.clientId?._id || row.clientId);

        if (
          rowClientId !== targetClientId ||
          row.inflowType !== clientRow.inflowType
        ) {
          return row;
        }

        return {
          ...row,
          forecastAmounts: forecastMonths.map((month) => ({
            month: getMonthKey(month),
            amount: 0,
          })),
        };
      }),
    }));
    setIsDirty(true);
  };

  // Handle Discount Change
  const handleDiscountChange = useCallback((month, index, value) => {
    setCashFlowSummary((current) => ({
      ...current,
      discountsAndRefunds: forecastMonths.map((forecastMonth, amountIndex) => {
        const monthKey = getMonthKey(forecastMonth);
        const existingAmount = current.discountsAndRefunds.find(
          (item) => item.month === monthKey,
        );

        return {
          month: monthKey,
          amount:
            amountIndex === index
              ? value === ''
                ? ''
                : Number(value)
              : Number(existingAmount?.amount) || 0,
        };
      }),
    }));
    setIsDirty(true);
  }, [forecastMonths]);

  // Handle Opening Balance in Summary Table
  const handleOpeningBalanceChange = useCallback((value) => {
    setCashFlowSummary((current) => ({
      ...current,
      openingSurplusDeficit: value === '' ? '' : Number(value),
    }));
    setIsDirty(true);
  }, []);

  // Save CashFlow Summary
  const saveCashFlowSummary = async () => {
    if (!forecastId) {
      return null;
    }

    const payload = {
      clientInflows: cashFlowSummary.clientInflows.map((row) => ({
        _id: row._id,
        clientId: row.clientId?._id || row.clientId,
        inflowType: row.inflowType,
        forecastAmounts: forecastMonths.map((month) => {
          const monthKey = getMonthKey(month);
          const existingAmount = row.forecastAmounts?.find(
            (item) => item.month === monthKey,
          );
          return {
            month: monthKey,
            amount: Number(existingAmount?.amount) || 0,
          };
        }),
      })),

      discountsAndRefunds: forecastMonths.map((month) => {
        const monthKey = getMonthKey(month);
        const existingAmount = cashFlowSummary.discountsAndRefunds.find(
          (item) => item.month === monthKey,
        );
        return {
          month: monthKey,
          amount: Number(existingAmount?.amount) || 0,
        };
      }),
      openingSurplusDeficit: Number(cashFlowSummary.openingSurplusDeficit) || 0,
    };
    const response = await api.patch(
      `/api/cashFlowRouter/forecast/${forecastId}/cash-flow-summary`,
      payload,
    );
    const summaryData = response.data?.data;

    setCashFlowSummary({
      clientInflows: summaryData?.clientInflows || [],
      discountsAndRefunds: summaryData?.discountsAndRefunds || [],
      openingSurplusDeficit: Number(summaryData?.openingSurplusDeficit) || 0,
    });
    return response;
  };

  // Save Report
  const handleSaveReport = async () => {
    if (!forecastId || !forecastRows.length) {
      showMessage('Please import the report before saving.', 'warning');
      return;
    }

    if (saving) {
      return;
    }

    try {
      setSaving(true);

      const rows = forecastRows.map((row) => ({
        componentId: row.componentId?._id || row.componentId || null,
        parentComponentId:
          row.parentComponentId?._id || row.parentComponentId || null,
        componentCode: row.componentCode || '',
        componentName:
          row.componentName || row.componentId?.componentName || '',
        rowSource: row.rowSource || 'TALLY_IMPORT',
        isManuallyAdded: Boolean(row.isManuallyAdded),
        financialCategoryId:
          row.financialCategoryId?._id || row.financialCategoryId || null,
        financialCategoryCode:
          row.financialCategoryCode ||
          row.financialCategoryId?.categoryCode ||
          '',
        financialCategoryName:
          row.financialCategoryName ||
          row.financialCategoryId?.categoryName ||
          '',
        financialSubCategoryId:
          row.financialSubCategoryId?._id || row.financialSubCategoryId || null,
        financialSubCategoryCode:
          row.financialSubCategoryCode ||
          row.financialSubCategoryId?.subCategoryCode ||
          '',
        financialSubCategoryName:
          row.financialSubCategoryName ||
          row.financialSubCategoryId?.subCategoryName ||
          '',
        description: row.description || '',
        displayOrder: Number(row.displayOrder) || 0,
        sourceAmount: Number(row.sourceAmount) || 0,
        forecastAmounts: forecastMonths.map((month, index) => ({
          month: getMonthKey(month),
          amount: Number(row[`month${index + 1}`]) || 0,
        })),

        matchStatus: row.matchStatus || 'NOT_PRESENT_IN_TALLY',
        hasTallyExpense: Boolean(row.hasTallyExpense),
        matchedTallyLedgers: row.matchedTallyLedgers || [],
        subComponentBreakdown: row.subComponentBreakdown || [],
        isEdited: Boolean(row.isEdited),
      }));

      const forecastResponse = await api.patch(
        `/api/cashFlowRouter/forecast/${forecastId}/rows`,
        {
          rows,
        },
      );
      const savedForecastRows = forecastResponse.data?.data?.rows;
      if (!savedForecastRows) {
        throw new Error('The saved forecast rows response is invalid.');
      }

      const editedFixedCosts = fixedCostRows.filter(
        (row) => row.isEdited === true,
      );

      const fixedCostResponses = await Promise.all(
        editedFixedCosts.map((row) => {
          const forecastAmounts = forecastMonths.map((month, index) => ({
            month: getMonthKey(month),
            amount: Number(row[`month${index + 1}Amount`]) || 0,
          }));

          return api.patch(
            `/api/cashFlowRouter/forecast/${forecastId}/fixed-cost/${row._id}`,
            {
              itemName: row.itemName,
              description: row.description || '',
              forecastAmounts,
            },
          );
        }),
      );

      if (fixedCostResponses.length > 0) {
        const updatedFixedCosts = fixedCostResponses
          .map((result) => result.data?.data)
          .filter(Boolean);

        setFixedCostRows((currentRows) =>
          currentRows.map((row) => {
            const updatedItem = updatedFixedCosts.find(
              (item) => String(item._id) === String(row._id),
            );

            if (!updatedItem) {
              return row;
            }

            return mapFixedCosts([updatedItem])[0];
          }),
        );
      }

      await saveCashFlowSummary();

      await Promise.all(
        deletedFixedCostIds.map((fixedCostId) =>
          api.delete(
            `/api/cashFlowRouter/forecast/${forecastId}/fixed-cost/${fixedCostId}`,
          ),
        ),
      );

      if (deletedFixedCostIds.length > 0) {
        setDeletedFixedCostIds([]);
      }

      await api.patch(`/api/cashFlowRouter/forecast/${forecastId}/status`, {
        status: 'DRAFT',
      });
      setReportStatus('DRAFT');

      setIsDirty(false);

      showMessage('Report Saved successfully.', 'success');
    } catch {
      showMessage('Unable to save changes. Please try again', 'error');
    } finally {
      setSaving(false);
    }
  };

  // PDF Export
  const capturePDFPage = async (pageElement) => {
    if (!pageElement) {
      throw new Error('The PDF page is not available.');
    }

    if (document.fonts?.ready) {
      await document.fonts.ready;
    }

    await waitForRender();

    const pageWidth = pageElement.offsetWidth || A4_WIDTH_PX;
    const pageHeight = pageElement.offsetHeight || A4_HEIGHT_PX;

    const canvas = await html2canvas(pageElement, {
      scale: 2,
      useCORS: true,
      allowTaint: false,
      backgroundColor: '#ffffff',
      logging: false,
      scrollX: 0,
      scrollY: 0,
      width: pageWidth,
      height: pageHeight,
      windowWidth: pageWidth,
      windowHeight: pageHeight,
    });

    if (!canvas.width || !canvas.height) {
      throw new Error('The PDF page could not be captured.');
    }

    return {
      image: canvas.toDataURL('image/jpeg', 0.96),
      width: canvas.width,
      height: canvas.height,
    };
  };

  const handleExportPDF = async () => {
    if (!forecastRows.length) {
      showMessage(
        'Please import the report data before generating the PDF.',
        'warning',
      );
      return;
    }

    if (isDirty) {
      showMessage(
        'You have unsaved changes. Please save the report before exporting.',
        'warning',
      );
      return;
    }

    if (exporting) return;

    try {
      flushSync(() => {
        setExporting(true);
        setRenderPDFPages(true);
      });

      if (document.fonts?.ready) {
        await document.fonts.ready;
      }

      await waitForRender();
      await waitForRender();
      await wait(150);

      const pageElements = pdfPagesRef.current?.querySelectorAll(
        "[data-pdf-page='true']",
      );

      if (!pageElements?.length) {
        throw new Error('PDF content is not available.');
      }

      const documentPDF = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true,
      });

      const pdfWidth = documentPDF.internal.pageSize.getWidth();
      const pdfHeight = documentPDF.internal.pageSize.getHeight();
      const pdfMargin = 3;

      for (let index = 0; index < pageElements.length; index += 1) {
        const pageCapture = await capturePDFPage(pageElements[index]);

        if (index > 0) {
          documentPDF.addPage('a4', 'portrait');
        }

        const printableWidth = pdfWidth - pdfMargin * 2;
        const printableHeight = pdfHeight - pdfMargin * 2;
        const scale = Math.min(
          printableWidth / pageCapture.width,
          printableHeight / pageCapture.height,
        );
        const imageWidth = pageCapture.width * scale;
        const imageHeight = pageCapture.height * scale;
        const imageX = (pdfWidth - imageWidth) / 2;
        const imageY = (pdfHeight - imageHeight) / 2;

        documentPDF.addImage(
          pageCapture.image,
          'JPEG',
          imageX,
          imageY,
          imageWidth,
          imageHeight,
          undefined,
          'FAST',
        );
      }

      const safeSourcePeriod = sourcePeriod.replace(/\s+/g, '-');

      documentPDF.save(`Cash-Flow-Analysis-${safeSourcePeriod}.pdf`);
      setPdfExported(true);

      try {
        await api.patch(`/api/cashFlowRouter/forecast/${forecastId}/status`, {
          status: 'FINALIZED',
        });
        setReportStatus('FINALIZED');
      } catch {
        showMessage(
          'The PDF was downloaded successfully, but the report status could not be updated. Please refresh the page and verify the report status.',
          'error',
        );
        return;
      }

      showMessage('Cash Flow report downloaded successfully.');
    } catch (error) {
      showMessage(error.message || 'Unable to export the PDF report.', 'error');
    } finally {
      flushSync(() => {
        setRenderPDFPages(false);
        setExporting(false);
      });
    }
  };

  return (
    <Box
      sx={{
        width: '100%',
        minHeight: '100vh',
        overflowX: 'hidden',
        bgcolor: '#F8FAFC',
      }}
    >
      <Container maxWidth="xl" sx={{ py: { xs: 2, sm: 2.5, md: 3 } }}>
        <Stack spacing={{ xs: 2, md: 3 }}>
          <ForecastSummaryCards
            sourceTotal={totals.source}
            forecastTotal={totals.forecast + fixedCostGrandTotal}
            sourcePeriod={sourcePeriod}
          />

          {isDirty && (
            <Alert severity="warning" variant="outlined">
              This forecast contains unsaved changes. Save the report before
              refreshing or closing this page.
            </Alert>
          )}

          <Paper
            variant="outlined"
            sx={{ overflow: 'hidden', borderRadius: 0 }}
          >
            <Box
              sx={{
                px: 2,
                py: 1.5,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 2,
                bgcolor: 'background.default',
                borderBottom: '1px solid',
                borderColor: 'divider',
              }}
            >
              <Box>
                <Typography variant="h6" fontWeight={800}>
                  Cash Flow Analysis
                </Typography>
              </Box>

              <Stack direction="row" alignItems="center" spacing={1}>
                {!exporting &&
                  !pdfExported &&
                  reportStatus !== 'FINALIZED' &&
                  unmatchedTallyRows.length > 0 && (
                    <Button
                      variant="outlined"
                      onClick={() => setUnknownComponentsDialogOpen(true)}
                    >
                      Review unmatched ({unmatchedTallyRows.length})
                    </Button>
                  )}
                <Button
                  component="label"
                  variant="outlined"
                  disabled={
                    loadingForecast ||
                    loadingImportedMonths ||
                    importing ||
                    saving ||
                    exporting ||
                    Boolean(forecastId) ||
                    isDirty ||
                    currentMonthAlreadyImported
                  }
                >
                  {loadingForecast
                    ? 'Loading...'
                    : loadingImportedMonths
                      ? 'Checking imports...'
                      : importing
                        ? 'Importing...'
                        : currentMonthAlreadyImported
                          ? 'Upload Data'
                          : 'Upload Data'}

                  <input
                    type="file"
                    accept=".xlsx,.xls"
                    hidden
                    onChange={handleExcelImport}
                  />
                </Button>
              </Stack>
            </Box>

            {forecastRows.length ? (
              <Box
                component="fieldset"
                disabled={reportStatus === 'FINALIZED'}
                sx={{
                  m: 0,
                  p: 0,
                  border: 0,
                  minWidth: 0,
                  '& .MuiOutlinedInput-root': {
                    bgcolor:
                      reportStatus === 'FINALIZED' ? '#F3F4F6' : undefined,
                  },
                  '& input:disabled': {
                    WebkitTextFillColor:
                      reportStatus === 'FINALIZED' ? '#4B5563' : undefined,
                  },
                }}
              >
                <ForecastStatementTable
                  rows={forecastRows}
                  fixedCostRows={fixedCostRows}
                  forecastMonths={forecastMonths}
                  exporting={exporting}
                  onCellChange={handleForecastCellChange}
                  onFixedCostCellChange={handleFixedCostCellChange}
                  onResetRow={handleResetRow}
                  onRemoveForecastRow={handleRemoveForecastRowRequest}
                  onAddForecastRow={handleAddForecastRow}
                  onAddFixedCost={handleAddFixedCost}
                  onResetFixedCost={handleResetFixedCost}
                  onDeleteFixedCost={handleDeleteFixedCostRequest}
                />
              </Box>
            ) : (
              <Box sx={{ py: 8, textAlign: 'center' }}>
                <Typography fontWeight={700}>
                  {loadingForecast
                    ? 'Loading forecast...'
                    : 'No cash flow report is generated'}
                </Typography>

                {!loadingForecast && (
                  <Typography variant="body2" color="text.secondary">
                    Import a Tally report to generate the cash flow report.
                  </Typography>
                )}
              </Box>
            )}
          </Paper>

          {forecastRows.length > 0 && (
            <Paper
              variant="outlined"
              sx={{
                overflow: 'hidden',
                borderRadius: 0,
              }}
            >
              {loadingCashFlowSummary ? (
                <Box
                  sx={{
                    py: 6,
                    textAlign: 'center',
                  }}
                >
                  <Typography fontWeight={700}>
                    Loading Cash Flow Summary...
                  </Typography>
                </Box>
              ) : cashFlowSummaryLoaded ? (
                <Box
                  component="fieldset"
                  disabled={reportStatus === 'FINALIZED'}
                  sx={{
                    m: 0,
                    p: 0,
                    border: 0,
                    minWidth: 0,
                    '& .MuiOutlinedInput-root': {
                      bgcolor:
                        reportStatus === 'FINALIZED' ? '#F3F4F6' : undefined,
                    },
                    '& input:disabled': {
                      WebkitTextFillColor:
                        reportStatus === 'FINALIZED' ? '#4B5563' : undefined,
                    },
                  }}
                >
                  <CashFlowSummaryTable
                    forecastMonths={forecastMonths}
                    clientInflows={cashFlowSummary.clientInflows}
                    discountsAndRefunds={cashFlowSummary.discountsAndRefunds}
                    openingSurplusDeficit={
                      cashFlowSummary.openingSurplusDeficit
                    }
                    previousMonthSurplusDeficit={
                      calculatedCashFlowSummary.previousMonthSurplusDeficit
                    }
                    surplusDeficit={calculatedCashFlowSummary.surplusDeficit}
                    cashOutflowTotals={cashOutflowTotals}
                    exporting={exporting}
                    onClientInflowChange={handleClientInflowChange}
                    onDiscountChange={handleDiscountChange}
                    onOpeningBalanceChange={handleOpeningBalanceChange}
                    onAddCashInflow={handleAddCashInflow}
                    onRemoveCashInflow={handleRemoveCashInflowRequest}
                    onResetClientInflow={handleResetClientInflow}
                  />
                </Box>
              ) : (
                <Box
                  sx={{
                    py: 6,
                    textAlign: 'center',
                  }}
                >
                  <Typography fontWeight={700}>
                    Cash Flow Summary is unavailable.
                  </Typography>

                  <Button
                    variant="outlined"
                    sx={{ mt: 2 }}
                    onClick={() => loadCashFlowSummary(forecastId)}
                  >
                    Retry
                  </Button>
                </Box>
              )}
            </Paper>
          )}

          {forecastRows.length > 0 && (
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Stack
                direction={{ xs: 'column', sm: 'row' }}
                alignItems={{ xs: 'stretch', sm: 'center' }}
                justifyContent="space-between"
                sx={{
                  alignItems: { xs: 'stretch', sm: 'center' },
                  justifyContent: 'flex-end',
                }}
                spacing={2}
              >
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
                  <Button
                    variant="contained"
                    onClick={handleSaveReport}
                    disabled={
                      saving || !isDirty || reportStatus === 'FINALIZED'
                    }
                  >
                    {saving ? 'Saving...' : 'Save Report'}
                  </Button>

                  <Button
                    variant="outlined"
                    onClick={handleExportPDF}
                    disabled={exporting || saving || isDirty}
                  >
                    {exporting ? 'Exporting...' : 'Export as PDF'}
                  </Button>
                </Stack>
              </Stack>
            </Paper>
          )}
        </Stack>
      </Container>

      <Dialog
        open={
          unknownComponentsDialogOpen &&
          !exporting &&
          !pdfExported &&
          reportStatus !== 'FINALIZED' &&
          unmatchedTallyRows.length > 0
        }
        onClose={() => setUnknownComponentsDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 2,
            fontWeight: 700,
          }}
        >
          <Typography component="span" variant="h6" >
            Some Uploaded Values Need Your Attention
          </Typography>
          <IconButton
            aria-label="Close unmatched values"
            onClick={() => setUnknownComponentsDialogOpen(false)}
            size="small"
            sx={{ flexShrink: 0 }}
          >
            <Icons.CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ overflowX: 'hidden', py: 2.5 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            The following uploaded values could not be matched with existing
            records. Choose whether to add them to your master data or include
            them only in this report.
          </Typography>
          <Stack spacing={1.25}>
            {unmatchedTallyRows.map((row, index) => (
              <Box
                key={`${row.excelRowNumber || 'row'}-${index}`}
                sx={{
                  display: 'grid',
                  gridTemplateColumns: {
                    xs: 'minmax(0, 1fr)',
                    md: 'minmax(0, 0.9fr) minmax(0, 1.1fr)',
                  },
                  alignItems: 'center',
                  gap: 2,
                  p: { xs: 1.5, sm: 2 },
                  border: '1px solid',
                  borderColor: 'divider',
                  borderRadius: 1,
                  bgcolor: 'background.paper',
                }}
              >
                <Box
                  sx={{
                    minWidth: 0,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 2,
                  }}
                >
                  <Box sx={{ minWidth: 0 }}>
                    <Typography variant="h6" color="text.secondary">
                      Uploaded value
                    </Typography>
                    <Typography
                      variant="body2"
                      fontWeight={700}
                      sx={{ overflowWrap: 'anywhere' }}
                    >
                      {row.tallyLedgerName || 'Unnamed value'}
                    </Typography>
                  </Box>
                  <Box sx={{ flexShrink: 0, textAlign: 'right' }}>
                    <Typography variant="h6" color="text.secondary">
                      Amount
                    </Typography>
                    <Typography variant="subtitle1" fontWeight={700}>
                      {(Number(row.amount) || 0).toLocaleString('en-IN')}
                    </Typography>
                  </Box>
                </Box>

                <Box
                  sx={{
                    display: 'grid',
                    gridTemplateColumns: {
                      xs: 'minmax(0, 1fr) minmax(0, 1fr)',
                      sm: '180px 140px 36px',
                    },
                    alignItems: 'center',
                    gap: 1,
                    width: { xs: '100%', sm: 'fit-content' },
                    justifySelf: { xs: 'stretch', sm: 'end' },
                  }}
                >
                  <Button
                    size="small"
                    variant="contained"
                    disableElevation
                    startIcon={<Icons.AddIcon fontSize="small" />}
                    sx={{
                      minWidth: 0,
                      minHeight: 34,
                      whiteSpace: 'normal',
                      lineHeight: 1.2,
                      borderRadius: 1,
                      fontWeight: 700,
                      fontSize: '0.8125rem',
                    }}
                    onClick={() => handleOpenUnknownMasterForm(row)}
                    disabled={
                      resolvingUnknownRow || Boolean(discardingUnknownRowKey)
                    }
                  >
                    Add to Master Data
                  </Button>
                  <Button
                    size="small"
                    variant="outlined"
                    startIcon={<Icons.ReceiptLongIcon fontSize="small" />}
                    sx={{
                      minWidth: 0,
                      minHeight: 34,
                      whiteSpace: 'normal',
                      lineHeight: 1.2,
                      borderRadius: 1,
                      fontWeight: 600,
                      fontSize: '0.8125rem',
                    }}
                    onClick={() => handleOpenUnknownReportOnlyForm(row)}
                    disabled={
                      resolvingUnknownRow || Boolean(discardingUnknownRowKey)
                    }
                  >
                    Report Only
                  </Button>
                  <Tooltip
                    title={
                      discardingUnknownRowKey === getUnmatchedTallyRowId(row)
                        ? 'Discarding...'
                        : 'Discard unmatched value'
                    }
                  >
                    <Box
                      sx={{
                        gridColumn: { xs: '1 / -1', sm: 'auto' },
                        justifySelf: { xs: 'end', sm: 'stretch' },
                      }}
                    >
                      <IconButton
                        color="error"
                        aria-label={`Discard ${row.tallyLedgerName || 'unmatched value'}`}
                        onClick={() => setPendingUnmatchedDiscard(row)}
                        disabled={
                          resolvingUnknownRow ||
                          Boolean(discardingUnknownRowKey)
                        }
                        sx={{
                          width: 36,
                          height: 36,
                          border: '1px solid',
                          borderColor: '#FECACA',
                          borderRadius: 1,
                          bgcolor: '#FFF7F7',
                          '&:hover': {
                            bgcolor: '#FEF2F2',
                            borderColor: 'error.light',
                          },
                        }}
                      >
                        <Icons.DeleteOutlineIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  </Tooltip>
                </Box>
              </Box>
            ))}
          </Stack>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={Boolean(pendingUnmatchedDiscard)}
        title="Discard unmatched value?"
        message={`Are you sure you want to discard "${pendingUnmatchedDiscard?.tallyLedgerName || 'this unmatched value'}" from this report?`}
        confirmLabel={
          discardingUnknownRowKey ? 'Discarding...' : 'Yes, discard'
        }
        confirmColor="error.main"
        onConfirm={handleConfirmUnmatchedDiscard}
        onCancel={() => {
          if (!discardingUnknownRowKey) {
            setPendingUnmatchedDiscard(null);
          }
        }}
      />

      <EntityFormDialog
        open={unknownMasterDialogOpen}
        mode="create"
        title="Add Component to Master Data"
        fields={unknownMasterFields}
        initialValues={unknownMasterInitialValues}
        loading={resolvingUnknownRow}
        onFieldChange={handleUnknownMasterFieldChange}
        saveConfirmTitle={(values) =>
          `Add ${values.componentName?.trim() || 'this Component'} to Master Data?`
        }
        saveConfirmMessage={(values) =>
          `Add ${values.componentName?.trim() || 'this Component'} to Master Data and this report?`
        }
        saveConfirmLabel="Yes, add"
        onClose={() => {
          if (resolvingUnknownRow) return;
          setUnknownMasterDialogOpen(false);
          setActiveUnknownTallyRow(null);
          setAvailableFinancialSubCategories([]);
        }}
        onSave={(values) =>
          handleResolveUnknownTallyRow(values, 'MASTER_COMPONENT')
        }
      />

      <EntityFormDialog
        open={unknownReportOnlyDialogOpen}
        mode="create"
        title="Add Report-only Value"
        fields={unknownReportOnlyFields}
        initialValues={unknownReportOnlyInitialValues}
        loading={resolvingUnknownRow}
        onFieldChange={handleUnknownReportOnlyFieldChange}
        saveConfirmTitle={(values) =>
          `Add ${values.itemName?.trim() || 'this value'} as a report-only value?`
        }
        saveConfirmMessage={(values) =>
          `Add ${values.itemName?.trim() || 'this value'} to this report only?`
        }
        saveConfirmLabel="Yes, add"
        onClose={() => {
          if (resolvingUnknownRow) return;
          setUnknownReportOnlyDialogOpen(false);
          setActiveUnknownTallyRow(null);
          setAvailableFinancialSubCategories([]);
        }}
        onSave={(values) => handleResolveUnknownTallyRow(values, 'REPORT_ONLY')}
      />

      <EntityFormDialog
        open={fixedCostDialog.open}
        mode={fixedCostDialog.mode}
        title="Add Fixed Cost"
        fields={fixedCostFields}
        initialValues={fixedCostDialog.initialValues}
        loading={savingFixedCost}
        saveConfirmTitle={(values) =>
          values.itemName?.trim()
            ? `Add ${values.itemName.trim()} to Fixed Cost?`
            : 'Add this Fixed Cost?'
        }
        saveConfirmMessage={(values) =>
          values.itemName?.trim()
            ? `Are you sure you want to add ${values.itemName.trim()} to Fixed Cost?`
            : 'Are you sure you want to add this Fixed Cost?'
        }
        saveConfirmLabel="Yes, add"
        onClose={() => {
          if (savingFixedCost) {
            return;
          }

          setFixedCostDialog({
            open: false,
            mode: 'create',
            initialValues: {},
          });
        }}
        onSave={handleSaveFixedCost}
      />

      <EntityFormDialog
        open={addForecastRowDialog.open}
        mode="create"
        title={`Add Item to ${addForecastRowDialog.sectionName || 'Forecast'}`}
        fields={addForecastRowFields}
        initialValues={addForecastRowDialog.initialValues}
        loading={loadingMasterComponents || savingForecastRow}
        onFieldChange={handleAddForecastRowFieldChange}
        saveConfirmTitle={(values) => {
          const selectedComponent = availableMasterComponents.find(
            (component) => String(component._id) === String(values.componentId),
          );

          const itemName =
            values.addType === 'MASTER_COMPONENT'
              ? selectedComponent?.componentName
              : values.itemName;

          return `Add ${itemName || 'this item'} to ${
            addForecastRowDialog.sectionName || 'the report'
          }?`;
        }}
        saveConfirmMessage={(values) => {
          const selectedComponent = availableMasterComponents.find(
            (component) => String(component._id) === String(values.componentId),
          );

          const itemName =
            values.addType === 'MASTER_COMPONENT'
              ? selectedComponent?.componentName
              : values.itemName;

          return `Are you sure you want to add ${
            itemName || 'this item'
          } to the current Cash Flow Analysis ?`;
        }}
        saveConfirmLabel="Yes, add"
        onClose={() => {
          if (savingForecastRow) return;

          setAddForecastRowDialog({
            open: false,
            category: null,
            subCategory: null,
            sectionName: '',
            initialValues: {},
          });

          setAvailableMasterComponents([]);
          setForecastRowAddType('MASTER_COMPONENT');
        }}
        onSave={handleSaveForecastRow}
      />

      <EntityFormDialog
        open={addCashInflowDialog.open}
        mode="create"
        title="Add Cash Inflow"
        fields={addCashInflowFields}
        initialValues={addCashInflowDialog.initialValues}
        loading={loadingSummaryClients || savingCashInflow}
        onFieldChange={handleCashInflowFieldChange}
        saveConfirmTitle={(values) => {
          const selectedClient = availableSummaryClients.find(
            (client) => String(client._id) === String(values.clientId),
          );

          const itemName =
            values.addType === 'MASTER_CLIENT'
              ? selectedClient?.clientName
              : values.itemName;

          return `Add ${itemName || 'this Cash Inflow'}?`;
        }}
        saveConfirmMessage={(values) => {
          const selectedClient = availableSummaryClients.find(
            (client) => String(client._id) === String(values.clientId),
          );
          const itemName =
            values.addType === 'MASTER_CLIENT'
              ? selectedClient?.clientName
              : values.itemName;
          return `Are you sure you want to add ${
            itemName || 'this item'
          } to the Cash Flow Summary?`;
        }}
        saveConfirmLabel="Yes, add"
        onClose={() => {
          if (savingCashInflow) {
            return;
          }
          setAddCashInflowDialog({
            open: false,
            initialValues: {},
          });
          setAvailableSummaryClients([]);
          setCashInflowAddType('MASTER_CLIENT');
        }}
        onSave={handleSaveCashInflow}
      />

      <ConfirmDialog
        open={Boolean(removeTarget)}
        title="Remove item from report?"
        message={
          removeTarget
            ? removeTarget.type === 'FORECAST_ROW'
              ? `Are you sure you want to remove "${removeTarget.name}" from the current Cash Flow Analysis ? This will not delete the Component from Component Masters.`
              : `Are you sure you want to remove "${removeTarget.name}" from the current Cash Flow Analysis ?`
            : ''
        }
        confirmLabel={removingItem ? 'Removing...' : 'Yes, remove'}
        confirmColor="error.main"
        onConfirm={handleConfirmRemove}
        onCancel={() => {
          if (!removingItem) {
            setRemoveTarget(null);
          }
        }}
      />

      <ConfirmDialog
        open={Boolean(removeCashInflowTarget)}
        title="Remove Cash Inflow?"
        message={
          removeCashInflowTarget
            ? `Are you sure you want to remove "${removeCashInflowTarget.name}" from the Cash Flow Summary? This will not delete the Client from Client Masters.`
            : ''
        }
        confirmLabel={removingCashInflow ? 'Removing...' : 'Yes, remove'}
        confirmColor="error.main"
        onConfirm={handleConfirmRemoveCashInflow}
        onCancel={() => {
          if (!removingCashInflow) {
            setRemoveCashInflowTarget(null);
          }
        }}
      />

      <ConfirmDialog
        open={navigationBlocker.state === 'blocked'}
        title="Unsaved changes"
        message={`There are unsaved changes in the Cash Flow Analysis. Are you sure you want to continue to ${navigationDestinationName} without saving the report?`}
        confirmLabel={`Continue to ${navigationDestinationName}`}
        cancelLabel="Stay on this page"
        confirmColor="error.main"
        onConfirm={handleContinueNavigation}
        onCancel={handleStayOnCurrentPage}
      />
      <Snackbar
        open={message.open}
        autoHideDuration={3500}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        onClose={(_, reason) => {
          if (reason === 'clickaway') return;

          setMessage((current) => ({
            ...current,
            open: false,
          }));
        }}
      >
        <Alert
          severity={message.severity}
          variant="filled"
          onClose={() =>
            setMessage((current) => ({
              ...current,
              open: false,
            }))
          }
          sx={{
            alignItems: 'center',
            '& .MuiAlert-icon': {
              alignItems: 'center',
              display: 'flex',
            },
            '& .MuiAlert-message': {
              display: 'flex',
              alignItems: 'center',
            },
          }}
        >
          {message.text}
        </Alert>
      </Snackbar>

      <ForecastPdfPages
        ref={pdfPagesRef}
        open={renderPDFPages}
        sourcePeriod={sourcePeriod}
        forecastMonths={forecastMonths}
        rows={forecastRows}
        fixedCostRows={fixedCostRows}
        clientInflows={cashFlowSummary.clientInflows}
        discountsAndRefunds={cashFlowSummary.discountsAndRefunds}
        openingSurplusDeficit={cashFlowSummary.openingSurplusDeficit}
        previousMonthSurplusDeficit={
          calculatedCashFlowSummary.previousMonthSurplusDeficit
        }
        surplusDeficit={calculatedCashFlowSummary.surplusDeficit}
        cashOutflowTotals={cashOutflowTotals}
      />
    </Box>
  );
}