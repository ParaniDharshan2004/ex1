import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Container,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
  MenuItem,
} from '@mui/material';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutlined';
import { useLocation, useNavigate } from 'react-router-dom';
import { DataProvider } from '../context/DataContext.jsx';
import OperationalExpensesPage from './OperationalExpensesPage.jsx';
import ConfirmDialog from '../components/common-components/ConfirmDialog';
import {
  deleteOperationalExpenseReport,
  generateOperationalExpenseInvoice,
  getInvoiceAllocations,
  getOperationalExpenseReports,
  updateOperationalExpenseReportStatus,
} from '../utils/operational-expense/operationalExpenseApi.js';
import {
  InvoiceClientDialog,
  InvoiceDraftDialog,
  InvoiceLocationDialog,
} from '../components/operational-expense-components/InvoiceDialogs.jsx';
import OperationalExpenseDashboardCards from '../components/operational-expense-components/OperationalExpenseDashboardCards.jsx';
import OperationalExpenseDashboardTable from '../components/operational-expense-components/OperationalExpenseDashboardTable.jsx';
 
const getReportId = (report) => report?._id || report?.id;
 
const getSourceMonth = (report) => {
  const month = report?.reportMonth;
  if (/^\d{4}-(0[1-9]|1[0-2])$/.test(month || '')) {
    return new Date(`${month}-01T00:00:00`);
  }
 
  const date = report?.reportDate ? new Date(report.reportDate) : null;
  return date && !Number.isNaN(date.getTime()) ? date : null;
};
 
const formatMonth = (report) => {
  const date = getSourceMonth(report);
  return date
    ? date.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })
    : report?.reportMonth || 'Unknown month';
};
 
const getRows = (report) => (Array.isArray(report?.rows) ? report.rows : []);
 
const getMonthlyTotal = (report) =>
  Number(report?.totals?.operationalExpenseTotal ?? report?.monthlyTotal) ||
  getRows(report).reduce(
    (total, row) => total + (Number(row.amount) || 0),
    0,
  );
 
const formatAmount = (amount) =>
  (Number(amount) || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
 
export default function OperationalExpenseReportPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const workflowSection = {
    '/operational-expense-dashboard': 'dashboard',
    '/operational-expense-reports': 'reports',
    '/operational-expense-invoices': 'invoices',
    '/operational-expense-audit': 'audit',
  }[location.pathname] || 'reports';
  const [reports, setReports] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const loadingDetails = false;
  const [editingId, setEditingId] = useState(null);
  const [reportToDelete, setReportToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [invoiceAllocation, setInvoiceAllocation] = useState(null);
  const [invoiceAllocations, setInvoiceAllocations] = useState([]);
  const [invoiceClientDialogOpen, setInvoiceClientDialogOpen] = useState(false);
  const [invoiceLocationDialogOpen, setInvoiceLocationDialogOpen] =
    useState(false);
  const [invoiceDraftLocation, setInvoiceDraftLocation] = useState(null);
  const [invoiceDialogClientId, setInvoiceDialogClientId] = useState('');
  const [invoiceReportId, setInvoiceReportId] = useState('');
  const [invoiceLoading, setInvoiceLoading] = useState(false);
  const [exportingReportId, setExportingReportId] = useState('');
  const [invoiceData, setInvoiceData] = useState([]);
  const [invoicePageLoading, setInvoicePageLoading] = useState(false);
  const [invoiceYear, setInvoiceYear] = useState('all');
  const [invoiceMonth, setInvoiceMonth] = useState('all');
  const [calendarYear, setCalendarYear] = useState(String(new Date().getFullYear()));
  const [dashboardMonth, setDashboardMonth] = useState('all');
 
  useEffect(() => {
    let active = true;
 
    const loadReports = async () => {
      try {
        setErrorMessage('');
        const response = await getOperationalExpenseReports();
        if (active) setReports(response.data?.data || []);
      } catch (error) {
        if (active) {
          setErrorMessage(
            error.response?.data?.message ||
              'Unable to load Operational Expense reports.',
          );
        }
      } finally {
        if (active) setLoading(false);
      }
    };
 
    loadReports();
    return () => {
      active = false;
    };
  }, []);
 
  const filteredReports = useMemo(() => reports, [reports]);

  const reportYears = useMemo(() => [...new Set([new Date().getFullYear(), ...reports.map((report) => getSourceMonth(report)?.getFullYear()).filter(Number.isInteger)])].sort((a, b) => b - a).map(String), [reports]);

  useEffect(() => {
    if (workflowSection !== 'invoices' || !reports.length) return undefined;
    let active = true;
    Promise.resolve().then(() => active && setInvoicePageLoading(true));
    Promise.all(reports.map(async (report) => {
      try {
        const response = await getInvoiceAllocations(getReportId(report));
        return (response.data?.data || []).map((allocation) => ({ ...allocation, report }));
      } catch {
        return [];
      }
    })).then((groups) => active && setInvoiceData(groups.flat())).finally(() => active && setInvoicePageLoading(false));
    return () => { active = false; };
  }, [reports, workflowSection]);

  const invoiceYears = useMemo(
    () => [...new Set(invoiceData.map((item) => getSourceMonth(item.report)?.getFullYear()).filter(Number.isInteger))]
      .sort((left, right) => right - left)
      .map(String),
    [invoiceData],
  );

  const filteredInvoiceItems = useMemo(
    () => invoiceData.filter((item) => {
      const date = getSourceMonth(item.report);
      if (!date) return false;
      return (invoiceYear === 'all' || String(date.getFullYear()) === invoiceYear) &&
        (invoiceMonth === 'all' || String(date.getMonth() + 1).padStart(2, '0') === invoiceMonth);
    }),
    [invoiceData, invoiceMonth, invoiceYear],
  );

  const invoicePageItems = filteredInvoiceItems;

  const editReport = async (report) => {
    const reportId = getReportId(report);
    if (!reportId) return;
    if (report.status === 'INVOICED') {
      setErrorMessage('Invoiced Operational Expense reports cannot be edited.');
      return;
    }
    console.log('Report to edit:', report.status);
    try {
      setEditingId(String(reportId));
      setErrorMessage('');
      if (report.status !== 'DRAFT') {
        await updateOperationalExpenseReportStatus(reportId, 'DRAFT');
        setReports((current) =>
          current.map((item) =>
            String(getReportId(item)) === String(reportId)
              ? { ...item, status: 'DRAFT' }
              : item,
          ),
        );
      }
      navigate('/operational-expenses', {
        state: { operationalExpenseReportId: reportId },
      });
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message ||
          'Unable to edit the Operational Expense report.',
      );
    } finally {
      setEditingId(null);
    }
  };
 
  const deleteReport = async () => {
    if (!reportToDelete || deleting) return;
    const reportId = getReportId(reportToDelete);
 
    try {
      setDeleting(true);
      setErrorMessage('');
      await deleteOperationalExpenseReport(reportId);
      setReports((current) =>
        current.filter((report) => String(getReportId(report)) !== String(reportId)),
      );
      if (String(getReportId(selectedReport)) === String(reportId)) {
        setSelectedReport(null);
      }
      setReportToDelete(null);
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message ||
          'Unable to delete the Operational Expense report.',
      );
    } finally {
      setDeleting(false);
    }
  };

  const generateInvoice = async (report) => {
    const reportId = getReportId(report);
    if (!reportId) {
      setErrorMessage(
        'A valid report ID is required before generating an invoice.',
      );
      return;
    }

    try {
      setInvoiceLoading(true);
      setErrorMessage('');
      const response = await getInvoiceAllocations(reportId);
      const allocations = (response.data?.data || []).filter(
        (allocation) => allocation?.clientId,
      );
      if (!allocations.length) {
        setErrorMessage(
          'No client allocations are available for this report.',
        );
        return;
      }
      setInvoiceReportId(String(reportId));
      setInvoiceAllocations(allocations);
      setInvoiceClientDialogOpen(true);
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message || 'Unable to load invoice allocation.',
      );
    } finally {
      setInvoiceLoading(false);
    }
  };

  const exportReport = async (report) => {
    const reportId = getReportId(report);
    if (!reportId) return;
    try {
      if (report.status === 'DRAFT') {
        await updateOperationalExpenseReportStatus(reportId, 'FINALIZED');
        setReports((current) =>
          current.map((item) =>
            String(getReportId(item)) === String(reportId)
              ? { ...item, status: 'FINALIZED' }
              : item,
          ),
        );
      }
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message ||
          'Unable to finalize the Operational Expense report.',
      );
      return;
    }
    setExportingReportId(String(reportId));
  };

  const selectInvoiceClient = async (allocation) => {
    const clientId = String(allocation.clientId || '');
    if (!clientId || !invoiceReportId) {
      setErrorMessage('Valid report and client IDs are required.');
      return;
    }
    setInvoiceClientDialogOpen(false);
    setInvoiceDialogClientId(clientId);
    setInvoiceAllocation(allocation);
    if (allocation.locationAllocations?.length) {
      setInvoiceLocationDialogOpen(true);
    } else {
      await createInvoice(allocation, null, invoiceReportId, clientId);
    }
  };

  const createInvoice = async (
    allocation,
    location,
    reportId = invoiceReportId,
    clientId = invoiceDialogClientId,
  ) => {
    if (!reportId || !clientId || !allocation) {
      setErrorMessage('Valid report and client IDs are required.');
      return;
    }
    try {
      setInvoiceLoading(true);
      await generateOperationalExpenseInvoice(reportId, {
        clientId,
        locationId: location?.locationId || null,
      });
      setInvoiceLocationDialogOpen(false);
      setInvoiceDraftLocation(
        location || { locationId: null, isClientLevel: true },
      );
    } catch (error) {
      setErrorMessage(
        error.response?.data?.message || 'Unable to generate invoice.',
      );
    } finally {
      setInvoiceLoading(false);
    }
  };
 
  return (
    <Container maxWidth="xl" sx={{ py: { xs: 2, sm: 2.5, md: 3 } }}>
      <Stack spacing={2}>
        <Box>
          <Typography variant="h5" fontWeight={700}>
            Operational Expense Reports
          </Typography>
          <Typography variant="body2" color="text.secondary">
            View and manage saved monthly reports.
          </Typography>
        </Box>
 
        {errorMessage && <Alert severity="error">{errorMessage}</Alert>}

        {!selectedReport && workflowSection === 'dashboard' && (
          <Stack spacing={2}>
          
            <OperationalExpenseDashboardCards reports={reports} />
            <Paper variant="outlined" sx={{ p: { xs: 1.5, sm: 2.5 }, borderRadius: 2.5 }}>
              <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'stretch', md: 'center' }} spacing={1.5} mb={2}><Box><Typography variant="h6" fontWeight={800}>Monthly records</Typography><Typography variant="body2" color="text.secondary">Select Continue, View or Start Again based on the workflow status.</Typography></Box><Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}><TextField select size="small" label="Year" value={calendarYear} onChange={(event) => setCalendarYear(event.target.value)} sx={{ minWidth: { xs: '100%', sm: 110 } }}>{reportYears.map((year) => <MenuItem key={year} value={year}>{year}</MenuItem>)}</TextField><TextField select size="small" label="Month" value={dashboardMonth} onChange={(event) => setDashboardMonth(event.target.value)} sx={{ minWidth: { xs: '100%', sm: 180 } }}><MenuItem value="all">All months</MenuItem>{Array.from({ length: 12 }, (_, index) => { const value = String(index + 1).padStart(2, '0'); return <MenuItem key={value} value={value}>{new Date(2000, index, 1).toLocaleDateString('en-IN', { month: 'long' })}</MenuItem>; })}</TextField></Stack></Stack>
              <OperationalExpenseDashboardTable reports={reports} selectedYear={calendarYear} month={dashboardMonth} onEdit={editReport} onExport={exportReport} onGenerate={generateInvoice} onDelete={setReportToDelete} />
            </Paper>
          </Stack>
        )}

        {!selectedReport && workflowSection === 'audit' && (
          <Paper variant="outlined" sx={{ p: { xs: 3, sm: 5 }, textAlign: 'center', borderRadius: 2.5 }}>
            <Typography variant="h6" fontWeight={800}>Audit Trail unavailable</Typography>
            <Typography color="text.secondary" sx={{ mt: 1 }}>The current Operational Expense API does not expose audit events. No audit records are fabricated in the frontend.</Typography>
          </Paper>
        )}

        {!selectedReport && workflowSection === 'invoices' && (
          <Paper variant="outlined" sx={{ p: { xs: 1.5, sm: 2.5 }, borderRadius: 2.5 }}>
            <Typography variant="h6" fontWeight={800}>Operational Expense Invoices</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>Confirmed client and location allocations available for invoice generation.</Typography>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} sx={{ mb: 2 }}>
              <TextField select size="small" label="Year" value={invoiceYear} onChange={(event) => setInvoiceYear(event.target.value)} sx={{ minWidth: 130 }}><MenuItem value="all">All years</MenuItem>{invoiceYears.map((year) => <MenuItem key={year} value={year}>{year}</MenuItem>)}</TextField>
              <TextField select size="small" label="Month" value={invoiceMonth} onChange={(event) => setInvoiceMonth(event.target.value)} sx={{ minWidth: 160 }}><MenuItem value="all">All months</MenuItem>{Array.from({ length: 12 }, (_, index) => { const value = String(index + 1).padStart(2, '0'); return <MenuItem key={value} value={value}>{new Date(2000, index, 1).toLocaleDateString('en-IN', { month: 'long' })}</MenuItem>; })}</TextField>
            </Stack>
            {invoicePageLoading ? <Typography color="text.secondary">Loading invoice allocations...</Typography> : invoicePageItems.length === 0 ? <Typography color="text.secondary">No confirmed invoice allocations are available.</Typography> : <Stack spacing={1}>{invoicePageItems.map((item) => <Stack key={`${getReportId(item.report)}-${item.clientId}`} direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" spacing={1} sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}><Box><Typography fontWeight={700}>{item.clientName || item.clientCode || 'Client'}</Typography><Typography variant="caption" color="text.secondary">{formatMonth(item.report)} · {item.clientCode || '—'}</Typography></Box><Stack direction="row" spacing={1} alignItems="center"><Typography fontWeight={800}>₹{formatAmount(item.clientTotalAmount)}</Typography><Button variant="outlined" size="small" onClick={() => generateInvoice(item.report)}>Preview / Generate</Button></Stack></Stack>)}</Stack>}
          </Paper>
        )}
 
        {!selectedReport && workflowSection === 'reports' && (
          <Stack spacing={2}>
            {loading ? (
              <Paper variant="outlined" sx={{ p: 5, textAlign: 'center' }}>
                <Typography fontWeight={700}>Loading saved reports...</Typography>
              </Paper>
            ) : filteredReports.length === 0 ? (
              <Paper variant="outlined" sx={{ p: 5, textAlign: 'center' }}>
                <Typography fontWeight={700}>No saved reports found</Typography>
                <Typography variant="body2" color="text.secondary">
                  Import and save an Operational Expense report to see it here.
                </Typography>
              </Paper>
            ) : (
              filteredReports.map((report) => (
                <Card key={getReportId(report)} variant="outlined" sx={{ borderRadius: 2 }}>
                  <CardContent sx={{ p: { xs: 2, sm: 2.5 } }}>
                    <Stack
                      direction={{ xs: 'column', md: 'row' }}
                      alignItems={{ xs: 'stretch', md: 'center' }}
                      justifyContent="space-between"
                      spacing={2}
                      sx={{ alignItems: { xs: 'stretch', md: 'center' }, justifyContent: { xs: 'space-between' }}}
                    >
                      <Box
                        sx={{ flex: 1, minWidth: 0 }}
                      >
                        <Stack direction="row" alignItems="center" spacing={1.5}>
                          <Typography variant="h6" fontWeight={800}>
                            {formatMonth(report)}
                          </Typography>
                          <Chip
                            size="small"
                            label={
                              report.status === 'INVOICED'
                                ? 'Invoiced'
                                : report.status === 'FINALIZED'
                                ? 'Finalized'
                                : report.status === 'ARCHIVED'
                                  ? 'Archived'
                                  : 'Draft'
                            }
                            color={
                              report.status === 'INVOICED' ||
                              report.status === 'FINALIZED'
                                ? 'success'
                                : 'default'
                            }
                          />
                        </Stack>
                        <Typography variant="caption" color="text.secondary">
                          Saved on{' '}
                          {report.updatedAt || report.createdAt
                            ? new Date(report.updatedAt || report.createdAt).toLocaleDateString('en-IN')
                            : '-'}
                        </Typography>
                      </Box>
                      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
                        <Button
                          variant="outlined"
                          onClick={() => exportReport(report)}
                          disabled={
                            exportingReportId === String(getReportId(report))
                          }
                        >
                          Export Report
                        </Button>
                        <Button
                          variant="outlined"
                          onClick={() => generateInvoice(report)}
                          disabled={invoiceLoading}
                        >
                          Generate Invoice
                        </Button>
                        <Button
                          variant="contained"
                          startIcon={<EditOutlinedIcon />}
                          onClick={() => editReport(report)}
                          disabled={report.status === 'INVOICED' || editingId !== null}
                        >
                          {editingId === String(getReportId(report)) ? 'Opening...' : 'Edit'}
                        </Button>
                        <Button
                          variant="outlined"
                          color="error"
                          startIcon={<DeleteOutlineIcon />}
                          onClick={() => setReportToDelete(report)}
                          disabled={report.status === 'INVOICED'}
                        >
                          Delete
                        </Button>
                      </Stack>
                    </Stack>
                  </CardContent>
                </Card>
              ))
            )}
          </Stack>
        )}
 
        {selectedReport && (
          <Stack spacing={2}>
            {loadingDetails ? (
              <Paper variant="outlined" sx={{ p: 5, textAlign: 'center' }}>
                <Typography fontWeight={700}>Loading report...</Typography>
              </Paper>
            ) : (
              <Paper variant="outlined" sx={{ overflow: 'hidden' }}>
                <Box sx={{ px: 2, py: 1.5, bgcolor: 'background.default' }}>
                  <Typography variant="h6" fontWeight={800}>
                    Operational Expense Report - {formatMonth(selectedReport)}
                  </Typography>
                </Box>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Expense</TableCell>
                        <TableCell>Category</TableCell>
                        <TableCell>Subcategory</TableCell>
                        <TableCell align="right">Monthly Amount</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {getRows(selectedReport).map((row, index) => (
                        <TableRow key={row._id || row.id || `${row.name}-${index}`}>
                          <TableCell>{row.componentName || '-'}</TableCell>
                          <TableCell>
                            {row.financialCategoryName || row.financialCategoryCode || '-'}
                          </TableCell>
                          <TableCell>
                            {(row.matchedTallyLedgers || [])
                              .filter((ledger) => ledger.matchType === 'SUBCOMPONENT')
                              .map((ledger) => ledger.subComponentName)
                              .filter(Boolean)
                              .join(', ') || '-'}
                          </TableCell>
                          <TableCell align="right">
                            {formatAmount(row.amount)}
                          </TableCell>
                        </TableRow>
                      ))}
                      <TableRow>
                        <TableCell colSpan={3} align="right" sx={{ fontWeight: 800 }}>
                          Operational Expense Total
                        </TableCell>
                        <TableCell align="right" sx={{ fontWeight: 800 }}>
                          {formatAmount(getMonthlyTotal(selectedReport))}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
                <Stack
                  direction={{ xs: 'column', sm: 'row' }}
                  flexWrap="wrap"
                  spacing={{ xs: 0.5, sm: 3 }}
                  sx={{ px: 2, py: 1.5, borderTop: '1px solid', borderColor: 'divider' }}
                >
                  <Typography variant="body2">
                    Sub Total: {formatAmount(selectedReport.totals?.subtotal)}
                  </Typography>
                  <Typography variant="body2">
                    Markup: {formatAmount(selectedReport.markup?.amount)}
                  </Typography>
                  <Typography variant="body2">
                    MKPL: {formatAmount(
                      getRows(selectedReport).length
                        ? (selectedReport.allocations || [])
                            .filter((allocation) =>
                              `${allocation.clientCode} ${allocation.clientName}`
                                .toLowerCase()
                                .includes('mkpl'),
                            )
                            .reduce((total, allocation) => total + (Number(allocation.amount) || 0), 0)
                        : 0,
                    )}
                  </Typography>
                  <Typography variant="body2">
                    CRKLIN: {formatAmount(
                      (selectedReport.allocations || [])
                        .filter((allocation) =>
                          `${allocation.clientCode} ${allocation.clientName}`
                            .toLowerCase()
                            .includes('crklin'),
                        )
                        .reduce((total, allocation) => total + (Number(allocation.amount) || 0), 0),
                    )}
                  </Typography>
                </Stack>
              </Paper>
            )}
          </Stack>
        )}
      </Stack>
 
      <ConfirmDialog
        open={Boolean(reportToDelete)}
        title="Delete this Operational Expense report?"
        message={
          reportToDelete
            ? `This permanently deletes the ${formatMonth(reportToDelete)} report. This action cannot be undone.`
            : ''
        }
        confirmLabel={deleting ? 'Deleting...' : 'Yes, delete'}
        confirmColor="error.main"
        onConfirm={deleteReport}
        onCancel={() => {
          if (!deleting) setReportToDelete(null);
        }}
      />
      <InvoiceClientDialog
        open={invoiceClientDialogOpen}
        allocations={invoiceAllocations}
        loading={invoiceLoading}
        onClose={() => setInvoiceClientDialogOpen(false)}
        onSelect={selectInvoiceClient}
      />
      <InvoiceLocationDialog
        open={invoiceLocationDialogOpen}
        allocation={invoiceAllocation}
        loading={invoiceLoading}
        onClose={() => setInvoiceLocationDialogOpen(false)}
        onSelect={(location) => createInvoice(invoiceAllocation, location)}
      />
      <InvoiceDraftDialog
        open={Boolean(invoiceDraftLocation)}
        allocation={invoiceAllocation}
        location={invoiceDraftLocation}
        reportMonth={selectedReport?.reportMonth || invoiceAllocation?.reportMonth}
        onClose={() => setInvoiceDraftLocation(null)}
        onDownloaded={async () => {
          await updateOperationalExpenseReportStatus(
            invoiceReportId,
            'INVOICED',
          );
          setReports((current) =>
            current.map((report) =>
              String(getReportId(report)) === String(invoiceReportId)
                ? { ...report, status: 'INVOICED' }
                : report,
            ),
          );
        }}
      />
      <Box
        aria-hidden="true"
        sx={{
          position: 'absolute',
          left: '-100000px',
          top: 0,
          width: '1200px',
          opacity: 0,
          pointerEvents: 'none',
        }}
      >
        <DataProvider>
          <OperationalExpensesPage
            exportReportId={exportingReportId}
            onExportComplete={() => setExportingReportId('')}
          />
        </DataProvider>
      </Box>
    </Container>
  );
}
 
