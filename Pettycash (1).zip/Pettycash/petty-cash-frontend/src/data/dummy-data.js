import { Icons } from "../theme/icons";

export const NAV_ITEMS = [
  {
    label: "Dashboard",
    icon: Icons.DashboardIcon,
    to: "/",
  },

  {
    label: "Petty Cash",
    icon: Icons.AccountBalanceWalletIcon,

    children: [
      {
        label: "Transactions",
        to: "/transactions",
      },
      {
        label: "Cash Inflow",
        to: "/cash-inflow",
      },
      {
        label: "Reports",
        to: "/pettycash-report",
      },
    ],
  },

  {
    label: "Cash Flow",
    icon: Icons.TrendingUpIcon,

    children: [
      // {
      //   label: "Cash Flow Entry",
      //   icon: Icons.TrendingUpIcon,
      //   to: "/cash-flow-entry",
      // },
      {
        label: "Cash Flow Analysis",
        icon: Icons.TrendingUpIcon,
        to: "/cash-flow-analysis",
      },
      {
        label: "Cash Flow Report",
        icon: Icons.TrendingUpIcon,
        to: "/cash-flow-report",
      },
    ],
  },

  {
    label: "Operational Expense",
    icon: Icons.ReceiptLongIcon,
    children: [
      {
        label: "Dashboard",
        icon: Icons.DashboardIcon,
        to: "/operational-expense-dashboard",
      },
      {
        label: "Upload & Review",
        icon: Icons.ReceiptLongIcon,
        to: "/operational-expenses",
      },
      {
        label: "Reports",
        icon: Icons.TrendingUpIcon,
        to: "/operational-expense-reports",
      },
      {
        label: "Invoices",
        icon: Icons.ReceiptLongIcon,
        to: "/operational-expense-invoices",
      },
      {
        label: "Audit Trail",
        icon: Icons.PendingActionsIcon,
        to: "/operational-expense-audit",
      },
    ],
  },

  {
    label: "Masters",
    icon: Icons.PeopleIcon,

    children: [
      {
        label: "Components",
        to: "/add-components",
      },
      {
        label: "Clients",
        to: "/clients",
      },
      // {
      //   label: "Sender Accounts",
      //   to: "/sender-accounts",
      // },
      // {
      //   label: "Petty Cash Accounts",
      //   to: "/pettycash-accounts",
      // },
    ],
  },
];

export const STATUS_STYLES = {
  approved: { color: "success", bg: "#1E7F5C1A", label: "Approved" },
  pending: { color: "pending", bg: "#B8860B1A", label: "Pending" },
  rejected: { color: "error", bg: "#B3261E1A", label: "Rejected" },
};

export const A4_WIDTH_PX = 794;
export const A4_HEIGHT_PX = 1123;

export const PDF_ROWS_PER_PAGE = 15;
export const PDF_PAGE_PADDING = 44;

export const ACCEPTED_EXCEL_EXTENSIONS = ["xlsx", "xls"];

export const FORECAST_FIELDS = ["month1", "month2", "month3"];

export const IGNORED_ROW_LABELS = new Set([
  "",
  "particulars",
  "transactions",
  "transaction",
  "debit",
  "debit amount",
  "credit",
  "total",
  "grand total",
  "opening balance",
  "closing balance",
  "indirect expenses",
]);

export const INITIAL_MESSAGE_STATE = {
  open: false,
  text: "",
  severity: "success",
};

export const CARD_SX = {
  width: "100%",
  maxWidth: "100%",
  minWidth: 0,
  boxSizing: "border-box",
  borderRadius: 1,
  border: "1px solid",
  borderColor: "divider",
  overflow: "hidden",
  backgroundColor: "background.paper",
};

export const PDF_PAGE_SX = {
  position: "relative",

  width: `${A4_WIDTH_PX}px`,
  minWidth: `${A4_WIDTH_PX}px`,
  maxWidth: `${A4_WIDTH_PX}px`,

  height: `${A4_HEIGHT_PX}px`,
  minHeight: `${A4_HEIGHT_PX}px`,
  maxHeight: `${A4_HEIGHT_PX}px`,

  boxSizing: "border-box",
  overflow: "hidden",

  backgroundColor: "#ffffff",
  color: "#172033",

  px: `${PDF_PAGE_PADDING}px`,
  pt: "40px",
  pb: "68px",

  fontFamily: '"DM Sans", sans-serif',
};
