import { Routes, Route, Navigate, useLocation, useParams } from "react-router-dom";

import { ThemeProvider, CssBaseline } from "@mui/material";

import { useState } from "react";

import buildTheme from "./theme";

import Dashboard from "./pages/Dashboard";
import PettyCashPage from "./pages/PettyCashPage";
import CashInflowPage from "./pages/CashInflowPage";
import AddComponentsPage from "./pages/AddComponents";
import LoginPage from "./pages/LoginPage";

import ProtectedRoute from "./routes/ProtectedRoute";
import AppLayout from "./routes/AppLayout";
import ReportsPage from "./pages/ReportsPage"
import CashFlowForecastPage from "./pages/CashFlowForcastPage";
import CashFlowEntriesPage from "./pages/CashFlowEntriesPage";
import CashFlowReportPage from "./pages/CashFlowReportPage";
import ClientsPage from "./pages/ClientsPage";
import OperationalExpensesPage from "./pages/OperationalExpensesPage";
import OperationalExpenseReportPage from "./pages/OperationalExpenseReportPage";
import { DataProvider } from "./context/DataContext.jsx";

export const backendUrl = import.meta.env.VITE_BACKEND_URL;

function OperationalExpensesRoute() {
  const location = useLocation();
  const { reportId } = useParams();
  const queryReportId = new URLSearchParams(location.search).get("reportId");
  const requestedReportId = reportId || queryReportId;

  if (requestedReportId) {
    return (
      <Navigate
        to="/operational-expenses"
        replace
        state={{ operationalExpenseReportId: requestedReportId }}
      />
    );
  }

  return (
    <DataProvider>
      <OperationalExpensesPage />
    </DataProvider>
  );
}

function OperationalExpenseDashboardRoute() {
  return <DataProvider><OperationalExpenseReportPage /></DataProvider>;
}

function OperationalExpenseReportsRoute() {
  return <DataProvider><OperationalExpenseReportPage /></DataProvider>;
}

function OperationalExpenseInvoicesRoute() {
  return <DataProvider><OperationalExpenseReportPage /></DataProvider>;
}

function OperationalExpenseAuditRoute() {
  return <DataProvider><OperationalExpenseReportPage /></DataProvider>;
}

function App() {
  const [mode] = useState("light");

  const theme = buildTheme(mode);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      <Routes>
        {/* Public Route */}
        <Route path="/login" element={<LoginPage />} />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<AppLayout />}>
            <Route path="/" element={<Dashboard />} />

            <Route path="/transactions" element={<PettyCashPage />} />

            <Route path="/cash-inflow" element={<CashInflowPage />} />

            <Route path="/add-components" element={<AddComponentsPage />} />
            <Route path="/clients" element={<ClientsPage />} />

            <Route path="/pettycash-report" element={<ReportsPage />} />
            <Route path="/cash-flow-entry" element={<CashFlowEntriesPage />}/>
            <Route path="/cash-flow-analysis" element={<CashFlowForecastPage />}/>
            <Route path="/cash-flow-report" element={<CashFlowReportPage />}/>
            <Route path="/operational-expenses" element={<OperationalExpensesRoute />} />
            <Route path="/operational-expenses/:reportId" element={<OperationalExpensesRoute />} />
            <Route path="/operational-expense-report" element={<Navigate to="/operational-expense-reports" replace />} />
            <Route path="/operational-expense-dashboard" element={<OperationalExpenseDashboardRoute />} />
            <Route path="/operational-expense-reports" element={<OperationalExpenseReportsRoute />} />
            <Route path="/operational-expense-invoices" element={<OperationalExpenseInvoicesRoute />} />
            <Route path="/operational-expense-audit" element={<OperationalExpenseAuditRoute />} />
            {/* <Route path="/sender-accounts" element={<SenderAccountsPage />}/>
            <Route path="/pettycash-accounts" element={<CashAccountsPage />}/> */}
          </Route>
        </Route>

        {/* Default Redirect */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;
