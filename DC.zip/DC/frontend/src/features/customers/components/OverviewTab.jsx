import { useState } from 'react';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { EmptyState } from '@/components/feedback/PageStates';
import EntityLink from '@/components/ui/EntityLink';
import Money from '@/components/ui/Money';
import StatusChip from '@/components/ui/StatusChip';
import AddressCard from './AddressCard';
import { formatDate } from '@/utils/format';

function SummaryCard({ label, value }) {
  return (
    <Paper variant="outlined" sx={{ p: 2 }}>
      <Typography variant="body2" color="text.secondary">
        {label}
      </Typography>
      <Typography variant="h2" sx={{ mt: 0.5 }}>
        {value}
      </Typography>
    </Paper>
  );
}

export default function OverviewTab({ data, onCreateBooking }) {
  const { summary, addresses, subscriptions, bookings, payments, invoices } = data;
  const defaultAddress = addresses.find((a) => a.isDefault) || addresses[0];
  const [expandedGroups, setExpandedGroups] = useState({});

  const groupedNextVisits = (subscriptions || [])
    .map((subscription, index) => {
      const upcomingVisits = (subscription.visits || [])
        .filter((visit) => !visit.isCompleted && !visit.isCancelled)
        .sort(
          (a, b) =>
            new Date(a.date || a.scheduledStartDateTime) -
            new Date(b.date || b.scheduledStartDateTime),
        );

      return {
        id: subscription.id || subscription.subscriptionNumber || `subscription-${index}`,
        label: `Subscription ${index + 1}`,
        planName: subscription.planName || subscription.currentPeriod?.planName || 'Subscription',
        visits: upcomingVisits,
      };
    })
    .filter((group) => group.visits.length > 0);

  const toggleGroup = (groupId) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} md={8}>
        <Stack spacing={3}>
          <Grid container spacing={2}>
            <Grid item xs={6} sm={3}>
              <SummaryCard label="Addresses" value={summary.addressCount} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <SummaryCard label="Total Bookings" value={summary.totalBookings} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <SummaryCard label="Active Plans" value={summary.activeSubscriptions} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <SummaryCard label="Visits Done" value={summary.visitsCompleted} />
            </Grid>
          </Grid>

          <Paper variant="outlined" sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="h3" sx={{ mb: 2 }}>
              Upcoming Visits
            </Typography>
            {groupedNextVisits.length === 0 ? (
              <EmptyState title="No upcoming visits scheduled" description="Next visits will appear here once bookings or subscriptions are created." />
            ) : (
              <Stack spacing={2}>
                {groupedNextVisits.map((group) => {
                  const isExpanded = !!expandedGroups[group.id];
                  const displayedVisits = isExpanded ? group.visits : group.visits.slice(0, 1);

                  return (
                    <Paper key={group.id} variant="outlined" sx={{ p: 2, borderRadius: 2.5, bgcolor: '#fafafa' }}>
                      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                        <Stack direction="row" spacing={1} alignItems="center">
                          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                            {group.label}
                          </Typography>
                          <Chip label={group.planName} size="small" variant="outlined" />
                        </Stack>

                        {group.visits.length > 1 && (
                          <IconButton size="small" onClick={() => toggleGroup(group.id)}>
                            {isExpanded ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                          </IconButton>
                        )}
                      </Stack>

                      <Stack spacing={1}>
                        {displayedVisits.map((visit) => (
                          <Stack key={visit.id} direction="row" justifyContent="space-between" alignItems="center" sx={{ p: 1.5, bgcolor: '#ffffff', borderRadius: 2, border: '1px solid #eeeeee' }}>
                            <Box>
                              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                                {formatDate(visit.date || visit.scheduledStartDateTime)}
                              </Typography>
                              <Typography variant="caption" color="text.secondary">
                                {visit.slotLabel || 'Time slot'}
                              </Typography>
                            </Box>
                            <StatusChip status={visit.status || 'Scheduled'} />
                          </Stack>
                        ))}
                      </Stack>
                    </Paper>
                  );
                })}
              </Stack>
            )}
          </Paper>

          <Paper variant="outlined" sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="h3" sx={{ mb: 2 }}>
              Recent Payments & Invoices
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
                  Payments ({payments.length})
                </Typography>
                <Stack spacing={1}>
                  {payments.slice(0, 3).map((p) => (
                    <Stack key={p.id} direction="row" justifyContent="space-between" alignItems="center" sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}>
                      <EntityLink type="Payment" id={p.paymentNumber} />
                      <Money value={p.amount} />
                    </Stack>
                  ))}
                  {payments.length === 0 && <Typography variant="body2" color="text.secondary">No payments yet</Typography>}
                </Stack>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
                  Invoices ({invoices.length})
                </Typography>
                <Stack spacing={1}>
                  {invoices.slice(0, 3).map((inv) => (
                    <Stack key={inv.id} direction="row" justifyContent="space-between" alignItems="center" sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 2 }}>
                      <EntityLink type="Invoice" id={inv.invoiceNumber} />
                      <Money value={inv.amount} />
                    </Stack>
                  ))}
                  {invoices.length === 0 && <Typography variant="body2" color="text.secondary">No invoices yet</Typography>}
                </Stack>
              </Grid>
            </Grid>
          </Paper>
        </Stack>
      </Grid>

      <Grid item xs={12} md={4}>
        <Stack spacing={3}>
          {defaultAddress && (
            <Paper variant="outlined" sx={{ p: 3, borderRadius: 3 }}>
              <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
                Primary Service Address
              </Typography>
              <AddressCard address={defaultAddress} onCreateBooking={onCreateBooking} />
            </Paper>
          )}

          <Paper variant="outlined" sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
              Lifetime Value
            </Typography>
            <Money value={summary.lifetimeCollected} sx={{ fontSize: '1.75rem', fontWeight: 700, color: 'primary.main' }} />
          </Paper>
        </Stack>
      </Grid>
    </Grid>
  );
}
