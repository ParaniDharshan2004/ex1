import { apiFetch } from "@/services/http/client.js";

export async function fetchBathroomConfigs() {
  const [counts, durations, pricings] = await Promise.all([
    apiFetch("/bathroom-counts").catch(() => []),
    apiFetch("/service-durations").catch(() => []),
    apiFetch("/pricing").catch(() => []),
  ]);

  const countsList = Array.isArray(counts) ? counts : [];
  const durationsList = Array.isArray(durations) ? durations : [];
  const pricingsList = Array.isArray(pricings) ? pricings : [];

  return countsList
    .filter((countItem) => countItem?.bathroomCount !== undefined && countItem?.bathroomCount !== null)
    .map((countItem) => {
      const countValue = Number(countItem.bathroomCount);
      const countId = countItem._id || null;

      const activePricing = pricingsList.find((p) => {
        const matchedCount = Number(
          p.bathroomCountReference?.bathroomCount ??
          p.bathroomCountId?.bathroomCount ??
          p.bathroomCount ??
          0,
        );
        return matchedCount === countValue && p.isActive !== false;
      }) || pricingsList.find((p) => {
        return String(p.bathroomCountReference?._id || p.bathroomCountReference || p.bathroomCountId?._id || '') === String(countId) && p.isActive !== false;
      });

      const durationObj = activePricing?.serviceDurationReference || activePricing?.serviceDurationId || null;
      const durationMins =
        typeof durationObj === "object" && durationObj !== null
          ? Number(durationObj.durationMinutes ?? 0)
          : "";

      return {
        count: countValue,
        price: activePricing ? Number(activePricing.price) : "",
        durationMinutes: durationMins,
        isActive: activePricing ? activePricing.isActive !== false : true,
        pricingId: activePricing?._id || null,
        bathroomCountId: countId,
        serviceDurationId: typeof durationObj === "object" && durationObj !== null ? durationObj?._id : null,
      };
    })
    .sort((a, b) => Number(a.count) - Number(b.count));
}

export async function saveBathroomConfig(item) {
  const priceNum = Number(item.price);
  const durationNum = Number(item.durationMinutes);

  let bCountId = item.bathroomCountId;
  if (!bCountId) {
    const counts = await apiFetch("/bathroom-counts").catch(() => []);
    const existing = counts.find((c) => Number(c.bathroomCount) === item.count);
    if (existing) {
      bCountId = existing._id;
    } else {
      const newCnt = await apiFetch("/bathroom-counts", {
        method: "POST",
        body: JSON.stringify({ bathroomCount: item.count, isActive: true }),
      });
      bCountId = newCnt._id;
    }
  }

  let sDurationId = item.serviceDurationId;
  const durations = await apiFetch("/service-durations").catch(() => []);
  const existingDur = durations.find((d) => Number(d.durationMinutes) === durationNum);
  if (existingDur) {
    sDurationId = existingDur._id;
  } else {
    const newDur = await apiFetch("/service-durations", {
      method: "POST",
      body: JSON.stringify({ durationMinutes: durationNum, isActive: true }),
    });
    sDurationId = newDur._id;
  }

  if (item.pricingId) {
    return apiFetch(`/pricing/${item.pricingId}`, {
      method: "PUT",
      body: JSON.stringify({
        price: priceNum,
        bathroomCountReference: bCountId,
        serviceDurationReference: sDurationId,
        isActive: item.isActive,
      }),
    });
  }

  return apiFetch("/pricing", {
    method: "POST",
    body: JSON.stringify({
      price: priceNum,
      bathroomCountReference: bCountId,
      serviceDurationReference: sDurationId,
      isActive: item.isActive,
      deactivatePrevious: true,
    }),
  });
}
