import { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Alert from '@mui/material/Alert';
import CircularProgress from '@mui/material/CircularProgress';
import Divider from '@mui/material/Divider';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';
import InputAdornment from '@mui/material/InputAdornment';
import {
  SaveIcon,
  EditIcon,
  RefreshIcon,
  AccessTimeOutlinedIcon,
  BathtubOutlinedIcon,
  AdminPanelSettingsOutlinedIcon,
} from '@/theme/icons';

import PageHeader from '@/components/layout/PageHeader';
import { useBathroomConfigs, useSaveBathroomConfig } from '../hooks/useSettings.js';
import { useSnackbar } from '@/components/feedback/SnackbarProvider';

export default function SettingsPage() {
  const snackbar = useSnackbar();
  const { data: fetchedConfigs = [], isLoading, isError, error, refetch } = useBathroomConfigs();
  const saveMutation = useSaveBathroomConfig();

  const [savingCount, setSavingCount] = useState(null);
  const [editingState, setEditingState] = useState({});

  const handleEdit = (item) => {
    setEditingState((prev) => ({
      ...prev,
      [item.count]: {
        price: item.price,
        durationMinutes: item.durationMinutes,
        isActive: item.isActive,
        errors: {},
      },
    }));
  };

  const handleCancel = (count) => {
    setEditingState((prev) => {
      const copy = { ...prev };
      delete copy[count];
      return copy;
    });
  };

  const handleChange = (count, field, value) => {
    setEditingState((prev) => {
      const current = prev[count] || {};
      const updated = { ...current, [field]: value };
      const errors = { ...updated.errors };
      if (field === 'price' && value >= 0) delete errors.price;
      if (field === 'durationMinutes' && value > 0) delete errors.durationMinutes;
      return { ...prev, [count]: { ...updated, errors } };
    });
  };

  const handleSave = async (item) => {
    const editValues = editingState[item.count] || {};
    const priceVal = editValues.price !== undefined ? editValues.price : item.price;
    const durationVal = editValues.durationMinutes !== undefined ? editValues.durationMinutes : item.durationMinutes;
    const isActiveVal = editValues.isActive !== undefined ? editValues.isActive : item.isActive;

    const priceNum = Number(priceVal);
    const durationNum = Number(durationVal);

    const errors = {};
    if (isNaN(priceNum) || priceNum < 0) {
      errors.price = 'Price must be a valid non-negative number';
    }
    if (isNaN(durationNum) || durationNum <= 0) {
      errors.durationMinutes = 'Duration must be greater than 0 minutes';
    }

    if (Object.keys(errors).length > 0) {
      setEditingState((prev) => ({
        ...prev,
        [item.count]: {
          price: priceVal,
          durationMinutes: durationVal,
          isActive: isActiveVal,
          errors,
        },
      }));
      return;
    }

    setSavingCount(item.count);
    try {
      await saveMutation.mutateAsync({
        ...item,
        price: priceNum,
        durationMinutes: durationNum,
        isActive: isActiveVal,
      });
      snackbar.success(`${item.count} Bathroom configuration saved successfully.`);
      setEditingState((prev) => {
        const copy = { ...prev };
        delete copy[item.count];
        return copy;
      });
    } catch (err) {
      snackbar.error(`Failed to save configuration: ${err.message}`);
    } finally {
      setSavingCount(null);
    }
  };

  return (
    <Stack spacing={3}>
      <PageHeader
        title="Settings & Administration"
        subtitle="Configure Super Admin system parameters, service pricing, and cleaning durations."
        icon={AdminPanelSettingsOutlinedIcon}
        action={
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={() => refetch()}
            disabled={isLoading}
            sx={{
              borderRadius: 2,
              px: 2,
              py: 1,
              fontWeight: 600,
            }}
          >
            Refresh
          </Button>
        }
      />

      {isError && <Alert severity="error" sx={{ borderRadius: 2 }}>{error?.message || 'Failed to load bathroom pricing configuration.'}</Alert>}

      {isLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Paper
          sx={{
            p: { xs: 2.5, sm: 3 },
            borderRadius: 4,
            background: 'linear-gradient(180deg, rgba(255,255,255,0.98) 0%, rgba(246,249,249,0.98) 100%)',
            border: '1px solid rgba(15, 62, 54, 0.08)',
            boxShadow: '0 10px 30px rgba(15, 62, 54, 0.06)',
          }}
        >
          <Box sx={{ mb: 3, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            <Typography variant="h5" sx={{ fontWeight: 800, color: 'text.primary' }}>
              Bathroom Cleaning Configuration
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 980 }}>
              Set the price and cleaning duration for each supported bathroom count. These settings dynamically govern booking availability, total service duration, and invoice pricing.
            </Typography>
          </Box>

          <Divider sx={{ mb: 3 }} />

          <Grid container spacing={2.5}>
            {fetchedConfigs.map((configItem) => {
              const isSaving = savingCount === configItem.count;
              const isEditing = Boolean(editingState[configItem.count]);
              const editVal = editingState[configItem.count] || {};

              const price = editVal.price !== undefined ? editVal.price : configItem.price;
              const durationMinutes = editVal.durationMinutes !== undefined ? editVal.durationMinutes : configItem.durationMinutes;
              const isActive = editVal.isActive !== undefined ? editVal.isActive : configItem.isActive;
              const errors = editVal.errors || {};

              return (
                <Grid item xs={12} sm={6} xl={3} key={configItem.count}>
                  <Card
                    variant="outlined"
                    sx={{
                      height: '100%',
                      borderRadius: 3,
                      borderColor: isEditing ? 'primary.main' : 'rgba(15, 62, 54, 0.12)',
                      background: isEditing
                        ? 'linear-gradient(180deg, rgba(16, 185, 129, 0.04), rgba(255,255,255,1))'
                        : 'rgba(255,255,255,0.75)',
                      boxShadow: isEditing ? '0 8px 24px rgba(15, 62, 54, 0.08)' : '0 2px 10px rgba(15, 62, 54, 0.03)',
                      transition: 'all 0.2s ease-in-out',
                      '&:hover': {
                        borderColor: 'rgba(15, 62, 54, 0.22)',
                        transform: 'translateY(-1px)',
                      },
                    }}
                  >
                    <CardContent sx={{ p: { xs: 2.25, sm: 2.5 }, '&:last-child': { pb: { xs: 2.25, sm: 2.5 } } }}>
                      <Stack spacing={2.25}>
                        <Stack direction="row" justifyContent="space-between" alignItems="center" spacing={1}>
                          <Stack direction="row" spacing={1.25} alignItems="center">
                            <Box
                              sx={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 42,
                                height: 42,
                                borderRadius: 2,
                                background: 'rgba(15, 118, 110, 0.10)',
                                color: 'primary.main',
                              }}
                            >
                              <BathtubOutlinedIcon fontSize="medium" />
                            </Box>
                            <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.2 }}>
                              {configItem.count}
                            </Typography>
                            <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary' }}>
                              {configItem.count === 1 ? 'Bathroom' : 'Bathrooms'}
                            </Typography>
                          </Stack>

                          <FormControlLabel
                            control={
                              <Switch
                                size="small"
                                checked={isActive}
                                disabled={!isEditing || isSaving}
                                onChange={(e) => handleChange(configItem.count, 'isActive', e.target.checked)}
                                sx={{
                                  '& .MuiSwitch-switchBase.Mui-checked': {
                                    color: '#1F8F7A',
                                  },
                                  '& .MuiSwitch-track': {
                                    backgroundColor: 'rgba(15, 118, 110, 0.2)',
                                  },
                                }}
                              />
                            }
                            label={isActive ? 'Act' : 'Inact'}
                            sx={{ m: 0, '& .MuiFormControlLabel-label': { fontSize: 12, color: 'text.secondary' } }}
                          />
                        </Stack>

                        <Divider sx={{ borderColor: 'rgba(15,62,54,0.10)' }} />

                        <TextField
                          label="Cleaning Price"
                          type="number"
                          size="small"
                          fullWidth
                          disabled={!isEditing || isSaving}
                          value={price}
                          onChange={(e) => handleChange(configItem.count, 'price', e.target.value)}
                          error={Boolean(errors?.price)}
                          helperText={errors?.price}
                          InputProps={{
                            startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                          }}
                          sx={{
                            '& .MuiOutlinedInput-root': {
                              borderRadius: 2,
                              backgroundColor: 'rgba(15, 62, 54, 0.02)',
                            },
                          }}
                        />

                        <TextField
                          label="Cleaning Duration"
                          type="number"
                          size="small"
                          fullWidth
                          disabled={!isEditing || isSaving}
                          value={durationMinutes}
                          onChange={(e) => handleChange(configItem.count, 'durationMinutes', e.target.value)}
                          error={Boolean(errors?.durationMinutes)}
                          helperText={errors?.durationMinutes}
                          InputProps={{
                            endAdornment: <InputAdornment position="end">mins</InputAdornment>,
                            startAdornment: (
                              <InputAdornment position="start">
                                <AccessTimeOutlinedIcon fontSize="small" />
                              </InputAdornment>
                            ),
                          }}
                          sx={{
                            '& .MuiOutlinedInput-root': {
                              borderRadius: 2,
                              backgroundColor: 'rgba(15, 62, 54, 0.02)',
                            },
                          }}
                        />

                        <Box sx={{ pt: 0.5 }}>
                          {!isEditing ? (
                            <Button
                              variant="outlined"
                              fullWidth
                              startIcon={<EditIcon />}
                              onClick={() => handleEdit(configItem)}
                              sx={{
                                borderRadius: 2,
                                py: 1.1,
                                fontWeight: 700,
                                borderColor: 'rgba(15, 118, 110, 0.6)',
                                color: 'primary.main',
                                backgroundColor: 'rgba(15, 118, 110, 0.03)',
                                '&:hover': {
                                  backgroundColor: 'rgba(15, 118, 110, 0.08)',
                                  borderColor: 'primary.main',
                                },
                              }}
                            >
                              Edit Pricing
                            </Button>
                          ) : (
                            <Stack direction="row" spacing={1}>
                              <Button
                                variant="contained"
                                fullWidth
                                color="primary"
                                startIcon={
                                  isSaving ? <CircularProgress size={16} color="inherit" /> : <SaveIcon />
                                }
                                disabled={isSaving}
                                onClick={() => handleSave(configItem)}
                                sx={{
                                  borderRadius: 2,
                                  py: 1.1,
                                  fontWeight: 700,
                                }}
                              >
                                {isSaving ? 'Saving' : 'Save'}
                              </Button>
                              <Button
                                variant="outlined"
                                color="inherit"
                                disabled={isSaving}
                                onClick={() => handleCancel(configItem.count)}
                                sx={{
                                  borderRadius: 2,
                                  px: 1.5,
                                  minWidth: 88,
                                }}
                              >
                                Cancel
                              </Button>
                            </Stack>
                          )}
                        </Box>
                      </Stack>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}
          </Grid>
        </Paper>
      )}
    </Stack>
  );
}
