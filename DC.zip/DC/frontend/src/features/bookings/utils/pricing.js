import dayjs from "dayjs";

export function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function quotePricing({
  planId,
  frequencyId,
  bathrooms,
  discount = 0,
  planOptions = [],
  frequencyOptions = [],
}) {
  const plan = (planOptions || []).find((p) => p.id === planId);
  const frequency = (frequencyOptions || []).find((f) => f.id === frequencyId);

  if (!plan || !frequency || !bathrooms) return null;

  const bathroomCount = Number(bathrooms);

  if (!Number.isFinite(bathroomCount) || bathroomCount <= 0) {
    throw new Error("Invalid bathroom count selected for pricing.");
  }

  const configuredPrice = plan.pricePerServiceByBathroom?.[bathroomCount];

  if (
    configuredPrice == null ||
    configuredPrice === "" ||
    !Number.isFinite(Number(configuredPrice)) ||
    Number(configuredPrice) < 0
  ) {
    throw new Error(
      `No active pricing configuration found for ${bathroomCount} bathroom(s). Please configure the pricing in Settings.`,
    );
  }

  const pricePerService = Number(configuredPrice);

  const numServices = Math.max(
    1,
    (plan.termMonths || 1) * (frequency.visitsPerMonth || 1),
  );

  const serviceCharges = round2(pricePerService * numServices);
  const taxableAmount = round2(serviceCharges);

  const cgstAmount = round2(taxableAmount * 0.09);
  const sgstAmount = round2(taxableAmount * 0.09);
  const grossBeforeDiscount = round2(taxableAmount + cgstAmount + sgstAmount);
  const authorizedDiscount = round2(
    Math.min(discount || 0, grossBeforeDiscount),
  );

  const taxes = [
    {
      id: "CGST",
      label: "CGST",
      rate: 0.09,
      amount: cgstAmount,
    },
    {
      id: "SGST",
      label: "SGST",
      rate: 0.09,
      amount: sgstAmount,
    },
  ];

  const taxTotal = round2(taxes.reduce((s, t) => s + t.amount, 0));
  const total = round2(grossBeforeDiscount - authorizedDiscount);

  return {
    plan,
    frequency,
    bathroomCount,
    pricePerService,
    numServices,
    serviceCharges,
    authorizedDiscount,
    taxableAmount,
    taxes,
    taxTotal,
    total,
    effectiveDate: dayjs().format("YYYY-MM-DD"),
  };
}
